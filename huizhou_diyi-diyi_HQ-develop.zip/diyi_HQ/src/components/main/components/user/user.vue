<template>
  <div class="user-avator-dropdown">
    <Dropdown @on-click="handleClick">
      <!-- <Avatar :src="userAvator"/> -->
      <span>{{realname}}</span>
      <Icon :size="18" type="md-arrow-dropdown"></Icon>
      <DropdownMenu slot="list">
        <DropdownItem name="baseInfo">基本信息</DropdownItem>
        <DropdownItem name="showModifyPwd">修改密码</DropdownItem>
        <DropdownItem name="logout">退出登录</DropdownItem>
      </DropdownMenu>
    </Dropdown>
    <!-- base info -->
    <Modal
        v-model="showBaseInfo"
        title="基本信息"
        >
        <Row class="base-info-row">
          <Col span="6"><div class="base-info-col1">账号：</div></Col>
          <Col span="16"><div class="base-info-col2">{{baseInfo.account}}</div></Col>
        </Row>
        <Row class="base-info-row">
          <Col span="6"><div class="base-info-col1">姓名：</div></Col>
          <Col span="16"><div class="base-info-col2">{{baseInfo.realname}}</div></Col>
        </Row>
        <Row class="base-info-row">
          <Col span="6"><div class="base-info-col1">角色名：</div></Col>
          <Col span="16"><div class="base-info-col2">{{baseInfo.roleName}}</div></Col>
        </Row>
        <Row class="base-info-row">
          <Col span="6"><div class="base-info-col1">最后一次登录时间：</div></Col>
          <Col span="16"><div class="base-info-col2">{{baseInfo.lastLoginTime}}</div></Col>
        </Row>
    </Modal>
    <!-- modify pwd -->
    <Modal
        v-model="showModifyPwd"
        title="修改密码"
        >
        <Form ref="modifyPwd" :model="ModifyPwdData">
          <FormItem prop="rate">
            <Row class="form-row">
              <Col span="6"><div class="col1">当前密码：</div></Col>
              <Col span="16"><Input v-model="ModifyPwdData.oldPwd" placeholder="请输入当前密码，初始密码为123456"></Input> </Col>
            </Row>
            <Row class="form-row">
              <Col span="6"><div class="col1">新密码：</div></Col>
              <Col span="16"><Input v-model="ModifyPwdData.newPwd" placeholder="密码长度为6到32位"></Input> </Col>
            </Row>
            <Row class="form-row">
              <Col span="6"><div class="col1">确认密码：</div></Col>
              <Col span="16"><Input v-model="ModifyPwdData.reNewPwd" placeholder="确认密码和新密码保持一致"></Input> </Col>
            </Row>
          </formItem>
        </Form>
        <div slot="footer">
          <Button type="text" size="large" @click="resetModifyPwdData(); showModifyPwd=false">取消</Button>
          <Button type="primary" size="large" @click="modifyPwd">确定</Button>
        </div>
    </Modal>
  </div>
</template>

<script>
import './user.less'
import { modifyPwd } from '@/api/user'
import { getToken } from '@/libs/util'
import { getDate } from '@/libs/tools'
import { mapActions } from 'vuex'
export default {
  name: 'User',
  props: {
    userAvator: {
      type: String,
      default: ''
    },
    realname: {
      type: String,
      default: '管理员'
    }
  },
  data () {
    return {
      showModifyPwd: false,
      showBaseInfo: false,
      ModifyPwdData: {
        oldPwd: '',
        newPwd: '',
        reNewPwd: ''
      },
      baseInfo: {
        account: '',
        realname: '',
        roleName: '',
        lastLoginTime: ''
      }
    }
  },
  methods: {
    ...mapActions([
      'handleLogOut'
    ]),
    handleClick (name) {
      switch (name) {
        case 'baseInfo':
          this.showBaseInfo = true
          break
        case 'logout':
          this.handleLogOut().then(res => {
            if (res.code > 0) {
              this.$router.push({
                name: 'login'
              })
            } else {
              this.$Message.info(res.data.message)
            }
          })
          break
        case 'showModifyPwd':
          this.showModifyPwd = true
          break
      }
    },
    resetModifyPwdData () {
      let keys = Object.keys(this.ModifyPwdData)
      if (keys.length > 0) {
        keys.forEach(key => {
          this.ModifyPwdData[key] = ''
        })
      }
    },
    modifyPwd () {
      if (this.ModifyPwdData.oldPwd.length < 6 || this.ModifyPwdData.oldPwd.length > 25) this.$Message.info('旧密码不正确')
      else if (this.ModifyPwdData.newPwd.length < 6 || this.ModifyPwdData.newPwd.length > 25) this.$Message.info('新密码长度应为6~25位')
      else if (this.ModifyPwdData.reNewPwd.length < 6 || this.ModifyPwdData.oldPwd.length > 25) this.$Message.info('重复密码应长度为6~25位')
      else if (this.ModifyPwdData.newPwd != this.ModifyPwdData.reNewPwd) this.$Message.info('重复密码不一致~25位')
      else {
        let data = {
          oldpwd: this.ModifyPwdData.oldPwd,
          pwd: this.ModifyPwdData.newPwd,
          repwd: this.ModifyPwdData.reNewPwd,
          //
        }
        modifyPwd(data)
          .then((res) => {
            if (res.data.code > 0) {
              this.showModifyPwd = false
              this.$Message.info(res.data.message + ', 请重新登录')
              this.handleLogOut().then(() => {
                this.$router.push({
                  name: 'login'
                })
              })
            } else {
              this.$Message.info(res.data.message)
            }
          })
          .catch(err => {
          })
      }
    }
  },
  mounted () {
    this.baseInfo.account = this.$store.state.user.adminInfo.account
    this.baseInfo.realname = this.$store.state.user.adminInfo.realname
    this.baseInfo.roleName = this.$store.state.user.adminInfo.role_name
    this.baseInfo.lastLoginTime = this.$store.state.user.adminInfo.last_login_time
  }
}
</script>
