import SideMenu from './side-menu.vue'
export default SideMenu
