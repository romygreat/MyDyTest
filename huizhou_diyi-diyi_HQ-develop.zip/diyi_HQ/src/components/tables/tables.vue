<template>
    <div>
        <Table :columns="columns1" :data="roledata"></Table>
        <br>
        <!-- <Switch v-model="loading"></Switch> -->
    </div>
</template>
<script>
    export default {
        data () {
            return {
                // loading: true,
                columns1: [
                    {
                        title: 'ID',
                        key: 'id'
                    },
                    {
                        title: '父级',
                        key: 'pid'
                    },
                    {
                        title: '名称',
                        key: 'name'
                    },
                ],
                roledata: [
                    {
                        id: '1',
                        pid: '0',
                        name: '超级管理员',
                        children: [
                          {
                            id: '6',
                            pid: '1',
                            name: '测试出',
                          },
                          {
                            id: '5',
                            pid: '1',
                            name: '测试组',
                          },
                          {
                            id: '2',
                            pid: '1',
                            name: '二级管理员',
                            children:[
                              {
                                id: '3',
                                pid: '2',
                                name: '客服',
                              }
                            ]
                          },
                        ]
                    },
                ]
            }
        }
    }
</script>
