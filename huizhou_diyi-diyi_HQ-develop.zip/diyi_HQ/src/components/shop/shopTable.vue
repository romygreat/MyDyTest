<style scoped>
    .expand-row{
        margin-bottom: 16px;
    }
    .expand-key{
    font-size:14px;
    margin-bottom:10px;
}
.expand-value{
    font-size:14px;
    margin-bottom:20px;
}
</style>
<template>
    <div>
        <Row class="expand-row">
            <Col span="8">
                <span class="expand-key">门店详细地址：</span>
                <span class="expand-value">{{ row.address }}</span>
            </Col>
            <Col span="8">
                <span class="expand-key">代理人：</span>
                <span class="expand-value">{{ row.agent_id }}</span>
            </Col>
            <Col span="8">
                <span class="expand-key">状态：</span>
                <span class="expand-value">{{ row.status }}</span>
            </Col>
            <Col span="8">
                <span class="expand-key">商家评分：</span>
                <span class="expand-value">{{ row.shop_pre }}</span>
            </Col>
            <Col span="8">
                <span class="expand-key">物流评分：</span>
                <span class="expand-value">{{ row.service_pre }}</span>
            </Col>
            <Col span="8">
                <span class="expand-key">申请时间：</span>
                <span class="expand-value">{{ row.create_time }}</span>
            </Col>
            <Col span="8">
                <span class="expand-key">营业执照：</span>
                <span class="expand-value">{{ row.licences }}</span>
            </Col>
            <Col span="8">
                <span class="expand-key">身份证号：</span>
                <span class="expand-value">{{ row.card_no }}</span>
            </Col>
            <Col span="8">
                <span class="expand-key">更新时间：</span>
                <span class="expand-value">{{ row.update_time }}</span>
            </Col>
            <Col span="8">
                <span class="expand-key">删除时间：</span>
                <span class="expand-value">{{ row.delete_time }}</span>
            </Col>
            <Col span="24">
                <span class="expand-key">门店简介：</span>
                <span class="expand-value">{{ row.description }}</span>
            </Col>
        </Row>
    </div>
</template>
<script>
export default {
  props: {
    row: Object
  }
}
</script>
