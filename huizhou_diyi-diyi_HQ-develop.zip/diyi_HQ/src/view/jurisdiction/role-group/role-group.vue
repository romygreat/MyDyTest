<template>
    <div>
        <p class="adminTitle" >角色列表</p>
        <!-- add admin buttom -->
        <Button class="m20" type="primary" @click="showEdit('add')" >添加角色</Button>
        <!-- role search -->
        <div class="inline-div" >
           <p  class="inline-div search-title" >名称查询： </p>
           <Input clearable  v-model="requestParam.name"  icon="search"   placeholder="输入你要查询的角色组名称"  style="width: 200px; display: inline-block" />
           <Button  style="display: inline-block; margin:0 0 0 15px;  "  type="primary" @click="handleSearch" >查询</Button>
        </div>
        <!-- role tables -->
        <Table border :total="Number(pageTotal)" :columns="columns7" :data="roleTableinfo" stripe  style="width: 552px;"></Table>
        <div style="margin: 10px 0;width: 552px;text-align: right;">
            <Page
              :total="Number(pageTotal)"
              show-elevator
              @on-change='handlePage'
              >
            </Page>
        </div>
        <!-- edit role -->
         <Modal
            v-model="isShowEdit"
            :title="editTitle"
            >
            <Row style="line-height: 44px;">
              <Col style="text-align:right;" span="4">角色名称：</Col>
              <Col span="16">
                <Input
                  :maxlength=10
                  v-model="editRoleInfo.name"
                  placeholder="输入角色名称(名称不能超过10个字)"
                  style="width: 300px; margin: 10px 0; " />
              </Col>
            </Row>
            <Row style="line-height: 44px;">
              <Col style="text-align:right;" span="4">菜单权限</Col>
              <Col span="8">：</Col>
              <Col span="8">操作权限：</Col>
            </Row>
            <Row>
              <Col style="margin-left:40px;" span="8">
                <Tree :data="allMenuTree"  show-checkbox></Tree>
              </Col>
              <Col style="margin-left:50px;" span="8">
                <Tree :data="allPermissionTree" show-checkbox></Tree>
              </Col>
            </Row>
            <div>

            </div>

            <div slot="footer">
              <Button type="text" size="large" @click="isShowEdit = false">取消</Button>
              <Button type="primary" size="large" @click="saveRoleInfo">确定</Button>
            </div>
        </Modal>
    </div>
</template>
<script>
import routers from '@/router/routers'
import { getToken, getAllMenuByRouter, setCheckedTree, getCheckedTree, MellsetCheckedTree, cloneArray } from '@/libs/util'
import { delRoleButtom, getRoleTablesButtom, saveRoleInfo, listPermission } from '@/api/data'
export default {
  data () {
    return {
      roleTableinfo: [],
      columns7: [
        {
          title: 'ID',
          key: 'id',
          width: 110,
          align: 'center',
          sortable: true,
          render: (h, params) => {
            return h('div', [h('strong', params.row.id)])
          }
        },
        {
          title: '名称',
          key: 'name',
          width: 260,
          align: 'center'
        },
        // 操作事件
        {
          title: '编辑',
          key: 'action',
          width: 180,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.showEdit('edit', params.index)
                    }
                  }
                },
                '修改'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      isShowEdit: false,
      editTitle: '',
      editRoleInfo: {},
      pageTotal: '',
      requestParam: {
        //,
        name: '',
        page: '1',
        rows: '10',
        sort: { id: 'desc' }
      },
      allMenuTree: [
        {
          title: '全部',
          expand: true,
          selected: true,
          children: []
        }
      ],
      allPermissionTree: [
        {
          title: '全部',
          expand: true,
          selected: true,
          children: []
        }
      ]
    }
  },
  methods: {
    showEdit (type, index) {
      if (type == 'add') {
        this.editRoleInfo.name = ''
        this.editTitle = '添加角色信息'
        this.allMenuTree = setCheckedTree(cloneArray(this.allMenuTree), [])
        this.allPermissionTree = setCheckedTree(cloneArray(this.allPermissionTree), [])
      } else if (type == 'edit') {
        this.editTitle = '修改角色信息'
        this.editRoleInfo = Object.assign({}, this.roleTableinfo[index])

        let menus = this.editRoleInfo.menu_set.split(',')
        this.allMenuTree = setCheckedTree(cloneArray(this.allMenuTree), menus)

        let permissions = this.editRoleInfo.permission_set.split(',')
        this.allPermissionTree = MellsetCheckedTree(cloneArray(this.allPermissionTree), permissions)
      }

      // 重置问题
      this.$set(this.allMenuTree[0], 'expand', false)
      this.$set(this.allPermissionTree[0], 'expand', false)
      this.allMenuTree[0].expand = false
      this.allPermissionTree[0].expand = false
      this.isShowEdit = true
    },
    remove (index) {
      this.$Modal.confirm({
        title: '删除角色组',
        content: '<p>你正在进行操作！确认要删除吗？</p>',
        onOk: () => {
          const delRoleinfo = {
            //,
            id: this.roleTableinfo[index].id
          }
          delRoleButtom(delRoleinfo)
            .then(response => {
              this.$Message.info(response.data.message)
              this.getRoleTables()
            })
            .catch(error => {
              this.$Message.info(error)
            })
        },
        onCancel: () => {
          this.$Message.info('取消了删除操作')
        }
      })
    },
    // 获取分页
    handlePage (value) {
      this.requestParam.page = value
      this.getRoleTables()
    },
    getRoleTables () {
      getRoleTablesButtom(this.requestParam).then(response => {
        this.roleTableinfo = response.data.data.list
        this.pageTotal = Number(response.data.data.total)
      }).catch(error => {
        console.error(error)
      })
    },
    // 修改角色组名称
    saveRoleInfo () {
      if (!this.editRoleInfo.name) {
        this.$Message.info({
          content: '请输入角色名称'
        })
        return false
      }
      const menuSet = getCheckedTree(this.allMenuTree[0].children).join(',')
      if (!menuSet) {
        this.$Message.info({
          content: '请选择菜单权限'
        })
        return false
      }
      const permissionSet = getCheckedTree(this.allPermissionTree[0].children).join(',')
      if (!permissionSet) {
        this.$Message.info({
          content: '请选择操作权限'
        })
        return false
      }
      this.editRoleInfo.menu_set = menuSet
      this.editRoleInfo.permission_set = permissionSet
      saveRoleInfo(this.editRoleInfo).then((res) => {
        if (res.data.code == 1) {
          this.$Message.info({
            content: res.data.message,
            duration: 10,
            closable: true
          })
          this.getRoleTables()
          this.isShowEdit = false
        }
      }).catch(error => {
        console.error(error)
      })
    },
    // 搜索角色组
    handleSearch () {
      this.getRoleTables()
    },
    getAllMenuByRouter () {
      this.allMenuTree[0].children = getAllMenuByRouter(routers, this.$store.state.user.access)
    },
    getAllPermissionTree () {
      let param = {
        //,
        level_id: 1,
        is_tree: 1
      }
      listPermission(param).then(res => {
        console.log('permission list:', res)
        if (res.data.code == 1) {
          this.allPermissionTree[0].children = res.data.data
        }
      }).catch(err => {
        console.error(err)
      })
    }
  },
  mounted () {
    this.getRoleTables()
    this.getAllMenuByRouter()
    this.getAllPermissionTree()
  }
}
</script>
<style>
.adminTitle{
  font-size: 18px;
  font-weight: bold;
}
.m20{
  margin: 20px 0;
}
.inline-div{
  display: inline-block;
  margin: 0 10px;
}
.search-title{
  font-size: 14px;
}
</style>
