import printerMenu from './printerMenu.vue'
export default printerMenu