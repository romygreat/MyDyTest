<!--
 * @Author: 叶锦荣
 * @Date: 2019-11-23 08:43:29
 * @LastEditTime: 2019-11-23 10:27:46
 -->
<template>
  <div>
    <h3 class="titleH3" >打印机厂商列表</h3>
    <div class="searchBox" >
        <Button @click="openList('add')" type="primary">添加打印机厂商</Button>
        <h3>厂商名称：</h3>
        <Input v-model="resparam.name" placeholder="请输入打印机厂商名" style="width: 300px" />
        <Button style="margin-left:10px" @click="setPrinterMenu()" type="primary">搜索</Button>
    </div>
    <section class="tables" >
        <Table :width='600' :columns="columns" :data="list" />
        <div class="page" >
            <Page  @on-change='setPrinterMenu' :current='resparam.page' :page-size='resparam.rows'  :total="resparam.total" />
        </div>
    </section>
    <!-- edit && add -->
    <Modal
        v-model="moalShow"
        :title="moalTital"
        :footer-hide='true'
      >
      <div class="printerEdit" >
        <dl>
          <dt>厂商名称：</dt>
          <dd><Input v-model="openData.name" placeholder="请输入打印机厂商名" style="width: 300px" /></dd>
        </dl>
        <dl>
          <dt>用户名:</dt>
          <dd><Input v-model="openData.user" placeholder="请输入打印用户名" style="width: 300px" /></dd>
        </dl>
        <dl>
          <dt>用户键:</dt>
          <dd><Input v-model="openData.ukey" placeholder="请输入打印机用户键" style="width: 300px" /></dd>
        </dl>
        <div class="bottom" >
            <Button @click="openList('edit',openData)"  style="margin-right:10px"  type="primary">确认</Button>
            <Button @click="moalShow=false" >取消</Button>
        </div>
      </div>
    </Modal>
  </div>
</template>
<script>
import { printerManuList,deleteManuApi,saveManu } from '@/api/printer'
export default {
  data() {
    return {
      moalShow:false,
      resparam: {
        rows: 10,
        page: 1,
        total:0,
        name:''
      },
      list:[],
      columns:[
        {title:'厂商名称',key:'name'},
        {title:'用户名',key:'user'},
        {title:'用户键',key:'ukey'},
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.openData = JSON.parse(JSON.stringify(params.row))
                      this.openList('edit')
                    }
                  }
                },
                '编辑'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.toPrinterDelete(params.row.id)
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      openData:{},
      moalTital:'添加打印机厂商'
    }
  },
  methods: {
    /**
     *  @descriptio 获取打印机厂商列表
     */
    async setPrinterMenu(v) {
      if(v) this.resparam.page = v
      else this.resparam.page = 1
      let res = await printerManuList(this.resparam)
      this.list = res.data.data.list
      this.resparam.total = res.data.data.total
    },
    /** 
     * @description 删除打印机
     */
    toPrinterDelete(ids) {
      this.$Modal.confirm({
        title: '删除',
        content: '确认删除打印机吗？注意！删除后不可恢复',
        onOk: () => {
          const data = {
            id: ids
          }
         deleteManuApi(data).then(res => {
            if(res.data.code === 1) {
              this.$Message.info('删除成功')
            } else {
              this.$Message.info('删除失败')
            }
             this.setPrinterMenu()
          })
        },
        onCancel: () => {
          this.$Message.info('取消了删除操作')
        }
      })
    },
    /** 
     * @description 添加 || 编辑
     */
    async openList(type,data){
      if(data) {
        if( (!data.name   || !data.user  || !data.ukey) || (data.name == '' || data.user == '' || data.ukey == '' )) {
          this.$Message.error('当前填写的信息不得为空')
          return
        }
        let res = await saveManu(data)
        if(res.data.code == 1) {
          this.$Message.info(  this.moalTital ='添加打印机厂商' ? '添加成功' : '修改成功' )
        } else {
          this.$Message.error(  this.moalTital ='添加打印机厂商' ? '添加失败' : '修改失败' )
        }
        this.setPrinterMenu()
        this.moalShow = false
        return
      }


      if(type === 'add') {
        this.openData = {}
        this.moalShow = true
        this.moalTital ='添加打印机厂商'
      } else {
        this.moalShow = true
        this.moalTital ='修改打印机厂商'
      }
    }
  },
  mounted() {
    this.setPrinterMenu()
  }
}
</script>
<style lang='less' scoped>
@import url('./printerMenu.less');
</style>
<style lang="less">
  .printerEdit {
    > dl {
        margin: 10px 0;
        display: block;
        > dt {
            width: 80px;
            display: inline-block;
        }
        > dd {
           width: 250px;
          display: inline-block;
        }
    }
    .bottom {
        margin-top: 20px;
        display: block;
        text-align: left;
    }
}
</style>