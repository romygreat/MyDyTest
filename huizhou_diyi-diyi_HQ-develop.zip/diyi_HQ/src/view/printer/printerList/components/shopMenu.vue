<template>
  <div style="width:300px">
    <div>
      <Select
        @on-query-change="remotenull"
        @on-change="sdkinfo"
        v-model="selectinfo"
        filterable
        remote
        :remote-method="remoteMethod2"
        :loading="loading2"
      >
        <Option
          v-for="(option, index) in options2"
          :value="option.value"
          :key="index"
        >{{option.label}}</Option>
      </Select>
    </div>
  </div>
</template>

<script>
import { getShopTablesButtom } from '@/api/data'
export default {
  props: ['shop_id'],
  data() {
    return {
      selectinfo: [],
      loading2: false,
      options2: [],
      list: [],
      resselect: []
    }
  },
  methods: {
    async getCateProduct() {
      const data = {}
      await getShopTablesButtom(data).then(res => {
        this.list = JSON.parse(JSON.stringify(res.data.data.list))
        
        let listinfo = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        console.log(listinfo);
        
        this.options2 = listinfo
      })
    },
    remoteMethod2(query) {
      if (query !== '') {
        this.loading2 = true
        setTimeout(() => {
          let arrlist = []
          this.loading2 = false
          const data = { name: query }
          getShopTablesButtom(data).then(res => {
            console.log(111,arrlist)
            arrlist = JSON.parse(JSON.stringify(res.data.data.list))
                        console.log(222,arrlist)
            let listinfo = arrlist.map(item => {
              return {
                value: item.id,
                label: item.name
              }
            })
            this.options2 = listinfo.filter(
              item => item.label.toLowerCase().indexOf(query.toLowerCase()) > -1
            )
            this.tovalue()
          })
        }, 200)
      } else {
        this.options2 = []
        this.tovalue()
      }
    },
    sdkinfo(i) {
      const listinfo = this.list.map(item => {
        return {
          value: item.id,
          label: item.name
        }
      })
      this.options2 = listinfo
      this.resselect = []
      let arr = JSON.parse(JSON.stringify(this.selectinfo))
      for (let i in arr) {
        this.resselect[i] = { label_id: arr[i] }
      }
      this.tovalue()
    },
    remotenull(v) {
      if (v === '') {
        const listinfo = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        this.options2 = listinfo
        
        this.tovalue()
      }
    },
    tovalue() {
      //  The world! 時間よ、止まって。!!!
      console.log('時間よ、止まって。!!!', this.selectinfo)
      this.$emit('garShop', this.selectinfo)
     }
  },
  async mounted() {
    await this.getCateProduct()
      if (this.shop_id && this.shop_id != '') {
        this.list.forEach(el => {
          console.log(el.id,'duib',this.shop_id)
        if(el.id == this.shop_id) {
          this.selectinfo = this.shop_id
        }
        })
      }
  }
}
</script>

<style>
</style>