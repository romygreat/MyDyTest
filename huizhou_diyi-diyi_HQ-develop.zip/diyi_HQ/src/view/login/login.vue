<!--
 * @Author: 叶锦荣
 * @Date: 2018-11-19 21:07:35
 * @LastEditTime: 2019-11-22 16:38:20
 -->
<style lang="less">
  @import './login.less';
</style>

<template>
  <div class="login">
    <div class="login-con">
      <Card icon="log-in" title="欢迎登录" :bordered="false">
        <div class="form-con">
          <login-form @on-success-valid="handleSubmit"></login-form>
        </div>
      </Card>
    </div>
  </div>
</template>

<script>
import LoginForm from '_c/login-form'
import { mapActions } from 'vuex'
import {  getStatus } from '@/api/data'
import {setStautsText} from '@/libs/tools'
export default {
  components: {
    LoginForm
  },
  methods: {
    ...mapActions([
      'handleLogin',
      'getUserInfo'
    ]),
    // 登陆事件
    handleSubmit ({ userName, password }) {
      this.handleLogin({ userName, password }).then(res => {
        if (res.code > 0) {
          getStatus({}).then(resinfo => {
            setStautsText(resinfo.data.data)
            this.$router.push({
              name: this.$config.homeName
            })
          })
        }else {
          this.$Message.info(res.message)
        }
      })
    }
  }
}
</script>

<style>

</style>
