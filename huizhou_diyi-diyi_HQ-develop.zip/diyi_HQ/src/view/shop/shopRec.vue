<template>
  <div>
    <p class="adminTitle">店铺回收站</p>
    <div class="inline-div">
      <p class="inline-div search-title">店铺查询：</p>
      <Input
        clearable
        v-model="requestParam.name"
        icon="search"
        placeholder="输入你要查询的店铺名称"
        style="width: 200px; display: inline-block"
      />
      <p class="inline-div search-title">电话查询：</p>
      <Input
        clearable
        v-model="requestParam.phone"
        icon="search"
        placeholder="输入你要查询的电话号码"
        style="width: 200px; display: inline-block"
      />
      <p class="inline-div search-title">联系人查询：</p>
      <Input
        clearable
        v-model="requestParam.realname"
        icon="search"
        placeholder="输入你要查询的联系人姓名"
        style="width: 200px; display: inline-block"
      />
      <Button
        style="display: inline-block; margin:10px 0 10px 10px;  "
        @click="handleSearch"
        type="primary"
      >查询</Button>
    </div>
    <Table
      style="width: 992px;"
      :columns="columns"
      :data="recData"
      border
      @on-selection-change="selectIndex"
    ></Table>
    <Button style="float:left; margin:10px 10px 0 0; " @click="batchReduc" type="primary">批量还原</Button>
    <Button style="float:left; margin:10px 0; " type="error" @click="batchDel">批量删除</Button>
    <div style="margin: 10px 0;width: 992px;">
      <Page style="float: right;" :total="Number(pageTotal)" @on-change="handlePage" show-total></Page>
    </div>
  </div>
</template>

<script>
import {
  deleteShopTablesButtom,
  reductionShopButtom,
  getShopTablesButtom
} from '@/api/data'
import { getToken } from '@/libs/util'
export default {
  data() {
    return {
      columns: [
        {
          type: 'selection',
          width: 50,
          align: 'center'
        },
        {
          title: 'ID',
          key: 'id',
          width: 70,
          align: 'center',
          sortable: true,
          render: (h, params) => {
            return h('div', [h('strong', params.row.id)])
          }
        },
        {
          title: '店铺名称',
          key: 'name',
          width: 220,
          align: 'center'
        },
        {
          title: '店铺所在地区',
          key: 'prov_name',
          width: 200,
          align: 'center',
          render: (h, params) => {
            let arr = []
            if (params.row.prov_name) arr.push(params.row.prov_name)
            if (params.row.city_name) arr.push(params.row.city_name)
            if (params.row.zone_name) arr.push(params.row.zone_name)
            return h('div', arr.join('-'))
          }
        },
        {
          title: '联系人',
          width: 150,
          align: 'center',
          key: 'realname'
        },
        {
          title: '电话',
          width: 150,
          align: 'center',
          key: 'phone'
        },
        {
          title: '编辑',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.show(params.index)
                    }
                  }
                },
                '还原'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                    }
                  }
                },
                '彻底删除'
              )
            ])
          }
        }
      ],
      recData: [],
      requestParam: {
        title: '',
        page: 1,
        rows: 10,
        trashed: 1,
        sort: { id: 'desc' }
      },
      pageTotal: 0,
      selectIds: []
    }
  },
  methods: {
    show(index) {
      this.$Modal.confirm({
        title: '还原店铺',
        content: '<p>确认还原店铺？</p>',
        onOk: () => {
          const reductionShopinfo = {
            //,
            id: this.recData[index].id
          }
          reductionShopButtom(reductionShopinfo)
            .then(response => {
              this.$Message.info('已经还原了店铺')
              this.getShopTables()
            })
            .catch(error => {
              this.$Message.info(error)
            })
        },
        onCancel: () => {
          this.$Message.info('取消了还原操作')
        }
      })
    },
    remove(index) {
      this.$Modal.confirm({
        title: '彻底删除',
        content: '<p>确认彻底删除？</p>',
        onOk: () => {
          const tdeleteShopTablesinfo = {
            //,
            id: this.recData[index].id,
            del: 1
          }
          deleteShopTablesButtom(tdeleteShopTablesinfo).then(response => {
            this.getShopTables()
          })
          this.$Message.info('已经彻底删除')
        },
        onCancel: () => {
          this.$Message.info('取消了彻底删除操作')
        }
      })
    },
    handlePage(value) {
      this.requestParam.page = value
      this.getShopTables()
    },
    handleSearch() {
      this.getShopTables()
    },
    getShopTables() {
      getShopTablesButtom(this.requestParam)
        .then(response => {
          this.recData = response.data.data.list
          this.pageTotal = Number(response.data.data.total)
        })
        .catch(error => {})
    },
    // 勾选时获取已勾选的数据的ID
    selectIndex(selection) {
      this.selectIds = []
      selection.forEach(item => {
        this.selectIds.push(item.id)
      })
    },
    batchReduc() {
      if (this.selectIds.length === 0) {
        this.$Message.info('请选择要还原的店铺信息')
        return false
      }
      this.$Modal.confirm({
        title: '还原店铺',
        content: '<p>确认还原店铺？</p>',
        onOk: () => {
          let data = {
            id: this.selectIds.join(',')
          }
          reductionShopButtom(data)
            .then(response => {
              this.$Message.info(response.data.message)
              this.getShopTables()
            })
            .catch(error => {
              this.$Message.info(error)
            })
        },
        onCancel: () => {
          this.$Message.info('取消了还原操作')
        }
      })
    },
    batchDel() {
      if (this.selectIds.length === 0) {
        this.$Message.info('请选择要还原的店铺信息')
        return false
      }
      this.$Modal.confirm({
        title: '彻底删除',
        content: '<p>确认彻底删除？</p>',
        onOk: () => {
          let data = {
            id: this.selectIds.join(','),
            del: 1
          }
          deleteShopTablesButtom(data).then(response => {
            this.$Message.info(response.data.message)
            this.getShopTables()
          })
          this.$Message.info('已经彻底删除')
        },
        onCancel: () => {
          this.$Message.info('取消了彻底删除操作')
        }
      })
    }
  },
  mounted() {
    this.getShopTables()
  }
}
</script>

<style>
.inline-div{
    display: inline-block;
    margin: 0 10px;
  }
</style>
