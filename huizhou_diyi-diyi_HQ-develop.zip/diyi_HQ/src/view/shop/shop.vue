<template>
  <div>
    <p class="adminTitle">店铺管理列表</p>
    <!-- add admin buttom -->
    <Button class="m20" type="primary" @click="showAddForm">添加店铺</Button>
    <div class="inline-div">
      <p class="inline-div search-title">店铺名称</p>
      <Input
        clearable
        v-model="requestParam.name"
        icon="search"
        placeholder="请输入店铺名称"
        style="width: 200px; display: inline-block;margin-right: 15px;"
      />

      <p class="inline-div search-title">电话</p>
      <Input
        clearable
        v-model="requestParam.phone"
        icon="search"
        placeholder="请输入电话号码"
        style="width: 200px; display: inline-block; margin-right: 15px;"
      />

      <p class="inline-div search-title">联系人</p>
      <Input
        clearable
        v-model="requestParam.realname"
        icon="search"
        placeholder="请输入联系人名称"
        style="width: 200px; display: inline-block;    margin-right: 15px;"
      />

      <Button style="display: inline-block; margin:0;  " @click="handleSearch" type="primary">查询</Button>
    </div>
    <!-- shop tables -->
    <Table :columns="columns" :data="shopList" border style="width: 1302px;"></Table>
    <div style="width: 1302px; margin: 10px 0">
      <Page style="float: right; " :total="Number(pageTotal)" show-total @on-change="handlePage"></Page>
    </div>
    <!-- edit shop -->
    <Modal v-model="isEditShop" :title="editTitle" :footer-hide="true">
      <Form ref="editShopInfo" :model="editShopInfo" :rules="editRuleValidate" :label-width="120">
        <FormItem label="店铺名称" prop="name">
          <Input
            v-model="editShopInfo.name"
            placeholder="请输入店铺名称"
            style="display: inline-block; width:300px; "
          />
        </FormItem>
        <FormItem label="联系人姓名" prop="realname">
          <Input v-model="editShopInfo.realname" placeholder="请输入联系人姓名" style="width: 300px;  " />
        </FormItem>
        <FormItem label="联系人手机号" prop="phone">
          <Input v-model="editShopInfo.phone" placeholder="请输入手机号码" style="width: 300px;  " />
        </FormItem>
        <FormItem class="ivu-form-item-required" label="联系人身份证号" prop="card_no">
          <Input v-model="editShopInfo.card_no" placeholder="请输入身份证号码" style="width: 300px;  " />
        </FormItem>
        <FormItem class="ivu-form-item-required" label="所在地区" prop="cityInfo">
          <Cascader
            :data="cityList"
            v-model="editShopInfo.cityInfo"
            style="display: inline-block; width:300px; "
          ></Cascader>
        </FormItem>
        <FormItem label="详细地址" prop="address">
          <Input v-model="editShopInfo.address" placeholder="请输入门店详细的地址" style="width: 300px;  " />
        </FormItem>
        <FormItem label="营业执照" prop="licences">
          <input type="hidden" v-model="editShopInfo.licences" />
          <img style="max-width:100%" height="80px;" v-if="licencesImg" :src="licencesImg" />
          <Upload
            style="display: inline-block;margin: -100px 0 0 10px;"
            :before-upload="beforeUpload"
            action="/"
          >
            <Button icon="ios-cloud-upload-outline">{{licencesImg?'重新上传':'选择文件'}}</Button>
          </Upload>
          <Progress v-if="percent" :percent="percent" status="active" />
        </FormItem>
        <FormItem label="店铺状态">
          <RadioGroup v-model="editShopInfo.status" type="button">
            <Radio label="1">正常</Radio>
            <Radio label="0">禁用</Radio>
          </RadioGroup>
        </FormItem>
        <FormItem label="店铺介绍" prop="description">
          <Input
            type="textarea"
            v-model="editShopInfo.description"
            placeholder="请输入门店详情"
            style="width: 300px;  "
          />
        </FormItem>
        <FormItem>
          <Button style="margin-right:15px" type="primary" @click="saveShopInfo">保存</Button>
          <Button @click="isEditShop=false">取消</Button>
        </FormItem>
      </Form>
    </Modal>
  </div>
</template>
<script>
import { getToken, checkCardID, setToken } from "@/libs/util";
import { getQnDomain, uploadFile } from "@/libs/upload";
import {
  allCity,
  handleSearchShop,
  assistShopButtom,
  deleteShopTablesButtom,
  addShopTablesButtom,
  getShopTablesButtom
} from "@/api/data";
export default {
  data() {
    return {
      columns: [
        {
          title: "ID",
          key: "id",
          width: 80,
          align: "center",
          sortable: true,
          render: (h, params) => {
            return h("div", [h("strong", params.row.id)]);
          }
        },
        {
          title: "店铺名称",
          key: "name",
          width: 200,
          align: "center",
          tooltip: true,
          className: "shop-active",
          render: (h, params) => {
            return h("div", [
              h(
                "div",
                {
                  style: {
                    width: "100%",
                    height: "100%"
                  },
                  on: {
                    click: () => {
                        window.open(
                          `http://shop.gddiyi.cn`
                        )
                    }
                  }
                },
                params.row.name
              )
            ]);
          }
        },
        {
          title: "店铺所在地区",
          key: "prov_name",
          width: 200,
          align: "center",
          render: (h, params) => {
            let arr = [];
            if (params.row.prov_name) arr.push(params.row.prov_name);
            if (params.row.city_name) arr.push(params.row.city_name);
            if (params.row.zone_name) arr.push(params.row.zone_name);
            return h("div", arr.join("-"));
          }
        },
        {
          title: "详细地址",
          key: "address",
          width: 220,
          align: "center"
        },
        {
          title: "联系人",
          key: "realname",
          width: 120,
          align: "center"
        },
        {
          title: "电话",
          key: "phone",
          width: 120,
          align: "center"
        },
        {
          title: "点餐机数",
          key: "machine_num",
          width: 100,
          align: "center"
        },
        {
          title: "状态",
          key: "status",
          width: 80,
          align: "center",
          render: (h, param) => {
            return h("div", param.row.status == 1 ? "正常" : "禁用");
          }
        },
        {
          title: "编辑",
          key: "action",
          width: 180,
          align: "center",
          render: (h, param) => {
            return h("div", [
              h(
                "Button",
                {
                  props: {
                    type: "primary",
                    size: "small"
                  },
                  style: {
                    marginRight: "5px"
                  },
                  on: {
                    click: () => {
                      this.$router.push({
                        name: "shopMachine",
                        query: {
                          shopId: param.row.id,
                          shopName: param.row.name
                        },
                        meta: {
                          title: `商家设备-${param.row.id}`
                        }
                      });
                    }
                  }
                },
                "设备"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "primary",
                    size: "small"
                  },
                  style: {
                    marginRight: "5px"
                  },
                  on: {
                    click: () => {
                      this.showEditForm(param.index);
                    }
                  }
                },
                "修改"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "error",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.remove(param.index);
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ],
      loading: true,
      shopList: [],
      searchConName: "",
      addShopTables: "",
      cityList: [],
      cityinfoEdit: [],
      // 添加门店data
      addShop: false,
      isEditShop: false,
      editTitle: "",
      requestParam: {
        title: "",
        page: 1,
        rows: 10,
        sort: { id: "desc" }
      },
      pageTotal: 0,
      editShopInfo: {},
      licencesImg: "",
      percent: 0,
      editRuleValidate: {
        name: [{ required: true, message: "标题不能为空", trigger: "blur" }],
        cityInfo: [
          {
            validator: (rule, value, callback) => {
              if (value && value.length > 0) {
                return callback();
              }
              return callback(new Error("请选择店铺所在的地区"));
            },
            trigger: "blur"
          }
        ],
        address: [
          { required: true, message: "详细地址不能为空", trigger: "blur" }
        ],
        phone: [
          { required: true, message: "手机号不能为空", trigger: "blur" },
          {
            type: "string",
            pattern: /^1[3-9]\d{9}$/,
            message: "请输入正确地手机号",
            trigger: "blur"
          }
        ],
        card_no: [
          {
            validator: (rule, value, callback) => {
              if (!value) {
                return callback(new Error("请输入身份证号码"));
              } else if (!checkCardID(value)) {
                return callback(new Error("请输入正确的身份证号码"));
              }
              return callback();
            },
            trigger: "blur"
          }
        ],
        realname: [
          { required: true, message: "姓名不能为空", trigger: "blur" }
        ],
        licences: [
          { required: true, message: "营业执照不能为空", trigger: "blur" }
        ]
      }
    };
  },
  methods: {
    showAddForm() {
      this.editShopInfo = {};
      this.editTitle = "添加店铺信息";
      this.isEditShop = true;
      this.licencesImg = "";
    },
    showEditForm(index) {
      this.editShopInfo = Object.assign({}, this.shopList[index]);
      this.editShopInfo.cityInfo = [];
      this.licencesImg = "";
      if (this.editShopInfo.licences) {
        getQnDomain("shop").then(domain => {
          this.licencesImg = domain + "/" + this.editShopInfo.licences;
        });
      }
      this.editShopInfo.status = this.editShopInfo.status.toString();
      this.editShopInfo.cityInfo[0] = this.editShopInfo.prov;
      this.editShopInfo.cityInfo[1] = this.editShopInfo.city;
      this.editShopInfo.cityInfo[2] = this.editShopInfo.zone;
      this.editTitle = "修改店铺信息";
      this.isEditShop = true;
    },
    beforeUpload(file) {
      let path = "shop";
      if (file.type.indexOf("image") !== 0) {
        this.$Message.info({
          content: "文件类型不正确，请上传图片文件",
          duration: 5,
          closable: true
        });
      } else {
        uploadFile("shop", file, path, percent => {
          // 上传进度回调
          this.percent = parseInt(percent.percent);
          if (this.percent == 100) this.percent = 0;
        }).then(res => {
          // 上传结果
          this.editShopInfo.licences = res.key;
          getQnDomain("shop").then(domain => {
            this.licencesImg = domain + "/" + this.editShopInfo.licences;
          });
        });
      }
      return false;
    },
    // 修改当前门店
    saveShopInfo() {
      this.$refs["editShopInfo"].validate(valid => {
        if (valid) {
          addShopTablesButtom(this.editShopInfo)
            .then(response => {
              this.$Message.info({
                content: response.data.message,
                duration: 5,
                closable: true
              });
              this.getShopTables();
              if (response.data.code == 1) {
                this.isEditShop = false;
              }
            })
            .catch(error => {
              console.error(error);
            });
        }
      });
      return false;
    },
    // 删除门店
    remove(index) {
      console.log(this.shopList[index]);
      this.$Modal.confirm({
        title: "删除门店",
        content: "<p>你正在进行删除门店操作！确认要删除吗？</p>",
        onOk: () => {
          const deleteShopTablesinfo = {
            //,
            id: this.shopList[index].id
          };
          deleteShopTablesButtom(deleteShopTablesinfo)
            .then(response => {
              this.$Message.info(response.data.message);
              this.getShopTables();
            })
            .catch(error => {
              this.$Message.info(error);
              console.error(error);
            });
        },
        onCancel: () => {
          this.$Message.info("取消了删除操作");
        }
      });
    },
    // 读取门店分页
    handlePage(value) {
      this.requestParam.page = value;
      this.getShopTables();
    },
    // 获取门店列表
    getShopTables() {
      getShopTablesButtom(this.requestParam)
        .then(response => {
          this.shopList = response.data.data.list;
          this.pageTotal = Number(response.data.data.total);
        })
        .catch(error => {
          console.error(error);
        });
    },
    getCityData() {
      const allCityinfo = {
        // //
      };
      allCity(allCityinfo)
        .then(response => {
          this.cityList = response.data.data;
        })
        .catch(error => {
          console.error(error);
        });
    },
    // 搜索门店
    handleSearch() {
      this.getShopTables();
    }
  },
  mounted() {
    this.getShopTables();
    this.getCityData();
  }
};
</script>
<style>
.adminTitle {
  font-size: 18px;
  font-weight: bold;
}
.m20 {
  margin: 20px 0;
}
.inline-div {
  display: inline-block;
  margin: 0 10px;
}
.search-title {
  font-size: 14px;
}
.shop-active:hover {
  cursor: pointer;
}
</style>
