<style lang="less">
@import "../common.less";
</style>
<template>
  <div>
    <p class="adminTitle">打印机相关设置</p>
    <Tabs v-model="tabName" @on-click="switchTabs()">
      <TabPane label="打印机列表" font-size="20px" name="printersList">
        <Button style="margin: 10px 0;" type="primary" @click="showEdit('add')">添加设备</Button>
        <div class="inline-div">
          <p class="inline-div search-title">设备查询：</p>
          <Input
            v-model="requestSn"
            icon="search"
            placeholder="输入你要查询打印机的SN号"
            style="width: 200px; display: inline-block"
          />
          <Button
            style="display: inline-block; margin:0 0 0 15px;  "
            type="primary"
            @click="showTables('query')"
          >查询</Button>
        </div>
        <Table
          ref="printerstable"
          stripe
          border
          @on-selection-change="selectIndex"
          :columns="printerTitle"
          :data="showTenPrinters"
          style="width: auto;"
        ></Table>
        <Page
          :total="Number(this.allPrintersCount)"
          show-total
          @on-change="handleShowPage"
          style="float:right; margin:15px 0;"
        ></Page>
      </TabPane>
      <TabPane label="厂商列表" name="manuList">
        <manuComponents v-on:manuInfo="getAllManuId"></manuComponents>
      </TabPane>
      <TabPane label="导出打印机列表" name="exportData">
        <Button type="primary" @click="myExport()">导出打印机数据</Button> 
      </TabPane>
    </Tabs>

    <Modal v-model="editShow" :title="editTitle">
      <div>
        <span>序列号码：</span>
        <Input v-model="editInfo.sn" placeholder="输入SN码" style="width: 300px; margin: 10px 0; " />
        <br />
        <span>设备标题：</span>
        <Input v-model="editInfo.title" placeholder="输入标题" style="width: 300px; margin: 10px 0; " />
        <br />
        <div>
          <span>厂商名称：</span>
          <Select
            style="width: 150px; margin: 10px 0; display:inline-block "
            v-model="editInfo.manu_id"
          >
            <Option
              v-for="(option, index) in allManuData"
              :key="index"
              :value="option.id"
            >{{option.name}}</Option>
          </Select>
        </div>

        <div>
          <span>打印样式：</span>
          <Select
            style="width: 150px; margin: 10px 0; display:inline-block "
            v-model="editInfo.style"
          >
            <Option
              v-for="(option, index) in printStyle"
              :key="index"
              :value="option.value"
            >{{option.name}}</Option>
          </Select>
        </div>
        <div>
          <span>绑定商家：</span>
          <Select
            style="width: 150px; margin: 10px 0; display:inline-block "
            v-model="editInfo.shop_id"
          >
            <Option
              v-for="(option, index) in shopId"
              :value="option.id"
              :key="index"
            >{{option.value}}</Option>
          </Select>
          <span style="padding-left:5px;">{{editInfo.shop_id ? editInfo.shop_name : "未绑定"}}</span>
        </div>
        <div style="margin: 10px 0; ">
          <span>设备状态：</span>
          <!-- 0-未分配，1-正常，2-故障，3-丢失, 4-返修 -->
          <RadioGroup v-model="editInfo.status" type="button">
            <Radio label="0">未分配</Radio>
            <Radio label="1">正常</Radio>
            <Radio label="2">故障</Radio>
            <Radio label="3">丢失</Radio>
            <Radio label="4">返修</Radio>
          </RadioGroup>
        </div>
        <div>
          <span>设备备注：</span>
          <Input
            style="width:300px;margin:10px 0;"
            v-model="editInfo.remark"
            type="textarea"
            :maxlength="200"
            :rows="3"
            placeholder="请输入"
          />
        </div>
      </div>
      <div slot="footer">
        <Button type="text" size="large" @click="editEx()">取消</Button>
        <Button type="primary" size="large" @click="addPrinter()">确定</Button>
      </div>
    </Modal>
  </div>
</template>
<script>
import excel from "@/libs/excel";
import { getToken } from "@/libs/util";
import {
  //打印机列表
  savePrinter,
  searchShop,
  getPrinters,
  getAllShopName,
  deletePrinters,
  //厂商列表
  printerManuList
} from "@/api/printer";

import manu from "./manu";
export default {
  name: "printer",
  data() {
    return {
      editShow: false,
      editPrinter: false,
      printerInfo: {},
      editTitle: "添加打印机设备",
      allManuData: [],

      //批量处理变量
      selectPrinterIds: [],

      pageSize: 10,
      requestSn: "",
      allPrintersCount: 0,
      printStyle: [{ name: "简单", value: 1 }, { name: "详细", value: 2 }],
      shopId: {},
      editInfo: {},
      //厂商列表
      tabName: "",
      requestParam: {
        sn: ""
      },
      printerTitle: [
        {
          type: "selection",
          width: 40,
          align: "center"
        },
        {
          title: "ID",
          key: "id",
          sortable: true,
          align: "center",
          width: 80
        },

        {
          title: "序列号",
          key: "sn",
          width: 220,
          align: "center"
        },
        {
          title: "设备标题",
          key: "title",
          width: 220,
          align: "center"
        },
        {
          title: "厂商",
          key: "manu_name",
          width: 220,
          align: "center"
        },
        {
          title: "门店",
          key: "shop_name",
          width: 220,
          align: "center"
        },
        {
          title: "状态",
          key: "status",
          width: 110,
          align: "center",
          filters: [
            {
              label: "未分配",
              value: 0
            },
            {
              label: "正常",
              value: 1
            },
            {
              label: "故障",
              value: 2
            },

            {
              label: "丢失",
              value: 3
            },
            {
              label: "维修",
              value: 4
            }
          ],
          filterMultiple: false,
          filterMethod(value, row) {
            if (value == row.status) {
              return row.status;
            }
          },

          render: (h, param) => {
            let statusText = {
              1: "正常",
              2: "故障",
              3: "返修",
              4: "丢失",
              0: "未分配"
            };
            return h("div", statusText[param.row.status]);
          }
        },
        {
          title: "打印样式",
          key: "style",
          width: 110,
          align: "center",
          filters: [
            {
              label: "简单打印",
              value: 1
            },
            {
              label: "详细详细",
              value: 2
            }
          ],
          filterMultiple: false,
          filterMethod(value, row) {
            console.log(value, row.type);
            if (value == row.type) {
              return row.type;
            }
          },
          render: (h, param) => {
            let statusText = {
              1: "简单打印",
              2: "详细打印"
            };
            return h("div", statusText[param.row.style]);
          }
        },
        {
          title: "备注",
          key: "remark",
          width: 220,
          align: "center"
        },
        {
          title: "编辑",
          key: "action",
          width: 230,
          align: "center",
          render: (h, params) => {
            return h("div", [
              h(
                "Button",
                {
                  props: {
                    type: "primary",
                    size: "small"
                  },
                  style: {
                    marginRight: "5px"
                  },
                  on: {
                    click: () => {
                      this.showEdit("edit", params.row);
                    }
                  }
                },
                "修改"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "error",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.deletePrinter(params.row.id, "d1");
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ],
      tableData: [],
      showTenPrinters: []
    };
  },
  watch: {
    requestSn(curVal, oldVal) {
      // 实现input连续输入，只发一次请求
      clearTimeout(this.timeout);
      this.timeout = setTimeout(() => {
        this.showTables("qurey");
      }, 300);
    }
  },

  methods: {
    //导入数据
    handleBeforeImport(file) {
      console.log("file", file);
      const fileExt = file.name
        .split(".")
        .pop()
        .toLocaleLowerCase();
      if (fileExt === "xlsx" || fileExt === "xls") {
        this.readFile(file);
      } else {
        this.$Notice.warning({
          title: "文件类型错误",
          desc:
            "文件：" +
            file.name +
            "不是EXCEL文件，请选择后缀为.xlsx或者.xls的EXCEL文件。"
        });
      }
      return false;
    },
    // 读取文件
    readFile(file) {
      const reader = new FileReader();
      reader.readAsArrayBuffer(file);
      reader.onerror = e => {
        this.$Message.error("文件读取出错");
      };
      reader.onload = e => {
        const data = e.target.result;
        const { header, results } = excel.read(data, "array");
        console.log("头部信息");
        console.log(header);
        console.log("result");
        console.log(results);
      };
    },
    //导出数据
    myExport() {
      let exportData = this.tableData.filter((item, index, self) => {
        switch (item.status) {
          case "0":
            self[index].status = "未匹配";
            break;
          case "1":
            self[index].status = "正常";
            break;
          case "2":
            self[index].status = "故障";
            break;
          case "3":
            self[index].status = "丢失";
            break;
          case "4":
            self[index].status = "返修";
            break;
        }
        if (item.style == "2") {
          self[index].style = "详细打印";
        } else {
          self[index].style = "简单打印";
        }
        return true;
      });
      if (this.tableData.length) {
        this.$refs.printerstable.exportCsv({
          filename: "打印机列表",
          original: false,
          columns: this.printerTitle,
          data: this.tableData
        });
      } else {
        this.$Message.info("无表格数据");
      }
    },
    switchTabs() {
      if (this.tabName == "printersList") {
        console.log("展示表");
        this.showTables();
      }
    },
    //tabs3
    showEdit(type, printerInfo) {
      if (type == "edit") {
        this.editPrinter = true;
        this.editInfo.id = printerInfo.id;
        this.editInfo.title = printerInfo.title;
        this.editInfo.sn = printerInfo.sn;
        this.editInfo.manu_id = printerInfo.manu_id;
        this.editInfo.shop_id = printerInfo.shop_id;
        this.editInfo.remark = printerInfo.remark;
        this.editInfo.status = printerInfo.status;
        this.editInfo.style = printerInfo.style;
      } else {
        this.editInfo.id = "";
        this.editPrinter = false;
      }
      this.editShow = true;
    },
    editEx() {
      this.editShow = false;
    },
    handleShowPage(index) {
      let startIndex = (index - 1) * this.pageSize;
      let endIndex = index * this.pageSize;
      this.showTenPrinters = this.tableData.slice(startIndex, endIndex);
    },
    selectIndex(selection) {
      console.log("选择的");
      selection.forEach(item => {
        this.selectPrinterIds.push(item.id);
        console.log(item.id);
      });
      console.log(this.selectPrinterIds.join(","));
    },

    addPrinter() {
      savePrinter(this.editInfo).then(res => {
        console.log("获取的token:" + getToken());
        console.log(this.editInfo);
        console.log("门店ID" + this.editInfo.shop_id);
        this.editShow = false;
        this.showTables();
      });
    },
    deletePrinter(deletePrinterId, type) {
      if (type === "d1") {
        this.$Modal.confirm({
          title: "删除设备",
          content: "<p>你正在进行删除操作,确认要删除吗？</p>",
          onOk: () => {
            let data = { id: deletePrinterId };
            deletePrinters(data).then(res => {
              this.showTables();
              this.$Message.info("删除成功");
            });
          },
          onCancel: () => {
            this.$Message.info("取消了删除操作");
          }
        });
      }
    },
    showTables(query) {
      let snData = "";
      if (query) {
        snData = this.requestSn;
      }
      let data = {
        token: getToken(),
        machine: "hq",
        sn: snData
      };
      getPrinters(data).then(res => {
        this.tableData = res.data.data.list;
        this.allPrintersCount = parseInt(res.data.data.total);
        if (res.data.data.list.length < this.pageSize) {
          this.showTenPrinters = res.data.data.list;
        } else {
          this.showTenPrinters = this.tableData.slice(0, this.pageSize);
        }
      });
    },
    //tabs2
    getAllManuId(allManu) {
      console.log("allManu");
      console.log(allManu);
      this.allManuData = allManu;
    },sampleExcel(){
      let titleSample=[{width: 220,key:"sn"},{key:"title"},{key:"manu_id"},{key:"shop_id"},{key:"style"},{key:"status"},{ width: 220,key:"remark"}]
      this.$refs.printerstable.exportCsv({
          filename: "sample",
          original: false,
          columns: titleSample,
          data:[{sn:"打印机序列号",title:"打印机名称",manu_id:"厂商名称",shop_id:"商店ID",style:"打印样式",status:"打印机状态",remark:"备注只支持excel表文件导入"}]
        });
    }
  },
  
  components: {
    manuComponents: manu
  },
  mounted() {
    console.log("此时mounted");
    this.showTables();
    getAllShopName().then(res => {
      console.log(res);
      this.shopId = res.data.data.list.map(item => {
        return {
          id: item.id,
          value: item.name
        };
      });
    });
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>

