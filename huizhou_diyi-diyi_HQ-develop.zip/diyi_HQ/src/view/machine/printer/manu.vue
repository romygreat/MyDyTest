
<style lang="less">
@import "../common.less";
</style>
<template>
  <div>
    <Button style="margin: 10px 0;" type="primary" @click="showEdit('add')">添加厂商</Button>
    <div class="inline-div">
      <p class="inline-div search-title">设备查询：</p>
      <Input
        v-model="queryName"
        icon="search"
        placeholder="输入你要查询打印机的SN号"
        style="width: 200px; display: inline-block"
      />
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        type="primary"
        @click="showTables('query')"
      >查询</Button>
    </div>
    <Table
      ref="table"
      stripe
      border
      :columns="printerTitle"
      :data="showTenPrinters"
      style="width: 1100px;"
    ></Table>
    <Page
      :total="Number(this.allPrintersCount)"
      show-total
      @on-change="handleShowPage"
      style="float:right; margin:15px 0;"
    ></Page>

    <Modal v-model="editShow" :title="editTitle">
      <div>
        <span>厂商名：</span>
        <Input v-model="editInfo.name" placeholder="输入厂商名称" style="width: 300px; margin: 10px 0; " />
        <br />
        <span>用户名：</span>
        <Input v-model="editInfo.user" placeholder="输入标题" style="width: 300px; margin: 10px 0; " />
        <br />
        <span>用户键：</span>
        <Input v-model="editInfo.ukey" placeholder="用户键" style="width: 300px; margin: 10px 0; " />
        <br />
      </div>
      <div slot="footer">
        <Button type="text" size="large" @click="editEx()">取消</Button>
        <Button type="primary" size="large" @click="addManu()">确定</Button>
      </div>
    </Modal>
  </div>
</template>
<script>
import { getToken } from "@/libs/util";
import {
  //厂商列表
  printerManuList,
  saveManu,
  deleteManuApi
} from "@/api/printer";
export default {
  name: "manu",
  data() {
    return {
      editShow: false,
      editPrinter: false,
      printerInfo: {},
      editTitle: "添加打印机厂商",

      pageSize: 10,
      queryName: "",
      allPrintersCount: 0,

      shopId: {},
      editInfo: {},

      printerTitle: [
        {
          type: "selection",
          width: 50,
          align: "center"
        },
        {
          title: "ID",
          key: "id",
          align: "center",
          width: 80
        },

        {
          title: "厂商名称",
          key: "name",
          width: 300,
          align: "center"
        },
        {
          title: "用户",
          key: "user",
          width: 200,
          align: "center"
        },
        {
          title: "用户键",
          key: "ukey",
          width: 200,
          align: "center"
        },
        {
          title: "删除",
          key: "action",
          width: 300,
          align: "center",
          render: (h, params) => {
            return h("div", [
              h(
                "Button",
                {
                  props: {
                    type: "error",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.deleteManu(params.row.id, "d1");
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ],
      tableData: [],
      showTenPrinters: []
    };
  },
  watch: {
    queryName(curVal, oldVal) {
      // 实现input连续输入，只发一次请求
      clearTimeout(this.timeout);
      this.timeout = setTimeout(() => {
        this.showTables("qurey");
      }, 300);
    }
  },

  methods: {
    showEdit(type, printerInfo) {
      console.log("获取的token:" + getToken());
      if (type == "edit") {
        this.editInfo.id = printerInfo.id;
        this.editInfo.name = printerInfo.name;
        this.editInfo.user = printerInfo.user;
        this.editInfo.ukey = printerInfo.ukey;
      } else {
        //弹出添加编辑框
        this.editPrinter = false;
      }
      this.editShow = true;
    },
    editEx() {
      this.editShow = false;
    },
    handleShowPage(index) {
      let startIndex = (index - 1) * this.pageSize;
      let endIndex = index * this.pageSize;
      this.showTenPrinters = this.tableData.slice(startIndex, endIndex);
    },

    addManu() {
      saveManu(this.editInfo).then(res => {
        this.editShow = false;
        this.showTables();
      });
    },
    deleteManu(deletePrinterId, type) {
      if (type === "d1") {
        this.$Modal.confirm({
          title: "删除设备",
          content: "<p>你正在进行删除操作,确认要删除吗？</p>",
          onOk: () => {
            let data = { id: deletePrinterId };
            console.log(deletePrinterId);
            deleteManuApi(data).then(res => {
                console.log(res)
                if(res.data.code==1){
              this.$Message.info("删除成功");
              this.showTables()}
            });
          },
          onCancel: () => {
            this.$Message.info("取消了删除操作");
          }
        });
      }
    },
    showTables(query) {
      let snData = "";
      if (query) {
        snData = this.queryName;
      }
      let data = {
        name: snData
      };
      printerManuList(data).then(res => {
        this.tableData = res.data.data;
        this.allPrintersCount = parseInt(res.data.data.length);
        if (res.data.data.length < this.pageSize) {
          this.showTenPrinters = res.data.data;
        } else {
          this.showTenPrinters = this.tableData.slice(0, this.pageSize);
        }
        this.sendMessage2ParentComponent(this.tableData)
      });
    },
    sendMessage2ParentComponent(allManuInfo){
        this.$emit("manuInfo",allManuInfo)
    }
  },

  mounted() {
    console.log("此时mounted");
    this.showTables();
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>

