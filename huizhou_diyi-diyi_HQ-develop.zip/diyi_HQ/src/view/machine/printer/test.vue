<template>
<div>
  <countTo :startVal='startVal' :endVal='endVal' :duration='5000'></countTo>
   <button>测试结果</button>
   <editor></editor>
</div>
</template>

<script>
  import countTo from '_c/count-to/count-to.vue';
   import editor from '_c/editor/editor.vue';
  export default {
    components: { countTo,editor },
    data () {
      return {
        startVal: 0,
        endVal: 2019
      }
    }
  }
</script>