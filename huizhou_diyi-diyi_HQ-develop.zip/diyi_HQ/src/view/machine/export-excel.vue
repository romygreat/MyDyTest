<style lang="less">
@import './common.less';
</style>
<template>
  <div>
    <p class="adminTitle">设备列表</p>
    <!-- add buttom -->
    <Button style="margin: 10px 0;" type="primary" @click="showEdit('add')">添加设备</Button>
    <div class="inline-div">
      <p class="inline-div search-title">设备查询：</p>
      <Input
        v-model="requestParam.sn"
        icon="search"
        placeholder="输入你要查询的设备的序列号"
        style="width: 200px; display: inline-block"
      />
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        type="primary"
        @click="handleSearch"
      >查询</Button>
      <div style="display: inline-block; margin:0 0 0 15px;  ">
        <Upload action :before-upload="handleBeforeImport" accept=".xls, .xlsx">
          <Button icon="ios-cloud-upload-outline">批量导入设备</Button>
        </Upload>
      </div>
    </div>
    <Row class="margin-top-10">
      <Table
        ref="table"
        stripe
        border
        @on-selection-change="selectIndex"
        :columns="tableTitle"
        :data="tableData"
        style="width: 1192px;"
      ></Table>
      <div style="width: 1192px;">
        <Button
          v-if="!this.requestParam.shop_id"
          type="primary"
          style="margin: 10px 0;"
          @click="showBacthBind"
        >批量绑定</Button>
        <Button v-else type="primary" style="margin: 10px 0;" @click="routerBack">返回</Button>
        <Button type="error" style="margin: 0 10px" @click="remove">批量删除</Button>
        <Page
          :total="Number(pageTotal)"
          show-total
          @on-change="handlePage"
          style="float:right; margin:15px 0;"
        ></Page>
      </div>
    </Row>
    <Card style="width:1192px" title="导出EXCEL">
      <Row>
        <Col v-show="this.requestParam.shop_id" span="3"></Col>
      </Row>
    </Card>
    <Modal v-model="editEx" :title="editTitle">
      <div>
        <span>序列号：</span>
        <Input v-model="editInfo.sn" placeholder="输入SN码" style="width: 300px; margin: 10px 0; " />
      </div>
      <div v-show="!this.requestParam.shop_id">
        <span>绑定商家：</span>
        
        <Select
          style="width: 150px; margin: 10px 0; display:inline-block "
          v-model="editInfo.shop_id"
          filterable
          remote
        :loading="loading1"
        >
          <Option
            v-for="(option, index) in options1"
            :value="option.value"
            :key="index"
          >{{option.label}}</Option>
        </Select>
        
        <span style="padding-left:5px;">{{editInfo.shop_id ? editInfo.shop_name : "未绑定"}}</span>
      </div>
      <div style="margin: 10px 0; ">
        <span>设备状态：</span>
        <RadioGroup v-model="editInfo.status" type="button">
          <Radio label="0">未分配</Radio>
          <Radio label="1">正常</Radio>
          <Radio label="2">故障</Radio>
          <Radio label="3">返修</Radio>
          <Radio label="4">丢失</Radio>
        </RadioGroup>
      </div>
      <div>
        <span>设备备注：</span>
        <Input
          style="width:300px;margin:10px 0;"
          v-model="editInfo.remark"
          type="textarea"
          :maxlength="200"
          :rows="3"
          placeholder="请输入"
        />
      </div>

      <div slot="footer">
        <Button type="text" size="large" @click="editEx = false;machineTables()">取消</Button>
        <Button type="primary" size="large" @click="saveMacineInfo">确定</Button>
      </div>
    </Modal>
    <Modal v-model="isShowBacthBind" title="批量绑定" @on-ok="allMocBinding">
      <div>
        <span>输入店铺名称：</span>
        <Select
          style="width: 300px; margin: 10px 0; display:inline-block "
          v-model="bindShopId"
          filterable
          remote
          :loading="loading1"
        >
          <Option
            v-for="(option, index) in options1"
            :value="option.value"
            :key="index"
          >{{option.label}}</Option>
        </Select>
      </div>
    </Modal>
  </div>
</template>
<script>
import excel from '@/libs/excel'
import { getToken } from '@/libs/util'
import {
  allMachBangdingButtom,
  searchShopsButtom,
  editMacineButtom,
  delMachineButtom,
  handleSearchMac,
  machineTablesButtom,
  uploadExcelButtom
} from '@/api/data'
export default {
  name: 'export-excel',
  data() {
    return {
      exportLoading: false,
      tableTitle: [
        {
          type: 'selection',
          width: 60,
          align: 'center'
        },
        {
          title: 'ID',
          key: 'id',
          align: 'center',
          width: 80
        },
        {
          title: '序列号',
          key: 'sn',
          width: 220,
          align: 'center'
        },

        {
          title: '商家名称',
          key: 'shop_name',
          width: 220,
          align: 'center'
        },
        {
          title: '状态',
          key: 'status',
          width: 110,
          align: 'center',
          filters: [
            {
              label: '未分配',
              value: 0
            },
            {
              label: '正常',
              value: 1
            },
            {
              label: '故障',
              value: 2
            },
            {
              label: '返修',
              value: 3
            },
            {
              label: '丢失',
              value: 4
            }
          ],
          filterMultiple: false,
          filterMethod(value, row) {
            if (value == row.status) {
              return row.status
            }
          },
          render: (h, param) => {
            let statusText = {
              1: '正常',
              2: '故障',
              3: '返修',
              4: '丢失',
              0: '未分配'
            }
            return h('div', statusText[param.row.status])
          }
        },
        {
          title: '备注',
          key: 'remark',
          width: 260,
          align: 'center'
        },
        {
          title: '编辑',
          key: 'action',
          width: 230,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.showEdit('edit', params.index)
                    }
                  }
                },
                '修改'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index, 'rec')
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      tableData: [],
      pageTotal: 0,
      requestParam: {
        sn: '',
        page: 1,
        rows: 10,
        type: 1,
        sort: { id: 'desc' }
      },
      // 修改挂载
      editTitle: '',
      editEx: false,
      loading: false,
      editInfo: {},
      selectIds: [],
      // 搜索
      loading1: false,
      options1: [],
      bindShopId: 0,
      list: [],
      isShowBacthBind: false,
      // 导出
      allTablesData: {}
    }
  },
  methods: {
    showEdit(type, index) {
      if (type == 'edit') {
        this.editTitle = '编辑设备'
        this.editInfo = Object.assign({}, this.tableData[index])
        this.editInfo.status = this.editInfo.status.toString()
        this.editInfo.type = '1'
      } else if (type == 'add') {
        this.editTitle = '添加设备'
        this.editInfo = {}
        this.editInfo.type = '1'
      }
      this.editEx = true
    },
    remove(index, type) {
      if (type === 'rec') {
        this.$Modal.confirm({
          title: '删除设备',
          content: '<p>你正在进行删除操作,确认要删除吗？</p>',
          onOk: () => {
            const delMachineinfo = {
              //,
              id: this.tableData[index].id
            }
            delMachineButtom(delMachineinfo).then(response => {
              this.machineTables()
              this.$Message.info(response.data.message)
            })
          },
          onCancel: () => {
            this.$Message.info('取消了删除操作')
          }
        })
      } else {
        this.$Modal.confirm({
          title: '批量删除设备',
          content: '<p>你正在进行批量删除操作,确认要删除吗？</p>',
          onOk: () => {
            const delMachineinfo = {
              //,
              id: this.selectIds.join(',')
            }
            delMachineButtom(delMachineinfo).then(response => {
              this.machineTables()
              this.$Message.info(response.data.message)
            })
          },
          onCancel: () => {
            this.$Message.info('取消了删除操作')
          }
        })
      }
    },
    machineTables() {
      machineTablesButtom(this.requestParam)
        .then(response => {
          this.tableData = response.data.data.list          
          this.pageTotal = response.data.data.total
          this.tableData = response.data.data.list.filter(
            (item, index, self) => {
              //过滤出的是点餐机设备
              if (item.type == 1) return true
            }
          )
        })
        .catch(error => {
          console.error(error)
        })
    },
    handlePage(value) {
      this.requestParam.page = value
      this.machineTables()
    },
    handleSearch() {
      this.machineTables()
    },
    saveMacineInfo() {
      if (!this.editInfo.sn) {
        this.$Message.info('SN号不能为空')
      } else if (!this.editInfo.type) {
        this.$Message.info('请选择一个设备类型')
      } else {
        if (!this.editInfo.status) this.editInfo.status = 0
        if (this.requestParam.shop_id)
          this.editInfo.shop_id = this.requestParam.shop_id
        editMacineButtom(this.editInfo)
          .then(response => {
            this.$Message.info({
              content: response.data.message,
              duration: 5,
              closable: true
            })
            if (response.data.code == 1) {
              this.editEx = false
              this.getOp1()
              this.machineTables()
            }
          })
          .catch(error => {
            this.$Message.info({
              content: error,
              duration: 5,
              closable: true
            })
          })
      }
    },
    showBacthBind() {
      if (this.selectIds.length === 0) {
        this.$Message.info('请至少选择一个设备')
        return false
      }
      this.isShowBacthBind = true
    },
    // 批量绑定
    allMocBinding() {
      if (this.selectIds.length === 0) {
        this.$Message.info('请至少选择一个设备')
        return false
      }
      let allMachBangdinginfo = {
        id: this.selectIds.join(','),
        shop_id: this.bindShopId
      }
      allMachBangdingButtom(allMachBangdinginfo).then(response => {
          if (response.deat.code==6) {
            this.selectIds=[]
            this.bindShopId=''
          }
        this.$Message.info({
          content: response.data.message,
          duration: 10,
          closable: true
        })
        this.getOp1()
        this.machineTables()
      })
    },
    // 勾选时获取已勾选的数据的ID
    selectIndex(selection) {
      this.selectIds = []

      selection.forEach(item => {
        this.selectIds.push(item.id)
      })
    },
    // 远程搜索
    searchShops(name) {
      if (name !== '') {
        searchShopsButtom({ name })
          .then(response => {
            this.list = response.data.data
            this.loading1 = true
            setTimeout(() => {
              this.loading1 = false
              const list = this.list.map(item => {
                return {
                  value: item.id,
                  label: item.name
                }
              })
              this.options1 = list.filter(
                item =>
                  item.label.toLowerCase().indexOf(name.toLowerCase()) > -1
              )
            }, 200)
          })
          .catch(error => {
            console.error(error)
          })
      } else {
        this.options1 = []
      }
    },
    getOp1() {
      searchShopsButtom({}).then(res => {
        this.list = res.data.data
        const list = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        this.options1 = list
      })
    },
    routerBack() {
      this.$router.back(-1)
    },
    handleBeforeImport(file) {
      console.log('file', file)
      const fileExt = file.name
        .split('.')
        .pop()
        .toLocaleLowerCase()
      if (fileExt === 'xlsx' || fileExt === 'xls') {
        this.readFile(file)
      } else {
        this.$Notice.warning({
          title: '文件类型错误',
          desc:
            '文件：' +
            file.name +
            '不是EXCEL文件，请选择后缀为.xlsx或者.xls的EXCEL文件。'
        })
      }
      return false
    },
    // 读取文件
    readFile(file) {
      const reader = new FileReader()
      reader.readAsArrayBuffer(file)
      reader.onerror = e => {
        this.$Message.error('文件读取出错')
      }
      reader.onload = e => {
        const data = e.target.result
        const { header, results } = excel.read(data, 'array')
        this.uploadExcel(results)
      }
    },
    uploadExcel(data) {
      if (data.length === 0) {
        this.$Message.info({
          content: '没有可用数据，请导入文件',
          duration: 5,
          closable: true
        })
      } else if (data.length > 1000) {
        this.$Message.info({
          content: '内容超过1000条，请分开上传',
          duration: 5,
          closable: true
        })
      } else {
        let f = true
        data.forEach(item => {
          if (item.sn) {
            if(this.requestParam.shop_id) {
              item.shop_id = this.requestParam.shop_id
              item.status = 1
            }
          } else {
            f = false
          }
        })
        if (!f) {
          this.$Message.info({
            content: '参数错误，请检查表格数据后刷新页面后重试',
            duration: 5,
            closable: true
          })
          return false
        }
        uploadExcelButtom({ data }).then(response => {
          this.machineTables()
          console.log(response,'response');
          
          this.$Message.info({
            content: response.data.message,
            duration: 5,
            closable: true
          })
        })
      }
    }
  },
  mounted() {
    this.requestParam.shop_id = this.$route.query.shopId
      ? this.$route.query.shopId
      : 0
    this.machineTables()
    this.getOp1()
  },
  watch: {
    $route(to, from) {
      if (from.path == '/shop/shop-admin' && to.query.shopId) {
        this.requestParam.shop_id = to.query.shopId
      } else {
        this.requestParam.shop_id = 0
      }
      this.machineTables()
    }
  }
}
</script>
