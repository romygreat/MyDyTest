<template>
  <div>
    <p class="adminTitle">设备回收站</p>
    <div class="inline-div" style="margin-top:10px;margin-left:0; margin-bottom:20px">
      <p style="margin-left:0" class="inline-div search-title">设备查询：</p>
      <Input
        clearable
        v-model="sdkrec.sn"
        icon="search"
        placeholder="输入你要查询的设备SN号"
        style="width: 200px; display: inline-block"
      />
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        type="primary"
        @click="machineTables"
      >查询</Button>
    </div>
    <Table
      @on-selection-change="selectBox"
      style="width:1192px"
      :columns="tableTitle"
      :data="tableData"
      border
    ></Table>
    <div style="width: 1192px;">
      <Button type="primary" style="margin: 10px 0;" @click="showEdit('2','all')">批量还原</Button>
      <Button type="error" style="margin: 0 10px" @click="remove('1','all')">批量删除</Button>
      <Page
        :total="Number(tableTotal)"
        :page-size="sdkrec.rows"
        show-total
        @on-change="handlePage"
        style="float:right; margin:15px 0;"
      ></Page>
    </div>
  </div>
</template>

<script>
import {
  restoreMachineButtom,
  macRecButtom,
  delMachineButtom
} from "@/api/data";
export default {
  data() {
    return {
      tableTitle: [
        {
          type: "selection",
          width: 50,
          align: "center"
        },
        {
          title: "ID",
          key: "id",
          align: "center",
          width: 80
        },
        {
          title: "序列号",
          key: "sn",
          width: 220,
          align: "center"
        },
        {
          title: "设备类型",
          key: "type_name",
          width: 110,
          align: "center",
          filters: [
            {
              label: "点餐机",
              value: 1
            },
            {
              label: "打印机",
              value: 2
            }
          ],
          filterMultiple: false,
          filterMethod(value, row) {
            console.log(value, row.type);
            if (value == row.type) {
              return row.type;
            }
          }
        },
        {
          title: "商家名称",
          key: "shop_name",
          width: 220,
          align: "center"
        },
        {
          title: "状态",
          key: "status",
          width: 110,
          align: "center",
          filters: [
            {
              label: "未分配",
              value: 0
            },
            {
              label: "正常",
              value: 1
            },
            {
              label: "故障",
              value: 2
            }
          ],
          filterMultiple: false,
          filterMethod(value, row) {
            if (value == row.status) {
              return row.status;
            }
          },
          render: (h, param) => {
            let statusText = {
              1: "正常",
              2: "故障",
              0: "未分配"
            };
            return h("div", statusText[param.row.status]);
          }
        },
        {
          title: "备注",
          key: "remark",
          width: 220,
          align: "center"
        },
        {
          title: "编辑",
          key: "action",
          width: 180,
          align: "center",
          render: (h, params) => {
            return h("div", [
              h(
                "Button",
                {
                  props: {
                    type: "primary",
                    size: "small"
                  },
                  style: {
                    marginRight: "5px"
                  },
                  on: {
                    click: () => {
                      this.showEdit(params.index);
                    }
                  }
                },
                "还原"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "error",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.remove(params.index);
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ],
      tableData: [],
      sdkrec: {
        sn: "",
        page: 1,
        rows: 10,
        trashed: 1,
        sort: { id: "desc" }
      },
      tableTotal: "",
      allactive: ""
    };
  },
  methods: {
    machineTables() {
      macRecButtom(this.sdkrec)
        .then(res => {
          console.log(res);
          this.tableTotal = res.data.data.total;
          this.tableData = res.data.data.list;
        })
        .catch(err => {
          console.error(err);
        });
    },
    showEdit(index, type) {
      if (!type) {
        this.$Modal.confirm({
          title: "还原设备",
          content: "<p>你正在进行还原设备操作！确认要还原吗？</p>",
          onOk: () => {
            const data = {
              id: this.tableData[index].id
            };
            restoreMachineButtom(data)
              .then(res => {
                console.log(res);
                this.$Message.info(res.data.message);
                this.machineTables();
              })
              .catch(err => {
                console.error(err);
              });
          },
          onCancel: () => {
            this.$Message.info("取消了还原操作");
          }
        });
      } else if (type === "all") {
        this.$Modal.confirm({
          title: "批量还原设备",
          content: "<p>你正在进行批量还原设备操作！确认要批量还原吗？</p>",
          onOk: () => {
            const data = {
              id: this.allactive
            };
            restoreMachineButtom(data)
              .then(res => {
                console.log(res);
                this.$Message.info(res.data.message);
                this.machineTables();
              })
              .catch(err => {
                console.error(err);
              });
          },
          onCancel: () => {
            this.$Message.info("取消了还原操作");
          }
        });
      }
    },
    remove(index, type) {
      if (!type) {
        this.$Modal.confirm({
          title: "彻底删除设备",
          content: "<p>你正在进行彻底删除操作！确认要删除吗？</p>",
          onOk: () => {
            const delMachineinfo = {
              id: this.tableData[index].id,
              del: 1
            };
            delMachineButtom(delMachineinfo)
              .then(res => {
                this.$Message.info(res.data.message);
                this.machineTables();
              })
              .catch(err => {
                console.error(err);
              });
          },
          onCancel: () => {
            this.$Message.info("取消了删除操作");
          }
        });
      } else if (type === "all") {
        this.$Modal.confirm({
          title: "批量彻底删除设备",
          content: "<p>你正在进行批量彻底删除操作！确认要批量彻底删除吗？</p>",
          onOk: () => {
            const delMachineinfo = {
              del: 1,
              id: this.allactive
            };
            delMachineButtom(delMachineinfo)
              .then(res => {
                this.$Message.info(res.data.message);
                this.machineTables();
              })
              .catch(err => {
                console.error(err);
              });
          },
          onCancel: () => {
            this.$Message.info("取消了删除操作");
          }
        });
      }
    },
    handlePage(index) {
      this.sdkrec.page = index;
      this.machineTables();
    },
    selectBox(index) {
      let arr = [];
      for (let i in index) {
        arr[i] = index[i].id;
      }
      this.allactive = arr.join(",");
    }
  },
  created() {
    this.machineTables();
  }
};
</script>

<style>
@import "./common.less";
</style>
