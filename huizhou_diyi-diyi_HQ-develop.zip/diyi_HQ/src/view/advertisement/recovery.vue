<template>
  <div>
    <p class="adminTitle">广告回收站</p>
    <Table
      style="width:782px;"
      :columns="columns"
      :data="recData"
      border
      @on-select="allLaunch"
      @on-select-all="allLaunchs"
    ></Table>
    <div style="width:782px;">
      <Button style="float:left; margin:10px 10px 0 0;" @click="allreduc" type="primary">批量还原</Button>
      <Button style="float:left; margin:10px 0;" type="error" @click="alldel">批量删除</Button>

      <Page
        style="float: right;margin-top: 10px"
        :total="Number(pagetotal)"
        :current="1"
        show-total
        @on-change="handlePage"
      ></Page>
    </div>
  </div>
</template>

<script>
import { truedel, reductionAdv, getRecTablesButtom } from '@/api/data'
import { getToken } from '@/libs/util'
export default {
  data() {
    return {
      columns: [
        {
          type: 'selection',
          width: 50,
          align: 'center'
        },
        {
          title: 'ID',
          key: 'id',
          width: 80,
          align: 'center',
          sortable: true,
          render: (h, params) => {
            return h('div', [h('strong', params.row.id)])
          }
        },
        {
          title: '标题',
          key: 'title',
          width: 280,
          align: 'center',
          tooltip: true
        },
        {
          title: '投放地区',
          key: 'prov_name',
          width: 220,
          render: (h, params) => {
            let arr = []
            if (params.row.prov_name) arr.push(params.row.prov_name)
            if (params.row.city_name) arr.push(params.row.city_name)
            if (params.row.zone_name) arr.push(params.row.zone_name)
            return h('div', [h('strong', arr.join('-'))])
          }
        },
        {
          title: '编辑',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.show(params.index)
                    }
                  }
                },
                '还原'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                    }
                  }
                },
                '彻底删除'
              )
            ])
          }
        }
      ],
      recData: [],
      pagetotal: '',
      pageNum: '',
      allAdvinfo: []
    }
  },
  methods: {
    show(index) {
      this.$Modal.confirm({
        title: '还原广告',
        content: '<p>确认还原广告？</p>',
        onOk: () => {
          const reductionAdvinfo = {
            //,
            id: this.recData[index].id
          }
          reductionAdv(reductionAdvinfo)
            .then(response => {
              console.log(response)
              this.$Message.info('已经还原了广告')
              this.getRecTables()
            })
            .catch(error => {
              this.$Message.info(error)
            })
        },
        onCancel: () => {
          this.$Message.info('取消了还原操作')
        }
      })
    },
    remove(index) {
      console.log(this.recData[index], '删除事件')
      this.$Modal.confirm({
        title: '彻底删除',
        content: '<p>确认彻底删除？</p>',
        onOk: () => {
          const truedelinfo = {
            //,
            id: this.recData[index].id,
            del: 1
          }
          truedel(truedelinfo).then(response => {
            console.log(response)
            this.getRecTables()
          })
          this.$Message.info('已经彻底删除')
        },
        onCancel: () => {
          this.$Message.info('取消了彻底删除操作')
        }
      })
    },
    handlePage(value) {
      console.log(value)
      this.pageNum = value
      const getRecTablesinfo = {
        //,
        page: this.pageNum,
        rows: 10,
        trashed: 1
      }
      getRecTablesButtom(getRecTablesinfo)
        .then(response => {
          this.recData = response.data.data.list
          this.pagetotal = response.data.data.total
        })
        .catch(error => {
          console.error(error)
        })
    },
    // 获取回收站列表
    getRecTables() {
      const getRecTablesinfo = {
        //,
        page: 1,
        rows: 10,
        trashed: 1
      }
      getRecTablesButtom(getRecTablesinfo)
        .then(response => {
          console.log(response.data.data.total, '总数')
          this.recData = response.data.data.list
          this.pagetotal = response.data.data.total
        })
        .catch(error => {
          console.error(error)
        })
    },
    // 获取批量
    allLaunch(data) {
      var Launch = []
      for (let i = 0; i < data.length; i++) {
        Launch.push(data[i].id)
      }
      console.log(Launch.join(','), 123)
      this.allAdvinfo = Launch.join(',')
    },
    allLaunchs(data) {
      var Launchs = []
      for (let i = 0; i < data.length; i++) {
        Launchs.push(data[i].id)
      }
      console.log(Launchs.join(','), 123)
      this.allAdvinfo = Launchs.join(',')
    },
    // 批量还原
    allreduc() {
      this.$Modal.confirm({
        title: '批量还原',
        content: '<p>确认还原当前所选广告？</p>',
        onOk: () => {
          const reductionAdvinfo = {
            //,
            id: this.allAdvinfo
          }
          reductionAdv(reductionAdvinfo)
            .then(response => {
              console.log(response)
              this.$Message.info('已经批量还原了广告')
              this.getRecTables()
            })
            .catch(error => {
              this.$Message.info(error)
            })
        },
        onCancel: () => {
          this.$Message.info('取消了还原操作')
        }
      })
    },
    // 批量删除
    alldel() {
      this.$Modal.confirm({
        title: '批量彻底删除',
        content: '<p>确认彻底删除当前所选广告？</p>',
        onOk: () => {
          const truedelinfo = {
            //,
            id: this.allAdvinfo,
            del: 1
          }
          truedel(truedelinfo).then(response => {
            console.log(response)
            this.getRecTables()
          })
          this.$Message.info('已经批量彻底删除')
        },
        onCancel: () => {
          this.$Message.info('取消了彻底删除操作')
        }
      })
    }
  },
  mounted() {
    this.getRecTables()
  }
}
</script>

<style>
.adminTitle {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;
}
</style>
