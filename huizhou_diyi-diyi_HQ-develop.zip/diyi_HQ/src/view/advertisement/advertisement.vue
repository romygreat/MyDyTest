<template>
  <div>
    <p class="adminTitle">广告列表</p>
    <!-- add adv buttom -->
    <Button class="m20" type="primary" @click="showAdd">添加广告</Button>
    <!-- adv search -->
    <div class="inline-div">
      <p class="inline-div search-title">标题查询：</p>
      <Input
        clearable
        v-model="requestParam.title"
        icon="search"
        placeholder="输入你要查询的标题"
        style="width: 200px; display: inline-block"
      />
      <p class="inline-div search-title">店铺查询：</p>
      <Input
        clearable
        v-model="requestParam.shop_id"
        icon="search"
        placeholder="输入你要查询的标题"
        style="width: 200px; display: inline-block"
      />
      <p class="inline-div search-title">状态查询：</p>
        <Select
          style="width: 120px; display: inline-block"
          v-model="requestParam.status"
        >
          <Option :value="1"   >开启</Option>
          <Option :value="0"   >关闭</Option>
        </Select>
      <Button
        style="display: inline-block; margin:0 0 0 15px;"
        type="primary"
        @click="handleSearchAdv"
      >查询</Button>
    </div>
    <!-- adv tables -->
    <Table
      ref="selection"
      style="width: 1500px;"
      border
      :total="Number(pageTotal)"
      :columns="columns7"
      :data="advTableinfo"
      @on-selection-change="selectIndex"
    ></Table>
    <div style="width: 1500px;">
      <Button style="float:left" class="m20" type="primary" @click="showBatchPut">批量投放</Button>
      <Button
        style="float:left;margin-left: 10px"
        class="m20"
        type="error"
        @click="batchRemove"
      >批量删除</Button>
      <Page
        style="float: right;margin-top: 20px"
        :total="Number(pageTotal)"
        show-total
        @on-change="handlePage"
      ></Page>
    </div>
    <!-- edit adv -->
    <Modal v-model="showEditAdv" :title="editTitle" @on-cancel="stopVideo" style="width:560px;">
      <div class="input-row">
        <span>广告标题：</span>
        <Input
          v-model="editAdvinfo.title"
          placeholder="输入广告标题"
          style="width: 300px; margin-bottom: 10px; "
        />
      </div>
      <div class="input-row">
        <span>投放地区：</span>
        <Cascader
          :data="cityList"
          v-model="cityValue"
          change-on-select
          style="display: inline-block; width:300px; margin-bottom: 10px;"
        ></Cascader>
      </div>
      <div v-if="showEditAdv" class="input-row">
        <span>指定店铺：</span>
        <Select
          @on-change='setShopid'
          style="width: 150px;margin: 0 10px 10px 0;"
          v-model="editAdvinfo.name"
          filterable
          remote
          :remote-method="searchShop"
          :loading="loading"
        >
          <Option
            v-for="(option, index) in shopList"
            :value="option.name"
            :key="index"
          >{{option.label}}</Option>
        </Select>
        <span>{{editAdvinfo.shop_id?editAdvinfo.shop_name:'未指定到店铺'}}</span>
      </div>
      <div class="input-row">
        <span>播放日期：</span>
        <DatePicker
          v-model="start_time"
          type="date"
          :options="dateOptions"
          placeholder="选择开始时间"
          style="width: 120px"
        ></DatePicker>-
        <DatePicker
          v-model="end_time"
          type="date"
          :options="dateOptions"
          placeholder="选择结束时间"
          style="width: 120px"
        ></DatePicker>
      </div>
      <div class="input-row">
        <span>广告排序：</span>
        <Input
          v-model="editAdvinfo.sort"
          placeholder="输入排序序号"
          style="width: 100px; margin: 10px 0;"
        />
      </div>
      <div class="input-row">
        <span>广告状态：</span>
        <!-- <RadioGroup v-model="editAdvinfo.status" type="button" style="margin: 0 10px 10px 0;">
                  <Radio label="1">开启</Radio>
                  <Radio label="0">关闭</Radio>
        </RadioGroup>-->
        <i-switch @on-change="switchStaro" v-model="formItemswitch" size="large">
          <span slot="open">开启</span>
          <span slot="close">关闭</span>
        </i-switch>
      </div>
      <div class="input-row">
        <span>文件上传：</span>
        <Upload
          style="display:inline-block;margin-bottom: 10px;"
          action="/"
          :before-upload="beforeUpload"
        >
          <Button icon="ios-cloud-upload-outline">点击上传</Button>
          <span class="input-row-tips">请选择要上传的广告图片，分辨率为1920x1080，大小为1M以内，图片只能为jpg、png格式</span>
        </Upload>
        <Progress v-if="percent" :percent="percent" status="active" />
      </div>
      <div class="input-row">
        <span>广告预览：</span>
        <br />
        <video
          id="ad-video"
          v-if="isVideo"
          style="margin-top: 5px; width: 480px; height: 250px;"
          controls
          :src="adPath"
          :type="editAdvinfo.type"
        >
          <!-- <source :src="adPath" :type="editAdvinfo.type"> -->
          文件错误
        </video>
        <div v-if="isImage">
          <img style="max-width:100%; margin-top: 5px;; " :src="adPath" />
        </div>
      </div>

      <div slot="footer">
        <Button type="text" size="large" @click="stopVideo();showEditAdv = false">取消</Button>
        <Button type="primary" size="large" @click="saveAd">确定</Button>
      </div>
    </Modal>
    <!-- 批量上传 -->
    <Modal v-model="allAdv" title="批量投放">
      <div>
        <span>投放地区：</span>
        <Cascader
          :data="cityList"
          v-model="cityValue"
          change-on-select
          style="display: inline-block; width:300px; "
        ></Cascader>
      </div>
      <div style="margin-top: 10px;">
        <span>指定店铺：</span>
        <Select
          @on-query-change="searchShop"
           @on-change='addShopId'
          style="width: 220px;"
          v-model="batchShopId"
          filterable
          remote
          :remote-method="searchShop"
          :loading="loading"
        >
          <Option
            v-for="(option, index) in shopList"
            :value="option.value"
            :key="index"
          >{{option.label}}</Option>
        </Select>
      </div>

      <div slot="footer">
        <Button type="text" size="large" @click="allAdv = false">取消</Button>
        <Button type="primary" size="large" @click="batchPut">确定</Button>
      </div>
    </Modal>
  </div>
</template>
<script>
import dayjs from 'dayjs'
import { getQnDomain, uploadFile } from '@/libs/upload'
import { nowTime, getDate } from '@/libs/tools'
import {
  allCity,
  editadvTablesButtom,
  deleteAdvButtom,
  getadvTablesButtom,
  handlePageAdv,
  handleSearchAdv,
  addAdvTablesButtom,
  allAdvbuttom,
  searchShopsButtom
} from '@/api/data'

export default {
  data() {
    return {
      advTableinfo: [],
      columns7: [
        {
          type: 'selection',
          width: 50,
          align: 'center'
        },
        {
          title: 'ID',
          key: 'id',
          width: 80,
          align: 'center',
          sortable: true,
          render: (h, params) => {
            return h('div', [h('strong', params.row.id)])
          }
        },
        {
          title: '标题',
          key: 'title',
          align: 'center',
          width: 220,
          tooltip: true
        },
        {
          title: '类型',
          key: 'title',
          width: 80,
          align: 'center',
          render: (h, params) => {
            let text = ''
            if (params.row.type.indexOf('video') === 0) text = '视频'
            else if (params.row.type.indexOf('image') === 0) text = '图片'
            return h('div', [h('strong', text)])
          }
        },
        {
          title: '投放地区',
          key: 'prov_name',
          width: 180,
          align: 'center',
          render: (h, params) => {
            let arr = []
            if (params.row.prov_name) arr.push(params.row.prov_name)
            if (params.row.city_name) arr.push(params.row.city_name)
            if (params.row.zone_name) arr.push(params.row.zone_name)
            return h('div', arr.join('-'))
          }
        },
        {
          title: '投放店铺',
          key: 'shop_name',
          width: 220,
          align: 'center',
          tooltip: true,
          render: (h, params) => {
            const nameText = params.row.shop_name
            if (!nameText) {
              params.row.shop_name = '无'
            }
            return h('div', [h('strong', params.row.shop_name)])
          }
        },
        {
          title:'投放时间',
          key:'start_time',
          align: 'center',
          render: (h, params) => {
            return (
              <span>{ dayjs(params.row.start_time * 1000).format('YYYY-MM-DD') }</span>
            )
          }
        },
        {
          title:'结束时间',
          align: 'center',
          key:'end_time',
          render: (h, params) => {
            return (
              <span>{ dayjs(params.row.end_time * 1000).format('YYYY-MM-DD') }</span>
            )
          }
        },
        {
          title: '状态',
          key: 'status',
          width: 80,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h('strong', params.row.status == 1 ? '开启' : '关闭')
            ])
          }
        },
        {
          title: '排序',
          key: 'sort',
          align: 'center',
          width: 80,
          render: (h, params) => {
            return h('div', [h('strong', params.row.sort)])
          }
        },
        // 操作事件
        {
          title: '编辑',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.showEdit(params.index)
                    }
                  }
                },
                '修改'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      requestParam: {
        title: '',
        page: 1,
        rows: 10,
        sort: { sort: 'asc', id: 'desc',end_time:'desc' }
      },
      // 添加挂载
      cityList: [],
      cityValue: [],
      // 修改挂载
      showEditAdv: false,
      isVideo: false,
      isImage: false,
      editTitle: '',
      cityinfoEdit: [],
      editAdvinfo: {
        title:'',
        name:'',

      },
      // 批量投放
      allAdv: false,
      allAdvinfo: '',
      loading: false,
      adPath: '',
      percent: 0,
      searchShopId: '',
      shopList: [],
      loading: false,
      start_time: '',
      end_time: '',
      dateOptions: {
        disabledDate(date) {
          return date && date.valueOf() < Date.now() - 86400000
        }
      },
      selectIds: [],
      batchShopId: 0,
      pageTotal: 0,
      formItemswitch: false
    }
  },
  methods: {
    // 弹出添加广告窗口
    showAdd() {
      this.editTitle = '添加广告'
      this.editAdvinfo = {}
      this.cityValue = []
      this.isVideo = false
      this.isImage = false
      this.adPath = ''
      this.showEditAdv = true
      this.start_time = ''
      this.end_time = ''
      this.batchShopId = ''
      this.searchShop()
    },
    // 弹出编辑广告窗口
    async showEdit(index) {
      this.editTitle = '修改广告'
      this.editAdvinfo = Object.assign({}, this.advTableinfo[index])
      this.editAdvinfo.status == 0
        ? (this.formItemswitch = false)
        : (this.formItemswitch = true)
      this.editAdvinfo.status = this.editAdvinfo.status.toString()
      console.log(this.editAdvinfo.start_time, 'zhibi', this.start_time)
      if (this.editAdvinfo.start_time) {
        this.start_time = new Date(this.editAdvinfo.start_time * 1000)
      } else this.start_time = '0'
      if (this.editAdvinfo.end_time) {
        this.end_time = new Date(this.editAdvinfo.end_time * 1000)
      } else this.end_time = '0'
      this.cityValue = []
      this.cityValue[0] = this.editAdvinfo.prov
      this.cityValue[1] = this.editAdvinfo.city
      this.cityValue[2] = this.editAdvinfo.zone

      this.isVideo =
        this.editAdvinfo.path &&
        this.editAdvinfo.type &&
        this.editAdvinfo.type.indexOf('video') == 0
      this.isImage =
        this.editAdvinfo.path &&
        this.editAdvinfo.type &&
        this.editAdvinfo.type.indexOf('image') == 0
      await getQnDomain().then(res => {
        this.adPath = res + '/' + this.editAdvinfo.path
      })
      if (this.editAdvinfo.status == 1) {
        this.formItemswitch = true
      } else if (this.editAdvinfo.status == 2) {
        this.formItemswitch = false
      }
      this.showEditAdv = true
    },
    // 停止播放广告视频
    stopVideo() {
      if (
        this.editAdvinfo.type &&
        this.editAdvinfo.type.indexOf('video') === 0
      ) {
        let v = document.getElementById('ad-video')
        v.currentTime = 0
        v.pause()
      }
    },
    // 将广告移到回收站
    remove(index) {
      this.$Modal.confirm({
        title: '删除广告',
        content: '<p>您确定要删除吗？</p>',
        onOk: () => {
          const deleteAdvinfo = {
            id: this.advTableinfo[index].id
          }
          deleteAdvButtom(deleteAdvinfo)
            .then(response => {
              this.$Message.info(response.data.message)
              this.getadvTables()
            })
            .catch(error => {
              this.$Message.info(error)
            })
        },
        onCancel: () => {
          this.$Message.info('取消了删除操作')
        }
      })
    },
    // 勾选时获取已勾选的数据的ID
    selectIndex(selection) {
      this.selectIds = []
      selection.forEach(item => {
        this.selectIds.push(item.id)
      })
    },
    // 获取广告分页
    handlePage(value) {
      this.requestParam.page = value
      this.getadvTables()
    },
    // 获取广告列表
    getadvTables() {
      getadvTablesButtom(this.requestParam)
        .then(response => {
          this.pageTotal = Number(response.data.data.total)
          this.advTableinfo = response.data.data.list
        })
        .catch(error => {})
    },
    // 保存广告
    saveAd() {
      console.log(this.start_time, 11, this.editAdvinfo.start_time)
      this.editAdvinfo.start_time = this.start_time
        ? parseInt(this.start_time.getTime() / 1000)
        : 0
      this.editAdvinfo.end_time = this.end_time
        ? parseInt(this.end_time.getTime() / 1000)
        : 0
      if (!this.editAdvinfo.title) {
        this.$Message.info({
          content: '广告标题不能为空',
          duration: 5,
          closable: true
        })
      } else if (!this.editAdvinfo.path) {
        this.$Message.info({
          content: '广告文件不能为空',
          duration: 5,
          closable: true
        })
      } else if (!this.editAdvinfo.type) {
        this.$Message.info({
          content: '广告文件类型不能为空',
          duration: 5,
          closable: true
        })
      } else if (
        this.start_time &&
        this.end_time &&
        this.start_time > this.end_time
      ) {
        this.$Message.info({
          content: '开始时间不能大于或等于结束时间',
          duration: 5,
          closable: true
        })
      } else {
        this.editAdvinfo.terminal_type = 1
        this.editAdvinfo.prov = this.cityValue[0] ? this.cityValue[0] : 0
        this.editAdvinfo.city = this.cityValue[1] ? this.cityValue[1] : 0
        this.editAdvinfo.zone = this.cityValue[2] ? this.cityValue[2] : 0
        delete this.editAdvinfo.create_time
        delete this.editAdvinfo.update_time
        console.log('触发事件')
        editadvTablesButtom(this.editAdvinfo)
          .then(response => {
            this.$Message.info({
              content: response.data.message,
              duration: 5,
              closable: true
            })
            this.getadvTables()
            setTimeout(() => {
              this.showEditAdv = false
            }, 1000)
          })
          .catch(error => {
            this.$Message.info({
              content: error,
              duration: 10,
              closable: true
            })
          })
      }
      return false
    },
    // 搜索广告
    handleSearchAdv() {
      this.getadvTables()
    },
    // 获取全国地区
    getCityList() {
      const allCityinfo = {}
      allCity(allCityinfo)
        .then(response => {
          this.cityList = response.data.data
        })
        .catch(error => {})
    },
    beforeUpload(file) {
      let path = 'ad'
      if(file.size > 2 * 1024 * 1024) {
       this.$Message.info({
          content: '文件大小不能大于2M',
          duration: 5,
          closable: true
        })
        return
      }
      if (
        file.type.indexOf('video') !== 0 &&
        file.type.indexOf('image') !== 0
      ) {
        this.$Message.info({
          content: '广告文件类型不正确，请上传视频或图片',
          duration: 5,
          closable: true
        })
      } else {
        uploadFile('ad', file, path, percent => {
          // 上传进度回调
          this.percent = parseInt(percent.percent)
          if (this.percent == 100) this.percent = 0
        }).then(res => {
          // 上传结果
          this.editAdvinfo.type = file.type
          this.editAdvinfo.path = res.key
          getQnDomain().then(domain => {
            if (file.type.indexOf('video') === 0) {
              this.isVideo = true
              this.isImage = false
            } else if (file.type.indexOf('image') === 0) {
              this.isImage = true
              this.isVideo = false
            }
            this.adPath = domain + '/' + this.editAdvinfo.path
          })
        })
      }
      return false
    },
    // 批量将广告移到回收站
    batchRemove() {
      if (this.selectIds.length === 0) {
        this.$Message.info('请选择要删除的数据')
        return false
      }
      this.$Modal.confirm({
        title: '删除广告',
        content: '<p>您确定要删除吗？</p>',
        onOk: () => {
          const deleteAdvinfo = {
            id: this.selectIds.join(',')
          }
          deleteAdvButtom(deleteAdvinfo)
            .then(response => {
              this.$Message.info(response.data.message)
              this.getadvTables()
            })
            .catch(error => {
              this.$Message.info(error)
            })
        },
        onCancel: () => {
          this.$Message.info('取消了删除操作')
        }
      })
    },
    showBatchPut() {
      this.cityValue = []
      if (this.selectIds.length === 0) {
        this.$Message.info('请选择要批量投放的广告')
        return false
      }
      this.allAdv = true
    },
    batchPut() {
      if (this.cityValue.length === 0 && !this.batchShopId) {
        this.$Message.info('请选择要批量投放的地区')
        return false
      }
      let allAdvinfos = {
        id: this.selectIds.join(',')
      }
      if (this.cityValue[0]) allAdvinfos.prov = this.cityValue[0]
      if (this.cityValue[1]) allAdvinfos.city = this.cityValue[1]
      if (this.cityValue[2]) allAdvinfos.zone = this.cityValue[2]
      allAdvinfos.shop_id = this.batchShopId ? this.batchShopId : 0

      allAdvbuttom(allAdvinfos)
        .then(response => {
          if (response.data.code == 5) {
            this.getadvTables()
            this.$Message.info({
              content: response.data.message,
              duration: 5,
              closable: true
            })
            setTimeout(() => {
              this.allAdv = false
            }, 1000)
          }
        })
        .catch(error => {
          this.$Message.info({
            content: error,
            duration: 5,
            closable: true
          })
        })
    },
    // 远程搜索
    searchShop(query) {
      if(query === undefined) query = ''
      let searchList = []
      if (query !== '') {
        const searchShopsinfo = {
          name: query
        }
        // if (this.cityValue[0]) searchShopsinfo.prov = this.cityValue[0]
        // if (this.cityValue[1]) searchShopsinfo.city = this.cityValue[1]
        // if (this.cityValue[2]) searchShopsinfo.zone = this.cityValue[2]

        this.loading = true
        searchShopsButtom(searchShopsinfo)
          .then(response => {
            searchList = response.data.data
            setTimeout(() => {
              this.loading = false
              let list = searchList.map(item => {
                return {
                  value: item.id,
                  label: item.name
                }
              })
              this.shopList = list.filter(
                item =>
                  item.label.toLowerCase().indexOf(query.toLowerCase()) > -1
              )
            }, 200)
          })
          .catch(error => {
            console.error(error)
          })
      } else {
        this.shopList = []
      }
    },
    setShopid(res){
      this.editAdvinfo.shop_id = this.shopList[0].value
    },
    addShopId(res){
      console.log(res,'111')
    },
    // 滑块
    switchStaro(vlaue) {
      if (vlaue) {
        this.editAdvinfo.status = 1
      } else {
        this.editAdvinfo.status = 0
      }
    }
  },
  mounted() {
    this.getadvTables()
    this.getCityList()
  }
}
</script>
<style>
.adminTitle {
  font-size: 18px;
  font-weight: bold;
}
.m20 {
  margin: 20px 0;
}
.inline-div {
  display: inline-block;
  margin: 0 10px;
}
.search-title {
  font-size: 14px;
}
.input-row {
  margin: 10px 20px;
}
.input-row-tips{
  margin-top: 12px;
  display: inline-block;
  font-size: 14px;
}
</style>
