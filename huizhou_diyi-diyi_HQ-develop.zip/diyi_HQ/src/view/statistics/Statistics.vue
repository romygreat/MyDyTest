<template>
  <div class="statistics">
    <header>
      <h3>商家营业流水统计</h3>
      <div class="search">
        <img :src="search" alt />
        <span>筛选查询</span>
      </div>
      <div class="search-menu">
        <div class="name">
          <span>商家名称：</span>
          <Input
            clearable
            v-model="requestParam.name"
            icon="search"
            placeholder="输入你要查询的店铺名称"
            style="width: 200px; display: inline-block"
          />
        </div>
        <div class="time">
          <Col span="12">
            <DatePicker
              type="daterange"
              v-model="day"
              confirm
              placement="bottom-end"
              placeholder="请选择时间"
              style="width: 200px"
            ></DatePicker>
          </Col>
        </div>
        <div class="date">
          <ul>
            <li
              v-for="(item, index) in searchMenu"
              :key="index"
              @click="useIndex=index;checkTime(item.title)"
              :class="useIndex==index?'active':''"
            >{{item.title}}</li>
          </ul>
        </div>
        <div class="search-btn">
          <Button
            style="display: inline-block; margin-top:-2px ;"
            @click="getSearch()"
            type="primary"
          >搜索</Button>
        </div>
      </div>
    </header>
    <section>
      <Table border :columns="statisticsColumns" :data="statisticsList">
        <!-- <template slot-scope="{ row }" slot="name">
            <strong>{{ row.name }}</strong>
        </template> -->
      </Table>
    </section>
  </div>
</template>
<script>
import search from '@/assets/images/search.png'
import { statisticsList } from '@/api/statistics'
import Calc from 'number-precision'
export default {
  data() {
    return {
      search,
      searchMenu: [
        { title: '今天', index: 1 },
        { title: '昨天', index: 2 },
        { title: '本周', index: 3 },
        { title: '本月', index: 4 },
        { title: '近7天', index: 5 }
      ],
      day: '',
      requestParam: {
        day: ''
      },
      statisticsColumns: [
        {
          title: '编号',
          key: 'shop_id'
        },
        {
          title: '商家名称',
          key: 'shop_name'
        },
        {
          title: '营业实收金额（元）',
          key: 'amount'
        },
        {
          title: '现金支付（元）',
          key: 'cash'
        },
        {
          title: '龙支付（元）',
          key: 'dragon'
        },
        {
          title: '微信支付（元）',
          key: 'wechat'
        },
        {
          title: '支付宝（元）',
          key: 'alipay'
        },
        {
          title: '消费人数（人）',
          key: 'consumer'
        },
        {
          title: '账单数（笔）',
          key: 'bill'
        }
        // {
        //   title: '设备数（台）',
        //   key: 'address'
        // },
        // {
        //   title: '投放日期',
        //   key: 'address'
        // }
      ],
      statisticsList: [],
      useIndex: ''
    }
  },
  methods: {
    searchDate(mon1, mon2, day1, day2) {
      let dateTime = new Date()
      console.log(dateTime)

      if (mon1 == '' || mon1 == undefined) {
        mon1 = dateTime.getMonth() + 1
      } else {
        mon1 = mon1 + 1
      }
      if (mon2 == '' || mon2 == undefined) {
        mon2 = dateTime.getMonth() + 1
      } else {
        mon2 = mon2 + 1
      }
      if (day1 == '' || day1 == undefined) {
        day1 = dateTime.getDate()
      }
      if (day2 == '' || day2 == undefined) {
        day2 = dateTime.getDate()
      }

      return (
        dateTime.getFullYear() +
        '-' +
        mon1 +
        '-' +
        day1 +
        ' - ' +
        dateTime.getFullYear() +
        '-' +
        mon2 +
        '-' +
        day2
      )
    },
    checkTime(value) {
      let dateTime = new Date()
      switch (value) {
        case '今天':
          this.requestParam.day = this.searchDate()
          break
        case '昨天':
          this.requestParam.day = this.searchDate(
            '',
            '',
            dateTime.getDate() - 1,
            dateTime.getDate() - 1
          )
          break
        case '本周':
          this.requestParam.day = this.searchDate(
            '',
            '',
            dateTime.getDate(),
            dateTime.getDate() - dateTime.getDay()
          )
          break
        case '本月':
          this.requestParam.day = this.searchDate(
            dateTime.getMonth(),
            dateTime.getMonth(),
            1,
            dateTime.getDate()
          )
          break
        case '近7天':
          this.requestParam.day = this.searchDate(
            '',
            '',
            dateTime.getDate() - 7,
            dateTime.getDate()
          )
          break

        default:
          break
      }
      console.log(this.requestParam.day)

      this.getList()
    },
    getSearch() {
      this.useIndex = -1
      if (this.day[0] != '' && this.day[1] != '') {
        let time1 = new Date(this.day[0])
        let time2 = new Date(this.day[1])
        time1.year = new Date(this.day[0]).getFullYear()
        time1.mon = new Date(this.day[0]).getMonth() + 1
        time1.day = new Date(this.day[0]).getDate()
        time2.year = new Date(this.day[1]).getFullYear()
        time2.mon = new Date(this.day[1]).getMonth() + 1
        time2.day = new Date(this.day[1]).getDate()
        this.requestParam.day =
          time1.year +
          '-' +
          time1.mon +
          '-' +
          time1.day +
          ' - ' +
          time2.year +
          '-' +
          time2.mon +
          '-' +
          time2.day
        console.log(this.requestParam.day, '时间')

        this.getList()
      }
    },
    getList() {
      statisticsList(this.requestParam).then(res => {
        if (res.data.code == 1) {
          this.statisticsList = res.data.data
          
          for (let i = 0; i < this.statisticsList.length; i++) {            
            this.statisticsList[i].amount = this.transformRMB(this.statisticsList[i].amount)
            this.statisticsList[i].alipay = this.transformRMB(this.statisticsList[i].alipay)
            this.statisticsList[i].wechat = this.transformRMB(this.statisticsList[i].wechat)
            this.statisticsList[i].cash = this.transformRMB(this.statisticsList[i].cash)
            this.statisticsList[i].dragon = this.transformRMB(this.statisticsList[i].dragon)
            this.statisticsList[i].shop_name = this.statisticsList[i].shop.name
          }
          console.log(this.statisticsList);

        } else {
          this.statisticsList = []
        }
      })
    },
    insertStr(soure, start, newStr) {
      if (start === -1) {
        return Number(0) + newStr + 0 + soure.slice(start)
      } else {
        return Number(soure.slice(0, start) + newStr + soure.slice(start))
      }
    },
    Twopoints(numberinfo) {
      var numberinfo = parseInt(Calc.times(numberinfo, 100)).toString()
      return this.insertStr(numberinfo, numberinfo.length - 2, '.')
    },
    transformRMB(value){
      return this.Twopoints(Calc.divide(value, 100))
    },
    
  },
  mounted() {
    this.checkTime('今天')
  }
}
</script>
<style lang="less">
@import url('./Statistics.less');
.active {
  color: #2d8cf0;
}
</style>