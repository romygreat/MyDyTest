import axios from '@/libs/api.request'

export const QINIU_DOMAIN_KEY = 'qiniu_domain'
export const getQiniuUpToken = (obj) => {
  if (!obj) obj = 'ad'
  let data = { obj }
  return axios.request({
    url: '/qiniu/Upload/getUptoken',
    data
  })
}

export const getQiniuDomain = (obj) => {
  if (!obj) obj = 'ad'
  let data = { obj }
  return axios.request({
    url: '/qiniu/Upload/getDomain',
    data
  })
}
