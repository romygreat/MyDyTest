import axios from '@/libs/api.request'
// 保存管理员信息
export const statisticsList = data => {
  return axios.request({
    url: '/statistics/Statistics/businessFlow',
    data: data,
    method: 'post'
  })
}
