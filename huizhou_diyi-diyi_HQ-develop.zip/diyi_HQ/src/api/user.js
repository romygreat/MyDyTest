import axios from '@/libs/api.request'

export const login = ({ userName, password }) => {
  const data = {
    account: userName,
    pwd: password,
    terminal_domain: 'hq.gddiyi.com'
  }
  return axios.request({
    url: '/account/Login/userLogin',
    data,
    method: 'post'
  })
}

export const logout = (token) => {
  const data = {
    token
  }
  return axios.request({
    url: '/account/Login/userLogout',
    data,
    method: 'post'
  })
}

// export const getAdminInfo = (token) => {
//   const data = {
//     token
//   }
//   return axios.request({
//     url: '/account/Account/getAdminInfo',
//     data,
//     method: 'post'
//   })
// }
export const getAdminInfo = () => {
  return axios.request({
    url: '/account/Account/getAdminInfo'
  })
}

export const modifyPwd = (data) => {
  return axios.request({
    url: '/account/Account/modifyPwd',
    data,
    method: 'post'
  })
}
