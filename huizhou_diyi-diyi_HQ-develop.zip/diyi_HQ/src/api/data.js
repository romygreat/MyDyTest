import axios from '@/libs/api.request'
export const getTableData = () => {
  return axios.request({
    url: 'get_table_data',
    method: 'get'
  })
}

export const getDragList = () => {
  return axios.request({
    url: 'get_drag_list',
    method: 'get'
  })
}

export const errorReq = () => {
  return axios.request({
    url: 'error_url',
    method: 'post'
  })
}

// 保存管理员信息
export const saveAdmin = addAdminsinfo => {
  return axios.request({
    url: '/account/Auth/saveAdmin',
    data: addAdminsinfo,
    method: 'post'
  })
}
// 管理员搜索
export const Searchbuttom = searinfo => {
  return axios.request({
    url: '/account/Auth/index',
    data: searinfo,
    method: 'post'
  })
}

// 删除管理员
export const deleteAdminButtom = deleteAdmininfo => {
  return axios.request({
    url: '/account/Auth/del',
    data: deleteAdmininfo,
    method: 'post'
  })
}
// 编辑管理员
export const setAdminButtom = setAdmininfo => {
  return axios.request({
    url: '/account/Auth/edit',
    data: setAdmininfo,
    method: 'post'
  })
}
// 获取角色组
export const getRoleListButtom = getRoleListinfo => {
  return axios.request({
    url: '/account/Role/index',
    data: getRoleListinfo,
    method: 'post'
  })
}
// 获取管理员列表
export const getAdminTablesButtom = getAdminTablesinfo => {
  return axios.request({
    url: '/account/Auth/index',
    data: getAdminTablesinfo,
    method: 'post'
  })
}
// 获取管理员分类
export const getpageadminButtom = getpageadmininfo => {
  return axios.request({
    url: '/account/Auth/index',
    data: getpageadmininfo,
    method: 'post'
  })
}
// 获取管理员分页
export const handlePageButtom = handlePageinfo => {
  return axios.request({
    url: '/account/Auth/index',
    data: handlePageinfo,
    method: 'post'
  })
}
// 获取角色组分页
export const handlePageeButtomRole = handlePageinfo => {
  return axios.request({
    url: '/account/Role/index',
    data: handlePageinfo,
    method: 'post'
  })
}
// 获取角色组列表
export const getRoleTablesButtom = getRoleTableinfo => {
  return axios.request({
    url: '/account/Role/index',
    data: getRoleTableinfo,
    method: 'post'
  })
}
// 修改角色组名称
export const saveRoleInfo = setRoleinfo => {
  return axios.request({
    url: '/account/Role/saveRole',
    data: setRoleinfo,
    method: 'post'
  })
}
// 添加角色组
export const listPermission = data => {
  return axios.request({
    url: '/account/Permission/getAuth',
    data
  })
}
// 搜索角色组
export const handleSearchRole = handleSearchinfo => {
  return axios.request({
    url: '/account/Role/index',
    data: handleSearchinfo,
    method: 'post'
  })
}
// 获取角色列表，下拉列表使用
export const listSelectRole = () => {
  return axios.request({
    url: '/account/Role/listSelectRole'
  })
}
// 删除角色组
export const delRoleButtom = delRole => {
  return axios.request({
    url: '/account/Role/del',
    data: delRole,
    method: 'post'
  })
}
// 获取广告列表
export const getadvTablesButtom = getadvTablesinfo => {
  return axios.request({
    url: '/advert/Ad/index',
    data: getadvTablesinfo,
    method: 'post'
  })
}
// 获取广告分页
export const handlePageAdv = handlePageinfo => {
  return axios.request({
    url: '/advert/Ad/index',
    data: handlePageinfo,
    method: 'post'
  })
}
// 添加广告
export const addAdvTablesButtom = addAdvTablesinfo => {
  return axios.request({
    url: '/advert/Ad/add',
    data: addAdvTablesinfo,
    method: 'post'
  })
}
//  删除广告
export const deleteAdvButtom = deleteAdvinfo => {
  return axios.request({
    url: '/advert/Ad/del',
    data: deleteAdvinfo,
    method: 'post'
  })
}
// 搜索广告
export const handleSearchAdv = handleSearchAdvinfo => {
  return axios.request({
    url: '/advert/Ad/index',
    data: handleSearchAdvinfo,
    method: 'post'
  })
}
// 修改广告
export const editadvTablesButtom = editadvTablesinfo => {
  return axios.request({
    url: editadvTablesinfo.id ? '/advert/Ad/edit' : '/advert/Ad/add',
    data: editadvTablesinfo,
    method: 'post'
  })
}
// 广告回收站
export const getRecTablesButtom = getRecTablesinfo => {
  return axios.request({
    url: '/advert/Ad/index',
    data: getRecTablesinfo,
    method: 'post'
  })
}
// 广告回收站还原
export const reductionAdv = reductionAdvinfo => {
  return axios.request({
    url: '/advert/Ad/restore',
    data: reductionAdvinfo,
    method: 'post'
  })
}
// 广告彻底删除
export const truedel = truedelinfo => {
  return axios.request({
    url: '/advert/Ad/del',
    data: truedelinfo,
    method: 'post'
  })
}
// 批量投放
export const allAdvbuttom = allAdvinfos => {
  return axios.request({
    url: '/advert/Ad/batch',
    data: allAdvinfos,
    method: 'post'
  })
}
// 获取门店列表
export const getShopTablesButtom = getShopTablesinfo => {
  return axios.request({
    url: '/shop/shop/listShop',
    data: getShopTablesinfo,
    method: 'post'
  })
}
// 添加门店信息
export const addShopTablesButtom = addShopTablesinfo => {
  return axios.request({
    url: '/shop/shop/saveShop',
    data: addShopTablesinfo,
    method: 'post'
  })
}
// 删除门店
export const deleteShopTablesButtom = deleteShopTablesinfo => {
  return axios.request({
    url: '/shop/shop/deleteShop',
    data: deleteShopTablesinfo,
    method: 'post'
  })
}
// 门店还原
export const reductionShopButtom = reductionShopinfo => {
  return axios.request({
    url: '/shop/shop/restoreShop',
    data: reductionShopinfo,
    method: 'post'
  })
}
// 搜索门店
export const handleSearchShop = handleSearchinfo => {
  return axios.request({
    url: '/shop/shop/listShop',
    data: handleSearchinfo,
    method: 'post'
  })
}
// 获取全国地区
export const allCity = allCityinfo => {
  return axios.request({
    url: '/area/Region/getRegion',
    data: allCityinfo,
    method: 'post'
  })
}
// 设备列表
export const machineTablesButtom = machineTablesinfo => {
  return axios.request({
    url: '/device/Machine/listMachine',
    data: machineTablesinfo,
    method: 'post'
  })
}
// 设备回收站
export const macRecButtom = data => {
  return axios.request({
    url: '/device/Machine/listMachine',
    data,
    method: 'post'
  })
}
// 查询设备
export const handleSearchMac = handleSearchinfo => {
  return axios.request({
    url: '/device/Machine/listMachine',
    data: handleSearchinfo,
    method: 'post'
  })
}
// 删除设备
export const delMachineButtom = delMachineinfo => {
  return axios.request({
    url: '/device/Machine/delMachine',
    data: delMachineinfo,
    method: 'post'
  })
}
// 还原设备
export const restoreMachineButtom = data => {
  return axios.request({
    url: '/device/Machine/restoreMachine',
    data
  })
}
// 修改设备
export const editMacineButtom = editMacineinfo => {
  return axios.request({
    url: '/device/Machine/saveMachine',
    data: editMacineinfo,
    method: 'post'
  })
}
// 批量上传
export const uploadExcelButtom = uploadExcelinfo => {
  return axios.request({
    url: '/device/Machine/importMachine',
    data: uploadExcelinfo,
    method: 'post'
  })
}
// 获取操作日志
export const getOperTablesButoom = getOperTablesinfo => {
  return axios.request({
    url: '/account/ActionLog/listLogs',
    data: getOperTablesinfo,
    method: 'post'
  })
}
// 获取操作日志详情
export const operinfotext = info => {
  return axios.request({
    url: '/account/ActionLog/details',
    data: info,
    method: 'post'
  })
}
// 远程搜索
export const searchShopsButtom = searchShopsinfo => {
  return axios.request({
    url: '/shop/shop/searchShop',
    data: searchShopsinfo,
    method: 'post'
  })
}
// 批量绑定
export const allMachBangdingButtom = allMachBangdinginfo => {
  return axios.request({
    url: '/device/Machine/matchMachine',
    data: allMachBangdinginfo,
    method: 'post'
  })
}
// 商家端名称跳转
export const assistShopButtom = data => {
  return axios.request({
    url: '/shop/shop/assistShop',
    data
  })
}

// 全局储存状态
export const getStatus = data => {
  return axios.request({
    url: '/status/text/getStatusText',
    data
  })
}
