import Main from '@/components/main'

export default [
  {
    path: '/login',
    name: 'login',
    meta: {
      title: '登录',
      hideInMenu: true
    },
    component: () => import('@/view/login/login.vue')
  },
  {
    path: '/',
    name: '_home',
    redirect: '/home',
    component: Main,
    meta: {
      hideInMenu: true,
      notCache: true
    },
    children: [
      {
        path: '/home',
        name: 'home',
        meta: {
          hideInMenu: true,
          title: '首页',
          notCache: true,
          icon: 'md-home'
        },
        component: () => import('@/view/single-page/home')
      }
    ]
  },
  {
    path: '/jurisdiction',
    name: 'jurisdiction',
    meta: {
      icon: 'md-contacts',
      title: '账号管理',
      access: '1000'
    },
    component: Main,
    children: [
      {
        path: 'admin-management',
        name: 'admin-management',
        meta: {
          icon: 'ios-contact-outline',
          title: '管理员管理',
          access: '1011'
        },
        component: () => import('@/view/jurisdiction/admin-management')
      },
      {
        path: 'role-group',
        name: 'role-group',
        meta: {
          icon: 'ios-people',
          title: '角色管理',
          access: '1021'
        },
        component: () => import('@/view/jurisdiction/role-group/role-group')
      }
    ]
  },
  {
    path: '/shop',
    name: 'shop',
    meta: {
      icon: 'ios-basket',
      title: '店铺管理',
      access: '2000'
    },
    component: Main,
    children: [
      {
        path: 'shop-admin',
        name: 'shop-admin',
        meta: {
          icon: 'ios-basket',
          title: '店铺列表',
          access: '2011'
        },
        component: () => import('@/view/shop/shop')
      },
      {
        path: 'shopRec',
        name: 'shopRec',
        meta: {
          icon: 'md-trash',
          title: '店铺回收站',
          access: '2012'
        },
        component: () => import('@/view/shop/shopRec')
      },
      {
        path: 'shopMachine',
        name: 'shopMachine',
        meta: {
          hideInMenu: true,
          notCache: true,
          title: '商家设备',
          icon: 'md-calculator'
        },
        component: () => import('@/view/shop/shopMachine')
      }
    ]
  },
  {
    path: '/ads',
    name: 'ads',
    meta: {
      icon: 'md-paper-plane',
      title: '广告管理',
      access: '3000'
    },
    component: Main,
    children: [
      {
        path: 'adv-admin',
        name: 'adv-admin',
        meta: {
          icon: 'ios-paper-plane-outline',
          title: '广告列表',
          access: '3001'
        },
        component: () => import('@/view/advertisement/advertisement')
      },
      {
        path: 'recovery',
        name: 'recovery',
        meta: {
          icon: 'md-trash',
          title: '广告回收站',
          access: '3002'
        },
        component: () => import('@/view/advertisement/recovery')
      }
    ]
  },
  {
    path: '/machine',
    name: 'machine',
    meta: {
      icon: 'ios-construct',
      title: '设备管理',
      access: '4000'
    },
    component: Main,
    children: [
      {
        path: 'export-excel',
        name: 'export-excel',
        meta: {
          icon: 'ios-create',
          title: '点餐机',
          access: '4001'
        },
        component: () => import('@/view/machine/export-excel')
      },
      // {
      //   path: 'printerSettings',
      //   name: 'printerSetting',
      //   meta: {
      //     icon: 'ios-create',
      //     title: '打印机',
      //     access: '4005'
      //   },
      //   component: () => import('@/view/machine/printer/printer.vue')
      //   // component: () => import('@/view/machine/printer/test.vue')
      // },
      {
        path: 'upload-excel',
        name: 'upload-excel',
        meta: {
          icon: 'ios-thunderstorm',
          title: '批量上传',
          access: '4002'
        },
        component: () => import('@/view/machine/upload-excel')
      },
      {
        path: 'macRec',
        name: 'macRec',
        meta: {
          icon: 'md-trash',
          title: '设备回收站',
          access: '4003'
        },
        component: () => import('@/view/machine/macRec')
      }
    ]
  },
  {
    path: '/statistics',
    name: 'statistics',
    meta: {
      hideInBread: true,
      access: '5000'
    },
    component: Main,
    children: [
      {
        path: 'shop_statistics',
        name: 'shop_statistics',
        meta: {
          icon: 'ios-pie',
          title: '统计管理',
          access: '5001'
        },
        component: () => import('@/view/statistics/Statistics')
      }
    ]
  },
  // {
  //   path: '/operation',
  //   name: 'operation',
  //   meta: {
  //     hideInBread: true,
  //     access: '5000'
  //   },
  //   component: Main,
  //   children: [
  //     {
  //       path: 'operationinfo',
  //       name: 'operationinfo',
  //       meta: {
  //         icon: 'md-clipboard',
  //         title: '操作日志',
  //         access: '6001'
  //       },
  //       component: () => import('@/view/operation/operation')
  //     }
  //   ]
  // },
  {
    path: '/printer',
    name: '/printer',
    meta: {
      icon: 'ios-print',
      title: '打印机',
      access: 6000
    },
    component: Main,
    children: [
      {
        path: 'printerList',
        name: 'printerList',
        meta: {
          icon: 'ios-print',
          title: '打印机管理',
          access: '6001'
        },
        component: () => import('@/view/printer/printerList')
      },
      {
        path: 'printerMenu',
        name: 'printerMenu',
        meta: {
          icon: 'ios-print',
          title: '打印机厂商',
          access: '6002'
        },
        component: () => import('@/view/printer/printerMenu')
      }
    ]
  },
  {
    path: '/401',
    name: 'error_401',
    meta: {
      hideInMenu: true
    },
    component: () => import('@/view/error-page/401.vue')
  },
  {
    path: '/500',
    name: 'error_500',
    meta: {
      hideInMenu: true
    },
    component: () => import('@/view/error-page/500.vue')
  },
  {
    path: '*',
    name: 'error_404',
    meta: {
      hideInMenu: true
    },
    component: () => import('@/view/error-page/404.vue')
  }
]
