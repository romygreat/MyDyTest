package com.gddiyi.aom.view;


import android.support.test.filters.LargeTest;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import javax.inject.Singleton;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class CrossWalkActivityTest {

    @Rule
    public ActivityTestRule<CrossWalkActivity> mActivityTestRule = new ActivityTestRule<>(CrossWalkActivity.class);

    @Test
    public void crossWalkActivityTest() {

    }
}
