package com.gddiyi.aom.model.dto;

import java.util.List;

public class ResponseUnbindTableList {

    /**
     * code : 1
     * message : 操作成功
     * data : [{"id":"357","title":"A003"},{"id":"362","title":"A02"},{"id":"363","title":"B01"},{"id":"366","title":"A009"}]
     */

    private int code;
    private String message;
    private List<DataBean> data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * id : 357
         * title : A003
         */

        private String id;
        private String title;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }
    }
}
