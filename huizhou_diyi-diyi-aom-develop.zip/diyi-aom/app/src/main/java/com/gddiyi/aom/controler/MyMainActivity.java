package com.gddiyi.aom.controler;

/**
 * 假MainActivity，在出错的时候进入主界面
 */
public class MyMainActivity extends NullPointerException {
    public MyMainActivity(String s) {
        super(s);
    }
    public static void goMyMainActivity(){
        MyMainActivity goMyMainActivity=new MyMainActivity("进入主界面");
        throw goMyMainActivity;

    }
}
