package com.gddiyi.aom.view;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.baidu.tts.client.SpeechSynthesizer;
import com.baidu.tts.client.TtsMode;
import com.bumptech.glide.Glide;
import com.gddiyi.aom.R;
import com.gddiyi.aom.YidiApplication;
import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.presenter.SpeechSynthesisPresenter;

/**
 * 此类在语音功能中弹出二维码，进行扫码使用
 */
public class QrCodeActivity extends BaseActivity {
    private static final int HANDLE_DELAY_MINTE = 1;
    ImageView qr_imageView;
    LinearLayout qrlinearLayout;
    Handler mHandler;
    SpeechSynthesisPresenter mSpeechSynthesisPresenter;
    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.showqr);
        qrlinearLayout=findViewById(R.id.qr_linearLayout);
        qr_imageView=findViewById(R.id.qr_iamgeView);
        mSpeechSynthesisPresenter=new SpeechSynthesisPresenter(getApplicationContext());
          Glide.with(this)
                .load
                (Uri.parse(VSConstances.QR_REQUEST_CODE))
                .into(qr_imageView);
        qrlinearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //点击退出二维码扫描
                QrCodeActivity.this.finish();
            }
        });
        mHandler=new Handler(getMainLooper()){
            @Override
            public void handleMessage(Message msg) {
                QrCodeActivity.this.finish();
            }
        };
        mHandler.sendEmptyMessageDelayed(HANDLE_DELAY_MINTE,VSConstances.TIME_UNIT_MIN);
    }


    @Override
    protected void onResume() {
        super.onResume();


    }

    @Override
    public void currentActivity() {
        ((YidiApplication)getApplication()).setCurrentActivityPage(VSConstances.QR_ACTIVITY);
    }


}
