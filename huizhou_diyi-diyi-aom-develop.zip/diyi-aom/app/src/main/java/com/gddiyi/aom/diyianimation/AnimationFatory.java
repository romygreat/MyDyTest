package com.gddiyi.aom.diyianimation;

import android.util.Log;

import com.gddiyi.aom.customview.EnterAnimLayout;

public class AnimationFatory {
    String TAG=getClass().getSimpleName();

    public static final int BaiYeChuang = 0;
    public static final int QieRu = 1;
    public static final int LunZi = 2;
    public static final int CaChu = 3;
    public static final int HeZhuang = 4;
    public static final int QiPan = 5;
    public static final int JieTi = 6;
    public static final int ZiXINFZHANKAI = 7;
    public static final int PAILIE =8 ;
    private static final int ANIMROTEANDSCALE =9 ;


    public static final int STYLE_COUNT =12;

    public AnimationFatory(int createAnim, EnterAnimLayout enterAnimLayout) {
        switch (createAnim) {
            case BaiYeChuang:
//                createAnimBaiYeChuang(enterAnimLayout);
                createAniCaChu(enterAnimLayout);
                Log.d(TAG, "AnimationFatory: BaiYeChuang");
                break;
            case QieRu:
//                createAnimQieRu(enterAnimLayout);
                createAniCaChu(enterAnimLayout);
                Log.d(TAG, "AnimationFatory:QieRu ");
                break;
            case LunZi:
                createAniCaChu(enterAnimLayout);
//                createAnimLunZi(enterAnimLayout);
                Log.d(TAG, "AnimationFatory: LunZi");
                break;
            case CaChu:
                createAniCaChu(enterAnimLayout);
                Log.d(TAG, "AnimationFatory: CaChu");
                break;
            case HeZhuang:
//                createAnimHeZhuang(enterAnimLayout);
                createAnimYuanXingKuoZhan(enterAnimLayout);
                Log.d(TAG, "AnimationFatory: HeZhuang");
                break;
            case QiPan:
//                createAnimQiPan(enterAnimLayout);
                createAnimYuanXingKuoZhan(enterAnimLayout);
                break;
            case JieTi:
//                createAnimJieti(enterAnimLayout);
                createAnimYuanXingKuoZhan(enterAnimLayout);
            break;
            case ZiXINFZHANKAI:
//                createAnimShanXingZhanKai(enterAnimLayout)
                createAniCaChu(enterAnimLayout);
                ;break;
            case PAILIE:
                createPaiLie(enterAnimLayout);
                //可以保留，排列
                Log.d(TAG, "AnimationFatory: ");
            break;
            case ANIMROTEANDSCALE:
                createAnimRoateAndScale(enterAnimLayout);
                Log.i("RoateAndScale", "AnimationFatory: ");
                break;
            case ANIMROTEANDSCALE+1:
                createAnimShiZiXingKuoZhan(enterAnimLayout);
                Log.i("RoateAndScale", "AnimationFatory: 2");
                break;
            case ANIMROTEANDSCALE+2:
              createLingXing(enterAnimLayout);
                Log.i("RoateAndScale", "AnimationFatory: 2");
                break;
            case ANIMROTEANDSCALE+3:
                createAnimYuanXingKuoZhan(enterAnimLayout);
                Log.i("RoateAndScale", "ANIMROTEANDSCALE+3 ");
                break;
            default:
                break;
        }
    }

    public static AnimQieRu createAnimQieRu(EnterAnimLayout enterAnimLayout) {
        AnimQieRu animQieRu = new AnimQieRu(enterAnimLayout);
        animQieRu.startAnimation();
        return animQieRu;
    }

    public static AnimBaiYeChuang createAnimBaiYeChuang(EnterAnimLayout enterAnimLayout) {
        AnimBaiYeChuang anim = new AnimBaiYeChuang(enterAnimLayout);
        anim.startAnimation();
        return anim;
    }

    public static AnimLunZi createAnimLunZi(EnterAnimLayout enterAnimLayout) {
        AnimLunZi anim = new AnimLunZi(enterAnimLayout);
        anim.startAnimation();
        return anim;
    }

    public static AnimCaChu createAniCaChu(EnterAnimLayout enterAnimLayout) {
        AnimCaChu animCaChu = new AnimCaChu(enterAnimLayout);
        animCaChu.startAnimation();
        return animCaChu;
    }

    public AnimHeZhuang createAnimHeZhuang(EnterAnimLayout enterAnimLayout) {
        AnimHeZhuang animHeZhuang = new AnimHeZhuang(enterAnimLayout);
        animHeZhuang.startAnimation();
        return animHeZhuang;
    }

    public static AnimQiPan createAnimQiPan(EnterAnimLayout enterAnimLayout) {
        AnimQiPan anim = new AnimQiPan(enterAnimLayout);
        anim.startAnimation();
        return anim;
    }

    public static AnimJieTi createAnimJieti(EnterAnimLayout enterAnimLayout) {
        AnimJieTi animJieTi = new AnimJieTi(enterAnimLayout);
        animJieTi.startAnimation();
        return animJieTi;
    }

    public static AnimLingXing createLingXing(EnterAnimLayout enterAnimLayout) {
        AnimLingXing animLingXing = new AnimLingXing(enterAnimLayout);
        animLingXing.startAnimation();
        return animLingXing;
    }

    public static AnimPiLie createPaiLie(EnterAnimLayout enterAnimLayout) {
        AnimPiLie animPiLie = new AnimPiLie(enterAnimLayout);
        animPiLie.startAnimation();
        return animPiLie;
    }
    public static AnimShanXingZhanKai createAnimShanXingZhanKai(EnterAnimLayout enterAnimLayout) {
        AnimShanXingZhanKai animPiLie = new AnimShanXingZhanKai(enterAnimLayout);
        animPiLie.startAnimation();
        return animPiLie;
    }
    public static AnimShiZiXingKuoZhan createAnimShiZiXingKuoZhan(EnterAnimLayout enterAnimLayout) {
        AnimShiZiXingKuoZhan animPiLie = new AnimShiZiXingKuoZhan(enterAnimLayout);
        animPiLie.startAnimation();
        return animPiLie;
    }
    public static AnimRoateAndScale createAnimRoateAndScale(EnterAnimLayout enterAnimLayout){
        AnimRoateAndScale animRoateAndScale=new AnimRoateAndScale(enterAnimLayout);
        animRoateAndScale.startAnimation();
        return animRoateAndScale;
    }
    public static AnimYuanXingKuoZhan createAnimYuanXingKuoZhan(EnterAnimLayout enterAnimLayout){
        AnimYuanXingKuoZhan animRoateAndScale=new AnimYuanXingKuoZhan(enterAnimLayout);
        animRoateAndScale.startAnimation();
        return animRoateAndScale;
    }
}
