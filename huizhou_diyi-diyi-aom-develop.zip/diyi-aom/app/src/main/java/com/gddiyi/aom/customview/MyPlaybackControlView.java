package com.gddiyi.aom.customview;

import android.content.Context;
import android.util.AttributeSet;

import com.google.android.exoplayer2.ui.PlaybackControlView;

public class MyPlaybackControlView extends PlaybackControlView {
    public MyPlaybackControlView(Context context) {
        super(context);
    }

    public MyPlaybackControlView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MyPlaybackControlView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
