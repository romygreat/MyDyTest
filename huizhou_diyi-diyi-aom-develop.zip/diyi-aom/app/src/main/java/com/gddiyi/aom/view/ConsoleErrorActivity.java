package com.gddiyi.aom.view;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.widget.TextView;

import com.gddiyi.aom.R;
import com.gddiyi.aom.YidiApplication;
import com.gddiyi.aom.constant.VSConstances;

import static com.gddiyi.aom.constant.VSConstances.SWITCH_URL;

public class ConsoleErrorActivity extends BaseActivity {

    TextView tvInfo;
    int errorInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.errormessage);
        Intent intent = getIntent();
        errorInfo = intent.getIntExtra(getString(R.string.errorInfo), 0);
        initView();
        messageTips();
        currentActivity();

    }

    private void messageTips() {
        String tips = "温馨提示，页面出现未知异常！";
        switch (errorInfo) {
            case VSConstances.ERR_CONNECTION_TIMED_OUT:
                tips = "提示：加载页面超时";
                break;
            case VSConstances.ONRECEIVALUE:
                tips = "无法加载网页";
                break;
            default:
                break;
        }
        tvInfo.setText(tips);
    }

    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.CONSOLEERROR_ACTIVITY);
    }

    private void initView() {
        tvInfo = findViewById(R.id.errorInfo);

    }

    public void fresh(View view) {
         restartAPP(this);
//        this.finish();
    }
}
