package com.gddiyi.aom.presenter;

import android.content.Context;
import android.content.Intent;

import com.gddiyi.aom.controler.DiyiInterface;
import com.gddiyi.aom.service.DownLoadService;
import com.gddiyi.aom.service.GetTokenService;
import com.gddiyi.aom.service.PingService;
import com.gddiyi.aom.service.WakeUpService;

public class StartServicePresenter implements DiyiInterface.StartServiceInterface {


    @Override
    public void startDownLoadService(Context context) {
        Intent intent=new Intent(context,DownLoadService.class);
        context.startService(intent);
    }

    @Override
    public void startGetTokenService(Context context) {
        Intent intent=new Intent(context,GetTokenService.class);
        context.startService(intent);
    }

    @Override
    public void startPingService(Context context) {
        //
        Intent intent=new Intent(context,PingService.class);
        context.startService(intent);
    }

    @Override
    public void startWakeUpService(Context context) {
        Intent intent=new Intent(context,WakeUpService.class);
        context.startService(intent);
    }


}
