package com.gddiyi.aom.constant;

import android.content.Context;
import android.util.Log;

import com.gddiyi.aom.YidiApplication;

import lombok.Getter;
import lombok.Setter;

public class VSConstances {
    public static final int ERROR_404 = 404;
    public static final int ERR_CONNECTION_TIMED_OUT =-8 ;
    public static final int ONRECEIVALUE = 10;
    public static final int ERR_CONNECTION_ABORTED =-6 ;
    public static final String ERROR ="ERROR" ;
    public static final String PREFIX_DE_SN ="DE" ;

    public static String[] adFileNames = null;
    public static final String PREFIX = "pwd_";
    public static final String JSONFILEPATH = "sdcard/jsonFile.txt";
    public static final String SDdir = "sdcard/ad/";
    public static final String DOWNLOADAPP_SAVEDIR = "/downloadAPP";
    public static final String DOWNLOADAPP_ABS_SAVEDIR = "/sdcard/downloadAPP/";

    public static final String LOCALPATH = "localPath";
    public static final String VIDEOCOUNT = "videoCount";
    //handler常量 1000开始
    public static final int NA = 1000;
    public static final int CONNECTED_SUCEESS = 1001;
    public static final int FIRSTBOOT_ACTIVITY = 1002;
    public static final String SWITCH_URL = "dev";
    public static final int CONETNT_LENGTH = 50;
    public static final String APP_UPGRADE_URL="http://apk.gddiyi.cn/aom/checked.json";
    public static final String APP_UPGRADE_URL_PATH="http://apk.gddiyi.cn/aom/package/";
    public static final String CHECK_HTML_BY_APP_ID = "javascript:window.android.getHtml(document.getElementById('app').innerHTML)";

//            "http://service." + SWITCH_URL + ".gddiyi.cn/";
//            "http://img.gddiyi.cn/";
//             "http://om.dev.gddiyi.cn/";
    public static String MAIN_URL =
//            "https://www.baidu.com/";
//            "http://om." + SWITCH_URL + ".gddiyi.cn/";
//            "http://shop.test.gddiyi.cn/home/";
//              "http://192.168.0.161:8080/";
             //自己的ip
//             "http://192.168.0.193:8080/";
//            "http://192.168.0.120:8082/";
//            "http://cash.dev.gddiyi.cn/";
               "http://om.gddiyi.cn/";
    public static String SERVICE_INTERFACE =MAIN_URL;
    public static final String URL_SN = MAIN_URL;
    public static final String IMG_PATH = "adfile.gddiyi.cn/";
    public static final String URL_TABLE_NUM = SERVICE_INTERFACE + "shop/ShopTable/getTableByToken/";
    public static final String REQUEST_DOMAINURL = SERVICE_INTERFACE + "qiniu/Upload/getDomain/";
    public static final String REQUEST_CHANGETABLE_NUM = SERVICE_INTERFACE + "shop/ShopTable/setMachine";


    public static final String AD = "ad";
    public static final String POST_VIDEO_PATH = SERVICE_INTERFACE ;
    public static final int TIME_UNIT_MIN = 1000 * 60;
    public static final int HALF_DAY=TIME_UNIT_MIN*60*12;
    public static final int PAY2CHARGE = 1003;

    public static final int REQUEST_OK = 200;
    public static final int CHECK_OUT_NETFAIL_COUNTS = 2;
    public static boolean SET_FROM_WIFY = false;
    //弹出二维码
    public static final String QR_REQUEST_CODE = "http://qr.topscan.com/api.php?text=" + MAIN_URL;
    public static final String URL_APPDOWNLOAD = SERVICE_INTERFACE + "apk/Package/getPackage";
    public static final String URL_APPDOWNLOAD1 = SERVICE_INTERFACE;
    public static final String URL_ABS_APPDOWNLOAD = SERVICE_INTERFACE + "package/";
    //语音调出支付接口
    public static final String TMP_PAYURL =
            MAIN_URL + "order-list?switch=true";
    //广告播放时间
    public static int PIC_SHOW_NEXT = 15000;
    //触摸几分钟后播放广告
    public static final int DELAYTIME = (int) (TIME_UNIT_MIN * 1.5);

    public static final String MACHINE = "machine";
    public static final int CROSSWALK_ACTIVITY = 0;
    public static final int PINGFAIL_ACTIVITY = 1;
    public static final int SETTING_ACTIVITY = 5;
    public static final int ERROR_ACTIVITY = 6;
    public static final int PERMIT_ACTIVITY = 7;
    public static final int QR_ACTIVITY = 8;
    public static final int INIT_ACTIVITY = 9;
    public static final int CONSOLEERROR_ACTIVITY = 9;
    public static final int WEBERROR_ACTIVITY = 10;
    public static final int VIDEO_ACTIVITY = 10;

    public static final boolean isPublish = true;
    @Getter
    @Setter
    static Context context;

}
