package com.gddiyi.aom.view;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;

import com.gddiyi.aom.R;
import com.gddiyi.aom.YidiApplication;
import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.controler.MyThreadPool;

public class InitActivity extends BaseActivity implements BaseActivity.CallBackPingService {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.initlayout);
        initPermission();
        if (PackageManager.PERMISSION_GRANTED ==
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_NETWORK_STATE)) {
            setmCallBackPing(this);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        MyThreadPool.startThread(new Runnable() {
            @Override
            public void run() {
                ping("Init");
            }
        });
    }

    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.INIT_ACTIVITY);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        MyThreadPool.startThread(new Runnable() {
            @Override
            public void run() {
                ping("Init");
            }
        });
    }

    @Override
    public int pingSuccess(String code) {
        Intent intent = new Intent(this, CrossWalkActivity.class);
        startActivity(intent);
        this.finish();
        return 0;
    }

    @Override
    public int pingFail(String code) {
        Intent intent = new Intent(this, PingFailActivity.class);
        intent.putExtra(getString(R.string.LOG),"InitActivity");
        startActivity(intent);
        this.finish();
        return 0;
    }

    @Override
    public int pingException(String code) {
        return 0;
    }
}
