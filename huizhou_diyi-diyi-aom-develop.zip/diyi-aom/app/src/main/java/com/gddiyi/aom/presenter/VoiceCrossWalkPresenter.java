package com.gddiyi.aom.presenter;

import android.content.Context;
import android.util.Log;

import com.gddiyi.aom.controler.VoiceInterface;


import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class VoiceCrossWalkPresenter implements VoiceInterface {
    VoiceInterface.VoiceURL Voice2CrossWalkActivity;
    VoiceInterface.Phone voice2Phone;
    VoiceInterface.Search voice2Search;
    String TAG = getClass().getSimpleName();
    SpeechSynthesisPresenter mSpeechSynthesisPresenter;
    Context mContext;
    static VoiceCrossWalkPresenter instance;

    private VoiceCrossWalkPresenter() {

    }

    @Override
    public String doWhatByVoice(String s) {
        if ("bill".equals(s)) {
            //进入买单语音
            Log.d(TAG, "doWhatByVoice: ");
            if (getVoice2CrossWalkActivity() != null) {
                getVoice2CrossWalkActivity().voiceTmpBillPay();
            }
        }
        return null;
    }

    @Override
    public String doSearch(String s) {
        //搜索
        if ("fresh".equals(s)){
        if (getVoice2CrossWalkActivity() != null) {
            getVoice2CrossWalkActivity().voiceOrder();
        }}
        return null;
    }

    public static VoiceCrossWalkPresenter getInstance() {
        if (instance == null) {
            instance = new VoiceCrossWalkPresenter();
        }
        return instance;
    }
}



