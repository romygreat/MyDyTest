package com.gddiyi.aom.controler;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;

import com.gddiyi.aom.model.dto.ResponseUpdateAppInfo;
import com.gddiyi.aom.utils.netutils.DownloadUtil;

public interface DiyiInterface {
    /**
     * 页面切换
     */
    interface SwitchPage {  //初始化操作
        void init(View view);

        void goWifiPage();

        void goNonetWorkPage();

        void goMainPage();

        void goVideoPage();

        void handleException();
    }

    /**
     * wifi设置
     */
    interface WiFiSetting {
        void setWiFi(Activity context,DialogInterface.OnClickListener onClickListener);

        boolean hasWifyConnected(Activity context);

        boolean isNetworkAvailable(Activity context);

        boolean isNetExcetion(Activity context);

        void reConnectWiFi(Activity context);
    }

    /**
     * 窗口设置
     */
    interface WindowSetting {
        void fullScreen(Activity activity);

        void setWindowListener(Activity activity);

        void hideNavigationBar(Activity context);

        void hideBottomUIMenu(Activity activity);
    }

    /**
     * 网络操作
     */
    interface NetWorkChangeListsener{
        /**
         * 监听外网连接情况
         * @param state
         * @param code 请求ping码，是一个字符串
         *  state=2 表示外网连接未知
         *  state=0 表示外网连接正常
         *  state=1 表示外网连接掉线
         * @see com.gddiyi.aom.view.BaseActivity
         */
        void noticeNetWorkChange(int state, String code);
    }
    /**
     * 启动服务的接口
     */
    interface StartServiceInterface{
        void startDownLoadService(Context context);
        void startGetTokenService(Context context);
        void startPingService(Context context);
        void startWakeUpService(Context context);
    }
    interface UpgradeApp{
        String getToken(String str);
        public String downLoadAPP(String content,String savePhoneUrl,DownloadUtil.OnDownloadListener listener);
        String getUpgradeInfo(ResponseUpdateAppInfo upgradeInfo);
        boolean isDownLoadSucess(boolean success);
    }
    interface JavaScriptReceivedListener{
        int receivedJavacriptCall(int callMethodId);
    }
//    interface NoticeCurrentTableName{
//        int noticeTableName(String tableName);
//    }


}
