package com.gddiyi.aom.service;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import com.baidu.speech.EventListener;
import com.baidu.speech.EventManager;
import com.baidu.speech.EventManagerFactory;
import com.baidu.speech.asr.SpeechConstant;
import com.baidu.speech.core.BDSHttpRequestMaker;
import com.baidu.tts.client.SpeechError;
import com.baidu.tts.client.SpeechSynthesizer;
import com.baidu.tts.client.SpeechSynthesizerListener;
import com.gddiyi.aom.YidiApplication;
import com.gddiyi.aom.controler.MyThreadPool;
import com.gddiyi.aom.controler.VoiceInterface;
import com.gddiyi.aom.model.dto.ResponseReg;
import com.gddiyi.aom.presenter.SpeechSynthesisPresenter;
import com.gddiyi.aom.presenter.VoiceCrossWalkPresenter;
import com.gddiyi.aom.view.QrCodeActivity;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

public class WakeUpService extends Service implements EventListener, SpeechSynthesizerListener {
    private static final int HANDLE_DELAY3s = 3;
    private static final int HANDLE_DELAY_50MS = 50;
    private static final int HANDLE_CHECK_NETWORK = 0;
    private EventManager wakeup;
    String TAG = getClass().getSimpleName();
    Handler mHandler;
    EventManager asr;
    Gson gson;
    @Setter
    @Getter
    VoiceInterface mVoiceInterFace;
   public static SpeechSynthesisPresenter mSpeechSynthesisPresenter;
    boolean isSearch = false;
    EventListener eventListener = new EventListener() {
        @Override
        public void onEvent(String name, String params, byte[] data, int offset, int length) {
            if (name.equals(SpeechConstant.CALLBACK_EVENT_ASR_PARTIAL)) {
                if (params != null) {
                    //通过final——results
                    if (params.contains(finalResult)) {
                        //返回结果处理识别的结果
                        String bestResult = getBestResult(params);
                        //处理逻辑
                        doWhatByVoice(bestResult);
                    }
                }
            }
        }
    };

    private void doWhatByVoice(String bestResult) {
        if (mVoiceInterFace != null) {
            mVoiceInterFace.doWhatByVoice(bestResult);
        }
    }

    private CharSequence finalResult = "final_result";

    public String getBestResult(String params) {
        ResponseReg responseReg = gson.fromJson(params, ResponseReg.class);
        String myString = responseReg.getBest_result();
        return myString;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mHandler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case HANDLE_DELAY3s:

                        MyThreadPool.startThread(new Runnable() {
                            @Override
                            public void run() {
                                start();
                            }
                        });
                        break;
                    case HANDLE_DELAY_50MS:
                        startReg();
                    case HANDLE_CHECK_NETWORK:
                        boolean currentNetWork = ((YidiApplication) getApplication()).getNoNetwork();
                        if (!currentNetWork) {
                            Log.i(TAG, "handleMessage:检查网络正常，注册语音");
                            if (mSpeechSynthesisPresenter==null){
                            mSpeechSynthesisPresenter = new SpeechSynthesisPresenter(getApplicationContext());
                            mSpeechSynthesisPresenter.setSpeechSynthesizerListener(WakeUpService.this);}
                        } else {
                            sendEmptyMessageDelayed(HANDLE_CHECK_NETWORK, 5000);
                        }
                        break;
                    default:
                        break;
                }

            }
        };
        mHandler.sendEmptyMessageDelayed(HANDLE_DELAY3s, 3000);
        mHandler.sendEmptyMessage(HANDLE_CHECK_NETWORK);

        MyThreadPool.startThread(new Runnable() {
            @Override
            public void run() {
                wakeup = EventManagerFactory.create(WakeUpService.this, "wp");
                gson = new Gson();
                wakeup.registerListener(WakeUpService.this);
                setRecg();
                Log.i(TAG, "onCreate: ");
            }
        });
    }

    private void setRecg() {
        asr = EventManagerFactory.create(this, "asr");
        asr.registerListener(eventListener);
    }
    @Override
    public void onEvent(String name, String params, byte[] data, int i, int i1) {
        String logTxt = "";
        if (name.equals("wp.data")) {
            try {
                JSONObject json = new JSONObject(params);
                Log.i(TAG, "onEvent: params" + params);
                int errorCode = json.getInt("errorCode");
                if (errorCode == 0) {
                    //唤醒成功
                    switch (json.getString("word")) {
                        case "小迪点餐":
                            Toast.makeText(this, "进入二维码界面", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(this, QrCodeActivity.class);
                            startActivity(intent);
                            break;
                        case "你好,小迪":
                            //重写逻辑代码，这里仅仅测试
                            mSpeechSynthesisPresenter.speak("店小二在，请说");
                            break;
                        case "小迪买单":
                            Toast.makeText(this, "请扫我吧", Toast.LENGTH_SHORT).show();
                            VoiceCrossWalkPresenter mVoiceCrossWalkPresenter = VoiceCrossWalkPresenter.getInstance();
                            mVoiceCrossWalkPresenter.doWhatByVoice("bill");
                            break;
                        default:
                            //点餐懂你
                            isSearch = true;
                            break;
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();

            }
        } else if ("wp.exit".equals(name)) {
            //唤醒已停止
        }
    }

    private void start() {
        Log.i(TAG, "start: ");
        Map<String, Object> params = new TreeMap<String, Object>();
        params.put(SpeechConstant.ACCEPT_AUDIO_VOLUME, false);
        params.put(SpeechConstant.WP_WORDS_FILE, "assets:///WakeUp.bin");

        String json = null;
        // 这里可以替换成你需要测试的json
        json = new JSONObject(params).toString();
        wakeup.send(SpeechConstant.WAKEUP_START, json, null, 0, 0);
    }

    private void stop() {
        wakeup.send(SpeechConstant.WAKEUP_STOP, null, null, 0, 0); //
    }

    void startReg() {
        Log.i(TAG, "startReg: ");
        Map<String, Object> params = new LinkedHashMap<String, Object>();
        String event = null;
        event = SpeechConstant.ASR_START;
        // 替换成测试的event
        String json = null;
        // 可以替换成自己的json
        json = new JSONObject(params).toString();
        // 这里可以替换成你需要测试的json
        asr.send(event, json, null, 0, 0);
    }

    @Override
    public void onSynthesizeStart(String s) {

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //这一参数很重要，当该服务被系统kill掉后，需要重新拉起服务
        return START_STICKY;
    }

    @Override
    public void onSynthesizeDataArrived(String s, byte[] bytes, int i) {

    }

    @Override
    public void onSynthesizeFinish(String s) {

    }

    @Override
    public void onSpeechStart(String s) {

    }

    @Override
    public void onSpeechProgressChanged(String s, int i) {

    }

    @Override
    public void onSpeechFinish(String s) {
        Log.i(TAG, "onSpeechFinish: " + s);
        startReg();

    }

    @Override
    public void onError(String s, SpeechError speechError) {

    }
}
