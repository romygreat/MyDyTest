package com.gddiyi.aom.presenter;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import com.baidu.tts.auth.AuthInfo;
import com.baidu.tts.client.SpeechSynthesizer;
import com.baidu.tts.client.SpeechSynthesizerListener;
import com.baidu.tts.client.TtsMode;


public class SpeechSynthesisPresenter {
    String TAG = "" + getClass().getSimpleName();
    SpeechSynthesizer mSpeechSynthesizer;
    String AppId = "15887705";
    String AppKey = "SqOngpE4MsCaBgt2lhtMNG0u";
    String AppSecret = "A3EplStZzz5uKlhl4v8cUWBxbYuioX0s";
    private TtsMode ttsMode = TtsMode.ONLINE;
    Handler mHandller = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            setSpeechSynthesizer();
            if (!checkAuth()) {
                //尝试继续注册
                sendEmptyMessageDelayed(0, 15_000);
            }
        }
    };

    public void setSpeechSynthesizerListener(SpeechSynthesizerListener speechSynthesizerListener) {
        this.speechSynthesizerListener = speechSynthesizerListener;
    }

    public SpeechSynthesizerListener getSpeechSynthesizerListener() {
        return speechSynthesizerListener;
    }

    SpeechSynthesizerListener speechSynthesizerListener;

    public SpeechSynthesisPresenter(Context mContext) {
        this.mContext = mContext;
        //先检查，然后判断情况
        mHandller.sendEmptyMessage(0);
    }

    Context mContext;

    public boolean checkAuth() {
        //鉴权检查
        AuthInfo authInfo = null;
        if (mSpeechSynthesizer != null) {
            authInfo = mSpeechSynthesizer.auth(ttsMode);
        }
        if (authInfo == null || (!authInfo.isSuccess())) {
            Log.i(TAG, "checkAuth: 语音未注册");
            return false;
        } else {
            Log.i(TAG, "checkAuth: 语音已注册");
            return true;
        }
    }

    public void setSpeechSynthesizer() {
        mSpeechSynthesizer = SpeechSynthesizer.getInstance();
        mSpeechSynthesizer.setContext(mContext);
        // 不使用压缩传输
        mSpeechSynthesizer.setParam(SpeechSynthesizer.PARAM_AUDIO_ENCODE, SpeechSynthesizer.AUDIO_ENCODE_PCM);
        mSpeechSynthesizer.setParam(SpeechSynthesizer.PARAM_AUDIO_RATE, SpeechSynthesizer.AUDIO_BITRATE_PCM);
        if (speechSynthesizerListener != null) {
            mSpeechSynthesizer.setSpeechSynthesizerListener(speechSynthesizerListener);
        }
        mSpeechSynthesizer.setAppId(AppId);
        mSpeechSynthesizer.setApiKey(AppKey, AppSecret);
        mSpeechSynthesizer.auth(TtsMode.ONLINE);
        mSpeechSynthesizer.setParam(SpeechSynthesizer.PARAM_SPEAKER, "0");
        mSpeechSynthesizer.initTts(TtsMode.MIX);
    }

    public int speak(String words) {
        if (getSpeechSynthesizerListener() != null) {
            mSpeechSynthesizer.setSpeechSynthesizerListener(getSpeechSynthesizerListener());
        }
        return mSpeechSynthesizer.speak(words);
    }

}
