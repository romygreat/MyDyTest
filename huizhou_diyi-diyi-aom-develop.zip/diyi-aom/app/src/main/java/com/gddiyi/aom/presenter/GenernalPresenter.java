package com.gddiyi.aom.presenter;

import android.util.Log;


import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.model.dto.ResponseUnbindTableList;
import com.gddiyi.aom.service.PostService;
import com.google.gson.Gson;


import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class GenernalPresenter {
    static Gson instanceGson;

    //一、创建一个Retrofit
    //二、post参数封装为一个JSONObject对象
    //三、通过GSON生成一个string字符串,最后转为RequestBody对象
    //四异步请求执行，返回一个接口

    /**
     *
     *
     * 参考createRequestBody
     * @return
     */
    public Retrofit createRetrofit(String url) {
        Retrofit retrofit2 = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .client(new OkHttpClient())
                .build();
        return retrofit2;
    }

    public  RequestBody createRequestBody(Object requestTableList) {
        Gson  gson = new Gson();
        String jsonString = gson.toJson(requestTableList);
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        RequestBody requestBody = RequestBody.create(JSON, jsonString);
        return requestBody;
    }
    public PostService createPostService(String url){
        PostService postService = createRetrofit(url).create(PostService.class);
       return  postService;
    }
    public RequestBody createRequestBody(JSONObject jsonObject) {
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        RequestBody requestBody = RequestBody.create(JSON, jsonObject.toString());

        return requestBody;
    }




}
