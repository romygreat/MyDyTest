package com.gddiyi.aom.view;


import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.gddiyi.aom.R;
import com.gddiyi.aom.YidiApplication;
import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.customview.MyWebView;
import com.gddiyi.aom.jsinterface.JavaScriptinterface;
import com.gddiyi.aom.presenter.CrossWalkPresenter;

import lombok.libs.org.objectweb.asm.Handle;

public class TestWebView extends BaseActivity  implements View.OnTouchListener{
    public MyWebView mWebView;
    final static String TAG = "TestWebView";
    JavaScriptinterface javaScriptinterface;
    WebSettings settings;
    CrossWalkPresenter mCrossWalkPresenter;
    TextView tv;
    LinearLayout linearLayout;
    Button videoExitbt;
    Handler mHandler;

    @Override
    protected void onXWalkReady() {
         setWebSettings();
        windowSettingImpls.setWindowListener(this);
        /*
        file:///sdcard
         */
        mWebView.loadUrl("http://player.youku.com/embed/XNDM3OTIyMDAzNg==");
        mWebView.loadUrl("file:///sdcard/tablevideo.mp4");
        showWebView();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        super.onCreate(savedInstanceState);
            initOnCreate();
            mHandler=new Handler(getMainLooper()){
                @Override
                public void handleMessage(Message msg) {
                    linearLayout.setVisibility(View.INVISIBLE);
                }
            }
            ;
    }

    private void initOnCreate() {
            setContentView(R.layout.crosswalk);
            mWebView = findViewById(R.id.xwalkWebView);
            mWebView.setOnTouchListener(this);
            tv=findViewById(R.id.tips);
            tv.setVisibility(View.INVISIBLE);
            linearLayout=findViewById(R.id.linearLayout);
            linearLayout.setVisibility(View.VISIBLE);
            videoExitbt=findViewById(R.id.videoExit);
            videoExitbt.setBackgroundColor(Color.BLACK);
            videoExitbt.setTextColor(Color.WHITE);
            videoExitbt.setText("退出视频");
            videoExitbt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    restartAPP(TestWebView.this);
                }
            });
    }

    private void setWebSettings() {
        mCrossWalkPresenter=new CrossWalkPresenter(this);
        settings = mCrossWalkPresenter.setWebViewSettings(mWebView);
        //设置自动播放视频
//        mWebView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        javaScriptinterface = new JavaScriptinterface(this);
        mWebView.addJavascriptInterface(javaScriptinterface, "android");
        mWebView.setWebChromeClient(getWebChromeClient());
        mWebView.setWebViewClient(getWebViewClient());
        //网络出现问题
        mWebView.getSettings().setBlockNetworkImage(false);
        //调试
        WebView.setWebContentsDebuggingEnabled(true);
    }

    private WebViewClient getWebViewClient() {
        WebViewClient webViewClient=new WebViewClient(){
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "onPageFinished:url= "+url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Log.d(TAG, "shouldOverrideUrlLoading: "+view.getUrl());
                return super.shouldOverrideUrlLoading(view, request);
            }
        };
        return webViewClient;
    }


    private WebChromeClient getWebChromeClient() {
        WebChromeClient webChromeClient = new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d(TAG, "onConsoleMessage: " + consoleMessage.message());
                return super.onConsoleMessage(consoleMessage);
            }
        };
        return webChromeClient;
    }

    private boolean showWebView() {
        mWebView.setVisibility(View.VISIBLE);
        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();
            onXWalkReady();
    }
    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.CROSSWALK_ACTIVITY);
    }


    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (MotionEvent.ACTION_DOWN==event.getAction()){
        linearLayout.setVisibility(View.VISIBLE);
        if (!mHandler.hasMessages(0))
        { mHandler.sendEmptyMessageDelayed(0,3000);}
        }
        return false;
    }
}

