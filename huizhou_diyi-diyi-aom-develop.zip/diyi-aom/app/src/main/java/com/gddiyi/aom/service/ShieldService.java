package com.gddiyi.aom.service;

import android.app.Service;




import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;


import com.gddiyi.aom.controler.MyThreadPool;

import java.lang.reflect.Method;


/**
 * Created by author on 2018/7/24.
 */

public class ShieldService extends Service{
    private static final String TAG = "ShieldService";

    @Override
    public void onCreate() {
        Log.d(TAG, "onCreate: ");
        super.onCreate();
    }
    @Override
    public int onStartCommand(Intent intent, int flag,int startId) {
        MyThreadPool.startThread(new Runnable() {
            @Override
            public void run() {
                while (true){
                    disableStatusBars();
                }
            }
        });
        return START_NOT_STICKY;

    }

    private void disableStatusBars() {
        try {
            Object service = getSystemService("statusbar");
            Class<?> claz = Class.forName("android.app.StatusBarManager");
            Method expand = claz.getMethod("collapsePanels");
            expand.invoke(service);
        } catch (Exception e) {
            e.printStackTrace();
    }
    }


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

}
