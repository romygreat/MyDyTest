package com.gddiyi.aom.service;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.util.Log;
import com.gddiyi.aom.constant.ConigInfo;

import com.gddiyi.aom.R;
import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.jsinterface.JavaScriptinterface;
import com.gddiyi.aom.model.dto.RequestJsonSn;
import com.gddiyi.aom.model.dto.ResponseJsonSn;
import com.gddiyi.aom.presenter.RetrofitPresenter;

import lombok.Getter;
import lombok.Setter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GetTokenService extends Service {
    String TAG = getClass().getSimpleName();
    RetrofitPresenter mPrensenter;
    String token;
    static TokenInterface tokenInterface;
    SharedPreferences sharedPreferences;

    public static void setTokenInterface(TokenInterface tokenInterface1) {
        tokenInterface = tokenInterface1;
    }

    @Setter
    @Getter
    public static TokenBindTableInterface tokenBindTableInterface;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sharedPreferences = getSharedPreferences(getString(R.string.diyi), Context.MODE_PRIVATE);
        mPrensenter = new RetrofitPresenter();
        mPrensenter.setCallback(new Callback<ResponseJsonSn>() {
            @Override
            public void onResponse(Call<ResponseJsonSn> call, Response<ResponseJsonSn> response) {
                ResponseJsonSn r = response.body();
                if (r != null && r.getData() != null) {
                    token = r.getData().getToken();
                    String tableID = r.getData().getId();
                    ConigInfo.tableNum=r.getData().getTable_title();
                    //数据保存到数据库
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString(getString(R.string.tableID), tableID);
                    editor.commit();

                }
                if (tokenInterface != null) {
                    tokenInterface.setToken(token);
                }
                if (tokenBindTableInterface != null) {
                    tokenBindTableInterface.setToken(token);
                }
                //需要多次获取token,每次请求返回后需要关掉服务
                stopSelf();
            }

            @Override
            public void onFailure(Call<ResponseJsonSn> call, Throwable t) {
            }
        });
        RequestJsonSn requestJsonSn = new RequestJsonSn();
        String urlSN = VSConstances.URL_SN;
        requestJsonSn.setSn(JavaScriptinterface.getSerialNumber());
        mPrensenter.retrofitPost(urlSN, mPrensenter.postJsonString(requestJsonSn));
    }

    public interface TokenInterface {
        String setToken(String token);
    }

    /**
     * 在settingActivity中
     */
    public interface TokenBindTableInterface {
        String setToken(String token);
    }
}
