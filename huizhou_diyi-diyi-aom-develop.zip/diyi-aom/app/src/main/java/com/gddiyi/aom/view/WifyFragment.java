package com.gddiyi.aom.view;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.LocationManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.gddiyi.aom.R;
import com.gddiyi.aom.YidiApplication;
import com.gddiyi.aom.adapter.WifiListAdapter;
import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.controler.DiyiInterface;
import com.gddiyi.aom.controler.MyMainActivity;
import com.gddiyi.aom.customview.dialog.WifiLinkDialog;
import com.gddiyi.aom.presenter.PictrueAdPresenter;
import com.gddiyi.aom.presenter.WifiAutoConnectPresenter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import javax.inject.Inject;

import static com.gddiyi.aom.presenter.WifiAutoConnectPresenter.connectWifiNoPassword;

/**
 * @author romygreat
 * @date 20190125
 * @see FirstBootActivity
 * 显示wifi列表及连接功能
 * 1、wifi连接注意位置定位需要打开，否则Android8 以上会出现此问题
 * 2、如果wifi连接不是通过本应用的连接，系统移除无效，系统原因
 * 3、本应用的WiFi设置进入，可以正常移除
 */
public class WifyFragment extends BaseFragment implements DiyiInterface.SwitchPage,
        View.OnClickListener, AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener {
    private static final int UPDATE_WIFY = 666;
    private static final int SCAN_WIFY = 667;
    private static final int RETRY_CONNECT = 700;
    private static final int DELAY_2SECONDS = 702;
    private static final int GOMAINACTIVITY = 1005;
    private static final int ERRO_NETTIPS = 1006;
    @Inject
    PictrueAdPresenter mPictrueAdPresenter;
    //连接不成功，尝试连接次数
    public static final int TYR_TIMES = 2;
    int currentRetry = 0;
    Context mContext;
    ListView listView;
    WifiManager mWifiManager;
    ArrayList<ScanResult> wifiListData = new ArrayList<>();

    TextView textView;
    TextView connectedTextView, availableWifyTextView;
    TextView wifiNameView;
    ImageView wifiRefreshImg;

    String[] wifyList;
    LinearLayout connectedItem;
    ArrayAdapter<String> adapter;
    WifiListAdapter wifiListAdapter;
    LinearLayout connectedWifiItemView;
    int wifiResult = 0;
    static final int TOASTTIPS = 668;
    boolean isTryNetworkAvailable = true;
    String connectedWIfy;
    String SSID;
    RotateAnimation animation;
    ArrayList<ScanResult> listWifiResult = new ArrayList<>();
    FistBootActvityInterface mFistBootActvityInterface;
    ImageView returnImageView;
    boolean remenberPassWord;

    public String getPassword1() {
        return password1;
    }

    public void setPassword1(String password1) {
        this.password1 = password1;
    }

    String password1 = "gddiyi2018";

    /**
     * 绑定到FirstBootActivity
     *
     * @param context
     */

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
        //轻量数据库存储wifi信息
        mSharedPreferences = mContext.getSharedPreferences(getString(R.string.diyi), Context.MODE_PRIVATE);
        mWifiManager = (WifiManager) mContext.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (mWifiManager.isWifiEnabled()) {
            mWifiManager.setWifiEnabled(true);
        }
        hideBottomUIMenu();
        //初始化handler
        initHandler();

    }


    private void initHandler() {
        wac.mHandler = new Handler(mContext.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                Log.i(TAG, "handleMessage: what" + msg.what);
                switch (msg.what) {
                    case VSConstances.CONNECTED_SUCEESS:
//                        printMytips("努力连接中");
                       Toast.makeText(mContext.getApplicationContext(),"努力连接中",Toast.LENGTH_LONG).show();
                        sendEmptyMessageDelayed(DELAY_2SECONDS, 2500);
                        break;
                    case DELAY_2SECONDS:
                        handleConnectSuccessed();
                        break;
                    case GOMAINACTIVITY:
                        if (SSID == null) {
                        } else {
                            goMainPage();
                        }
                        break;
                    case ERRO_NETTIPS:
                        printMytips("请检查网络或密码错误");
                        break;
                    case SCAN_WIFY:
                        mWifiManager.startScan();
                        //延时目的是得到wifi扫描结果，设计延期时间
                        sendEmptyMessageDelayed(UPDATE_WIFY, 4000);
                        break;
                    //获取wifi搜索结果
                    case UPDATE_WIFY:
                        handleUpdateWify();
                        break;
                    case TOASTTIPS:
                        printMytips("正在搜索wifi中");
                        break;
                    case RETRY_CONNECT:
                        handleReTryConnenectWify();
                        break;
                    default:
                        break;
                }
            }
        };
    }

    private void handleConnectSuccessed() {
        if (isNetworkAvailable()) {
            if (SSID != null) {
                printMytips("即将进入主界面");
                wac.mHandler.sendEmptyMessageDelayed(GOMAINACTIVITY, 2000);
                isTryNetworkAvailable = true;
            }
        } else {
            //连接成功又掉网
            handleException();
        }
    }

    private void handleUpdateWify() {
        wifiListData.clear();
        wifyList = null;
        listWifiResult.clear();
        //wifi直接扫描获取得到的结果
        wifiListData = (ArrayList<ScanResult>) mWifiManager.getScanResults();
        //获取wifi结果可能为0，打开位置信息，因位置信息导致的不能连接wifi
        if (wifiListData.size() == 0) {
            checkLocationSettings();
        }
        //根据wifi信号进行连接
        Collections.sort(wifiListData, new Comparator<ScanResult>() {
            @Override
            public int compare(ScanResult o1, ScanResult o2) {
                if (o1.level > o2.level) {
                    return -1;
                }
                return 0;
            }
        });
        wifyList = new String[wifiListData.size()];
        //代码目的是将wifiList数组传入到适配器中
        for (ScanResult scanResult : wifiListData) {
            if (!"".equals(scanResult.SSID.trim())) {
                //不能添加前缀
                wifyList[wifiResult++] = scanResult.SSID;
                //去除冗余代码
                listWifiResult.add(scanResult);
            }
            else {
                Log.d(TAG, "handleUpdateWify: "+scanResult.SSID);
            }
        }
        Log.d(TAG, "handleUpdateWify:wifiListData.size()= "+wifiListData.size());
        Log.d(TAG, "handleUpdateWify:listWifiResult.size()= "+listWifiResult.size());
        showWifyArray();
    }


    private void checkLocationSettings() {
        LocationManager lm = (LocationManager) mContext.getSystemService(Context.LOCATION_SERVICE);
        boolean ok = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if (!ok) {
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            mContext.startActivity(intent);
        }else {
            //不能刷新wifi
            mContext.startActivity(new Intent(mContext,FirstBootActivity.class));
        }
    }

    private void showWifyArray() {
        //在handlerUpdateWify中调用
        wifiResult = 0;
        if (wifyList != null && wifyList.length > 0) {
            wifiListAdapter = new WifiListAdapter(mContext, listWifiResult,mSharedPreferences);
            listView.setAdapter(wifiListAdapter);
            connectedWIfy = wac.getConnectedWify();
            Log.i(TAG, "handleMessage:connect " + connectedWIfy);
            //有连接的wifi
            if (connectedWIfy != null && hasWifyConnected()) {
                Log.i(TAG, "showWifyArray: haswifiConnected");
                //这里存在比较多的if判断语句，目的不让报错
                if (mContext != null && (connectedTextView != null)
                        && WifyFragment.this.isAdded() && (WifyFragment.this.isVisible())) {
                    try {
                        //已连接wifi展示

                    } catch (MyMainActivity e) {
                    } finally {
                        if (animation != null) {
                            animation.cancel();
                        }
                    }
                } else {
                    wac.mHandler.sendEmptyMessage(GOMAINACTIVITY);
                }
            }
        } else {
            //未搜索到附近wifi时
        }

    }

    private void handleReTryConnenectWify() {
        //此时的密码是password1
        wac.connect(SSID, password1, WifiAutoConnectPresenter.WifiCipherType.WIFICIPHER_WPA);
    }

    @Override
    public void onResume() {
        super.onResume();
       printMytips("正在搜索附近的wifi");
        //扫描wifi，延迟2.5s
        wac.mHandler.sendEmptyMessageDelayed(SCAN_WIFY, 500);
        //提示信息
        wac.mHandler.sendEmptyMessageDelayed(TOASTTIPS, 2000);
        //设置wifi

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View myView = inflater.inflate(R.layout.fragmnet_wifilist, container, false);
        init(myView);
        ischecked();
        return myView;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void ischecked() {
        mWifiManager.setWifiEnabled(true);
        listView.setVisibility(View.VISIBLE);
        connectedTextView.setVisibility(View.VISIBLE);
        textView.setClickable(true);
        availableWifyTextView.setVisibility(View.VISIBLE);
        textView.setText(getString(R.string.fresh));
        //有时候2秒时间加载的wifi已连接显示为无，需要再一次刷新
        wac.mHandler.sendEmptyMessageDelayed(SCAN_WIFY, 100);
    }

    @Override
    public void onClick(View v) {
        Toast.makeText(mContext.getApplicationContext(), "正在刷新，请稍后", Toast.LENGTH_LONG).show();
        wac.mHandler.sendEmptyMessage(SCAN_WIFY);
        Animation animation = getRotateAnimation();
        wifiRefreshImg.startAnimation(animation);
    }

    int itemPosition = -1;
    String[] hasRemPwd;

    /**
     * @param parent
     * @param view
     * @param position
     * @param id  选中当前wifi
     */
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (mWifiManager.isWifiEnabled()) {
            SSID = wifyList[position];
            if (SSID == null) {
                return;
            }
            itemPosition = position;
            //判断是否记住密码
            if (!hasRemenberPwd()) {
                Log.d(TAG, "onItemClick: 没有记住");
                showPassWordDialog(position);
            } else {
                //有记住密码
                connectRemnberWifiInfo();
                //保存SSID
            }
        } else {
            printMytips("请打开wifi开关");
        }
    }

    private void connectRemnberWifiInfo() {
        if (hasRemPwd != null && hasRemPwd[0] != null) {
            Log.d(TAG, "connectRemnberWifiInfo: ");
            printMytips("连接中");
            setSharePreference1(SSID, null);
            setSharePreference1(null,  hasRemPwd[0]);
            wac.connect(SSID, hasRemPwd[0], WifiAutoConnectPresenter.WifiCipherType.WIFICIPHER_WPA);
        }
    }

    private boolean hasRemenberPwd() {
        String pwds = mSharedPreferences.getString(VSConstances.PREFIX+SSID, "di|false");
        Log.d(TAG, "hasRemenberPwd: " + pwds);
        hasRemPwd = pwds.split("\\|");
        boolean remPwd = Boolean.parseBoolean(hasRemPwd[1]);
        Log.d(TAG, "hasRemenberPwd: " + hasRemPwd[0]);
        return remPwd;
    }

    int confirmCount = 0;

    /**
     * 点击确认，连接WiFi名为SSID
     *
     * @param inputedit
     * @param SSID
     */
    public void setMyEdit(EditText inputedit, String SSID) {
        currentRetry = 0;
        confirmCount++;
        if (confirmCount == 3) {
            confirmCount = 0;
        }
        String editTextString = inputedit.getText().toString();
        setPassword1(editTextString);
        setSharePreference(null, editTextString);
        //轻量级数据存储
        if (!TextUtils.isEmpty(editTextString)) {
            try {
                //密码长度不对
               if (getPassword1().trim().length()<6){
                   printMytips("密码输入错误,请重新输入");
                   return;
               }
                wac.connect(SSID.trim(), getPassword1().trim(),
                        WifiAutoConnectPresenter.WifiCipherType.WIFICIPHER_WPA);
                //保存SSID
                setSharePreference(SSID, null);
                //代码用于记住密码
                if (remenberPassWord) {
                    Log.d(TAG, "setMyEdit:remenberPassWord: " + SSID.trim());
                    saveConnectedWifiInfo(SSID.trim(), getPassword1().trim(), true);
                }
                SharedPreferences.Editor editor = mSharedPreferences.edit();
                if (SSID != null) {
                    editor.putString(getString(R.string.SSID1), SSID);
                    editor.commit();
                }
                printMytips("网络连接中，请耐心等待");
            } catch (MyMainActivity e) {
                printMytips("网络异常");
            }
        } else {
            connectWifiNoPassword(mWifiManager, SSID);
            wac.mHandler.sendEmptyMessageDelayed(VSConstances.CONNECTED_SUCEESS, 1000);
        }
        Log.d(TAG, "setMyEdit:editTextString:" + editTextString);
        Log.d(TAG, "setMyEdit:SSID=:" + SSID);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void init(View myView) {
        listView = myView.findViewById(R.id.wifyList);
        textView = myView.findViewById(R.id.fresh);
        connectedTextView = myView.findViewById(R.id.connected);
        availableWifyTextView = myView.findViewById(R.id.availableWify);
        wifiRefreshImg = myView.findViewById(R.id.wifiRefresh);
        connectedWifiItemView = myView.findViewById(R.id.connectedWifiItem);
        returnImageView = myView.findViewById(R.id.returnImageView);
        wifiNameView = myView.findViewById(R.id.wifiName);
        textView.setOnClickListener(this);
        wifiRefreshImg.setOnClickListener(this);
        returnImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isNetworkAvailable()) {
                    printMytips("请稍等");
                    restartAPP();
                } else {
                    Toast.makeText(mContext, "WIFI未连接，请连接", Toast.LENGTH_LONG).show();
                }
            }
        });
        mWifiManager.startScan();
        listView.setOnItemClickListener(this);
        listView.setOnItemLongClickListener(this);
        adapter = new ArrayAdapter<>(mContext, R.layout.wifiitem,
                R.id.wifiName, new String[]{"Admin"});
        listView.setAdapter(adapter);
        listView.setFooterDividersEnabled(true);
    }

    @Override
    public void goWifiPage() {
        Log.i(TAG, "goWifiPage: ");
        Toast.makeText(mContext, "刷新中，请稍后", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(mContext, FirstBootActivity.class);
        mContext.startActivity(intent);
        ((YidiApplication) mContext.getApplicationContext()).setPlayAd(false);
        ((YidiApplication) mContext.getApplicationContext()).setWifiPage(false);
    }

    @Override
    public void goNonetWorkPage() {
    }

    @Override
    public void goMainPage() {
        if (ping("go CrossWalkActivity")) {
            goCrossWalkActivity();
        } else {
            if (ping("else中进行ping")) {
                goCrossWalkActivity();
            } else {
                if (!((YidiApplication) mContext.getApplicationContext()).getWifiPage()) {
                    //进入failActivity，没法连接外网
                    Log.d(TAG, "goMainPage: else");

                    Toast.makeText(mContext, "wifi已连接，但无法连接外网", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(mContext, PingFailActivity.class);
                    intent.putExtra(getString(R.string.LOG),"frg_goMainPage");
                    ((YidiApplication) mContext.getApplicationContext()).setPlayAd(false);
                    mContext.startActivity(intent);
                }
            }
        }
    }

    public void goCrossWalkActivity() {
        confirmCount = 0;
        Intent intent = new Intent(mContext, CrossWalkActivity.class);
        mContext.startActivity(intent);
        //可以重新播放广告
        ((YidiApplication) mContext.getApplicationContext()).setPlayAd(true);
        //界面
        ((YidiApplication) mContext.getApplicationContext()).setWifiPage(false);
        ((YidiApplication) mContext.getApplicationContext()).setNoNetwork(true);
        ((YidiApplication) mContext.getApplicationContext()).setClickChoiceWifi(false);
        if (mFistBootActvityInterface != null) {
            mFistBootActvityInterface.onClose(true);
        }

    }

    @Override
    public void goVideoPage() {

    }

    @Override
    public void handleException() {
        if (isTryNetworkAvailable) {
            wac.mHandler.sendEmptyMessage(RETRY_CONNECT);
        } else {
            //努力连接中 && 正在尝试为您连接网络
            if (wac.mHandler.hasMessages(VSConstances.CONNECTED_SUCEESS)) {
                wac.mHandler.removeMessages(VSConstances.CONNECTED_SUCEESS);
            }
            if (itemPosition != -1) {
                showPassWordDialog(itemPosition);
            }
            printMytips("连接失败，请重试！");
        }
        currentRetry++;
        if (currentRetry == TYR_TIMES) {
            //新添加修改提示问题
            isTryNetworkAvailable = false;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    /**
     * 弹出WiFi密码框
     */
    private void showPassWordDialog(final int position) {
        //之前没配置过该网络， 弹出输入密码界面
//        WifiLinkDialog linkDialog = new WifiLinkDialog(mContext, R.style.dialog_download, wifyList[position]);
        WifiLinkDialog linkDialog = new WifiLinkDialog(mContext, R.style.dialog_download,listWifiResult.get(position).SSID );
        Log.d(TAG, "showPassWordDialog:listWifiResult.size()= "+listWifiResult.size());
        Log.d(TAG, "showPassWordDialog:wifiListData.size()= "+wifiListData.size());
        Log.d(TAG, "showPassWordDialog:wifiListData.SSID= "+listWifiResult.get(position).SSID);
        linkDialog.setMCallBackEdit(new WifiLinkDialog.CallBackEdit() {
            @Override
            public String setEditText(EditText inputedit) {
                setMyEdit(inputedit, listWifiResult.get(position).SSID);
                return null;
            }

            @Override
            public String setRemberPassword(boolean b) {
                remenberPassWord = b;
                return null;
            }
        });

        if (!linkDialog.isShowing()) {
            linkDialog.show();
        }
    }

    public boolean ping(String code) {
        String ip = "202.108.22.5";
        int status = 0;
        // ping 的地址，可以换成任何一种可靠的外网
        Process p = null;
        try {
            p = Runtime.getRuntime().exec("ping -c 2 -w 2 " + ip);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            status = (p != null ? p.waitFor() : 1);
        } catch (InterruptedException e) {
            Log.i(TAG, "ping: " + e.toString());
            e.printStackTrace();
        }

        return status == 0;

    }

    //刷新动画显示
    public Animation getRotateAnimation() {
        //实例化RotateAnimation
        //以自身中心为圆心，旋转360度 正值为顺时针旋转，负值为逆时针旋转
        animation = new RotateAnimation(0, 360,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f);
        //设置动画插值器 被用来修饰动画效果,定义动画的变化率
        animation.setInterpolator(new LinearInterpolator());
        animation.setRepeatCount(2);
        //设置动画执行时间
        animation.setDuration(1600);
        return animation;
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
        if (mWifiManager.isWifiEnabled()) {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(mContext);
            SSID = wifyList[position];
            alertDialog.setTitle("忘记"+SSID+"密码");
            alertDialog.setPositiveButton("是", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
//                    Log.d(TAG, "onClick: " + SSID);
//                    connectWifiNoPassword(mWifiManager, SSID);
//                    wac.mHandler.sendEmptyMessageDelayed(VSConstances.CONNECTED_SUCEESS, 1000);
                    //忘记密码，当前密码已忘记
                    saveConnectedWifiInfo(SSID,"wifi",false);
                    printMytips("刷新中");
                    wac.mHandler.sendEmptyMessage(SCAN_WIFY);
                    Animation animation = getRotateAnimation();
                    wifiRefreshImg.startAnimation(animation);
                }
            });
            alertDialog.setNegativeButton("否", null);
            alertDialog.show();
        } else {
            mWifiManager.setWifiEnabled(true);
        }
        return true;
    }


    interface FistBootActvityInterface {
        void onClose(boolean close);
    }

    void restartAPP() {
        Intent intent = new Intent(mContext, CrossWalkActivity.class);
        @SuppressLint("WrongConstant") PendingIntent
                restartIntent = PendingIntent.getActivity(mContext, 0, intent,
                Intent.FLAG_ACTIVITY_NEW_TASK);
        AlarmManager mgr = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
        assert mgr != null;
        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 500,
                restartIntent);
        // 0.5秒钟后重启应用
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }

}



