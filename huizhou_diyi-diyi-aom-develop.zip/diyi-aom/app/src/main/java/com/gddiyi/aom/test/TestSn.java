package com.gddiyi.aom.test;

import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.model.dto.RequestJsonSn;
import com.gddiyi.aom.model.dto.ResponseJsonSn;
import com.gddiyi.aom.presenter.RetrofitPresenter;
import com.gddiyi.aom.service.PostService;
import com.google.gson.JsonObject;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class TestSn {
    final String  TAG=getClass().getSimpleName();
    RetrofitPresenter mPrensenter;
    public static void main(String[] args) {
      TestSn testSn=new TestSn();
      testSn.testRequest();
    }
    private void beginTest() {
//        for (int i=0;i<=10000;i++){
//            MyThreadPool.startThread(new Runnable() {
//                @Override
//                public void run(){
//                    test1();
//                }
//            });
//        }
    }

    public void test1(){
        mPrensenter = new RetrofitPresenter();
        mPrensenter.setCallback(new Callback<ResponseJsonSn>() {
            @Override
            public void onResponse(Call<ResponseJsonSn> call, Response<ResponseJsonSn> response) {
                ResponseJsonSn r = response.body();
                if (r != null && r.getData() != null) {
                    System.out.println("onResponse:token "+r.getData().getToken());
                }
            }
            @Override
            public void onFailure(Call<ResponseJsonSn> call, Throwable t) {

            }
        });
        RequestJsonSn requestJsonSn = new RequestJsonSn();
        String urlSN = VSConstances.URL_SN;
        requestJsonSn.setSn("test05");
        mPrensenter.retrofitPost(urlSN, mPrensenter.postJsonString(requestJsonSn));
    }
    public void testRequest(){
        //1、获取retrofit对象
       mPrensenter = new RetrofitPresenter();
       Retrofit retrofit= mPrensenter.createRetrofit(VSConstances.URL_SN);
       //2、创建一个requestBody
        MediaType JSON = MediaType.parse("application");
        JsonObject jsonObject= new JsonObject();
            jsonObject.addProperty("sn","test02");
        //直接添加请求体
//        String requestJson="{\"sn\":\"test02\"}";
        String requestJson=jsonObject.toString();
        System.out.println("=="+requestJson);
        final RequestBody requestBody = RequestBody.create(JSON, requestJson);
        //3、请求服务接口
        PostService postService=retrofit.create(PostService.class);
        Call<ResponseBody> response=  postService.getSnResultTestNet(requestBody);
        response.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                try {
                    System.out.println("body=="+response.body().string());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
        });


    }
}
