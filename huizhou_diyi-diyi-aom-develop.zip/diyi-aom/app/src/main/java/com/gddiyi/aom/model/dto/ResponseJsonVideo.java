package com.gddiyi.aom.model.dto;

import java.util.Arrays;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter

public class ResponseJsonVideo {

    /**
     * code : 1
     * message : 操作成功
     * data : {"count":18,"list":[{"id":31,"title":"手动阀手动阀2","path":"ad/9e810023b8e689be648c657cf50d5c43.mp4","type":"video/mp4","prov":440000,"city":441300,"zone":441303,"shop_id":62,"terminal_type":1,"sort":222,"update_time":"1970-01-01 08:32:50","delete_time":0,"create_time":"1970-01-01 08:32:50","start_time":1546843624,"end_time":1546930209,"status":1}]}
     */

    private int code;
    private String message;
    private DataBean data;


    @Setter
    @Getter
    public static class DataBean implements Comparable<DataBean> {
        @Override
        public String toString() {
            return list.toString();
        }

        /**
         * count : 18
         */

        private int count;
        private List<ListBean> list;

        @Override
        public int compareTo(DataBean o) {
            return 0;
        }

        @Setter
        @Getter
        public static class ListBean implements Comparable<ListBean> {
            @Override
            public String toString() {
                return "\nid=" + id + "path=" + path + "---sort=" + sort + "\n";
            }

            /**
             * id : 31
             * title : 手动阀手动阀2
             * path : ad/9e810023b8e689be648c657cf50d5c43.mp4
             * type : video/mp4
             * prov : 440000
             * city : 441300
             * zone : 441303
             * shop_id : 62
             * terminal_type : 1
             * sort : 222
             * update_time : 1970-01-01 08:32:50
             * delete_time : 0
             * create_time : 1970-01-01 08:32:50
             * start_time : 1546843624
             * end_time : 1546930209
             * status : 1
             */

            private int id;
            private String title;

            private String path;
            private String type;
            private int prov;
            private int city;
            private int zone;
            private int shop_id;
            private int terminal_type;
            private int sort;
            private String update_time;
            private int delete_time;
            private String create_time;
            private int start_time;
            private int end_time;
            private int status;

            @Override
            public int compareTo(ListBean o) {
                //由于返回结果不一定是按顺序，需要进行排序
                if (this.sort > o.sort) {
                    return -1;
                } else {
                    if (this.id>o.id)
                    {
                        return 1;
                    }else{
                        if (this.shop_id>o.shop_id){
                            return -1;
                        }
                    }
                }
                //其它默认降序
                return -1;
            }
        }


    }
}
