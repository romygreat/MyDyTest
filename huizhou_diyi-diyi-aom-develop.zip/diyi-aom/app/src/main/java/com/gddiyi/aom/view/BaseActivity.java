package com.gddiyi.aom.view;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

import android.util.Log;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.widget.Toast;

import com.gddiyi.aom.R;
import com.gddiyi.aom.YidiApplication;
import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.controler.CrashHandler;
import com.gddiyi.aom.controler.DiyiInterface;
import com.gddiyi.aom.controler.WindowSettingImpls;
import com.gddiyi.aom.jsinterface.JavaScriptinterface;
import com.gddiyi.aom.model.dto.RequestJsonSn;
import com.gddiyi.aom.model.dto.ResponseUpdateAppInfo;
import com.gddiyi.aom.presenter.PressenterFactory;
import com.gddiyi.aom.presenter.RetrofitPresenter;
import com.gddiyi.aom.service.DownLoadService;
import com.gddiyi.aom.utils.netutils.DownloadUtil;
//import com.hdy.hdylights.LedAndChargeManager;


import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public abstract class BaseActivity extends Activity implements JavaScriptinterface.NoticefyPay, DiyiInterface.UpgradeApp {
    // TODO: 2019/6/20 在CrossWalkActivity中
    public boolean setWify = false;

    boolean xwalkWebviewReady = false;
    public static final int HANDLE_WAKEUP_SERVICE = 1002;
    Handler mBaseHandler;
    public boolean touch = true;
    public int BACKPRESS_TIME = 10;

    public boolean isAreadyPay = false;

    RetrofitPresenter mPrensenter;
    public int callStartSetttingActivityMethod = 0;
    @Setter
    @Getter
    public DiyiInterface.NetWorkChangeListsener netWorkChangeListsener;


    public void setReturnJsPay(boolean returnJsPay) {
        this.returnJsPay = returnJsPay;
    }

    public boolean getReturnJsPay() {
        return returnJsPay;
    }

    public boolean returnJsPay = true;
    public WindowSettingImpls windowSettingImpls;
    public static final int HANDLE_RELOAD_URL = 1000;
    public static final int HANDLE_DOWNLOAD_SERVICE = 2;
    public boolean restartApk = false;
    PressenterFactory mPressenterFactory = PressenterFactory.getInstance();

    boolean pingReulst = true;

    public CallBackPingService getmCallBackPing() {
        return mCallBackPing;
    }

    public void setmCallBackPing(CallBackPingService mCallBackPing) {
        this.mCallBackPing = mCallBackPing;
    }

    CallBackPingService mCallBackPing;
    long testNetFailTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        windowSettingImpls = new WindowSettingImpls();
        windowSettingImpls.fullScreen(this);
        windowSettingImpls.hideNavigationBar(this);
        //检查恢复设置后是否将sn号存于sdcard/serial/test中
        CrashHandler.getInstance().init(this, "" + getClass().getSimpleName());

        /**
         * CrashHandler.getInstance().init(this,""+currentActivity);
         * Binary XML file line #10: Binary XML file line #10
         *
         ****/
        super.onCreate(savedInstanceState);
        windowSettingImpls.hideBottomUIMenu(this);
        mBaseHandler = new Handler(getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case HANDLE_RELOAD_URL:
                        //视频播放多达30分钟,没有使用，关闭掉
                        //赞不处理
                        break;
                    case VSConstances.PAY2CHARGE:
                        handleCharge();
                        break;
                    case HANDLE_DOWNLOAD_SERVICE:
                        startDownloadService();
                        break;
                    case HANDLE_WAKEUP_SERVICE:
                        mPressenterFactory.createStartServicePresenter().startWakeUpService(BaseActivity.this);
                        break;
                    default:
                        break;
                }
                touch = true;
            }
        };
        //广播注册
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_POWER_DISCONNECTED);
        intentFilter.addAction(Intent.ACTION_POWER_CONNECTED);
    }

    private void handleCharge() {
        //已经支付，再一次判断充电
        if (isAreadyPay) {
            //顾客充电时间到，已经支付设置为false
            isAreadyPay = false;
            //付钱又可以充电
            setReturnJsPay(true);
//
        }
    }



    protected void onXWalkReady() {

    }

    private String TAG = "BaseActivity";


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    @Override
    protected void onStart() {
        super.onStart();
        windowSettingImpls.hideBottomUIMenu(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //确定取消充电广播？
        //需要unregister
        // unregisterReceiver(chargeBroadCast);
    }

    public boolean isNetworkAvailable() {
        //得到应用上下文
        Context context = getApplicationContext();
        // 获取手机所有连接管理对象（包括对wi-fi,net等连接的管理）  notificationManager /alarmManager
        ConnectivityManager connectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null) {
            return false;
        } else {
            if (networkInfo.isConnected()) {
                return true;
            }
        }
        return false;
    }

    //启动服务
    public void startDownloadService() {
        Intent downLoadIntent = new Intent(this, DownLoadService.class);
        startService(downLoadIntent);
    }

    @Override
    public boolean readyPay() {
        touch = false;
        return true;
    }

    @Override
    public boolean isNeedOpenCodeImg() {
        boolean b;
        //默认为true，需要打开二维码，还在充电中的需要设置为false
        b = getReturnJsPay();
//
        return b;
    }

    @Override
    public boolean finishPay(int time) {
        touch = true;
        //二、完成支付，无论是否为0，此时应该重新打开计时功能
        //三、将时间time保存，开启充电功能后，开启线程定时，定时取消充电功能
        Log.i(TAG, "finishPay: time" + time);
        SharedPreferences sharedPreferences = getSharedPreferences(getString(R.string.diyi), Context.MODE_PRIVATE);
        //防止客户第二次点击时出现显示已经支付情况
        if (time == 1 && (!isAreadyPay)) {
            Log.i(TAG, "时间：" + time);
            //已经付钱，不需要打开二维码，等待扫码完成再次打开充电二维码
            isAreadyPay = true;
            setReturnJsPay(false);
            int chageTime = sharedPreferences.getInt(getString(R.string.chargeTime), 1);
            //如果有发过消息，需要移除这个消息
            if (mBaseHandler.hasMessages(VSConstances.PAY2CHARGE)) {
                mBaseHandler.removeMessages(VSConstances.PAY2CHARGE);
            }
            //需要一个顺序时间，否则受影响
            mBaseHandler.sendEmptyMessageDelayed(VSConstances.PAY2CHARGE, chageTime * 60 * 1000);
            return true;
        }

        return false;
    }

    @Override
    public boolean unCharge() {
        isAreadyPay = false;
        //付钱又可以充电
        setReturnJsPay(true);
//
        return false;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        //屏蔽keyevent
        if ((event.getKeyCode() == KeyEvent.KEYCODE_BACK)) {
            android.os.Process.killProcess(android.os.Process.myPid());
            return true;
//

        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return super.onKeyDown(keyCode, event);
    }

    public boolean ping(String code) {
        boolean b = false;
        //中国电信的ip
        String ip = "114.114.114.114";
        // ping的地址，可以换成任何一种可靠的外网
        Process p = null;
        try {
            if (code.contains("chckPingAgain")) {
                testNetFailTime = System.currentTimeMillis();
                isNetOuterAvailable(code);
            } else if ("checkNetWork".equals(code)) {
                p = Runtime.getRuntime().exec("ping -c 3 -w 2 " + ip);
            } else {
                p = Runtime.getRuntime().exec("ping -c 2 -w 2 " + ip);
            }
        } catch (IOException e) {
            handleIOException(e);
        }
        // ping网址2次
        int status = 0;
        try {
            if (p != null) {
                status = p.waitFor();
            }
        } catch (InterruptedException e) {
            handleInterruptedException(e);

        }
        if (status == 0) {
            ((YidiApplication) getApplication()).setNoNetwork(false);
            if (getmCallBackPing() != null) {
                mCallBackPing.pingSuccess(code);
            }
            return true;
        } else {
            ((YidiApplication) getApplication()).setNoNetwork(true);
            //当fail时ping很快返回结果,偶现很慢，需要2秒多
            if (getmCallBackPing() != null) {
                mCallBackPing.pingFail(code);
            }
            return false;
        }

    }

    private void handleInterruptedException(InterruptedException e) {
        if (getmCallBackPing() != null) {
            mCallBackPing.pingException("handleInterruptedException in BaseActivity");
        }
        e.printStackTrace();
    }

    private void handleIOException(IOException e) {
        if (getmCallBackPing() != null) {
            mCallBackPing.pingException("handleIOException in BaseAct");
        }
        e.printStackTrace();
    }

    protected void startPingFailBaseActivity(String code) {
        Intent intent = new Intent(this, PingFailActivity.class);
        intent.putExtra(getString(R.string.LOG), code);
        startActivity(intent);
    }

    @Override
    public String getToken(String str) {
        return null;
    }

    @Override
    public String downLoadAPP(String content, String savePhoneUrl, DownloadUtil.OnDownloadListener listener) {
        return null;
    }


    @Override
    public String getUpgradeInfo(ResponseUpdateAppInfo upgradeInfo) {
        return null;
    }

    @Override
    public boolean isDownLoadSucess(boolean success) {
        return false;
    }

    public interface CallBackPingService {
        int pingSuccess(String code);

        int pingFail(String code);

        int pingException(String code);
    }

    public boolean initPermission() {
        String[] permissions = {
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.ACCESS_NETWORK_STATE,
                Manifest.permission.INTERNET,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_PHONE_STATE
        };
        ArrayList<String> toApplyList = new ArrayList<String>();
        for (String perm : permissions) {
            if (PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, perm)) {
                toApplyList.add(perm);
                // 进入到这里代表没有权限，应该进入无权限页面，同时设置相应的权限，避免白屏情况
                startActivity(new Intent(this, PermmissionActivity.class));
                onDestroy();
                this.finish();
                return false;
            } else {
                //权限设置完成好
                return true;
            }
        }
        String[] tmpList = new String[toApplyList.size()];
        if (!toApplyList.isEmpty()) {
            ActivityCompat.requestPermissions(this, toApplyList.toArray(tmpList), 123);
        }
        return false;
    }


    /**
     * @param code
     * @return
     * @description hello
     * 判断外网是否正常
     */
    boolean isNetOuterAvailable(final String code) {
        mPrensenter = new RetrofitPresenter();
        //response sn,当SN出问题，容易出现问题
        mPrensenter.setCallBackResponsebody(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> r) {
                //服务器问题出现空指针
                ((YidiApplication) getApplication()).setNoNetwork(false);
                ((YidiApplication) getApplication()).setOutNetWorkAvailable(true);
                if (getNetWorkChangeListsener() != null) {
                    getNetWorkChangeListsener().noticeNetWorkChange(0, code);
                }
                //触摸时不调用该回调方法
                if ((getmCallBackPing() != null) && !"checkNetworkAvailable".equals(code)) {
                    mCallBackPing.pingSuccess(code);
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                //设置网络是否成功
                ((YidiApplication) getApplication()).setNoNetwork(true);
                ((YidiApplication) getApplication()).setOutNetWorkAvailable(false);
                //网络监听失败
                if (getNetWorkChangeListsener() != null) {
                    //注意sn号不能为空，否则可能报错
                    getNetWorkChangeListsener().noticeNetWorkChange(1, code);
                }
                if ((getmCallBackPing() != null) && !code.contains("noticeNetWorkChange")) {
                    mCallBackPing.pingFail(code);
                }
            }
        });
        RequestJsonSn requestJsonSn = new RequestJsonSn();
        //这里的序列号出现了问题，导致容易掉线
        requestJsonSn.setSn(JavaScriptinterface.getSerialNumber());
        String urlSN = VSConstances.URL_SN;
        mPrensenter.retrofitPostSn(urlSN, mPrensenter.postJsonString(requestJsonSn));
        return true;
    }

    public static void restartAPP(Context context) {
        Intent intent = new Intent(context, CrossWalkActivity.class);
        @SuppressLint("WrongConstant") PendingIntent
                restartIntent = PendingIntent.getActivity(context, 0, intent,
                Intent.FLAG_ACTIVITY_NEW_TASK);
        AlarmManager mgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        assert mgr != null;
        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 200,
                restartIntent);
        // 1秒钟后重启应用
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }

    public void deleteCacheFile(File file) {
        if (file.exists() == false) {
            return;
        } else {
            Log.d(TAG, "deleteCacheFile: "+file.isFile());
            if (file.isFile()) {
                return;
            }
            if (file.isDirectory()) {
                File[] childFile = file.listFiles();
                if (childFile == null || childFile.length == 0) {
                    return;
                }
                file.delete();
            }
        }
    }


    public String getVerName() {
        String verName = "";
        try {
            verName = getPackageManager().
                    getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return verName;
    }

    public String getConnectedWifiName() {
        WifiManager wifiMgr = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifiMgr.getConnectionInfo();
        String wifiId = info != null ? info.getSSID() : null;
        //获取的原生”GDDIYI",需要剪切
        wifiId = wifiId.substring(1, wifiId.length() - 1);
        return wifiId.trim();
    }

    /**
     * 设置当前属于哪个页面，Activity必须继承该基类，
     * 否则页面切换可能受影响
     */
    public abstract void currentActivity();

    public int getCurrentActivity() {
        int currentActivityPage = ((YidiApplication) getApplication()).getCurrentActivityPage();
        Log.d(TAG, "getCurrentActivity: "+currentActivityPage);
        return currentActivityPage;
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        //效果不是很明显
//        disableStatusBars();
    }

    void disableStatusBars() {
        try {
            Object service = getSystemService("statusbar");
            Class<?> claz = Class.forName("android.app.StatusBarManager");
            Method expand = claz.getMethod("collapsePanels");
            expand.invoke(service);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
