package com.gddiyi.aom.model;

import android.support.v4.content.FileProvider;
/**
 * android 7.0以上需要，否则影响处理文件功能
 */
public class MyFileProvider extends FileProvider {
}
