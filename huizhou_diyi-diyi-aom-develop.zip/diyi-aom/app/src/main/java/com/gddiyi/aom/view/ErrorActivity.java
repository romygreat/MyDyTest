package com.gddiyi.aom.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.gddiyi.aom.R;
import com.gddiyi.aom.YidiApplication;
import com.gddiyi.aom.constant.VSConstances;

public class ErrorActivity extends BaseActivity {
    EditText mainUrlEdit,serviceUrlEdit;
    Button confirm;
    String mainUrlString,serviceUrlString;
    static  boolean isChangeUrl=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.error);
        initView();
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mainUrlEdit.getText().toString()!=null){
                    mainUrlString=mainUrlEdit.getText().toString();
                }
                if (serviceUrlEdit.getText().toString()!=null){
                    serviceUrlString=serviceUrlEdit.getText().toString();
                }
                VSConstances.MAIN_URL=mainUrlString;
                isChangeUrl=true;
                ErrorActivity.this.finish();

            }


        });

    }

    @Override
    public void currentActivity() {
        ((YidiApplication)getApplication()).setCurrentActivityPage(VSConstances.ERROR_ACTIVITY);
    }

    private void initView() {
        mainUrlEdit=findViewById(R.id.mainUrlEdit);
        serviceUrlEdit=findViewById(R.id.serviceUrlEdit);
        confirm=findViewById(R.id.confirm);
    }

}
