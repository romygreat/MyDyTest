package com.gddiyi.aom;

import android.app.Application;
import android.util.Log;

import com.gddiyi.aom.constant.VSConstances;

import lombok.Getter;
import lombok.Setter;

public class YidiApplication extends Application {

    String TAG = getClass().getSimpleName();
    public static YidiApplication yidiApplication;
    boolean WifiPage = true;
    @Setter
    @Getter
    boolean isClickChoiceWifi =false;
    @Getter
    @Setter
    public int currentActivityPage=0;
    @Getter
    @Setter
    public boolean isFresh=false;

    @Setter
    @Getter
    boolean playAd = true;

    @Setter
    @Getter
    boolean isNeedUpdateAdFile=false;

    @Setter
    @Getter
    boolean outNetWorkAvailable=true;

    boolean pingsu = false;

    public boolean getPingsu() {
        return pingsu;
    }

    public boolean getNoNetwork() {
        return noNetwork;
    }

    public void setNoNetwork(boolean noNetwork) {
        this.noNetwork = noNetwork;
    }

    boolean noNetwork = false;

    public void setVideo(String video) {
        this.video = video;
    }

    String video = "noPlayVideo";

    public String getVideo() {
        return video;
    }

    public boolean getWifiPage() {
        return WifiPage;
    }

    public void setWifiPage(boolean wifiPage) {
        WifiPage = wifiPage;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        VSConstances.setContext(getApplicationContext());
        yidiApplication=(YidiApplication) getApplicationContext();
        Log.d(TAG, "onCreate: "+getApplicationContext());
    }
    public static YidiApplication getMyAppcation(){
        return yidiApplication;
    }

}