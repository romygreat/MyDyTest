package com.gddiyi.aom.presenter;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.Toast;

import com.gddiyi.aom.R;
import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.controler.CrashHandler;
import com.gddiyi.aom.view.CrossWalkActivity;
//import com.hdy.hdylights.LedAndChargeManager;


import static android.webkit.WebSettings.LOAD_NO_CACHE;

public class CrossWalkPresenter {
    String TAG=getClass().getSimpleName();
    public static final int HANDLE_SUCCESS = 13;
    public static final int HANDLE_DISS_ALERTDIALOG = 14;
    public static final int HANDLE_KEYBACK = 17;
    public static final int HANDLE_AD = 1;
    public static final int HANDLE_SERVICE = 2;
    public static final int HANDLE_INIT_TIMER = 3;
    public static final int HANDLE_TIMER = 4;
    public static final int HANDLE_TOAST = 5;
    public static final int HANDLE_LOAD_MAIN_URL = 6;
    public static final int HANDLE_DELAY_2S = 8;
    public static final int HANDLE_NO_NET_WORK_TIPS = 9;
    public static final int HANDLE_TOUCH_PING = 11;
    public static final int HANDLE_SHOW_WEB_VIEW = 12;
    public static final int HANDLE_ABOUT_BLANK = 15;
    Activity activity;

    public CrossWalkPresenter(Activity activity) {
        this.activity = activity;
    }
   public WebSettings setWebViewSettings(WebView mWebView){
        WebSettings settings;
        settings = mWebView.getSettings();
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        //正式版本应该屏蔽该加载缓存，这里调试时可以动态改变h5
//        settings.setCacheMode(LOAD_NO_CACHE);
        //注册javascript接口
        settings.setJavaScriptEnabled(true);


        mWebView.loadDataWithBaseURL(null, null, "text/html", "utf-8", null);
        //设置不能放大
        mWebView.setVisibility(View.INVISIBLE);
        mWebView.clearCache(false);

        settings.setLoadWithOverviewMode(true);
        return settings;
    }
    public void setZoom(WebSettings settings){
        settings.setTextZoom(100);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
    }
     public void startTimer( boolean touch,android.os.Handler mHandler){
         Log.d(TAG, "startTimer:touch= "+touch);
        if (touch) {
        if (mHandler != null) {
            //广告应为2分钟的设置时间，演示效果更好
            Log.i(TAG, "startTimer: onTouch");
            mHandler.sendEmptyMessageDelayed(HANDLE_TIMER, VSConstances.DELAYTIME);
        }
    }
    }
    public void stopTimer( boolean touch,android.os.Handler mHandler){
        if (touch) {
            if (mHandler != null) {
                if (mHandler.hasMessages(HANDLE_TIMER)) {
                    mHandler.removeMessages(HANDLE_TIMER);
                }
            }
        }
    }

    public void resetSSID(Activity crossWalkActivity) {
        SharedPreferences mSharedPreferences = crossWalkActivity.getSharedPreferences
                (crossWalkActivity.getString(R.string.diyi), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        //SSID默认初始状态,这样在启动时无网络会进入wifi页面
        editor.putString(crossWalkActivity.getString(R.string.SSID), "..");
        editor.commit();
    }

    public void removewifiBySsid(Activity crossWalkActivity) {
        WifiManager mWifiManager = (WifiManager) crossWalkActivity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiAutoConnectPresenter wac = new WifiAutoConnectPresenter(mWifiManager);
        wac.removeWifiBySsid(mWifiManager);
    }

    public void checkToast(Toast toast) {
        if (toast != null) {
            toast.cancel();
        }
    }

    public void removeHandleTouch(Handler mHandler) {
        if (mHandler.hasMessages(HANDLE_TOUCH_PING)) {
            mHandler.removeMessages(HANDLE_TOUCH_PING);
        }
    }

    public void removeNoNetworkTips(Handler mHandler) {
        if (mHandler.hasMessages(HANDLE_NO_NET_WORK_TIPS)) {
            mHandler.removeMessages(HANDLE_NO_NET_WORK_TIPS);
        }
    }
}
