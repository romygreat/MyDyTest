package com.gddiyi.aom.controler;


import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.gddiyi.aom.R;
import com.gddiyi.aom.view.CrossWalkActivity;
import com.gddiyi.aom.view.PingFailActivity;

public class CrashHandler implements Thread.UncaughtExceptionHandler
//在baseActivity的onCreate
//CrossWalkPresenter构造函数中
{
    public static final String TAG = "CrashHandler";
    private static CrashHandler INSTANCE = new CrashHandler();
    private Context mContext;
    String activityClass;

    private CrashHandler() {
    }

    public static CrashHandler getInstance() {
        return INSTANCE;
    }

    public void init(Context context, String activityClass) {
        mContext = context;
        this.activityClass = activityClass;
        Thread.setDefaultUncaughtExceptionHandler(this);

    }

    @Override
    public void uncaughtException(Thread thread, Throwable ex) {
        //异常报错，进入的代码
        Log.d(TAG, "uncaughtException: "+ex.toString());
        MyThreadPool.getExeCutor().submit(new Runnable() {
            @Override
            public void run() {
                if (activityClass.equals("pingFail")) {
                    Intent intent = new Intent(mContext, PingFailActivity.class);
                    intent.putExtra(mContext.getString(R.string.LOG),"unCaughtEx");
                    mContext.startActivity(intent);
                } else {
                    Log.d(TAG, "run: ");
                    Intent intent = new Intent(mContext, CrossWalkActivity.class);
                    mContext.startActivity(intent);
                }

                android.os.Process.killProcess(android.os.Process.myPid());
            }
        });

    }
}