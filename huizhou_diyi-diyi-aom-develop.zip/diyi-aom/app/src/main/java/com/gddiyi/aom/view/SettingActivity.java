package com.gddiyi.aom.view;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.text.SpannableString;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.gddiyi.aom.R;
import com.gddiyi.aom.YidiApplication;
import com.gddiyi.aom.constant.ConigInfo;
import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.controler.MyThreadPool;
import com.gddiyi.aom.customview.dialog.BindTableDialog;
import com.gddiyi.aom.customview.dialog.UnBindTableListDialog;
import com.gddiyi.aom.customview.dialog.UpdateDialog;
import com.gddiyi.aom.jsinterface.JavaScriptinterface;
import com.gddiyi.aom.model.dto.ResponseUnbindTableList;
import com.gddiyi.aom.presenter.AppUpgradePresenter;
import com.gddiyi.aom.presenter.CrossWalkPresenter;
import com.gddiyi.aom.presenter.RequestPresenter;
import com.gddiyi.aom.presenter.RetrofitPresenter;
import com.gddiyi.aom.presenter.UpgradePresenter;
import com.gddiyi.aom.service.GetTokenService;
import com.gddiyi.aom.utils.DeleteFileUtil;
import com.gddiyi.aom.utils.netutils.CallBackUtil;
import com.gddiyi.aom.utils.netutils.DownloadUtil;
import com.gddiyi.aom.utils.netutils.OkhttpUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SettingActivity extends BaseActivity implements
        View.OnClickListener, UpdateDialog.CallBack, BindTableDialog.OnClickListener {
    String TAG = getClass().getSimpleName();
    TextView serialTv;
    TextView updateTv;
    TextView exitTv;
    TextView freshTv;
    TextView currenTableNameTv;
    TextView connectedWifiNameTv;

    TextView currentVersionTv;
    ProgressBar progressBar;
    SpannableString spanText;
    LinearLayout bindTableList, checkUpdatell, wifill, clearCachell,videoll;
    UpgradePresenter upgradePresenter;
    UpdateDialog updateDialog;
    UnBindTableListDialog unBindTableListDialog;
    boolean isNeedUpdate = false;
    RetrofitPresenter mPrensenter;

    String[] tableList;
    String token;
    int updataTvGraverty;
    int serveAppVersionCode;
    String serveApkPath;
    String serveMd5;
    String serverAppName;
    AppUpgradePresenter.CallBack appCallBack=new AppUpgradePresenter.CallBack() {
        @Override
        public void UpgradeInfo(String json) {
            Log.d(TAG, "UpgradeInfo: "+json);
            try {
                JSONObject jsonObject=new JSONObject(json);
                int version=(int) jsonObject.get("versionCode");
                serveMd5 =(String)jsonObject.get("md5");
                serverAppName =(String)jsonObject.get("appName");
                serveApkPath=VSConstances.APP_UPGRADE_URL_PATH+serverAppName;
                Log.d(TAG, "UpgradeInfo:version= "+version);
                Log.d(TAG, "UpgradeInfo: apkPath="+ serveApkPath);
                Log.d(TAG, "UpgradeInfo:md5 "+ serveMd5);
                Log.d(TAG, "UpgradeInfo:appName "+appName);
                serveAppVersionCode=version;
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    };

    //-------------更新相关变量------------------------

    String apkurl = VSConstances.URL_ABS_APPDOWNLOAD;
    String appName = "";
    String upgradeInfomation = "";
    HashMap<String, String> unbindTableMap;

    //-------------更新相关变量-----------------------

    boolean restartAPP = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settingactivity);
        setWify = true;
        restartApk = true;
        initView();
        initData();

    }
    boolean  isSetRedDot=false;
    private void initData() {

        serialTv.setText(JavaScriptinterface.getSerialNumber());

        currentVersionTv.setText(getVerName());

        if (getConnectedWifiName() != null) {
            Log.d(TAG, "initData: ");
            connectedWifiNameTv.setText(getConnectedWifiName());
        } else {
        }
        //优化检查更新结果
        upgradePresenter = new UpgradePresenter(this, this);
        checkUpdateAPP();
        connectedWifiNameTv.postDelayed(new Runnable() {
            @Override
            public void run() {
                checkUpdateAPP();
            }
        },4000);
        //获取桌台号
        getTableList();


    }

    private void getTableList() {
        mPrensenter = new RetrofitPresenter();
        Intent intent = new Intent(this, GetTokenService.class);
        startService(intent);
        GetTokenService.setTokenBindTableInterface(new GetTokenService.TokenBindTableInterface() {
            @Override
            public String setToken(String token) {
                SettingActivity.this.token = token;
                Log.i(TAG, "getTableList:token= " + token);
                if (ConigInfo.tableNum != null) {
                    currenTableNameTv.setText(ConigInfo.tableNum);
                }
                showTableList(token);
                return null;
            }
        });
    }

    public void showTableList(String token) {
        showUnbindTableList(token);
    }

    private void showUnbindTableList(String token) {
        final RequestPresenter requestPresenter = new RequestPresenter(this, token);
        requestPresenter.getUnbindTableList().enqueue(new Callback<ResponseUnbindTableList>() {
            @Override
            public void onResponse(Call<ResponseUnbindTableList> call, Response<ResponseUnbindTableList> response) {
                //响应成功
                if (response.code() == VSConstances.REQUEST_OK) {
                 //保存数据
                    tableList = new String[response.body().getData().size()];
                    unbindTableMap = new HashMap<>(response.body().getData().size());
                    for (int i = 0; i <= tableList.length - 1; i++) {
                        if (response.body().getData().get(i).getTitle() != null) {
                            tableList[i] = response.body().getData().get(i).getTitle();
                            //通过map方式去处理
                            unbindTableMap.put(response.body().getData().get(i).getTitle(), response.body().getData().get(i).getId());
                        }
                    }
                }
            }
            @Override
            public void onFailure(Call<ResponseUnbindTableList> call, Throwable t) {
                Log.d(TAG, "onFailure: testMy");

            }
        });
    }
    AppUpgradePresenter appUpgradePresenter=new AppUpgradePresenter(this,appCallBack);
    private void checkUpdateAPP() {
        //实例化UpgradePresenter，并且得到token,得到token请求并通知返回数据，仅仅是一个是否需要更新的数据

        upgradePresenter = new UpgradePresenter(this, this);
         if (appUpgradePresenter.isNeedtoUpdate(serveAppVersionCode)){
             isNeedUpdate=true;
             runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (updateDialog != null) {
                                updateDialog.updateTvTips.setText("检查到有新版本，是否立刻更新");
                            }
                        }
                    });
             //避免出现两次红点
             if (!isSetRedDot)
             {  isSetRedDot=setSuperScriptSpan(updateTv);
             }
         }else {
             showLastVersion(updateTv);
         }

    }


    public void showLastVersion(final TextView testView) {
        testView.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                testView.setText("检查新版本");

            }
        });
    }

    private void initView() {
        serialTv = findViewById(R.id.serialNum);
        updateTv = findViewById(R.id.updateTv);
        exitTv = findViewById(R.id.testView);
        freshTv = findViewById(R.id.freshSetting);
        currenTableNameTv = findViewById(R.id.currentTableName);
        connectedWifiNameTv = findViewById(R.id.connectedWifiName);
        progressBar = findViewById(R.id.progressBar);
        bindTableList = findViewById(R.id.bindTableList);
        checkUpdatell = findViewById(R.id.checkUpdatell);
        clearCachell = findViewById(R.id.clearCache);
        videoll=findViewById(R.id.setting_video);
        wifill = findViewById(R.id.wifiLinearLayout);
        currentVersionTv = findViewById(R.id.currentVersion);
        bindTableList.setOnClickListener(this);
        checkUpdatell.setOnClickListener(this);
        clearCachell.setOnClickListener(this);
        wifill.setOnClickListener(this);
        exitTv.setOnClickListener(this);
        videoll.setOnClickListener(this);
        freshTv.setOnClickListener(this);

        showLastVersion(updateTv);
        progressBar.setVisibility(View.INVISIBLE);
        updataTvGraverty = updateTv.getGravity();
    }

    public boolean setSuperScriptSpan(final TextView testView) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                SpannableString spanText = appUpgradePresenter.getSpannableString();
                testView.setGravity(Gravity.NO_GRAVITY);
                testView.append(spanText);
            }
        });
        return true;
    }

    BindTableDialog bindDialog;

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (restartAPP) {
            restartAPP(this);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bindTableList:
                //注意序列号需要写入sdcard/serial中，自己输入的序列号可能导致无效的结果
                if (unbindTableMap != null) {
                    bindDialog = new BindTableDialog(this, R.style.dialog_download, unbindTableMap);
                    bindDialog.setOnClickListener(this);
                    if (!bindDialog.isShowing()) {
                        Log.d(TAG, "onClick: bindDialog.isShowing");
                        bindDialog.show();
                        //unBindTableListDialog是未绑定的桌台号名称列表
                        unBindTableListDialog = new UnBindTableListDialog(this, R.style.dialog_download, tableList);
                        unBindTableListDialog.setItemClick(getItemClick());
                    }
                    bindDialog.spinner.setUnBindTableListDialog(unBindTableListDialog);

                }
                break;
            case R.id.checkUpdatell:
                Log.i(TAG, "onClick: ");
                if (updateDialog == null) {
                    if (isNeedUpdate) {
                        updateDialog = new UpdateDialog(SettingActivity.this,
                                R.style.dialog_download, "检查到有新版本，是否立刻更新", true);
                    } else {
                        updateDialog = new UpdateDialog(SettingActivity.this, R.style.dialog_download, false);
                    }
                }
                if (!updateDialog.isShowing()) {
                    updateDialog.setCallBack(this);
                    updateDialog.show();
                }
                break;
            case R.id.testView:
                //退出键
                Log.d(TAG, "onClick: exit");
                restartApk = false;
                this.finish();
                break;
            case R.id.wifiLinearLayout:
                Log.i(TAG, "onClick: wifiLinearLayout");
                CrossWalkPresenter mCrossWalkPresenter = new CrossWalkPresenter(this);
                mCrossWalkPresenter.resetSSID(this);
                mCrossWalkPresenter.removewifiBySsid(this);
                Intent intent = new Intent(this, FirstBootActivity.class);
                //设置wifi传递给firstBootActivity,键同样也是noNetWork，但是值为setWifi,有点别扭
                intent.putExtra("netWork", "setWifi");
                ((YidiApplication) getApplication()).setWifiPage(true);
                ((YidiApplication) getApplication()).setNoNetwork(false);
                startActivity(intent);
                restartApk = false;
                //因为wifi需要清理，所以这个也销毁
                CrossWalkActivity.mThis.finish();
                this.finish();
                break;
            case R.id.clearCache:
                restartAPP = true;
                clearCache();
                break;
            case R.id.freshSetting:
                ((YidiApplication) getApplication()).setFresh(true);
                printMytips("刷新中");
                this.finish();
                break;
            case R.id.setting_video:
                //进入视频广告
                startActivity(new Intent(this,VideoActivity.class));
                break;
            default:
                break;
        }
    }

    String tableID = "";

    @NonNull
    public UnBindTableListDialog.ItemClick getItemClick() {
        return new UnBindTableListDialog.ItemClick() {
            @Override
            public void onClickItem(String selectedItem) {
                tableID = unbindTableMap.get(selectedItem);
                unBindTableListDialog.dismiss();
                bindDialog.showSelectedItem(selectedItem);
                Log.d(TAG, "onClickItem: tableID=" + tableID);
            }
        };
    }

    @Override
    public boolean onConfirmClick(View view, String selectedId) {
        Log.d(TAG, "onConfirmClick: "+tableID);
        if (tableID != null) {
            requestChangeTableNum(tableID);
        }
        //绑定presenter开始执行
        return false;
    }

    @Override
    public boolean showToast(String str) {
        printMytips(str);
        return false;
    }

    public void clearCache() {
        restartApk = true;
//        deleteCacheFile(new File("data/data/" + getPackageName() + "/app_xwalkcore"));
        deleteCacheFile(new File("data/data/" + getPackageName() + "/app_webview"));

        this.finish();
    }

    @NonNull
    public DownloadUtil.OnDownloadListener getListener() {
        return new DownloadUtil.OnDownloadListener() {
            @Override
            public void onDownloadSuccess() {
                MyThreadPool.startThread(new Runnable() {
                    @Override
                    public void run() {
                        File file = new File(VSConstances.DOWNLOADAPP_ABS_SAVEDIR + serverAppName);
                        Log.d(TAG, "run:appName= "+appName);
                        if (file.exists()) {
                            Log.d(TAG, "run: 存在文件="+file.getName());
                            if (!SettingActivity.this.isFinishing()) {
                                //APk下载安全认证，比对MD5，如果无法通过认证，下载后一直会这么提示
                                checkMd5(file);
                            }
                        }
                    }
                });
            }

            @Override
            public void onDownloading(final int progress) {
                progressBar.setProgress(progress);
            }

            @Override
            public void onDownloadFailed() {

            }
        };
    }

    private void checkMd5(final File file) {
        String md5 = AppUpgradePresenter.getFileMD5(file).trim();
        Log.d(TAG, "nativeMd5= "+md5);
        Log.d(TAG, "serveMd5="+ serveMd5);
         if (md5==null){
             return;
         }
        //验证需要从eclipse获取MD5的值
        if (md5.equals(serveMd5.trim())) {
            upgradePresenter.installApk(file, SettingActivity.this);
        } else {
            //需要在主线程中
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(SettingActivity.this, "下载应用出现故障，请检查网络是否正常", Toast.LENGTH_LONG).show();
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(SettingActivity.this);
                    alertDialog.setTitle("验证码不一致，建议重新下载，是否重新下载？");
                    alertDialog.setPositiveButton("重新下载", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //重新下载
                            windowSettingImpls.hideBottomUIMenu(SettingActivity.this);
                            DeleteFileUtil.deleteDirectory(Environment.getExternalStorageDirectory().getPath() +"/downloadAPP");
                            progressBar.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    printMytips("准备下再中");
                                    upgradePresenter.downLoadAPP(serveApkPath, VSConstances.DOWNLOADAPP_SAVEDIR, getListener());
                                }
                            },3_000);

                        }
                    });
                    alertDialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
//                            upgradePresenter.installApk(file, SettingActivity.this);
                        }
                    });
                    alertDialog.show();
                }
            });

        }
    }
    void printMytips(final String str) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onClickUpdate(UpdateDialog updateDialog) {
        //更新app
        windowSettingImpls.hideBottomUIMenu(this);
        if (isNeedUpdate) {
            progressBar.setVisibility(View.VISIBLE);
            updateDialog.dismiss();
            apkurl = VSConstances.URL_ABS_APPDOWNLOAD;
            upgradeInfomation = upgradePresenter.getUpgradeInfomation();
            String url=apkurl + appName;
            upgradePresenter.downLoadAPP(serveApkPath, VSConstances.DOWNLOADAPP_SAVEDIR, getListener());
        } else {
            updateDialog.updateTvTips.setText("当前已是最新版本");
        }
    }


    private void requestChangeTableNum(String tableId) {
        JSONObject postArgs = new JSONObject();
        try {
            postArgs.put("token", token);
            postArgs.put(VSConstances.MACHINE, VSConstances.MACHINE);
            postArgs.put("sn", JavaScriptinterface.getSerialNumber());
            postArgs.put("id", tableId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        HashMap headerExtraInfo=new HashMap();
        headerExtraInfo.put("Content-Type","application/json;charset=UTF-8");
        headerExtraInfo.put("Behavior","api");
        OkhttpUtil.okHttpPostJson(VSConstances.REQUEST_CHANGETABLE_NUM, postArgs.toString(),headerExtraInfo, new CallBackUtil() {
            @Override
            public Object onParseResponse(okhttp3.Call call, okhttp3.Response response) {
                try {
                    Log.d(TAG, "onParseResponse: "+response.body().string());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (response.code() == VSConstances.REQUEST_OK) {
                    Log.d(TAG, "onParseResponse: REQUEST_OK");
                    printMytips("修改桌台号中，请稍等");
                    ((YidiApplication) getApplication()).setFresh(true);
                    SettingActivity.this.finish();
                }
                return null;
            }

            @Override
            public void onFailure(okhttp3.Call call, Exception e) {
                Log.d(TAG, "onFailure: 123"+e.toString());
            }

            @Override
            public void onResponse(Object response) {

            }
        });

    }

    @Override
    public void onBackPressed() {
        windowSettingImpls.hideBottomUIMenu(this);
    }

    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.SETTING_ACTIVITY);
    }



}
