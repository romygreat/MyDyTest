package com.gddiyi.aom.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;

public class MyWebView extends WebView {
    final  static String TAG="MyWebView";
    public MyWebView(Context context) {
        super(context);
        this.getSettings().setMediaPlaybackRequiresUserGesture(false);
        Log.d(TAG, "MyWebView: 1");
    }

    public MyWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.getSettings().setMediaPlaybackRequiresUserGesture(false);
        //在这里加载
        Log.d(TAG, "MyWebView: 2");
    }

    public MyWebView(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr,0);
        this.getSettings().setMediaPlaybackRequiresUserGesture(false);
        Log.d(TAG, "MyWebView: 3");
    }

    public MyWebView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        this.getSettings().setMediaPlaybackRequiresUserGesture(false);
        Log.d(TAG, "MyWebView: 4");
    }



}
