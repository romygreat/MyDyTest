package com.gddiyi.aom.controler;

public interface VoiceInterface {
    String doWhatByVoice(String s);
    String doSearch(String s);

    interface VoiceURL{
    void voiceOrder();
    void voiceAddDishes();
    void voiceQrCharge();
    void voiceTmpBillPay();
    void voiceIntroFood();
    }
    interface Phone{
        void voicePlayAd();
        void voiceSetWifi();
    }
    interface  Exit{
       void exitApp();
    }
    interface  IntroduceProduct{
        void speakProduct();
    }
    interface  Search{
        void doMySearch(String s);
    }
}
