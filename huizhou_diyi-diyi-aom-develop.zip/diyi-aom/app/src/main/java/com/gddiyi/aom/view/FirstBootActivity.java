package com.gddiyi.aom.view;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.gddiyi.aom.R;
import com.gddiyi.aom.YidiApplication;
import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.controler.MyThreadPool;
import com.gddiyi.aom.presenter.WifiAutoConnectPresenter;

import java.util.ArrayList;

/**
 * @author romygreat
 * @date 20180119
 * wifi页面
 * @see WifyFragment
 */
public class FirstBootActivity extends FragmentActivity implements WifyFragment.FistBootActvityInterface {
    FragmentTransaction fragmentTransaction;
    String TAG = getClass().getSimpleName();
    WifyFragment fragment;
    WifiAutoConnectPresenter wac;
    WifiManager mWifiManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        fullScreen();
        super.onCreate(savedInstanceState);
        hideBottomUIMenu();
        setContentView(R.layout.bootlayout);
        //WIFI列表设置fragment
        VSConstances.SET_FROM_WIFY = true;
        //特殊，直接这里设置
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.FIRSTBOOT_ACTIVITY);
        mWifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wac = new WifiAutoConnectPresenter(mWifiManager);
        initPermission();
        //这里设置广告false
        ((YidiApplication) getApplicationContext()).setPlayAd(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideBottomUIMenu();
        //没有网络进入的连接，不包含首次无网络
        boolean wifiPage = ((YidiApplication) getApplication()).getWifiPage();
        Log.d(TAG, "onResume: "+wifiPage);
        if (wifiPage) {
            Log.i(TAG, "onResume:wifiPage ");
            wac.removeWifiBySsid(mWifiManager);
            ((YidiApplication) getApplication()).setWifiPage(false);
            getWifyFragment();
        } else {
            Log.i(TAG, "onResume: else no netWork");
            if (((YidiApplication) getApplication()).getNoNetwork()) {
                //设置对应的为false
                // TODO: 2019/8/29
//                Intent intent = new Intent(this, PingFailActivity.class);
//                startActivity(intent);
//                this.finish();
                getWifyFragment();

            } else {
                ((YidiApplication) getApplication()).setWifiPage(false);
//            首次安装APP且无网络，noSetWifi进入wify设置
//            与设置wifi时进入此fragment
                //移除wifi耗时操作
                MyThreadPool.startThread(new Runnable() {
                    @Override
                    public void run() {
                        wac.removeWifiBySsid(mWifiManager);
                    }
                });
                getWifyFragment();

            }
        }
    }

    private void fullScreen() {
        // 隐藏标题
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    /**
     * 进入wifi设置界面，这个界面比较重要
     */
    private void getWifyFragment() {
        //添加判断，单例模式
        // TODO: 2019/5/30
//        if (fragment!=null)
        {
            fragment = new WifyFragment();
            fragment.mFistBootActvityInterface = this;
            fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.mainActivityId, fragment);
            fragmentTransaction.commit();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    protected void hideBottomUIMenu() {
        //隐藏虚拟按键，并且全屏
        View decorView = getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        decorView.setSystemUiVisibility(uiOptions);
    }

    public void initPermission() {
        String permissions[] = {
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.ACCESS_NETWORK_STATE,
                Manifest.permission.INTERNET,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_WIFI_STATE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_PHONE_STATE
        };
        ArrayList<String> toApplyList = new ArrayList<String>();
        for (String perm : permissions) {
            if (PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, perm)) {
                toApplyList.add(perm);
                // 进入到这里代表没有权限
            }
        }
        String tmpList[] = new String[toApplyList.size()];
        if (!toApplyList.isEmpty()) {
            ActivityCompat.requestPermissions(this, toApplyList.toArray(tmpList), 123);
        }

    }

    @Override
    public void onClose(boolean close) {
        if (this != null) {
            this.finish();
        }
    }
}

