package com.gddiyi.aom.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class WifiStrengthBroadcastReceiver extends BroadcastReceiver {
    String TAG=getClass().getSimpleName();
    @Override
    public void onReceive(Context context, Intent intent) {


    }

}
