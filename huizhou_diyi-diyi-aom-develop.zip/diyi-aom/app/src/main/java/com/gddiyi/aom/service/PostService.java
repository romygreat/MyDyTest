package com.gddiyi.aom.service;

import com.gddiyi.aom.model.dto.RequestTableList;
import com.gddiyi.aom.model.dto.ResponseJsonSn;
import com.gddiyi.aom.model.dto.ResponseJsonVideo;
import com.gddiyi.aom.model.dto.ResponseTableList;
import com.gddiyi.aom.model.dto.ResponseTableNum;
import com.gddiyi.aom.model.dto.ResponseUnbindTableList;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface PostService {

    @POST("device/Verify/checkDevice")
    @Headers({"Content-Type: application/json;charset=UTF-8","Behavior: api"})
    Call<ResponseJsonSn>getSnResult(@Body RequestBody rb);

    @POST("device/Verify/checkDevice")
    @Headers({"Content-Type: application/json;charset=UTF-8","Behavior: api"})
    Call<ResponseBody>getSnResultTestNet(@Body RequestBody rb);

    @POST("advert/Ad/playAd")
    @Headers({"Content-Type: application/json;charset=UTF-8","Behavior: api"})
    Call<ResponseJsonVideo>getVideoResult(@Body RequestBody rb);

    @POST("advert/Ad/playAd")
    @Headers({"Content-Type: application/json;charset=UTF-8","Behavior: api"})
    Call<ResponseBody>getVideoTest(@Body RequestBody rb);

    @POST("shop/ShopTable/getTableByToken")
    @Headers({"Content-Type: application/json;charset=UTF-8","Behavior: api"})
    Call<ResponseTableNum> getTableNum(@Body RequestBody rb);

    @POST("shop/ShopTable/optionShopTable")
    @Headers({"Content-Type: application/json;charset=UTF-8","Behavior: api"})
    Call<ResponseTableList> getTableList(@Body RequestBody rb);

    @POST("shop/ShopTable/optionShopTable")
    @Headers({"Content-Type: application/json;charset=UTF-8","Behavior: api"})
    Call<ResponseTableList> getTableListTest(@Body RequestBody rb);

    @POST("shop/ShopTable/getUnboundShopTable")
    @Headers({"Content-Type: application/json;charset=UTF-8","Behavior: api"})
    Call<ResponseUnbindTableList> getUnboundShopTable(@Body RequestBody rb);

}
