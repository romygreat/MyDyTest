package com.gddiyi.aom.presenter;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.SuperscriptSpan;
import android.util.Log;

import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.controler.DiyiInterface;
import com.gddiyi.aom.controler.MyFileProvider;
import com.gddiyi.aom.model.dto.ResponseUpdateAppInfo;
import com.gddiyi.aom.utils.netutils.CallBackUtil;
import com.gddiyi.aom.utils.netutils.DownloadUtil;
import com.gddiyi.aom.utils.netutils.OkhttpUtil;
import com.gddiyi.aom.service.GetTokenService;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;

import lombok.Getter;
import lombok.Setter;
import okhttp3.Call;

/**
 * 流程开启token服务
 * 回调setToken--->getUpgradeInfo-->DownloadApp
 */
@Deprecated
public class UpgradePresenter implements DiyiInterface.UpgradeApp, GetTokenService.TokenInterface {
    Activity mContext;
    String TAG = getClass().getSimpleName();
    @Setter
    @Getter
    NoticefyUpdate noticefyUpdate;
    DiyiInterface.UpgradeApp upgradeApp;
    @Setter
    @Getter
    String appName;
    @Getter
    org.json.JSONObject jsonObject;
    @Setter
    @Getter
    String upgradeInfomation;


    public UpgradePresenter(Activity mContext, DiyiInterface.UpgradeApp upgradeApp1) {
        this.mContext = mContext;
        this.upgradeApp = upgradeApp1;
        PressenterFactory.getInstance().createStartServicePresenter().startGetTokenService(mContext);
        GetTokenService.setTokenInterface(this);
    }

    @Override
    public String setToken(String token) {
        //设置token，从tokenservice
        org.json.JSONObject jsonObject = new JSONObject();
        try {// TODO: 2019/5/23
            jsonObject.put("machine", "machine");
            jsonObject.put("token", token);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        Log.i(TAG, "setToken: " + jsonObject.toString());
        //这里从获取升级包信息
        getUpgradeMessage(jsonObject.toString());
        return token;
    }

    @Override
    public String getToken(String token) {
        return token == null ? "-1" : token;
    }

    public String getUpgradeMessage(String jsonObject) {
        OkhttpUtil.okHttpPostJson(VSConstances.URL_APPDOWNLOAD, jsonObject, new CallBackUtil() {
            @Override
            public Object onParseResponse(okhttp3.Call call, okhttp3.Response response) {

                try {
                    final String jsonObj = response.body().string();
                    Log.d(TAG, "onParseResponse:jsonObj=="+jsonObj);
                    Gson gson = new Gson();
                    ResponseUpdateAppInfo myUpdateInfo = null;
                    try {
                        if (jsonObj!=null){
                        myUpdateInfo = gson.fromJson(jsonObj, ResponseUpdateAppInfo.class);
                       }
                    } catch (JsonSyntaxException e) {
                        e.printStackTrace();
                    }
                    if (myUpdateInfo != null) {
                        // "message": "没有相应的数据包"，最多的问题就是没有相应的数据包
                        if (jsonObj.contains("没有相应的数据包")) {
                            return "noData";
                        }
                        getUpgradeInfo(myUpdateInfo);

                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return "noData";
            }

            @Override
            public void onFailure(Call call, Exception e) {
                //下载失败

            }

            @Override
            public void onResponse(Object response) {
                Log.i(TAG, "onResponse: ");
            }
        });
        return null;
    }


    @Override
    public String downLoadAPP(String content, String savePhoneUrl, DownloadUtil.OnDownloadListener listener) {
        //获取下载路径的信息
        //  data: package\/20190423113058.apk
        //具体路径http://service.dev.gddiyi.cn/package/20190523104616.apk
        //注意url,不需要添加其他路径
        //在接口中设置有两项，根据上传apk成功后的返回值的data数据
        //1、修改apkPath为上传APP时返回来的20190423113058.apk
        //2、修改appName为上传APP时返回来的20190423113058.apk
//        apkurl = VSConstances.URL_APPDOWNLOAD1 + apkurl;
        Log.d(TAG, "downLoadAPP:content= "+content);
        DownloadUtil.get().download(content,
                savePhoneUrl, listener);
        return null;
    }

    @Override
    public String getUpgradeInfo(ResponseUpdateAppInfo upgradeInfo) {
        //获取upgradeInfo信息
        setRequestJsonObject(upgradeInfo);
        appName = upgradeInfo.getData().getAppName();
        upgradeInfomation=upgradeInfo.getData().getUpgradeinfo();
        if (isNeedtoUpdate(upgradeInfo)) {
            if (noticefyUpdate != null) {
                noticefyUpdate.notifyAppUpdate(true);
                upgradeApp.getUpgradeInfo(upgradeInfo);
            }
        } else {
            if (noticefyUpdate != null) {
                noticefyUpdate.notifyAppUpdate(false);
            }
        }
        return null;
    }


    @Override
    public boolean isDownLoadSucess(boolean success) {

        return false;
    }

    public void installApk(File file, Activity _this) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            //添加fileProvider
            Uri uri = MyFileProvider.getUriForFile(_this, _this.getPackageName() + ".myfileprovider", file);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
        } else {
            intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
        }
        _this.startActivity(intent);
    }

    public String getVersionName() throws Exception {
        // 获取packagemanager的实例
        PackageManager packageManager = mContext.getPackageManager();
        PackageInfo packInfo = packageManager.getPackageInfo(mContext.getPackageName(), 0);
        String version = packInfo.versionName;
        return version;
    }



    //请求查询APP信息
    public JSONObject createRequestJson(ResponseUpdateAppInfo.DataBean info) {
        JSONObject jsonObject = new JSONObject();
        try {
            // TODO: 2019/5/23
            jsonObject.put("token", info.getToken());
            jsonObject.put("apk", info.getApkPath());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }


    public boolean isNeedtoUpdate(ResponseUpdateAppInfo responseAppUpdate) {
        String lastVersion, currentAPPVersion = null;
        try {
            currentAPPVersion = getVersionName();
        } catch (Exception e) {
            e.printStackTrace();
        }
        lastVersion = responseAppUpdate.getData().getVersion();
        return Double.parseDouble(lastVersion) > Double.parseDouble(currentAPPVersion);
    }

    public interface NoticefyUpdate {
        boolean notifyAppUpdate(boolean appUpdate);
    }

    void setRequestJsonObject(ResponseUpdateAppInfo upgradeInfo) {
        ResponseUpdateAppInfo.DataBean info = upgradeInfo.getData();
        if (info.getApkPath() != null && info.getToken() != null) {
            jsonObject = createRequestJson(info);
        }
    }

    public SpannableString getSpannableString() {
        SpannableString spanText = new SpannableString(".");
        spanText.setSpan(new SuperscriptSpan(), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanText.setSpan(new StyleSpan(Typeface.BOLD), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanText.setSpan(new ForegroundColorSpan(Color.RED), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanText.setSpan(new RelativeSizeSpan(1.6f), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spanText;
    }
}
