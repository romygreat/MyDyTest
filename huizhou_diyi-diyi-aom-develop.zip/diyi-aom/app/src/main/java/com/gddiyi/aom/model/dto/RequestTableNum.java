package com.gddiyi.aom.model.dto;

public class RequestTableNum {

    /**
     * token : 2c3d5201d137b27432ea9a31bcf2feb0
     * machine : machine
     */

    private String token;
    private String machine;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getMachine() {
        return machine;
    }

    public void setMachine(String machine) {
        this.machine = machine;
    }
}
