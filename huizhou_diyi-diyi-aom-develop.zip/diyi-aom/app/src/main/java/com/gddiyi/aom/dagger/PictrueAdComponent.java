package com.gddiyi.aom.dagger;

import com.gddiyi.aom.view.CrossWalkActivity;

import dagger.Component;

@Component(modules = {PicModule.class})
public interface PictrueAdComponent {
     void inject(CrossWalkActivity crossWalkActivity);
}
