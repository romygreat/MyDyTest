package com.gddiyi.aom.presenter;


import android.util.Log;

import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.model.dto.RequestTableList;
import com.gddiyi.aom.model.dto.RequestTableNum;
import com.gddiyi.aom.model.dto.ResponseJsonSn;
import com.gddiyi.aom.model.dto.RequestJsonVideo;
import com.gddiyi.aom.model.dto.ResponseJsonVideo;
import com.gddiyi.aom.model.dto.ResponseTableList;
import com.gddiyi.aom.model.dto.ResponseTableNum;
import com.gddiyi.aom.model.dto.ResponseUnbindTableList;
import com.gddiyi.aom.service.PostService;
import com.gddiyi.aom.model.dto.RequestJsonSn;
import com.google.gson.Gson;

import lombok.Getter;
import lombok.Setter;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;

import okhttp3.ResponseBody;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitPresenter {
    String TAG = "RetrofitPresenter";
    Callback<ResponseJsonSn> callback;
    Callback<ResponseJsonVideo> callbackVideo;
    Callback<ResponseBody> callBackResponsebody;

    @Setter
    @Getter
    Callback<ResponseTableList> callbackResponseTableList;
    @Setter
    @Getter
    Callback<ResponseUnbindTableList>responseUnbindTableListCallback;

    public void setTAG(String TAG) {
        this.TAG = TAG;
    }

    public void setCallBackResponsebody(Callback<ResponseBody> callBackResponsebody) {
        this.callBackResponsebody = callBackResponsebody;
    }

    public String getTAG() {

        return TAG;
    }

    public Callback<ResponseBody> getCallBackResponsebody() {
        return callBackResponsebody;
    }

    public void setCallbackVideo(Callback<ResponseJsonVideo> callbackVideo) {
        this.callbackVideo = callbackVideo;
    }

    public Callback<ResponseJsonVideo> getCallbackVideo() {

        return callbackVideo;
    }

    //获取视频的结果
    public synchronized void retrofitPostVideo(String url, String content) {

        PostService postService = createRetrofit(url).create(PostService.class);
        RequestBody requestBody = createRequestBody(content);
        Log.d(TAG, "retrofitPostVideo: content="+content);
        Log.d(TAG, "retrofitPostVideo: url="+url);


        retrofit2.Call<ResponseJsonVideo> snResultJavaBean = postService.getVideoResult(requestBody);
        snResultJavaBean.enqueue(getCallbackVideo());

    }

    static Gson instanceGson;

    public Retrofit createRetrofit(String url) {
        Retrofit retrofit2 = new Retrofit.Builder()
                .baseUrl(url)
                .addConverterFactory(GsonConverterFactory.create())
                .client(new OkHttpClient())
                .build();
        return retrofit2;
    }

    public RequestBody createRequestBody(String content) {
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        RequestBody requestBody = RequestBody.create(JSON, content);
        return requestBody;
    }

    public synchronized void retrofitPost(String url, String content) {
        Log.d(TAG, "retrofitPost: ");
        PostService postService = createRetrofit(url).create(PostService.class);
        RequestBody requestBody = createRequestBody(content);
        Log.d(TAG, "retrofitPost: content="+content);
        retrofit2.Call<ResponseJsonSn> snResultJavaBean = postService.getSnResult(requestBody);
        snResultJavaBean.enqueue(getCallback());
    }
    public synchronized void retrofitPostSn(String url, String content) {
        PostService postService = createRetrofit(url).create(PostService.class);
        RequestBody requestBody = createRequestBody(content);
        retrofit2.Call<ResponseBody> snResultJavaBean = postService.getSnResultTestNet(requestBody);
        snResultJavaBean.enqueue(getCallBackResponsebody());
    }

    //设置回调接口
    public void setCallback(Callback<ResponseJsonSn> callback) {
        this.callback = callback;
    }

    public Callback<ResponseJsonSn> getCallback() {
        return callback;
    }

    public static Gson getInstanceGson() {
        if (instanceGson == null) {
            instanceGson = new Gson();
        }
        return instanceGson;
    }

    public String postJsonString(RequestJsonSn requestJsonSn) {
        Log.i(TAG, "postJsonString: ");
        String jsonString = getInstanceGson().toJson(requestJsonSn);
        return jsonString;
    }

    public synchronized void retrofitPostResponsebody(String url, String content) {
        PostService postService = createRetrofit(url).create(PostService.class);
        RequestBody requestBody = createRequestBody(content);
        retrofit2.Call<ResponseBody> snResultJavaBean = postService.getVideoTest(requestBody);
        snResultJavaBean.enqueue(getCallBackResponsebody());
    }

    public String postJsonString(RequestJsonVideo postVideoDataDto) {
        Log.i(TAG, "postJsonString: jsonVideo");
        String jsonString = getInstanceGson().toJson(postVideoDataDto);
        return jsonString;
    }


}
