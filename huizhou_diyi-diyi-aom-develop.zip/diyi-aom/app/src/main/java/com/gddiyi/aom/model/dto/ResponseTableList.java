package com.gddiyi.aom.model.dto;

import java.util.List;

public class ResponseTableList {

    /**
     * code : 1
     * message : 操作成功
     * data : [{"value":"356","lable":"A001"},{"value":"357","lable":"A003"},{"value":"358","lable":"A008"}]
     */

    private int code;
    private String message;
    private List<DataBean> data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ResponseTableList{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", data=" + data +
                '}';
    }

    public static class DataBean {
        @Override
        public String toString() {
            return "DataBean{" +
                    "value='" + value + '\'' +
                    ", lable='" + lable + '\'' +
                    '}';
        }

        /**
         * value : 356
         * lable : A001
         */

        private String value;
        private String lable;

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public String getLable() {
            return lable;
        }

        public void setLable(String lable) {
            this.lable = lable;
        }
    }
}
