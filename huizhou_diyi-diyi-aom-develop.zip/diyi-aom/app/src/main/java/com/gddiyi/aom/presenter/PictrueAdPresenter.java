package com.gddiyi.aom.presenter;

import android.content.Context;
import android.util.Log;

import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.controler.MyMainActivity;
import com.gddiyi.aom.controler.MyThreadPool;
import com.gddiyi.aom.diyianimation.AnimationFatory;
import com.gddiyi.aom.customview.EnterAnimLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class PictrueAdPresenter {
    String TAG = getClass().getSimpleName();
    Context mCOntext;
    org.json.JSONArray localPathArray = null;
    String playAllVideoPath;
    boolean firstLoadPic=true;
    String reg = "(.JPEG|.jpeg|.JPG|.jpg|.png)$";
    public void setCurrentPicIndex(int index) {
        this.currentPicIndex = index;
    }

    int currentPicIndex = 0;

    public PictrueAdPresenter() {
        readJsonFileFromSdcard();
    }

    public void readJsonFileFromSdcard() {
        //底层实现了线程操作
        MyThreadPool.startThread(new Runnable() {
            @Override
            public void run() {
              readFileFromSdcard();
            }
        });
    }
    public File ShowPicIndex() {
        File file = new File("sdcard/ad/" + getPicName());
        return file;
    }

    public int adsTotalCount() {
        Log.d(TAG, "hasSdAds: ");
        File files = new File(VSConstances.SDdir);
        if (files.exists() && files.isDirectory()) {
            int count = files.listFiles().length;
            return count;
        }
        return -1;
    }

    public String getPicName() {
        String url = null;
        try {
            //出现空指针情况，尤其是高版本问题
            //刚刷机出现空指针异常,,出现不能及时更新广告的问题？
            if (currentPicIndex==adsTotalCount()){
                Log.d(TAG, "getPicName: adsTotalCount="+adsTotalCount());
                currentPicIndex=0;
            }
            if (firstLoadPic){
                firstLoadPic=false;
                //首次加载问题为空判断
                if(localPathArray==null){
                    readFileFromSdcard();
                    //重新获取信息，判断是否为空
                    //IO耗时操作，睡眠等待2s
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    getLocalPathArray();
                }
            }

            url = (String) localPathArray.get(currentPicIndex);
            Pattern pattern = Pattern.compile(reg);
            Matcher matcher = pattern.matcher(url);
            if (matcher.find())
            {
            url = (String) localPathArray.get(currentPicIndex);
            }
        } catch (MyMainActivity e) {
            e.printStackTrace();
        } catch (JSONException e) {
            //这里报错异常，开始重新播放
            e.printStackTrace();
        }
        if (url == (null)) {
            try {
                setCurrentPicIndex(0);
                // TODO: 2019/8/21
                url = (String) localPathArray.get(0);

            } catch (JSONException e) {
                url = "noVideo";
            }
        }
        currentPicIndex++;
        return url;
    }

  synchronized  public  JSONObject getLocalPathArray() {
        org.json.JSONObject jsonObject = null;
        try {
            jsonObject = new org.json.JSONObject(playAllVideoPath);
            localPathArray = (org.json.JSONArray) jsonObject.get(VSConstances.LOCALPATH);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }

    /**
     * 读取sdcard上的jsonFile.txt文件
     */
   synchronized public JSONObject readFileFromSdcard() {
        JSONObject jsonObject = null;
        //json.txt保存在内置SDcard
        try {
            VideoPresenter mVideoPresenter = PressenterFactory.getInstance().createVideoPresenter();
            playAllVideoPath = mVideoPresenter.readJsonFile(1);
            jsonObject = getLocalPathArray();
        } catch (MyMainActivity e) {

        }
        return jsonObject;
    }

    public void setAnimation(EnterAnimLayout enterAnimLayout) {

        Random random=new Random();
        //随机生成图片动画效果
        int r=random.nextInt(AnimationFatory.STYLE_COUNT+1);
        new AnimationFatory(r,enterAnimLayout);
    }


}
