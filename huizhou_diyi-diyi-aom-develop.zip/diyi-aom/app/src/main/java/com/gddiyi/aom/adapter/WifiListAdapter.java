package com.gddiyi.aom.adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.ScanResult;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gddiyi.aom.R;
import com.gddiyi.aom.constant.VSConstances;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class WifiListAdapter extends BaseAdapter {
    public static final int WIFI_LEVEL0 = 0;
    public static final int WIFI_LEVEL1 = 1;
    public static final int WIFI_LEVEL2 = 2;
    public static final int WIFI_LEVEL3 = 3;
    SharedPreferences mSharedPreferences;
    int curWifiLevel;
    ArrayList<ScanResult> wifiList;
    Context context;
    ViewHolder viewHolder;
    LayoutInflater inflater;

    public WifiListAdapter(Context context, ArrayList<ScanResult> wifiList) {
        this.wifiList = wifiList;
        this.context = context;
        inflater = LayoutInflater.from(context);

    }
    public WifiListAdapter(Context context, ArrayList<ScanResult> wifiList,SharedPreferences sharedPreferences) {
        this.wifiList = wifiList;
        this.context = context;
        mSharedPreferences=sharedPreferences;
        inflater = LayoutInflater.from(context);
        Log.d("TAG", "WifiListAdapter: listWifiResult.size="+wifiList.size());
        for (ScanResult s:wifiList) {
            Log.d("WifiListAdapter", s.SSID+"的信号强度="+s.level);
        }
    }

    @Override
    public int getCount() {
        return wifiList.size();
    }

    @Override
    public ScanResult getItem(int position) {
        return wifiList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        viewHolder = new ViewHolder();
        if (convertView == null) {
            // 当为null的时候，View未被实例化，缓存池中无缓存
            viewHolder = new ViewHolder();
            convertView = inflater.inflate(R.layout.wifiitem, null);
            viewHolder.ssidNameTv = convertView.findViewById(R.id.wifiName);
            viewHolder.wifiSignalImg = convertView.findViewById(R.id.WifiSignal);
            viewHolder.hasSavePwdTv=convertView.findViewById(R.id.hasSavedPwd);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        ScanResult scanResult = wifiList.get(position);
        if (!"".equals(scanResult.SSID.trim())) {
            viewHolder.ssidNameTv.setText(scanResult.SSID);
            //WiFi信号分四个等级
            curWifiLevel = getWifiLevel(scanResult.level);
            if (hasRemenberPwd(scanResult.SSID)){
                viewHolder.hasSavePwdTv.setText("已保存");
            }else{
                viewHolder.hasSavePwdTv.setText("");
            }
            switch (curWifiLevel) {
                case WIFI_LEVEL0:
                    //信号很好
                    viewHolder.wifiSignalImg.setImageDrawable(context.getDrawable(R.mipmap.wifi4));
                    break;
                case WIFI_LEVEL1:
                    //信号好
                    viewHolder.wifiSignalImg.setImageDrawable(context.getDrawable(R.mipmap.wifi3));
                    break;
                case WIFI_LEVEL2:
                    //信号一般
                    viewHolder.wifiSignalImg.setImageDrawable(context.getDrawable(R.mipmap.wifi2));
                    break;
                case WIFI_LEVEL3:
                    //信号差
                    viewHolder.wifiSignalImg.setImageDrawable(context.getDrawable(R.mipmap.wifi1));
                    break;
                default:
                    //默认返回为5
                    viewHolder.wifiSignalImg.setImageDrawable(context.getDrawable(R.mipmap.wifi1));
                    break;
            }

        }else {
            Log.d("TAG", "getView:wifiListData= "+scanResult.SSID.trim());
        }

        return convertView;
    }

    private int getWifiLevel(int level) {
        //大于-65 很好//-65到-75 好//-75到-80 低//小于-80 很低
        //信号很好
        if (level > -65) {
            return WIFI_LEVEL0;
        }
        //信号好
        if (level <= -65 && level >= -75) {
            return WIFI_LEVEL1;
        }
        //信号一般
        if (level < -75 && level >= -80) {
            return WIFI_LEVEL2;
        }
        //信号弱
        if (level <= -80) {
            return WIFI_LEVEL3;
        }
        //默认返回5
        return 5;
    }

    private boolean hasRemenberPwd(String SSID) {
        String pwds = mSharedPreferences.getString(VSConstances.PREFIX+SSID, "wifi|false");
        String[] hasRemPwd;  hasRemPwd = pwds.split("\\|");
        boolean remPwd = Boolean.parseBoolean(hasRemPwd[1]);
        return remPwd;
    }
    static class ViewHolder {
        TextView ssidNameTv;
        ImageView wifiSignalImg;
        TextView  hasSavePwdTv;   }
}
