package com.gddiyi.aom.diyianimation;

import android.graphics.Canvas;

import com.gddiyi.aom.customview.EnterAnimLayout;

public class AnimRoateAndScale extends Anim {
    public AnimRoateAndScale(EnterAnimLayout view) {
        super(view);
    }

    @Override
    public void handleCanvas(Canvas canvas, float rate) {
        canvas.rotate(360*rate,w/2,h/2);
        canvas.scale(rate,rate,w/2,h/2);
        canvas.save();
    }
}
