package com.gddiyi.aom.test;


import com.gddiyi.aom.presenter.AppUpgradePresenter;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestHello {

    public static void main(String[] args) {
//        AppUpgradePresenter appUpgradePresenter=new AppUpgradePresenter(null);
//        appUpgradePresenter.requestUpgradeInfo();
    }
}
