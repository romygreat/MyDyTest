package com.gddiyi.aom.model.dto;

public class ResponseUpdateAppInfo {

    /**
     * code : 1
     * message : 操作成功
     * data : {"token":"65eca1843c91fbfe621e29a655199dd0","appName":"diyi.apk","version":"1.1","apkPath":"package/20190328154201.apk","patchName":"package/20190328154201.apk","patch":"1.1","patchPath":"http://192.168.0.193:8082/patch_signed_7zip.apk","upgradeinfo":"1、新增版本更新检查功能 2、性能提升"}
     */

    private int code;
    private String message;
    private DataBean data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * token : 65eca1843c91fbfe621e29a655199dd0
         * appName : diyi.apk
         * version : 1.1
         * apkPath : package/20190328154201.apk
         * patchName : package/20190328154201.apk
         * patch : 1.1
         * patchPath : http://192.168.0.193:8082/patch_signed_7zip.apk
         * upgradeinfo : 1、新增版本更新检查功能 2、性能提升
         */

        private String token;
        private String appName;
        private String version;
        private String apkPath;
        private String patchName;
        private String patch;
        private String patchPath;
        private String upgradeinfo;

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public String getAppName() {
            return appName;
        }

        public void setAppName(String appName) {
            this.appName = appName;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getApkPath() {
            return apkPath;
        }

        public void setApkPath(String apkPath) {
            this.apkPath = apkPath;
        }

        public String getPatchName() {
            return patchName;
        }

        public void setPatchName(String patchName) {
            this.patchName = patchName;
        }

        public String getPatch() {
            return patch;
        }

        public void setPatch(String patch) {
            this.patch = patch;
        }

        public String getPatchPath() {
            return patchPath;
        }

        public void setPatchPath(String patchPath) {
            this.patchPath = patchPath;
        }

        public String getUpgradeinfo() {
            return upgradeinfo;
        }

        public void setUpgradeinfo(String upgradeinfo) {
            this.upgradeinfo = upgradeinfo;
        }
    }
}
