package com.gddiyi.aom.dagger;

import com.gddiyi.aom.presenter.PictrueAdPresenter;


import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
public class PicModule {
    @Provides
   public PictrueAdPresenter createPictrueAdPresenter(){
        return new PictrueAdPresenter();
    }
}
