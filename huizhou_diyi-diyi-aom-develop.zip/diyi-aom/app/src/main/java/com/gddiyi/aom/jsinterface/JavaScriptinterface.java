package com.gddiyi.aom.jsinterface;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.JavascriptInterface;

import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.view.CrossWalkActivity;
//import com.hdy.hdylights.LedAndChargeManager;

import java.io.File;


public class JavaScriptinterface {
    Context mContext;
    String TAG = getClass().getSimpleName();
    NoticefyPay mNoticefyPay;
    public final static String SN = "test01";
    public static int jsMethodId = 0;

    public JavaScriptinterface(Context c) {
        mContext = c;
        mNoticefyPay = (NoticefyPay) c;
    }

    /**
     * 与js交互时用到的方法，在js里直接调用的
     */

    @JavascriptInterface
    public String getSn() {
        //来自javaScript
        Log.i(TAG, "getSn: " + getSerialNumber());
        jsMethodId = 1;
        return getSerialNumber();
//        return "000";
    }

    @JavascriptInterface
    public boolean readyPay() {
        Log.i(TAG, "readyPay: 来自JS准备支付");
        if (mNoticefyPay != null) {
            mNoticefyPay.readyPay();
            return true;
        } else {
            return true;
        }
    }

    @JavascriptInterface
    public boolean finishPay(int time) {
        Log.i(TAG, "finishPay: 来自JS== " + time);
        // time=0表示支付不成功,time=1表示支付成功
        if (mNoticefyPay != null) {
            boolean returnResult = mNoticefyPay.finishPay(time);
            return returnResult;
        }
        return false;
    }

    @JavascriptInterface
    public boolean isNeedOpenCodeImg() {
        boolean b = false;
        if (mNoticefyPay != null) {
            Log.d(getClass().getSimpleName(), "isNeedOpenCodeImg()");
            b = mNoticefyPay.isNeedOpenCodeImg();
        }
        return b;
    }

    @JavascriptInterface
    public void unCharge() {
        Log.i(TAG, "unCharge: shutdown123");
//        Log.i(TAG, "unCharge close" + LedAndChargeManager.switchCharge(LedAndChargeManager.SWITCH_OFF));
//        Log.i(TAG, "unCharge:close  " + LedAndChargeManager.setLedColor(LedAndChargeManager.BLUE_CLOSE));
        //顾客充电时间到，已经支付设置为false
        if (mNoticefyPay != null) {
            Log.i(TAG, "unCharge: is not null");
            mNoticefyPay.unCharge();
        }
    }

    //添加WIFI设置JS交
    @JavascriptInterface
    public void openWifySetting() {
        Log.i(TAG, "openWifySetting: ");
//        ((CrossWalkActivity) mContext).setWify();
    }

    @JavascriptInterface
    public void tmpBilPay(String requestUrl) {
        Log.i(TAG, "tmpBilPay: " + requestUrl);
    }

    @JavascriptInterface
    public boolean setttingActivity() {
        ((CrossWalkActivity) mContext).startSettingActivity();
        return true;
    }

    @JavascriptInterface
    public String getHtml(String html) {
        return html;
    }

    @JavascriptInterface
    public void sendMessage(int type) {
        Log.d(TAG, "sendMessage: " + type);
        switch (type) {
            case 0:
                ((CrossWalkActivity) mContext).playAdNow();
                break;
            default:
                break;
        }
    }

    public interface NoticefyPay {
        boolean readyPay();

        boolean isNeedOpenCodeImg();

        boolean finishPay(int time);

        boolean unCharge();
    }

    @SuppressLint("MissingPermission")
    public static String getSerialNumber() {
        File file = new File("/sdcard/serial");
        if (!file.exists()) {
            String sn = Build.SERIAL;
            if (!TextUtils.isEmpty(sn)) {
                if (sn.contains(VSConstances.PREFIX_DE_SN)) {
                    return sn;
                }
            }
        } else {
            Log.d("Javascript", "getSerialNumber: "+file.listFiles()[0].getName());
            return file.listFiles()[0].getName();
        }

        return "sn666666";
    }

    @JavascriptInterface
    public static String getIpList(String ipList) {
        Log.d("TAG", "getIpList: " + ipList);
        return "";
    }
}