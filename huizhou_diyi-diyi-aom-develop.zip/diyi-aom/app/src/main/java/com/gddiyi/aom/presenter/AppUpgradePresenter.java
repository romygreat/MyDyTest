package com.gddiyi.aom.presenter;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.text.style.SuperscriptSpan;
import android.util.Log;

import com.gddiyi.aom.constant.VSConstances;
import com.gddiyi.aom.utils.netutils.CallBackUtil;
import com.gddiyi.aom.utils.netutils.OkhttpUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import okhttp3.Call;
import okhttp3.Response;

public class AppUpgradePresenter {
    Context mContext;
    String TAG = "AppUpgradePresenter";
    CallBack callBack;

    public AppUpgradePresenter(Context mContext, CallBack callBack) {
        this.mContext = mContext;
        this.callBack = callBack;
        requestUpgradeInfo();
    }

    public void requestUpgradeInfo() {
        OkhttpUtil.okHttpGet(VSConstances.APP_UPGRADE_URL, new CallBackUtil() {
            @Override
            public Object onParseResponse(Call call, Response response) {
                try {
                    String json = response.body().string();
                    System.out.println("更新信息" + json);
                    if (AppUpgradePresenter.this.callBack != null) {
                        callBack.UpgradeInfo(json);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            public void onFailure(Call call, Exception e) {

            }

            @Override
            public void onResponse(Object response) {

            }
        });
    }

    public interface CallBack {
        void UpgradeInfo(String json);
    }

    public static String getFileMD5(File file) {
        FileInputStream in = null;
        String md5 = "";
        try {
            in = new FileInputStream(file);
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] buffer = new byte[1024 * 1024 * 10];

            int len = 0;
            while ((len = in.read(buffer)) > 0) {
                digest.update(buffer, 0, len);
            }
            md5 = new BigInteger(1, digest.digest()).toString(16);
            int length = 32 - md5.length();
            if (length > 0) {
                for (int i = 0; i < length; i++) {
                    md5 = "0" + md5;
                }
            }
            return md5;
        } catch (IOException e) {
            System.out.println(e);
        } catch (NoSuchAlgorithmException e) {
            System.out.println(e);
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                System.out.println(e);
            }
        }
        return md5;
    }

    public SpannableString getSpannableString() {
        SpannableString spanText = new SpannableString(".");
        spanText.setSpan(new SuperscriptSpan(), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanText.setSpan(new StyleSpan(Typeface.BOLD), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanText.setSpan(new ForegroundColorSpan(Color.RED), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanText.setSpan(new RelativeSizeSpan(1.6f), 0, 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spanText;
    }

    public boolean isNeedtoUpdate(int serverAppVersion) {
        if (serverAppVersion > getVersionName()) {
            return true;
        }
        return false;
    }

    public int getVersionName() {
        // 获取packagemanager的实例
        PackageManager packageManager = mContext.getPackageManager();
        PackageInfo packInfo = null;
        try {
            packInfo = packageManager.getPackageInfo(mContext.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        int version = packInfo.versionCode;
        return version;
    }
}
