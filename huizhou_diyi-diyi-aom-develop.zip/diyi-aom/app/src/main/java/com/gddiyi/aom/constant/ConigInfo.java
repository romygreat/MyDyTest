package com.gddiyi.aom.constant;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.gddiyi.aom.R;

import lombok.Getter;
import lombok.Setter;

public class ConigInfo {
    //桌台号
    @Getter
    @Setter
    public static String tableNum;
    //充电时间

}
