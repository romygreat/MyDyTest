package com.gddiyi.aom.view;


import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.gddiyi.aom.R;
import com.gddiyi.aom.YidiApplication;
import com.gddiyi.aom.constant.VSConstances;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.ExoPlaybackException;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.PlaybackParameters;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.RenderersFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.Timeline;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.TrackGroupArray;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelectionArray;
import com.google.android.exoplayer2.ui.PlaybackControlView;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;

//需要导入的包不能搞错

/**
 * 确定广告播放顺序与接口返回的数据播放
 * 不是根据ID播放，目前根据返回的接口进行播放
 */
public class VideoActivity extends BaseActivity implements View.OnTouchListener {
    SimpleExoPlayer mPlayer;
    PlaybackControlView playbackControlView;
    SimpleExoPlayerView playerView;
    String TAG = "videoActivity";
    Uri mp4Uri;
    ExtractorsFactory extractorsFactory;
    DefaultDataSourceFactory dataSourceFactory;
    String playAllVideoPath;
    Handler mHandler;
    Button button;

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.VIDEO_ACTIVITY);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.videolayout);
        initView();
        initExoPlayer();
        mHandler=new Handler(getMainLooper()){
            @Override
            public void handleMessage(Message msg) {
           button.setTextColor(Color.BLACK);
            }
        }
        ;

    }

    private void initView() {
        playerView=findViewById(R.id.simpleExoPlayerView);
        playbackControlView=new PlaybackControlView(this);
        button=findViewById(R.id.exitVideoBt);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                restartAPP(VideoActivity.this);
                mPlayer.stop();
                mPlayer.release();
                VideoActivity.this.finish();

            }
        });
    }

    private void initExoPlayer() {
        RenderersFactory renderersFactory = new DefaultRenderersFactory(this);
        DefaultTrackSelector trackSelector = new DefaultTrackSelector();
        LoadControl loadControl = new DefaultLoadControl();
        mPlayer = ExoPlayerFactory.newSimpleInstance(renderersFactory, trackSelector, loadControl);
        mPlayer.setRepeatMode(Player.REPEAT_MODE_ALL);
        playerView.setPlayer(mPlayer);
        playerView.setOnTouchListener(this);
        dataSourceFactory = new DefaultDataSourceFactory(
                this, Util.getUserAgent(this, "DiyiAppcation"));
        playerView.setBackgroundColor(Color.BLACK);
        extractorsFactory = new DefaultExtractorsFactory();
//        playAllVideoPath="http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4";
        playAllVideoPath="http://adfile.gddiyi.cn/order_video_guide.mp4";
//        playAllVideoPath="/sdcard/tablevideo.mp4";
        playVideostart(playAllVideoPath);
        mPlayer.addListener(new Player.EventListener() {
            @Override
            public void onTimelineChanged(Timeline timeline, Object manifest) {

            }

            @Override
            public void onTracksChanged(TrackGroupArray trackGroups, TrackSelectionArray trackSelections) {

            }

            @Override
            public void onLoadingChanged(boolean isLoading) {
                Log.d(TAG, "onLoadingChanged: "+isLoading);
            }

            @Override
            public void onPlayerStateChanged(boolean playWhenReady, int playbackState) {
                // playbackState 播放视频完成的状态playbackState 4
                Log.d(TAG, "onPlayerStateChanged: playWhenReady="+playWhenReady);
                if (playbackState ==4) {

                }
            }
            @Override
            public void onRepeatModeChanged(int repeatMode) {

            }

            @Override
            public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {

            }

            @Override
            public void onPlayerError(ExoPlaybackException error) {
                Log.i(TAG, "onPlayerError: "+error);
                Toast.makeText(VideoActivity.this,"播放异常，请后台人员检查网络有视频",Toast.LENGTH_LONG).show();
                //采用跳转的方式启动
//                VideoActivity.this.finish();
            }

            @Override
            public void onPositionDiscontinuity(int reason) {

            }

            @Override
            public void onPlaybackParametersChanged(PlaybackParameters playbackParameters) {

            }

            @Override
            public void onSeekProcessed() {

            }
        });

    }
    private void playVideostart(String testUrl) {
        mp4Uri = Uri.parse(testUrl);
        MediaSource mediaSource = new ExtractorMediaSource(
                mp4Uri, dataSourceFactory, extractorsFactory, null, null);
        mPlayer.prepare(mediaSource);
        mPlayer.setPlayWhenReady(true);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onDestroy() {
        mPlayer.release();
        super.onDestroy();
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (MotionEvent.ACTION_DOWN==event.getAction()){
            Log.d(TAG, "onTouch: ");
            button.setTextColor(Color.WHITE);
            if (!mHandler.hasMessages(0))
            { mHandler.sendEmptyMessageDelayed(0,3000);}
        }
        return false;
    }
    public static void restartAPP(Context context) {
        Intent intent = new Intent(context, CrossWalkActivity.class);
        @SuppressLint("WrongConstant") PendingIntent
                restartIntent = PendingIntent.getActivity(context, 0, intent,
                Intent.FLAG_ACTIVITY_NEW_TASK);
        AlarmManager mgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        assert mgr != null;
        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 100,
                restartIntent);
        // 1秒钟后重启应用
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }

}

