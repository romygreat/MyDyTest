import axios from '@/libs/api.request'

// 获取原因列表
export const reasonList = (data) => {
    return axios.request({
      url: '/shop/Reason/list',
      data
    })
}
// 修改 & 添加 
export const dataSet= (data) => {
    return axios.request({
      url: '/shop/Reason/dataSet',
      data
    })
}
// 删除
export const deleteSon = data => {
    return axios.request({
        url:'/shop/Reason/delete',
        data
    })
}
