import axios from '@/libs/api.request'

// 获取列表
export const getShopDataButtominfo = (data) => {
  return axios.request({
    url: '/product/product/listProduct',
    data
  })
}
//  修改产品
export const operationButtom = (data) => {
  return axios.request({
    url: '/product/product/saveProduct',
    data
  })
}
// 获取各产品分类
export const optionCateButtom = (data) => {
  return axios.request({
    url: '/product/productCate/optionCate',
    data
  })
}
// 删除
export const deloperationButtom = (data) => {
  return axios.request({
    url: '/product/product/delProduct',
    data
  })
}
