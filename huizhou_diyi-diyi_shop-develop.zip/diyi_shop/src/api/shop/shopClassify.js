import axios from '@/libs/api.request'

// 获取分类列表
export const getShopDataButtom = data => {
  return axios.request({
    url: '/product/productCate/listCate',
    data
  })
}
// 添加 & 修改
export const operationButtom = data => {
  return axios.request({
    url: '/product/productCate/saveCate',
    data
  })
}
// 删除
export const deloperationButtom = data => {
  return axios.request({
    url: '/product/productCate/delCate',
    data
  })
}
