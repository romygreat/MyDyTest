import axios from '@/libs/api.request'

// 商品排行
export const rankList = (data) => {
    return axios.request({
        url: '/statistics/Statistics/saleOrder',
        data
    })
}
// 营业报表
export const businessReport = (data) => {
    return axios.request({
        url:'/statistics/Statistics/businessReport',
        data
    })
}