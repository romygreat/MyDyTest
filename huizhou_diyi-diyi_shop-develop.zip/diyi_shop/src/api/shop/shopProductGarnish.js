import axios from '@/libs/api.request'

// 获取配菜列表
export const listProductSideDish = (data) => {
  return axios.request({
    url: '/Product/ProductSideDish/listProductSideDish',
    data
  })
}
// 删除配菜
export const delProductSideDish = (data) => {
  return axios.request({
    url: '/Product/ProductSideDish/delProductSideDish',
    data
  })
}
// 修改 & 添加
export const saveProductSideDish = (data) => {
  return axios.request({
    url: '/Product/ProductSideDish/saveProductSideDish',
    data
  })
}
