import axios from '@/libs/api.request'

// 获取配菜列表
export const listProductRemark = (data) => {
  return axios.request({
    url: '/Product/ProductRemark/listProductRemark',
    data
  })
}

// 备注删除
export const delProductRemark = (data) => {
  return axios.request({
    url: '/Product/ProductRemark/delProductRemark',
    data
  })
}

// 添加 & 删除
export const saveProductRemark = (data) => {
  return axios.request({
    url: '/Product/ProductRemark/saveProductRemark',
    data
  })
}
