import axios from '@/libs/api.request'

// 获取沽清列表
export const sellOutProductList = (data) => {
  return axios.request({
    url: '/product/product/sellOutProduct',
    data
  })
}
// 删除估清数目 && 删除
export const operationProduct = (data) => {
  return axios.request({
    url: '/product/product/operationProduct',
    data
  })
}
