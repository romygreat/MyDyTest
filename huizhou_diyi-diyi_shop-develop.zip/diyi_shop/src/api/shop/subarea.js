import axios from '@/libs/api.request'

// 店铺区域列表
export const listSubarea = (data) => {
  return axios.request({
    url: '/shop/ShopSubarea/listSubarea',
    data
  })
}

// 添加或修改店铺区域信息
export const saveSubarea = (data) => {
  return axios.request({
    url: '/shop/ShopSubarea/saveSubarea',
    data
  })
}

// 删除店铺区域信息
export const delSubarea = (data) => {
  return axios.request({
    url: '/shop/ShopSubarea/delSubarea',
    data
  })
}

// 店铺区域列表（前端下拉列表用）
export const optionSubarea = (data) => {
  return axios.request({
    url: '/shop/ShopSubarea/optionSubarea',
    data
  })
}
