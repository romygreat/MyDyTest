import axios from '@/libs/api.request'

// 获取规格列表
export const listSpeButtom = (data) => {
  return axios.request({
    url: '/product/Specification/listSpecification',
    data
  })
}
// 删除
export const delList = (data) => {
  return axios.request({
    url: '/product/Specification/delSpecification',
    data
  })
}
// 修改 或者 添加规格
export const setListButtom = (data) => {
  return axios.request({
    url: '/product/Specification/setSpecification',
    data
  })
}
