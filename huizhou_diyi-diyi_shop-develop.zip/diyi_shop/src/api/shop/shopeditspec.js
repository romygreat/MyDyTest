import axios from '@/libs/api.request'

// 获取规格列表
export const listSpeButtom = (data) => {
  return axios.request({
    url: '/product/Specification/listSpecification',
    data
  })
}
