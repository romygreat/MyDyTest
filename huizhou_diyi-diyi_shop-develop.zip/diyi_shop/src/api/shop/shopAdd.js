import axios from '@/libs/api.request'

export const optionCateButtom = (data) => {
  return axios.request({
    url: '/product/productCate/optionCate',
    data
  })
}
// 修改
export const editDataButoom = (data) => {
  return axios.request({
    url: '/product/product/saveProduct',
    data
  })
}
