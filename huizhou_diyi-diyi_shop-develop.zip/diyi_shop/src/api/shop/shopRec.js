import axios from '@/libs/api.request'

// 换原
export const restoreButtom = (data) => {
  return axios.request({
    url: '/product/product/restoreProduct',
    data
  })
}
