import axios from '@/libs/api.request'

// 修改做法
export const dataSet = (data) => {
  return axios.request({
    url: '/product/ProductProcedure/dataSet',
    data
  })
}
// 删除做法
export const deletePrac = (data) => {
  return axios.request({
    url: '/product/ProductProcedure/delete',
    data
  })
}
// 做法列表
export const PracList = (data) => {
  return axios.request({
    url: '/product/ProductProcedure/list',
    data
  })
}
