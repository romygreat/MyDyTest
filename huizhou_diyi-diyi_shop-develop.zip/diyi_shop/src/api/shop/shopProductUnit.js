import axios from '@/libs/api.request'

// 获取单位库列表
export const productUnitList = (data) => {
  return axios.request({
    url: '/product/ProductUnit/list',
    data
  })
}

// 编辑单位
export const productUnitDataSet = (data) => {
  return axios.request({
    url: '/product/ProductUnit/dataSet',
    data
  })
}

// 删除单位
export const productUnitDelete = (data) => {
  return axios.request({
    url: '/product/ProductUnit/delete',
    data
  })
}
