import axios from '@/libs/api.request'

// 获取标签列表
export const productLabelList = (data) => {
  return axios.request({
    url: '/product/ProductLabel/productLabelList',
    data
  })
}
// 添加 & 修改标签
export const productLabelSave = data => {
  return axios.request({
    url: '/product/ProductLabel/productLabelSave',
    data
  })
}
// 删除
export const productLabelDel = data => {
  return axios.request({
    url: '/product/ProductLabel/productLabelDel',
    data
  })
}
