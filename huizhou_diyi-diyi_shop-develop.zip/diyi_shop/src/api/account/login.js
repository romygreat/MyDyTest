import axios from '@/libs/api.request'

/**
 * 用户登录
 * @param {*} param0
 */
export const login = ({ userName, password }) => {
  const data = {
    account: userName,
    pwd: password,
    terminal_domain: 'shop.gddiyi.com'
  }
  return axios.request({
    url: '/account/Login/userLogin',
    data
  })
}

/**
 * 用户登出
 */
export const logout = () => {
  return axios.request({
    url: '/account/Login/userLogout'
  })
}
