import axios from '@/libs/api.request'

// 获取操作日志
export const getOperTablesButoom = data => {
  return axios.request({
    url: '',
    data
  })
}
// 获取操作日志详情
export const operinfotext = data => {
  return axios.request({
    url: '/account/ActionLog/details',
    data
  })
}
