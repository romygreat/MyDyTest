import axios from '@/libs/api.request'

export const getAdminInfo = () => {
  return axios.request({
    url: '/account/Account/getAdminInfo'
  })
}

export const modifyPwd = (data) => {
  return axios.request({
    url: '/account/Account/modifyPwd',
    data
  })
}
