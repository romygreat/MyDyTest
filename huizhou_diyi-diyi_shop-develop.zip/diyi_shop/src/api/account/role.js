import axios from '@/libs/api.request'

// 获取角色组
export const getRoleListButtom = data => {
  return axios.request({
    url: '/account/Role/index',
    data
  })
}

// 获取角色组分页
export const handlePageeButtomRole = data => {
  return axios.request({
    url: '/account/Role/index',
    data
  })
}
// 获取角色组列表
export const getRoleTablesButtom = data => {
  return axios.request({
    url: '/account/Role/index',
    data
  })
}
// 修改角色组名称
export const saveRoleInfo = data => {
  return axios.request({
    url: '/account/Role/saveRole',
    data
  })
}
// 搜索角色组
export const handleSearchRole = data => {
  return axios.request({
    url: '/account/Role/index',
    data
  })
}
// 删除角色组
export const delRoleButtom = data => {
  return axios.request({
    url: '/account/Role/del',
    data
  })
}

// 添加角色组
export const listPermission = data => {
  return axios.request({
    url: '/account/Permission/getAuth',
    data
  })
}

// 获取角色列表，下拉列表使用
export const listSelectRole = () => {
  return axios.request({
    url: '/account/Role/listSelectRole'
  })
}
