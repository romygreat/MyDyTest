import axios from '@/libs/api.request'

// 获取管理员
export const addAdminsButtom = data => {
  return axios.request({
    url: '/account/Auth/add',
    data
  })
}
// 管理员搜索
export const Searchbuttom = data => {
  return axios.request({
    url: '/account/Auth/index',
    data
  })
}

// 删除管理员
export const deleteAdminButtom = data => {
  return axios.request({
    url: '/account/Auth/del',
    data
  })
}
// 编辑管理员
export const saveAdmin = data => {
  return axios.request({
    url: '/account/Auth/saveAdmin',
    data
  })
}
// 获取管理员列表
export const getAdminTablesButtom = data => {
  return axios.request({
    url: '/account/Auth/index',
    data
  })
}
// 获取管理员分类
export const getpageadminButtom = data => {
  return axios.request({
    url: '/account/Auth/index',
    data
  })
}
// 获取管理员分页
export const handlePageButtom = data => {
  return axios.request({
    url: '/account/Auth/index',
    data
  })
}
