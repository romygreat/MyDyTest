import axios from '@/libs/api.request'

// 挂账列存储 && 修改
export const oASave = (data) => {
  return axios.request({
    url: '/order/OrdeerHangingAccounts/oASave',
    data
  })
}

// 挂账公司列表
export const oAList = (data) => {
  return axios.request({
    url: '/order/OrdeerHangingAccounts/oAList',
    data
  })
}

// 删除
export const oADel = (data) => {
  return axios.request({
    url: '/order/OrdeerHangingAccounts/oADel',
    data
  })
}

// 挂账信息列表
export const oAListInfo = (data) => {
  return axios.request({
    url: '/order/OrderArrearage/oAList',
    data
  })
}

// 挂账订单信息
export const getOrderDateByOrderId = (data) => {
  return axios.request({
    url: '/order/OrderArrearage/getOrderDateByOrderId',
    data
  })
}

// 挂账完结
export const oAEnd = (data) => {
  return axios.request({
    url: '/order/OrderArrearage/oAEnd',
    data
  })
}
