import axios from '@/libs/api.request'

// 页头基本数据
export const headertext = data => {
  return axios.request({
    url: '/Statement/Statement/index',
    data
  })
}
// 菜品销售排行榜
export const muneranks = data => {
  return axios.request({
    url: '/Statement/Statement/salesProductCate',
    data
  })
}
// 菜品分类
export const shopCate = data => {
  return axios.request({
    url: '/Product/ProductCate/shopCate',
    data
  })
}
// 菜品排行榜单 salesProduct
export const salesProduct = data => {
  return axios.request({
    url: '/Statement/Statement/salesProduct',
    data
  })
}

// 折线图
export const businessStatistics = data => {
  return axios.request({
    url: '/Statement/Statement/businessStatistics',
    data
  })
}
// 首页餐厅提醒
export const notification = data => {
  return axios.request({
    url: '/Statement/Statement/notification',
    data
  })
}
// 全局储存状态
export const getStatus = data => {
  return axios.request({
    url: '/status/text/getStatusText',
    data
  })
}
