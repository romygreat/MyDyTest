import axios from '@/libs/api.request'
// 设备列表
export const machineTablesButtom = data => {
  return axios.request({
    url: '/device/Machine/listMachine',
    data
  })
}
// 查询设备
export const handleSearchMac = data => {
  return axios.request({
    url: '/device/Machine/listMachine',
    data
  })
}
// 删除设备
export const delMachineButtom = data => {
  return axios.request({
    url: '/device/Machine/delMachine',
    data
  })
}
// 修改设备
export const editMacineButtom = data => {
  return axios.request({
    url: '/device/Machine/saveMachine',
    data
  })
}
// 批量上传
export const uploadExcelButtom = data => {
  return axios.request({
    url: '/device/Machine/importMachine',
    data
  })
}
// 批量绑定
export const allMachBangdingButtom = data => {
  return axios.request({
    url: '/device/Machine/matchMachine',
    data
  })
}

// 批量绑定
export const optionMachine = () => {
  return axios.request({
    url: '/device/Machine/optionMachine'
  })
}
