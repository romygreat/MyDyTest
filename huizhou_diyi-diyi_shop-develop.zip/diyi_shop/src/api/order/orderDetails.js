import axios from '@/libs/api.request'

// 获取订单详情
export const orderDetailButtom = (data) => {
        return axios.request({
            url: '/order/order/detailsOrder',
            data
        })
    }
    // 新的获取订单详情
export const newOrderDetailButtom = (data) => {
        return axios.request({
            url: '/order/order/setOrder',
            data
        })
    }
    // 修改订单商品
export const editOrderButtom = (data) => {
        return axios.request({
            url: '/order/orderList/editOrderList',
            data
        })
    }
    // 修改订单基本状态
export const editOrderBasicButtom = (data) => {
        return axios.request({
            url: '/order/Order/editOrder',
            data
        })
    }
    // 删除单个商品
export const delorderButtom = data => {
        return axios.request({
            url: '/order/orderList/delOrderList',
            data
        })
    }
    // 订单列表
export const indexOrder = (data) => {
    return axios.request({
        url: '/order/order/indexOrder',
        data
    })
}

// 2.5支付接口状态 http://www.dy.cc/status/Text/getStatusText
export const getStatusText = (data) => {
    return axios.request({
        url: '/status/Text/getStatusText',
        data
    })
}