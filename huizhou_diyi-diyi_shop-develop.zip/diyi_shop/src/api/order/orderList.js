import axios from '@/libs/api.request'

// 获取订单列表
export const orderDataButtom = (data) => {
  return axios.request({
    url: '/order/order/listOrder',
    data
  })
}
// 订单通知
export const newOrderButtom = (data) => {
  return axios.request({
    url: '/order/order/newOrder',
    data
  })
}
