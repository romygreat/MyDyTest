/*
 * @Author: 叶锦荣
 * @Date: 2019-11-15 12:02:21
 * @LastEditTime: 2019-11-29 18:36:36
 */
import axios from '@/libs/api.request'

// 获取打印机列表
export const printerList = data => {
  return axios.request({
    url: '/device/Printer/list',
    data
  })
}
// 添加 || 修改 打印机
export const printerSave = data => {
    return axios.request({
      url: '/device/Printer/save',
      data
    })
}
// 打印机厂商列表
export const printerManuList = data => {
    return axios.request({
      url: '/device/PrinterManu/list',
      data
    })
}
// 打印机删除
export const printerDelete = data => {
  return axios.request({
    url: '/device/Printer/delete',
    data
  })
}
export const shopCate = data => {
  return axios.request({
    url: '/Product/ProductCate/shopCate',
    data
  })
}



// 触发打印信息 
export const replacementOrder = data => {
  return axios.request({
    url: '/order/order/ReplacementOrder',
    data
  })
}