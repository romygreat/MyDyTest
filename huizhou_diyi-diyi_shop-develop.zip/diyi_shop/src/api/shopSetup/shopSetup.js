/*
 * @Author: 叶锦荣
 * @Date: 2018-12-28 21:09:13
 * @LastEditTime: 2019-12-04 14:34:58
 */
import axios from '@/libs/api.request'

// 修改支付设置
export const setPayButtom = (data) => {
  return axios.request({
    url: '/pay/PaySet/setPay',
    data
  })
}
// 获取商户支付设置
export const getPayButtom = () => {
  return axios.request({
    url: '/pay/PaySet/getPay'
  })
}
// 修改门店设置
export const setShop = data => {
  return axios.request({
    url:'/shop/shopSet/setShop',
    data
  })
}
// 获取门店设置
export const getShop = data => {
  return axios.request({
    url:'/shop/shopSet/getShop',
    data
  })
}
