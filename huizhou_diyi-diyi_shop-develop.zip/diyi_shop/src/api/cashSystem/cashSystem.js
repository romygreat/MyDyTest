import axios from '@/libs/api.request'

// 打印小票  /
export const replacementOrder = (data) => {
  return axios.request({
    url: '/order/order/ReplacementOrder',
    data
  })
}

// 门店菜品列表
export const cateProduct = data => {
  return axios.request({
    url: '/Product/Product/cateProduct',
    data
  })
}