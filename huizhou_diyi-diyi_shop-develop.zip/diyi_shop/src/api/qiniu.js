import axios from '@/libs/api.request'

export const QINIU_DOMAIN_KEY = 'qiniu_domain'
export const getQiniuUpToken = () => {
  let data = { obj: 'shop' }
  return axios.request({
    url: '/qiniu/Upload/getUptoken',
    data
  })
}
export const getQiniuDomain = () => {
  let data = { obj: 'shop' }
  return axios.request({
    url: '/qiniu/Upload/getDomain',
    data
  })
}
