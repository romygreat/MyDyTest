import axios from '@/libs/api.request'

// 月度流水明细
export const salesProduct = (data) => {
  return axios.request({
    url: '/statistics/Statistics/saleOrder',
    data
  })
}

export const rankList = (data) => {
  return axios.request({
      url: '/statistics/Statistics/saleOrder',
      data
  })
}
