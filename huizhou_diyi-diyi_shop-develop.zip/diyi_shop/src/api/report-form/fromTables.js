import axios from '@/libs/api.request'

// 月度流水明细
export const tableNoStatistics = (data) => {
  return axios.request({
    url: '/Statement/Statement/tableNoStatistics',
    data
  })
}
