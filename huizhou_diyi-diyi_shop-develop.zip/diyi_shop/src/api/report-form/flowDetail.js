import axios from '@/libs/api.request'

// 营业流水明细
export const salesOrderDetails = (data) => {
  return axios.request({
    url: '/Statement/Statement/salesDetails',
    data
  })
}
