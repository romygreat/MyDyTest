import axios from '@/libs/api.request'

// 时段流水明细
export const hourSalesStatement = (data) => {
  return axios.request({
    url: '/Statement/Statement/hourSalesStatement',
    data
  })
}
