export default {
  state: {
    newsOrder: '0',
    newsServer:0
  },
  mutations: {
    increase (state, type) {
      // state.newsOrder++
      state.newsOrder = type
    },
    clearNews (state) {
      state.newsOrder--
      if (state.newsOrder < 0) {
        state.newsOrder = 0
      }
    },
    serverSetValue(state,value){
      state.newsServer = value
    }
  },
  actions: {

  }
}
