import { login, logout } from '@/api/account/login'
import { getAdminInfo } from '@/api/account/account'
import { setToken } from '@/libs/util'

export default {
  state: {
    token: '',
    access: [],
    adminInfo: {}
  },
  mutations: {
    setStateToken(state, token) {
      state.token = token
      setToken(token)
    },
    setAccess(state, access) {
      state.access = access
    },
    setAdminInfo(state, adminInfo) {
      state.adminInfo = adminInfo
    }
  },
  actions: {
    // 登录 && 登陆判断
    handleLogin({ commit }, { userName, password }) {
      userName = userName.trim()
      return new Promise((resolve, reject) => {
        login({
          userName,
          password
        }).then(res => {
          if (res.data.code === 10011) {
            let data = res.data.data
            commit('setStateToken', data.token)
            if (data.menu_set) {
              commit('setAccess', data.menu_set.split(','))
            }
            commit('setAdminInfo', data)
            console.log(data.shop.product_bind, '写入小吃')
            sessionStorage.setItem('sncak', JSON.stringify(data.shop.product_bind))
          }
          resolve(res.data)
        }).catch(err => {
          reject(err)
        })
      })
    },
    getAdminInfo({ commit }, token) {
      return new Promise((resolve, reject) => {
        getAdminInfo(token).then(res => {
          if (res.data.code === 1) {
            let data = res.data.data
            if (data.menu_set) {
              commit('setAccess', data.menu_set.split(','))
            }
            commit('setAdminInfo', data)
            resolve(data)
          }
        }).catch(err => {
          reject(err)
        })
      })
    },
    // 退出登录
    handleLogOut({ state, commit }) {
      return new Promise((resolve, reject) => {
        logout(state.token).then(res => {
          if (res.data.code > 0) {
            commit('setStateToken', '')
            commit('setAccess', [])
          }
          resolve(res.data)
        }).catch(err => {
          reject(err)
        })
      })
    }
  }
}
