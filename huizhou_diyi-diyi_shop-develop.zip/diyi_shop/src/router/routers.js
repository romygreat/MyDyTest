import Main from '@/components/main'

export default [{
        path: '/login',
        name: 'login',
        meta: {
            title: '登录',
            hideInMenu: true
        },
        component: () =>
            import ('@/view/login/login.vue')
    },
    {
        path: '/remote/:token',
        name: '_remote',
        meta: {
            title: 'main',
            icon: 'md-home',
            hideInMenu: true,
            notCache: true
        }
    },
    {
        path: '/',
        name: '_home',
        redirect: '/home',
        component: Main,
        meta: {
            hideInMenu: true,
            notCache: true
        },
        children: [{
            path: '/home',
            name: 'home',
            meta: {
                hideInMenu: true,
                title: '首页',
                notCache: true,
                icon: 'md-home'
            },
            component: () =>
                import ('@/view/single-page/home')
        }]
    },
    {
        path: '/account',
        name: 'account',
        meta: {
            icon: 'md-contacts',
            title: '账号管理',
            access: '1000'
        },
        component: Main,
        children: [{
                path: 'staff',
                name: 'staff',
                meta: {
                    icon: 'ios-contact-outline',
                    title: '员工管理',
                    access: '1011'
                },
                component: () =>
                    import ('@/view/account/staff')
            },
            {
                path: 'role-group',
                name: 'role-group',
                meta: {
                    icon: 'ios-people',
                    title: '角色组',
                    access: '1021'
                },
                component: () =>
                    import ('@/view/account/role-group')
            }
        ]
    },
    {
        path: '/table',
        name: 'table',
        meta: {
            icon: 'md-wine',
            title: '桌号管理',
            access: '5000'
        },
        component: Main,
        children: [{
                path: 'table-list',
                name: 'table-list',
                meta: {
                    icon: 'ios-create',
                    title: '台桌列表',
                    access: '5001',
                    type: 1
                },
                component: () =>
                    import ('@/view/table/table-list')
            },
            {
                path: 'subarea',
                name: 'subarea',
                meta: {
                    icon: 'ios-map-outline',
                    title: '桌号分类',
                    access: '5002',
                    type: 2
                },
                component: () =>
                    import ('@/view/table/subarea')
            }
        ]
    },
    {
        path: '/product',
        name: 'product',
        meta: {
            icon: 'md-cart',
            title: '商品管理',
            access: '2000'
        },
        component: Main,
        children: [{
                path: 'productlist',
                name: 'productlist',
                meta: {
                    icon: 'ios-basket',
                    title: '商品列表',
                    access: '2002'
                },
                component: () =>
                    import ('@/view/product/product-list')
            },
            {
                path: 'product-cate',
                name: 'product-cate',
                meta: {
                    icon: 'md-barcode',
                    title: '品项分类',
                    access: '2001'
                },
                component: () =>
                    import ('@/view/product/product-cate')
            },
            {
                path: 'Productlabel',
                name: 'Productlabel',
                meta: {
                    icon: 'ios-bookmark',
                    title: '商品标签',
                    access: '2001'
                },
                component: () =>
                    import ('@/view/product/product-label')
            },
            {
                path: 'product_specification',
                name: 'product_specification',
                meta: {
                    title: '规格设置',
                    icon: 'logo-buffer'
                },
                component: () =>
                    import ('@/view/product/product_specification')
            },
            {
                path: 'product-garnish',
                name: 'product-garnish',
                meta: {
                    title: '加料配菜',
                    icon: 'md-basket'
                },
                component: () =>
                    import ('@/view/product/product-garnish')
            },
            {
                path: 'product-remarks',
                name: 'product-remarks',
                meta: {
                    title: '口味库',
                    icon: 'ios-paper'
                },
                component: () =>
                    import ('@/view/product/product-remarks')
            },
            {
                path: 'product-practice',
                name: 'product-practice',
                meta: {
                    title: '做法库',
                    icon: 'ios-paper'
                },
                component: () =>
                    import ('@/view/product/product-practice')
            },
            {
                path: 'product-company',
                name: 'product-company',
                meta: {
                    title: '单位库',
                    icon: 'ios-paper'
                },
                component: () =>
                    import ('@/view/product/product-company/product-company')
            },
            {
                path: 'product-edit',
                name: 'product-edit',
                meta: {
                    hideInMenu: true,
                    title: '编辑商品',
                    notCache: true,
                    access: '2003'
                },
                component: () =>
                    import ('@/view/product/product-edit')
            },
            {
                path: 'product-rec',
                name: 'product-rec',
                meta: {
                    title: '回收站',
                    icon: 'md-trash',
                    access: '2002'
                },
                component: () =>
                    import ('@/view/product/product-rec')
            },
            {
                path: 'product-limit',
                name: 'product-limit',
                meta: {
                    title: '沽清列表',
                    icon: 'md-list-box'
                },
                component: () =>
                    import ('@/view/product/product-limit')
            },
            {
                path:'product-reson',
                name:'product-reson',
                meta:{
                    title:'原因库',
                    icon: 'md-list-box'
                },
                component: () => import('@/view/product/product-reson')
            }
        ]
    },

    {
        path: '/order',
        name: 'order',
        access: '3001',
        component: Main,
        children: [{
                path: 'orderList',
                name: 'orderList',
                meta: {
                    title: '订单列表',
                    icon: 'md-clipboard',
                    access: '3002'
                },
                component: () =>
                    import ('@/view/order/orderList')
            },
            {
                path: 'orderDetails',
                name: 'orderDetails',
                meta: {
                    title: '订单详情',
                    hideInMenu: true,
                    access: '3003'
                },
                component: () =>
                    import ('@/view/order/orderDetails')
            }
        ]
    },
    {
        path: '/settleAcountsinfo',
        name: 'settleAcountsinfo',
        meta: {
            icon: 'ios-construct',
            title: '挂账',
            access: '4000'
        },
        component: Main,
        children: [{
                path: 'settleAcounts',
                name: 'settleAcounts',
                meta: {
                    title: '挂账主体',
                    icon: 'md-clipboard'
                },
                component: () =>
                    import ('@/view/settleAcounts')
            },
            {
                path: 'settleAccounts-LIST',
                name: 'settleAccounts-LIST',
                meta: {
                    title: '信息列表',
                    icon: 'md-clipboard'
                },
                component: () =>
                    import ('@/view/settleAcounts/settleAccounts-LIST')
            }
        ]
    },
    {
        path: '/machines',
        name: 'machines',
        meta: {
            icon: 'ios-construct',
            title: '设备管理',
            access: '4000'
        },
        component: Main,
        children: [{
                path: 'order-machine',
                name: 'order-machine',
                meta: {
                    icon: 'ios-create',
                    title: '终端管理',
                    access: '4001',
                    type: 1
                },
                component: () =>
                    import ('@/view/machine/machine')
            },
            {
                path:'print',
                name:'print',
                meta:{
                    icon:'md-print',
                    title:'打印机',
                    access:4002
                },
                component: () => 
                  import('@/view/machine/printer')
            }
        ]
    },
    {
        path: '/Setup',
        name: 'Setup',
        meta: {
            access: '5000',
            title: '门店操作'
        },
        component: Main,
        children: [{
            path: 'shopSetup',
            name: 'shopSetup',
            meta: {
                icon: 'md-build',
                title: '门店设置',
                access: '5010'
            },
            component: () =>
                import ('@/view/shopSetup/shopSetup')
        }]
    },
    {
        path: '/report',
        name: 'report',
        meta: {
            access: '7000',
            title: '营业报表',
            icon: 'logo-yen'
        },
        component: Main,
        children: [
           
            // {
            //     path: 'flowDetail',
            //     name: 'flowDetail',
            //     meta: {
            //         icon: 'md-trending-up',
            //         title: '营业流水明细',
            //         access: '7020'
            //     },
            //     component: () =>
            //         import ('@/view/report-form/flowDetail')
            // },
            {
                path: 'menuRank',
                name: 'menuRank',
                meta: {
                  icon: 'md-trending-up',
                  title: '菜品销售排行',
                  access: '7030'
                },
                component: () => import('@/view/report-form/menuRank')
              },
           
        ]
    },
    {
        path: '/401',
        name: 'error_401',
        meta: {
            hideInMenu: true
        },
        component: () =>
            import ('@/view/error-page/401.vue')
    },
    {
        path: '/500',
        name: 'error_500',
        meta: {
            hideInMenu: true
        },
        component: () =>
            import ('@/view/error-page/500.vue')
    },
    {
        path: '*',
        name: 'error_404',
        meta: {
            hideInMenu: true
        },
        component: () =>
            import ('@/view/error-page/404.vue')
    }
]