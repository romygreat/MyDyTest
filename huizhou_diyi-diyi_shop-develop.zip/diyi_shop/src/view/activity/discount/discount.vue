<template>
  <div>
    <ListPage
      title="限时折扣列表"
      desc="在这里可以浏览到您店铺所有的限时折扣信息"
      ref="list_page"
      :columns="table_columns"
      :route_edit="{name: 'activity-edit', query: { type: list_param.type } }"
      :list_param="list_param"
      :search_params="search_params"
      data_url="/activity/activity/selectPage"
      save_url="/activity/activity/save"
      del_url="/activity/activity/destroy"
    >
      <template v-slot:search_input>
        <span style="margin-left: 10px;">名称：</span>
        <Input v-model="search_params.name" clearable placeholder="输入你要查询的名称" style="width: 200px;"/>
        <span style="margin-left: 10px;">状态：</span>
        <Select v-model="search_params.status" clearable style="width:200px">
          <Option v-for="(text, status) in activityStatusList" :value="status" :key="status">{{ text }}</Option>
        </Select>
      </template>
    </ListPage>

  </div>
</template>

<script>
import ListPage from '@/components/list-page'
import { getStautsText } from '@/libs/tools'
import tableColumns from '../common/table_columns'
export default {
  name: 'Discount',
  components: { ListPage },
  data: function () {
    return {
      search_params: { name: '', status: 0 },
      list_param: { type: 2 }
    }
  },
  computed: {
    table_columns () {
      return tableColumns(this)
    },
    activityStatusList () {
      return getStautsText('activity.status')
    }
  }
}
</script>

<style scope>
@import url("discount.less");
</style>
