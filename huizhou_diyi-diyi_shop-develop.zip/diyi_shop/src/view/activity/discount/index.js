import Discount from './discount.vue'
export default Discount
