import ActivityEdit from './activity-edit.vue'
export default ActivityEdit
