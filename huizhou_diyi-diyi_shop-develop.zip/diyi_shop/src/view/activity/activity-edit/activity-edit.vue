<template>
  <div>
    <MainTile title="编辑活动" />
    <Form
      ref="activity_form"
      :model="item"
      :rules="ruleValidate"
      style="margin-top: 25px;"
      :label-width="120"
    >
      <FormItem label="名称：" prop="name" class="input_width">
        <Input v-model="item.name" placeholder="请输入套餐名称" />
      </FormItem>

      <FormItem label="门槛：" prop="condition">
        满
        <InputNumber :min="0" v-model="item.condition" placeholder="输入门槛" />
        <Select v-model="item.condition_unit" style="width:60px">
          <Option v-for="(text, inx) in conditionUnitList" :value="inx" :key="inx">{{ text }}</Option>
        </Select>
      </FormItem>
      <FormItem label="优惠：" prop="discount">
        <RadioGroup v-model="item.discount_way">
          <Radio v-for="(text, inx) in discountWayList" :key="inx" :label="Number(inx)">{{ text }}</Radio>
        </RadioGroup>
        <InputNumber
          :min="0"
          :max="item.discount_way == 1 ? 999999999 : 10"
          v-model="item.discount"
          placeholder="输入优惠"
        />
        <span>{{item.discount_way == 1 ? '元' : '折'}}</span>
      </FormItem>
      <FormItem label="期限：" prop="is_undated" style="width:600px">
        <DatePicker
          v-model="item.start_time"
          type="date"
          placeholder="开始日期"
          :disabled="item.is_undated == 1"
          style="display: inline-block;width: 150px"
        ></DatePicker>至
        <DatePicker
          v-model="item.end_time"
          type="date"
          placeholder="结束日期"
          :disabled="item.is_undated == 1"
          style="display: inline-block;width: 150px"
        ></DatePicker>
      </FormItem>
      <FormItem label="总发布数量">
        <InputNumber :min="0" v-model="item.total" placeholder="输入总发布数量"></InputNumber>
      </FormItem>
      <FormItem label="剩余数量">
        <InputNumber :min="0" v-model="item.surplus" placeholder="输入剩余发布数量"></InputNumber>
      </FormItem>
      <FormItem label="每单限量：" style="display: inline-block;">
        <i-switch v-model="is_limit_switch">
          <span slot="open">是</span>
          <span slot="close">否</span>
        </i-switch>
        <InputNumber
          :min="0"
          style="display: inline-block; width:100px; margin-left:15px"
          :disabled="item.is_limit != 1"
          :precision="0"
          v-model="item.limit_num"
          placeholder="输入限量数"
        />
      </FormItem>
      <FormItem label="全部商品：" prop="is_sale">
        <i-switch v-model="item.is_all" :true-value="1" :false-value="0">
          <span slot="open">是</span>
          <span slot="close">否</span>
        </i-switch>
      </FormItem>
      <FormItem label="是否上架：" prop="is_sale">
        <i-switch v-model="item.is_sale" :true-value="1" :false-value="0">
          <span slot="open">是</span>
          <span slot="close">否</span>
        </i-switch>
      </FormItem>
      <FormItem
        label="绑定菜品"
        prop="product_ids"
        v-if="item.product_ids !== undefined && item.is_all == 0"
      >
        <SelectProduct @change="selecter" :product_ids="item.product_ids" />
      </FormItem>

      <FormItem>
        <Button
          style="margin-right:15px"
          type="primary"
          :loading="save_loading"
          @click="save('activity_form')"
        >{{item.product_ids ? '保存' : '保存，并下一步'}}</Button>
      </FormItem>
    </Form>
  </div>
</template>

<script>
import MainTile from '@/components/main-title'
import { getStautsText } from '@/libs/tools'
import SelectProduct from '@/components/select_product'

import DatePlus from '@/libs/DatePlus'
export default {
  name: 'ActivityEdit',
  components: { MainTile, SelectProduct },
  data() {
    return {
      item: {
        type: 0,
        condition_unit: '1',
        condition: 0,
        discount_way: '1',
        discount: 0,
        is_all: 0
      },
      save_loading: false,
      pic: '',
      ruleValidate: {
        name: [{ required: true, message: '名称不能为空', trigger: 'blur' }],
        condition: [
          {
            required: true,
            type: 'number',
            message: '门槛不能为空',
            trigger: 'blur'
          }
        ],
        discount: [
          {
            required: true,
            type: 'number',
            message: '优惠不能为空',
            trigger: 'blur'
          }
        ],
        is_undated: [
          {
            validator: (rule, value, callback) => {
              if (!value) {
                if (!this.item.start_time) {
                  return callback(new Error('请选择开始日期'))
                } else if (!this.item.end_time) {
                  return callback(new Error('请选择结束日期'))
                } else {
                  let startTime = new DatePlus(this.item.start_time)
                  // if (startTime.compare(new Date()) === -1) {
                  //   return callback(new Error('开始时间不能小于当前时间'))
                  // }
                  if (startTime.compare(this.item.end_time) === 1) {
                    return callback(new Error('结束时间不能小于开始时间'))
                  }
                }
              }
              return callback()
            },
            trigger: 'none'
          }
        ]
      },
      is_limit_switch: false,
      is_all_switch: false
    }
  },
  methods: {
    save(from) {
      this.$refs[from].validate(valid => {
        console.log(!valid)
        if (!valid) {
          return
        }
        // TODO 这里UI组件里面的:true-values会出现无法遍历数据，日后需要观擦一下
        this.is_limit_switch == true
          ? (this.item.is_limit = 1)
          : (this.item.is_limit = 2)
        this.is_all_switch == true
          ? (this.item.is_all = 1)
          : (this.item.is_all = 0)

        /*
          @prame 分 * 100   折率 * 10
        */
        if (this.item.discount_way == 1)
          this.item.discount = Number(this.item.discount) * 100
        else this.item.discount = Number(this.item.discount) * 10
        if (this.item.condition_unit == 1)
          this.item.condition = Number(this.item.condition) * 100
        let data = JSON.parse(JSON.stringify(this.item))
        data.start_time = new DatePlus(data.start_time).getTimeStamp()
        data.end_time = new DatePlus(data.end_time).getTimeStamp()
        let requestParams = {
          url: '/activity/activity/save',
          data
        }
        this.save_loading = true
        this.$http
          .request(requestParams)
          .then(response => {
            this.save_loading = false
            this.$Message.info(response.data.message)
            if (response.data.code === 1) {
              if (this.item.product_ids === undefined) {
                this.item.product_ids = []
                this.item.id = response.data.data
              } else {
                this.$router.go(-1)
              }
            }
          })
          .catch(error => {
            console.error(error)
          })
      })
    },
    selecter(selectedIds) {
      this.item.product_ids = selectedIds
    }
  },
  computed: {
    conditionUnitList() {
      return getStautsText('activity.condition_unit')
    },
    discountWayList() {
      return getStautsText('activity.discount_way')
    }
  },
  created() {
    this.item.type = this.$route.query.type
    console.log('this.$route', this.$route.query.id, 11)
    if (this.$route.query.id) {
      let requestParams = {
        url: '/activity/activity/selectOne',
        data: { id: this.$route.query.id }
      }
      this.$http
        .request(requestParams)
        .then(response => {
          this.item = response.data.data
          this.item.total = Number(this.item.total)
          this.item.surplus = Number(this.item.surplus)
          this.item.limit_num = Number(this.item.limit_num)
          this.item.start_time = new DatePlus(this.item.start_time * 1000)
          this.item.end_time = new DatePlus(this.item.end_time * 1000)
          if (this.item.discount_way == 1)
            this.item.discount = Number(this.item.discount) / 100
          else this.item.discount = Number(this.item.discount) / 10
          if (this.item.condition_unit == 1)
            this.item.condition = Number(this.item.condition) / 100
          this.item.discount_way = Number(this.item.discount_way)
          this.item.is_limit == 1
            ? (this.is_limit_switch = true)
            : (this.is_limit_switch = false)
          this.item.is_all == 1
            ? (this.is_all_switch = true)
            : (this.is_all_switch = false)
        })
        .catch(error => {
          console.error(error)
        })
    }
  }
}
</script>

<style scope>
@import url('activity-edit.less');
</style>
