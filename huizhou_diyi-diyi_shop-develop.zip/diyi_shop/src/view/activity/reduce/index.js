import Reduce from './reduce.vue'
export default Reduce
