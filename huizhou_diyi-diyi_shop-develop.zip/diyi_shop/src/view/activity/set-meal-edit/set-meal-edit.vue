<template>
  <div>
    <MainTile title="添加套餐" />
    <Form
      ref="set_meal_form"
      :model="item"
      :rules="ruleValidate"
      style="margin-top: 25px;"
      :label-width="120"
    >
      <FormItem label="套餐名称：" prop="name" class="input_width">
        <Input v-model="item.name" placeholder="请输入套餐名称"/>
      </FormItem>
      <FormItem label="价格(元)：" prop="price" class="input_width">
        <Tooltip trigger="hover" placement="right" title="" content="保存后不可修改">
          <div v-if="item.product_ids">{{item.price.toFixed(2)}}</div>
          <InputNumber v-else :min="0" v-model="item.price" placeholder="请输入价格"  style="width:180px;" />
        </Tooltip>
      </FormItem>
      <FormItem label="无期限：" prop="is_undated" style="width:600px">
        <i-switch v-model="item.is_undated" :true-value="1" :false-value="0" style="margin-right:15px">
          <span slot="open">是</span>
          <span slot="close">否</span>
        </i-switch>
        <DatePicker v-model="item.start_time" type="date" placeholder="开始日期" :disabled="item.is_undated == 1" style="display: inline-block;width: 150px"></DatePicker> 至
        <DatePicker v-model="item.end_time" type="date" placeholder="结束日期" :disabled="item.is_undated == 1" style="display: inline-block;width: 150px"></DatePicker>
      </FormItem>
      <FormItem label="是否限量：" style="display: inline-block;">
        <i-switch v-model="item.is_limit" :true-value="1" :false-value="0">
          <span slot="open">是</span>
          <span slot="close">否</span>
        </i-switch>
        <InputNumber
          :min="0"
          style="display: inline-block; width:100px; margin-left:15px"
          :disabled="item.is_limit != 1"
          :precision="0"
          v-model="item.limit_num"
          placeholder="输入限量数"
        />
      </FormItem>
      <FormItem label="是否上架：" prop="is_sale" >
          <i-switch v-model="item.is_sale" :true-value="1" :false-value="0">
            <span slot="open">是</span>
            <span slot="close">否</span>
          </i-switch>
      </FormItem>
      <FormItem label="排序：" prop="sort" class="input_width">
        <InputNumber :min="0" v-model="item.sort" placeholder="请输入排序"  style="width:180px"/>
      </FormItem>
      <FormItem label="上传图片：" prop="sort" >
        <UploadPic :pic="pic" @complete="uploadComplete" />
      </FormItem>
      <FormItem  label="绑定菜品" prop="product_ids"  v-if="item.product_ids !== undefined">
        <SelectProduct @change="selecter" :product_ids="item.product_ids" />
      </FormItem>

      <FormItem>
        <Button style="margin-right:15px" type="primary" :loading="save_loading" @click="save('set_meal_form')">{{item.product_ids ? '保存' : '保存，并下一步'}}</Button>
      </FormItem>
    </Form>
  </div>
</template>

<script>
import MainTile from '@/components/main-title'
import UploadPic from '@/components/upload-pic'
import SelectProduct from '@/components/select_product'

import DatePlus from '@/libs/DatePlus'
export default {
  name: 'SetMealEdit',
  components: { MainTile, UploadPic, SelectProduct },
  data () {
    return {
      item: { price: 0, is_undated: 1, sort: 0 },
      save_loading: false,
      pic: '',
      ruleValidate: {
        name: [
          { required: true, message: '名称不能为空', trigger: 'blur' }
        ],
        price: [
          { required: true, type: 'number', message: '价格不能为空', trigger: 'blur' }
        ],
        is_undated: [
          {
            validator: (rule, value, callback) => {
              if (!value) {
                if (!this.item.start_time) {
                  return callback(new Error('请选择开始日期'))
                } else if (!this.item.end_time) {
                  return callback(new Error('请选择结束日期'))
                } else {
                  let startTime = new DatePlus(this.item.start_time)
                  if (startTime.compare(this.item.end_time) === 1) {
                    return callback(new Error('结束时间不能小于开始时间'))
                  }
                }
              }
              return callback()
            },
            trigger: 'none'
          }
        ]
      }
    }
  },
  methods: {
    save (from) {
      this.$refs[from].validate((valid) => {
        if (!valid) {
          return
        }
        let data = JSON.parse(JSON.stringify(this.item))
        data.start_time = new DatePlus(data.start_time).getTimeStamp()
        data.end_time = new DatePlus(data.end_time).getTimeStamp()
        let requestParams = {
          url: '/activity/set_meal/save',
          data
        }
        this.save_loading = true
        this.$http.request(requestParams)
          .then(response => {
            this.save_loading = false
            this.$Message.info(response.data.message)
            if (response.data.code === 1) {
              if (this.item.product_ids === undefined) {
                this.item.product_ids = []
                this.item.id = response.data.data
              } else {
                this.$router.push({ name: 'set-meal' })
              }
            }
          })
          .catch(error => {
            console.error(error)
          })
      })
    },
    uploadComplete (url) {
      this.item.pic = url
      this.pic = this.$store.state.app.qiniuDomain + this.item.pic
    },
    selecter (selectedIds) {
      this.item.product_ids = selectedIds
    }
  },
  created () {
    if (this.$route.query.id) {
      let requestParams = {
        url: '/activity/set_meal/selectOne',
        data: { id: this.$route.query.id }
      }
      this.$http.request(requestParams)
        .then(response => {
          this.item = response.data.data
          this.item.start_time = new DatePlus(this.item.start_time * 1000)
          this.item.end_time = new DatePlus(this.item.end_time * 1000)
          this.item.price = Number(this.item.price)
          if (this.item.pic != '') {
            this.pic = this.$store.state.app.qiniuDomain + this.item.pic
          }
        }).catch(error => {
          console.error(error)
        })
    }
  }
}
</script>

<style scope>
@import url("set-meal-edit.less");
</style>
