import Coupon from './coupon.vue'
export default Coupon
