
import DatePlus from '@/libs/DatePlus'
function tableColumns (vue) {
  return [
    {
      title: 'ID',
      key: 'id',
      align: 'center'
    },
    {
      title: '名称',
      key: 'name',
      align: 'center'
    },
    {
      title: '状态',
      key: 'status_text',
      align: 'center'
    },
    {
      title: '开始时间',
      key: 'start_time',
      align: 'center',
      render: (h, params) => {
        let time = '无期限'
        if (params.row.start_time) {
          time = new DatePlus(params.row.start_time * 1000).format('yyyy-MM-dd')
        }
        return h('span', time)
      }
    },
    {
      title: '结束时间',
      key: 'end_time',
      align: 'center',
      render: (h, params) => {
        let time = '无期限'
        if (params.row.end_time) {
          time = new DatePlus(params.row.end_time * 1000).format('yyyy-MM-dd')
        }
        return h('span', time)
      }
    },
    {
      title: '是否限量',
      key: 'is_limit',
      align: 'center',
      render: (h, params) => {
        return h('span', params.row.is_limit ? '是' : '否')
      }
    },
    {
      title: '限量数',
      key: 'limit_num',
      align: 'center'
    },
    {
      title: '参加菜品',
      key: 'is_all',
      align: 'center',
      render: (h, params) => {
        return h('span', params.row.is_all === 1 ? '全部' : '部份')
      }
    },
    {
      title: '是否上架',
      key: 'is_sale',
      align: 'center',
      render: (h, params) => {
        let _this = vue
        return h('i-switch', {
          props: {
            value: params.row.is_sale,
            'true-value': 1,
            'false-value': 0
          },
          on: {
            'on-change': (value) => {
              params.row.is_sale = value
              _this.$refs.list_page.save(params.index, params.row)
            }
          }
        }, [
          h('span', {
            slot: 'open',
            domProps: {
              innerHTML: '是'
            }
          }),
          h('span', {
            slot: 'close',
            domProps: {
              innerHTML: '否'
            }
          })
        ])
      }
    },
    {
      title: '操作',
      slot: 'action',
      width: 150,
      align: 'center'
    }
  ]
}
export default tableColumns
