<template>
  <div>
    <ListPage
      title="套餐列表"
      desc="在这里可以浏览到您店铺所有的优惠套餐信息"
      ref="list_page"
      :columns="table_columns"
      :route_edit="{name: 'set-meal-edit'}"
      :list_param="list_param"
      data_url="/activity/set_meal/selectPage"
      save_url="/activity/set_meal/save"
      del_url="/activity/set_meal/destroy"
    >
    </ListPage>

  </div>
</template>

<script>
import ListPage from '@/components/list-page'
import DatePlus from '@/libs/DatePlus'
export default {
  name: 'SetMeal',
  components: { ListPage },
  data: function () {
    return {
      table_columns: [
        {
          title: 'ID',
          key: 'id',
          align: 'center'
        },
        {
          title: '套餐名称',
          key: 'name',
          align: 'center'
        },
        {
          title: '套餐价格',
          key: 'price',
          align: 'center',
          render: (h, params) => {
            return h('span', params.row.price)
          }
        },
        {
          title: '是否限量',
          key: 'is_limit',
          align: 'center',
          render: (h, params) => {
            return h('span', params.row.is_limit ? '是' : '否')
          }
        },
        {
          title: '限量数',
          key: 'limit_num',
          align: 'center'
        },
        {
          title: '开始时间',
          key: 'start_time',
          align: 'center',
          render: (h, params) => {
            let time = '无期限'
            if (params.row.start_time) {
              time = new DatePlus(params.row.start_time * 1000).format('yyyy-MM-dd')
            }
            return h('span', time)
          }
        },
        {
          title: '结束时间',
          key: 'end_time',
          align: 'center',
          render: (h, params) => {
            let time = '无期限'
            if (params.row.end_time) {
              time = new DatePlus(params.row.end_time * 1000).format('yyyy-MM-dd')
            }
            return h('span', time)
          }
        },
        {
          title: '是否上架',
          key: 'is_sale',
          align: 'center',
          render: (h, params) => {
            let _this = this
            return h('i-switch', {
              props: {
                value: params.row.is_sale,
                'true-value': 1,
                'false-value': 0,
                disabled: params.row.product_ids.length === 0
              },
              on: {
                'on-change': (value) => {
                  params.row.is_sale = value
                  _this.$refs.list_page.save(params.index, params.row)
                }
              }
            }, [
              h('span', {
                slot: 'open',
                domProps: {
                  innerHTML: '是'
                }
              }),
              h('span', {
                slot: 'close',
                domProps: {
                  innerHTML: '否'
                }
              })
            ])
          }
        },
        {
          title: '排序',
          key: 'sort',
          align: 'center'
        },
        {
          title: '操作',
          slot: 'action',
          width: 150,
          align: 'center'
        }
      ],
      search_params: { name: '' },
      list_param: { sort: { sort: 'asc', id: 'desc' } }
    }
  }
}
</script>

<style scope>
@import url("set-meal.less");
</style>
