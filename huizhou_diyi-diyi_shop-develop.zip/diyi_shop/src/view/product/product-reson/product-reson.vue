<template>
  <div>
    <hgroup class="shopC-title">
      <h3>原因列表</h3>
      <p>这里可以设置原因选择</p>
    </hgroup>
    <div class="shopClass-search">
      <p class="shopClass-title">快速查找：</p>
      <Input
        clearable
        :maxlength="40"
        v-model="resdata.reason"
        icon="search"
        placeholder="输入你要查询的原因名称"
        style="width: 200px; display: inline-block"
      />
      <Select placeholder="输入你要查询的原因类型" v-model="resdata.type" style="width:170px;margin-left:10px">
        <Option v-for="item in resonMlist" :value="item.type" :key="item.value">{{ item.title }}</Option>
      </Select>
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="getReasonList(true)"
        type="primary"
      >搜索</Button>
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="resdata.reason='';resdata.type = '';getReasonList(true)"
        type="warning"
      >刷新</Button>
    </div>
    <Button
      @click="addshow"
      style="display: inline-block; margin:5px 0 10px 0;  "
      type="primary"
    >+添加原因</Button>
    <Table border style="width:600px" :columns="columns" :data="shopData" stripe></Table>
    <div class="clearf" style="width:600px;margin:10px 0 10px 0;">
      <Page
        show-elevator
        show-total
        @on-change="avgPage"
        style="display: inline-block; float: right; "
        :page-size="resdata.rows"
        :total="Number(resdata.total)"
      />
    </div>
    <Modal v-model="delboxshow" width="360">
      <p slot="header" style="color:#f60;text-align:center">
        <Icon type="ios-information-circle"></Icon>
        <span>删除原因</span>
      </p>
      <div style="text-align:center">
        <p>当前正常进行删除原因操作</p>
        <p>您确认删除吗?</p>
      </div>
      <div slot="footer">
        <Button type="error" long size="large" @click="del">删除</Button>
      </div>
    </Modal>
    <Modal v-model="editarr.show" :title="editarr.title" @on-ok="edit(isedit)" width="350">
      <Form :label-width="80" ref="uselist" :model="uselist" :rules="ruleValidate">
        <FormItem label="名称" prop="reason">
          <Input
            :maxlength="40"
            style="width:150px"
            v-model="uselist.reason"
            placeholder="请输入原因描述"
          />
        </FormItem>
        <FormItem label="类型" prop="type">
          <RadioGroup v-model="uselist.type">
            <Radio
              :label="item.type"
              v-for="(item, index) in resonMlist"
              :key="index"
            >{{item.title}}</Radio>
          </RadioGroup>
        </FormItem>
      </Form>
    </Modal>
  </div>
</template>

<script>
import { reasonList, dataSet, deleteSon } from '@/api/shop/shopReson'
import { getStautsText } from '@/libs/tools.js'
export default {
  data() {
    return {
      searchInfo: '',
      columns: [
        { key: 'reason', title: '名称' },
        {
          key: 'type',
          title: '原因类型',
          width: 120,
          render: (h, params) => {
            return h('div', [h('p', this.statusListinfo.type[params.row.type])])
          }
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.editarr.title = '修改原因'
                      this.uselist = JSON.parse(JSON.stringify(params.row))
                      this.uselist.sort = Number(this.uselist.sort)
                      this.isedit = 'edit'
                      this.editarr.show = true
                    }
                  }
                },
                '编辑'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.delboxshow = true
                      this.uselist = JSON.parse(JSON.stringify(params.row))
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      shopData: [],
      delboxshow: false,
      resdata: {
        page: 1,
        rows: 10,
        reason: '',
        total: ''
      },
      uselist: {
        name: ''
      },
      resonMlist: [
        
      ],
      editarr: {
        show: false,
        title: ''
      },
      isedit: '',
      statusListinfo: {},
      ruleValidate: {
        reason: [
          {
            required: true,
            message: '原因名称不能为空',
            trigger: 'blur'
          }
        ],
        type: [
          {
            required: true,
            message: '原因类型必须选择其一',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  methods: {
    // 获取
    getReasonList(type) {
      if (type) {
        this.resdata.page = 1
      }
      reasonList(this.resdata).then(res => {
        this.shopData = res.data.data.list
        this.resdata.total = Number(res.data.data.total)
      })
    },
    // 删除
    del() {
      const data = { id: this.uselist.id }
      deleteSon(data).then(res => {
        if (res.data.code == 1) {
          this.delboxshow = false
          this.$Notice.success({
            title: '该备注已经删除'
          })
          if (this.shopData.length == 1) {
            this.resdata.page -= 1
          }
          this.getReasonList()
        } else {
          this.$Notice.error({
            title: res.data.message
          })
        }
      })
      this.uselist = {}
    },
    // 添加 & 删除
    edit(type) {
      if (type === 'edit') {
        if (this.uselist.reason == '' && this.uselist.type == '') {
          this.$Message.error('描述或者类型不得为空')
        } else {
          dataSet(this.uselist).then(res => {
            this.$Message.success(res.data.message)
            this.getReasonList()
          })
        }
      } else {
        if (
          this.uselist.reason != undefined &&
          this.uselist.type != undefined
        ) {
          dataSet(this.uselist).then(res => {
            this.$Message.success(res.data.message)
            this.getReasonList()
          })
        } else {
          this.$Message.error('请选择原因类型')
        }
      }
    },
    addshow() {
      this.isedit = 'add'
      this.uselist = {}
      this.editarr.title = '添加原因'
      this.editarr.show = true
    },
    avgPage(v) {
      this.resdata.page = v
      this.getReasonList()
    },
    resonList() {
      Object.keys(getStautsText('reason.type')).forEach(item => {
        this.resonMlist.push({type:item,title:getStautsText('reason.type')[item]})
      });
    }
  },
  async mounted() {
    this.getReasonList()
    this.statusListinfo = getStautsText('reason')
    this.resonList()
  }
}
</script>

<style scope>
@import url('./product-reson.less');
</style>
