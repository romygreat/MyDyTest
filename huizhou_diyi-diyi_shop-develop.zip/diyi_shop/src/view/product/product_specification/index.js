import ProductSpecification from './product_specification'
export default ProductSpecification
