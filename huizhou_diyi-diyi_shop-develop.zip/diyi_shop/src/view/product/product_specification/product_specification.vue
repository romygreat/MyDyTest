<template>
  <div>
    <hgroup class="shopC-title">
      <h3>规格列表</h3>
      <p>这是您店内的商品规格，请仔细核对</p>
    </hgroup>
    <!-- shopClassify search -->
    <div class="shopClass-search">
      <p class="shopClass-title">规格名称：</p>
      <Input
        clearable
        v-model="pageData.searchInfo"
        icon="search"
        :maxlength='40'
        placeholder="输入你要查询的规格名称"
        style="width: 200px; display: inline-block"
      />
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="getShopData(false)"
        type="primary"
      >搜索</Button>
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="pageData.searchInfo='';getShopData(false)"
        type="warning"
      >刷新</Button>
    </div>
    <!-- add shopClassify buttom -->
    <Button
      type="primary"
      style="margin-bottom: 15px;"
      @click="operation.operTitle = '添加商品规格'; operation.operShow = true;newinfo()"
    >
      <span>
        <Icon type="md-add" />
        <span>新增规格</span>
      </span>
    </Button>
    <!-- shopClass Tables -->
    <Table :width="900" ref="selection" border :columns="columns" :data="specList" stripe></Table>
    <div style="margin-top:20px; width:900px">
      <Page
        :total="Number(pageData.total)"
        :current="Number(pageData.current)"
        :page-size=" Number(pageData.rows)"
        @on-change="getShopData"
        class="page-buttom"
      ></Page>
    </div>
    <!-- operation -->
    <Modal
      v-model="operation.operShow"
      :title="operation.operTitle"
      :footer-hide="true"
      width="450"
    >
      <Form ref="operation" :model="operation" :rules="ruleValidate" :label-width="100">
        <FormItem label="规格名称：" prop="operName">
          <Input :maxlength='40' style="width:200px" v-model="operation.operName" placeholder="请输入规格名称" />
        </FormItem>
        <FormItem label="规格值：">
          <Input :maxlength='40' style="width:200px" v-model="operation.operspec_val" placeholder="请输入规格值" />
          <p style="color: #999;">
            规格值请用 ',' （逗号）隔开！
            <br />修改规格值会改变规格组合的信息。
          </p>
        </FormItem>
        <FormItem label="排序：">
          <Input :maxlength='40' style="width:200px" v-model="operation.sort" placeholder="请输入排序值" />
        </FormItem>
        <FormItem>
          <Button type="primary" @click="handleSubmit('operation')">确认</Button>
          <Button @click="operation.operShow = false" style="margin-left: 8px">取消</Button>
        </FormItem>
      </Form>
    </Modal>
  </div>
</template>

<script>
import { delList, listSpeButtom, setListButtom } from '@/api/shop/shopAttribute'
import { searchList } from '@/libs/tools'
export default {
  data() {
    return {
      columns: [
        {
          title: 'ID',
          key: 'id',
          width: 88,
          align: 'center'
        },
        {
          title: '规格名称',
          key: 'name',
          width: 200,
          align: 'center'
        },
        {
          title: '排序',
          key: 'sort',
          width: 100,
          align: 'center'
        },
        {
          title: '可选规格值',
          key: 'spec_val',
          align: 'center',
          render: (h, params) => {
            let infotext = []
            for (let key in params.row.spec_val) {
              infotext.push(params.row.spec_val[key].spec_val)
            }
            return h('div', infotext.join(','))
          }
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.show(params.index)
                    }
                  }
                },
                '编辑'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      specList: [],
      pageData: {
        total: '20',
        current: 1,
        rows: '10',
        searchInfo: ''
      },
      operation: {
        operShow: false,
        operTitle: '',
        sort: 0,
        operName: '',
        operspec_val: '',
        operList: '',
        operId: 0
      },
      ruleValidate: {
        operName: [
          { required: true, message: '规格名不能为空', trigger: 'blur' },
          { min: 2, message: '规格名不能低于两个字', trigger: 'blur' }
        ],
        operspec_val: [
          { required: true, message: '规格值不能为空', trigger: 'blur' },
          { min: 2, message: '规格值不能低于两个字', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    //  获取列表
    getShopData(value) {
      if (value) {
        this.pageData.current = value
      } else {
        this.pageData.current = 1
      }
      const data = {
        page: this.pageData.current,
        rows: this.pageData.rows,
        name: this.pageData.searchInfo,
        sort: {
          sort: 'asc'
        }
      }
      listSpeButtom(data)
        .then(res => {
          this.specList = Object.values(res.data.data.list)
          console.log(this.specList, 67526752)
          this.pageData.total = res.data.data.total
          // this.pageData.searchInfo = ''
        })
        .catch(err => {
          console.error(err)
        })
    },
    // 编辑buttom
    show(index) {
      this.operation.operShow = true
      this.operation.operTitle = '修改商品规格'
      this.operation.operName = this.specList[index].name
      this.operation.operId = this.specList[index].id
      let infotext = []
      for (let key in this.specList[index].spec_val) {
        infotext.push(this.specList[index].spec_val[key].spec_val)
      }
      this.operation.operspec_val = infotext.join(',')
      this.operation.sort = this.specList[index].sort
    },
    // 删除buttom
    remove(index) {
      this.$Modal.confirm({
        title: '彻底删除',
        content: '<p>删除规格会改变规格组合的信息。</p><p>确认彻底删除？</p>',
        onOk: () => {
          const data = {
            id: this.specList[index].id
          }
          delList(data).then(res => {
            this.getShopData()
          })
          this.$Message.info('已经删除')
        },
        onCancel: () => {
          this.$Message.info('取消了彻底删除操作')
        }
      })
    },
    // 添加 && 修改
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          // 替换中文逗号并分割成数组
          let specVals = this.operation.operspec_val
            .replace(/，/g, ',')
            .replace(new RegExp('^\\,|\\,+$', 'g'), '')
            .split(',')
          // 组合规格值列表
          let specValList = []
          let spec_id = parseInt(this.operation.operId)
          specVals.forEach((val, index) => {
            let temp = {}
            if (spec_id != 0) {
              // 如果是编辑规格，保留原ID
              let omwSpec = searchList(this.specList, 'id', spec_id)
              let omwSpecVals = Object.values(omwSpec.spec_val)
              if (omwSpecVals[index]) {
                temp.id = omwSpecVals[index].id
              }
            }
            temp.spec_val = val
            temp.sort = index
            specValList.push(temp)
          })

          let data = {
            id: spec_id,
            name: this.operation.operName,
            type: 1,
            list: specValList,
            sort: this.operation.sort
          }
          setListButtom(data)
            .then(res => {
              this.$Message.success(res.data.message)
              this.getShopData()
              this.operation.operShow = false
            })
            .catch(err => {
              this.$Message.success(err)
            })
        } else {
          this.$Message.error('请按规则填写提交')
        }
      })
    },
    // 初始化
    newinfo() {
      this.operation.operShow = true
      this.operation.operTitle = '添加商品规格'
      this.operation.operId = 0
      this.operation.operName = ''
      this.operation.operspec_val = ''
      this.operation.sort = 0
    }
  },
  mounted() {
    this.getShopData()
  }
}
</script>
<style>
@import './product_specification.css';
</style>
