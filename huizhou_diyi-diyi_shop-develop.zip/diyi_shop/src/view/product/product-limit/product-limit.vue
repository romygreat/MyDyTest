<template>
    <div>
        <hgroup class="shopC-title" >
            <h3>沽清列表</h3>
            <p>这里是您设置了估清商量的列表集合，您可以进行修改和删除</p>
        </hgroup>
        <Table style="margin-top: 15px; width:500px; "  border :columns="colums" :data="limitList"></Table>
        <div style="margin-top: 15px; width:500px; " ><Page @on-change='nextpage' :total="resdata.total" /></div>
        <Modal v-model="delshow" width="360">
            <p slot="header" style="color:#f60;text-align:center">
                <Icon type="ios-information-circle"></Icon>
                <span>删除确认</span>
            </p>
            <div style="text-align:center">
                <p>您确认要删除吗？</p>
            </div>
            <div slot="footer">
                <Button type="error" size="large" long  @click="delLimit('del')">删除</Button>
            </div>
        </Modal>
        <Modal
            @on-ok="delLimit('edit')"
            v-model="editLimitShow"
            title="修改估清数"
            width="300">
            <!-- <Input v-model="editdata.limit_num" size="large" placeholder="请输入估清数" /> -->
             <InputNumber style="width:100%"  :min="0"  v-model="editdata.limit_num" size="large" placeholder="请输入估清数" />
        </Modal>
    </div>
</template>

<script>
import { sellOutProductList, operationProduct } from '@/api/shop/shopLimit.js'
export default {
  data () {
    return {
      editLimitShow: false,
      colums: [
        {
          title: '品项名称',
          key: 'name'
        },
        {
          title: '沽清数',
          key: 'limit_num'
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h('Button', {
                props: {
                  type: 'primary',
                  size: 'small'
                },
                style: {
                  marginRight: '5px'
                },
                on: {
                  click: () => {
                    this.editdata = JSON.parse(JSON.stringify(this.limitList[params.index]))
                    this.editdata.limit_num = Number(this.editdata.limit_num)
                    this.editLimitShow = true
                  }
                }
              }, '编辑'),
              h('Button', {
                props: {
                  type: 'error',
                  size: 'small'
                },
                on: {
                  click: () => {
                    this.delid = this.limitList[params.index].id
                    this.delshow = true
                  }
                }
              }, '删除')
            ])
          }
        }
      ],
      limitList: [],
      resdata: {
        is_limit: 1,
        rows: 10,
        page: 1,
        total: 0
      },
      delshow: false,
      delid: '',
      editdata: []
    }
  },
  methods: {
    sellOutProductList () {
      sellOutProductList(this.resdata).then(res => {
        this.limitList = res.data.data.list
        this.resdata.total = Number(res.data.data.total)
        console.log(this.limitList)
      })
    },
    delLimit (type) {
      if (type === 'del') {
        const data = {
          operation: 'del',
          id: this.delid,
          is_limit: 0,
          limit_num: 0
        }
        operationProduct(data).then(res => {
          this.$Notice.success({
            title: res.data.message
          })
          this.sellOutProductList()
          this.delshow = false
        })
      } else if (type === 'edit') {
        const data = {
          operation: 'edit',
          is_limit:1,
          limit_num: this.editdata.limit_num,
          id: this.editdata.id
        }
        operationProduct(data).then(res => {
          this.$Notice.success({
            title: res.data.message
          })
          this.sellOutProductList()
          this.editLimitShow = false
        })
      }
    },
    nextpage (v) {
      this.resdata.page = v
      this.sellOutProductList()
    }
  },
  mounted () {
    this.sellOutProductList()
  }
}
</script>

<style>
@import url('./product-limit.less');
</style>
