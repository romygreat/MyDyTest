import ProductEdit from './product-edit.vue'
export default ProductEdit
