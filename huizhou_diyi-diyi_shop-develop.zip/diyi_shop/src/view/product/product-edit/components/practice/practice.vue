<template>
  <div>
    <div style="margin-left:10px;">
      <Select
        @on-query-change="remotenull"
        @on-change="sdkinfo"
        v-model="selectinfo"
        multiple
        filterable
        remote
        :remote-method="remoteMethod2"
        :loading="loading2"
        placeholder="请选择或输入关键字"
      >
        <Option
          v-for="(option, index) in options2"
          :value="option.value"
          :key="index"
        >{{option.label}}</Option>
      </Select>
    </div>
  </div>
</template>

<script>
import { PracList } from '@/api/shop/shopPractice'
export default {
  props: ['propsProcedure'],
  data() {
    return {
      selectinfo: [],
      loading2: false,
      options2: [],
      list: [],
      resselect: []
    }
  },
  methods: {
    getPracList() {
      const data = {
        page: 1,
        rows: 50
      }
      PracList(data).then(res => {
        this.list = JSON.parse(JSON.stringify(res.data.data.list))
        const listinfo = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        this.options2 = listinfo
      })
    },
    remoteMethod2(query) {
      if (query !== '') {
        this.loading2 = true
        setTimeout(() => {
          let arrlist = []
          this.loading2 = false
          const data = { name: query }
          PracList(data).then(res => {
            arrlist = JSON.parse(JSON.stringify(res.data.data.list))
            const listinfo = arrlist.map(item => {
              return {
                value: item.id,
                label: item.name
              }
            })
            this.options2 = listinfo.filter(
              item => item.label.toLowerCase().indexOf(query.toLowerCase()) > -1
            )
            this.tovalue()
          })
        }, 200)
      } else {
        this.options2 = []
        this.tovalue()
      }
    },
    sdkinfo(i) {
      const listinfo = this.list.map(item => {
        return {
          value: item.id,
          label: item.name
        }
      })
      this.options2 = listinfo
      this.resselect = []
      let arr = JSON.parse(JSON.stringify(this.selectinfo))
      for (let i in arr) {
        this.resselect[i] = { label_id: arr[i] }
      }
      this.tovalue()
    },
    remotenull(v) {
      if (v === '') {
        const listinfo = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        this.options2 = listinfo
        this.tovalue()
      }
    },
    tovalue() {
      //  The world! 時間よ、止まって。!!!
      let arr = []
      this.selectinfo.forEach(element => {
        for (let i in this.list) {
          if (this.list[i].id == element) {
            arr.push(this.list[i].id)
          }
        }
      })
      this.$emit('practice', arr)
    }
  },
  mounted() {
    this.getPracList()
  },
  created() {
    if (this.propsProcedure && this.propsProcedure.length > 0) {
      let arr = []
      for (let i in this.propsProcedure) {
        arr.push(this.propsProcedure[i].procedure_id)
      }
      this.selectinfo = arr
    }
  }
}
</script>

<style>
</style>
