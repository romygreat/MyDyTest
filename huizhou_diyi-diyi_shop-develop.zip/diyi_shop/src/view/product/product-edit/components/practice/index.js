import Practice from './practice.vue'
export default Practice
