import Garnish from './garnish.vue'
export default Garnish
