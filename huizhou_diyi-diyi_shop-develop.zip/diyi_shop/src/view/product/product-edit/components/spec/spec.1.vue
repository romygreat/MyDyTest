<template>
  <div>
    <!-- 添加 -->
    <div v-show="!hasSpec" @click="hasSpec = true;addSpecseleter();" class="startbuttom">添加规格项目</div>
    <ul v-show="hasSpec" class="spec-buttomdiv">
      <li v-for="(selecter, index) in selecterSpec" :key="index">
        <div class="spec-select">
          <h3>规格名：</h3>
          <!-- 规格选择器 -->
          <Select @on-change="changedSpec()" v-model="spec[index]" style="width:180px">
            <Option
              v-for="(item, indexs) in allSpecList"
              :disabled="item.selected"
              :key="indexs"
              :value="item.id"
            >{{item.name}}</Option>
          </Select>
        </div>
        <div v-if="spec[index]" class="spec-data">
          <h3>规格值：</h3>
          <!-- 规格值选择器 -->
          <div>
            <div
              v-for="(selecter, selecterKey) in selecterSpecVal[spec[index]]"
              :key="selecterKey"
              style="position: relative;margin-right: 10px;display: inline-block"
            >
              <Select
                @on-change="changedSpecVal(index, selecterKey)"
                v-model="specVal[index][selecterKey]"
                filterable
              >
                <Option
                  v-for="(opt, idx) in allSpecList[spec[index]].spec_val"
                  :disabled="opt.selected"
                  :key="idx"
                  :value="opt.id"
                >{{opt.spec_val}}</Option>
              </Select>
              <!--  删除规格值选择器 -->
              <div @click="delSpecValseleter(index, selecterKey)" class="del-optian">
                <Icon type="ios-close"/>
              </div>
            </div>
          </div>
          <!-- 添加规格 值 事件 -->
          <Button size="small" @click="addSpecValseleter(index)" shape="circle" class="addBtn">添加规格值</Button>
        </div>
        <!--  删除规格选择器 -->
        <div @click="delSpecseleter(index)" class="del-optian">
          <Icon type="ios-close"/>
        </div>
      </li>
      <!-- 添加规格  名 事件 -->
      <p class="add-spec" @click="addSpecseleter()">添加规格名</p>
    </ul>
    <!-- 实时表数据 -->
    <!-- <div class="spec-table" >
          
    </div>-->
    <!-- buttom -->
    <!-- <Button @click="specpost" type="dashed">确认</Button> -->
  </div>
</template>

<script>
import { listSpeButtom } from "@/api/shop/shopeditspec";
export default {
  data() {
    return {
      // 是否显示规格选择器
      hasSpec: false,
      // 所有的规格和规格值
      allSpecList: [],
      // 规格选择器的数量
      selecterSpec: [],
      // 规格值选择器的数量，必须要初始化 “0”为规格ID
      selecterSpecVal: { 0: [] },
      // 已选择的规格ID
      spec: [],
      // 已选择的规格值ID，必须要初始化 “0”为规格ID
      specVal: { 0: [] },
      // 当前规格值列表
      specValList: []
    };
  },
  methods: {
    /**
     * 获取当前店铺所有的规格和规格值
     */
    listSpec() {
      const data = {};
      listSpeButtom(data)
        .then(res => {
          this.allSpecList = res.data.data.list;
          console.log("this.allSpecList", res);
        })
        .catch(err => {
          console.error(err);
        });
    },
    /**
     * 添加规格选择器
     */
    addSpecseleter() {
      // 添加规格选择器
      if (this.selecterSpec.length === 3) {
        this.$Message.warning("最多只能添加3个规格");
      } else {
        this.selecterSpec.push("selecter");
        // 初始化存储规格值的变量
        if (this.selecterSpec.length > 1)
          this.specVal[this.selecterSpec.length - 1] = [];
      }
    },
    /**
     * 添加规格值选择器
     * @param index 规格选择器索引
     */
    addSpecValseleter(index) {
      if (this.selecterSpecVal[this.spec[index]] != undefined) {
        if (this.selecterSpecVal[this.spec[index]].length === 3) {
          this.$Message.warning("最多只能添加3个规格值");
        } else {
          this.selecterSpecVal[this.spec[index]].push("selecter");
        }
      } else {
        this.selecterSpecVal[this.spec[index]] = ["selecter"];
      }
      this.spec = JSON.parse(JSON.stringify(this.spec));
    },
    /**
     * 删除规格选择器
     */
    delSpecseleter(index) {
      // 要先删除其下的规格值
      this.specVal[index] = [];
      this.changedSpecVal(index);
      // 再删规格
      this.selecterSpec.splice(index, 1);
      this.spec.splice(index, 1);
      this.changedSpec();
      // 没有了就不显示规格选择器
      if (this.selecterSpec.length === 0) this.hasSpec = false;
    },
    /**
     * 删除规格值选择器
     */
    delSpecValseleter(index, inx) {
      this.selecterSpecVal[this.spec[index]].splice(inx, 1);
      // 需要刷新一下选择器
      this.selecterSpecVal = JSON.parse(JSON.stringify(this.selecterSpecVal));
      this.specVal[index].splice(index, 1);
      if (this.specVal[index].length == 0) this.specVal[index] = [];
      // 取消已选择状态
      this.changedSpecVal(index);
    },
    /**
     * 监听规格选择器值改变事件
     */
    changedSpec() {
      for (let key in this.allSpecList) {
        this.allSpecList[key].selected = this.spec.indexOf(parseInt(key)) != -1;
      }
    },
    /**
     * 监听规格值选择器值改变事件
     */
    changedSpecVal(index) {
      let specValList = this.allSpecList[this.spec[index]].spec_val;
      for (let key in specValList) {
        specValList[key].selected =
          this.specVal[index].indexOf(parseInt(key)) != -1;
      }
      // 规格值选择器值改变后，更新SKU表格
      console.log("this.specVal", this.specVal);
    }
  },
  mounted() {
    this.listSpec();
  }
};
</script>

<style scope>
@import url("./spec.less");
.addBtn{
  color: #fff;
  background: #2D8cf0;
}
</style>
