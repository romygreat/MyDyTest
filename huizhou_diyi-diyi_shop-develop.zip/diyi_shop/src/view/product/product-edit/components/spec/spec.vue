<template>
  <div>
    <!-- 添加 -->
    <div v-if="!hasSpec" @click="hasSpec = true;addSpecseleter();" class="startbuttom">添加规格项目</div>
    <ul v-if="hasSpec" class="spec-buttomdiv">
      <li v-for="(selecter, index) in selecterSpec" :key="index">
        <div class="spec-select">
          <h3>规格名：</h3>
          <!-- 规格选择器 -->
          <Select @on-change="changedSpec()" v-model="spec[index]" style="width:180px">
            <Option
              v-for="(item, indexs) in allSpecList"
              :disabled="item.selected"
              :key="indexs"
              :value="item.id"
            >{{item.name}}</Option>
          </Select>
        </div>
        <div v-if="spec[index]" class="spec-data">
          <h3>规格值：</h3>
          <!-- 规格值选择器 -->
          <div>
            <div
              v-for="(selecter, selecterKey) in  selecterSpecVal[spec[index]]"
              :key="selecterKey"
              style="position: relative;margin-right: 10px;display: inline-block;margin-bottom:10px;"
            >
              <Select
                @on-change="changedSpecVal(index, selecterKey)"
                v-model="specVal[index][selecterKey]"
                filterable
              >
                <!-- opt.selected -->
                <Option
                  v-for="(opt, idx) in allSpecList[spec[index]].spec_val"
                  :disabled="opt.selected"
                  :key="idx"
                  :value="opt.id"
                >{{opt.spec_val}}</Option>
              </Select>
              <!--  删除规格值选择器 -->
              <div @click="delSpecValseleter(index, selecterKey)" class="del-optian">
                <Icon type="ios-close" />
              </div>
            </div>
          </div>
          <!-- 添加规格 值 事件 -->
          <Button
            size="small"
            @click="addSpecValseleter(index)"
            shape="circle"
            class="addBtn"
          >{{specVal[index].length>0?'添加':'添加规格值'}}</Button>
        </div>
        <!--  删除规格选择器 -->
        <div @click="delSpecseleter(index)" class="del-optian">
          <Icon type="ios-close" />
        </div>
      </li>
      <!-- 添加规格  名 事件 -->
      <p class="add-spec" @click="addSpecseleter()">添加规格名</p>
      <div style="margin-top: 10px;">
        <p>规格组合值:</p>
        <Tables
          :tableHead="tableColumn"
          :tableBody="tableData"
          v-if="loadSurvey"
          @sendPrice="getPrice"
        ></Tables>
      </div>
    </ul>
    <Modal v-model="isDel" width="360">
      <p slot="header" style="color:#f60;text-align:center">
        <Icon type="ios-information-circle"></Icon>
        <span>提示</span>
      </p>
      <div style="text-align:center">
        <p>是否确认删除?</p>
      </div>
      <div slot="footer">
        <Button type="error" size="large" long @click="doDel">确认</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import { listSpeButtom } from '@/api/shop/shopeditspec'
import { searchList, convertPrice, cloneObj } from '@/libs/tools'
import Tables from '@/view/product/product-edit/components/table/table'
export default {
  components: {
    Tables
  },
  props: {
    group: {
      type: Array,
      default: function() {
        return []
      }
    }
  },
  data() {
    return {
      isDel: false,
      delIndex: 0,
      loadSurvey: true,
      // 是否显示规格选择器
      hasSpec: false,
      // 所有的规格和规格值
      allSpecList: [],
      // 规格选择器的数量
      selecterSpec: [],
      // 规格值选择器的数量，必须要初始化 “0”为规格ID
      selecterSpecVal: { 0: [] },
      // 已选择的规格ID
      spec: [],
      // 已选择的规格值ID，必须要初始化 “0”为规格选择器的下标
      specVal: { 0: [] },
      // 规格组合表头
      tableColumn: [],
      // 规格组合表数据
      tableData: [],
      // 规格组合表原始数据
      tableInfo: [],
      oldspec: []
    }
  },
  methods: {
    /**
     * 获取当前店铺所有的规格和规格值
     */
    listSpec() {
      const data = { key: '' }
      listSpeButtom(data)
        .then(res => {
          this.allSpecList = res.data.data.list
          this.initTable()
        })
        .catch(err => {
          console.error(err)
        })
    },
    /**
     * 添加规格选择器
     */
    addSpecseleter() {
      // 需要赋值的变量有
      // 已选的规格ID this.spec
      // 已选的规格值ID this.specVal
      // 已选的规格选择器 this.selecterSpec
      // 已选的规格值选择器 this.selecterSpecVal
      // 所有规格和规格值 this.allSpecList

      if (this.selecterSpec.length === 5) {
        this.$Message.warning('最多只能添加5个规格')
      } else {
        this.specLeght = this.selecterSpec.length
        this.selecterSpec.push('selecter')
        // 初始化存储规格值的变量
        this.specVal[this.selecterSpec.length - 1] = []
      }
    },
    /**
     * 添加规格值选择器
     * @param index 规格选择器索引
     */
    addSpecValseleter(index) {
      if (
        this.selecterSpecVal[this.spec[index]] != undefined &&
        Object.keys(this.allSpecList[this.spec[index]].spec_val).length ==
          this.selecterSpecVal[this.spec[index]].length
      ) {
        this.$Message.warning('该属性没有更多值可选')
        return
      }
      if (this.selecterSpecVal[this.spec[index]] != undefined) {
        if (this.selecterSpecVal[this.spec[index]].length === 5) {
          this.$Message.warning('最多只能添加5个规格值')
        } else {
          this.selecterSpecVal[this.spec[index]].push('selecter')
        }
      } else {
        this.selecterSpecVal[this.spec[index]] = ['selecter']
      }
      this.spec = JSON.parse(JSON.stringify(this.spec))
    },
    /**
     * 删除规格选择器
     */
    delSpecseleter(index) {
      // 要先删除其下的规格值
      if (
        this.selecterSpecVal[this.spec[index]] &&
        this.selecterSpecVal[this.spec[index]].length > 0
      ) {
        if (this.isDel == false) {
          this.delIndex = index
          this.isDel = true
          return
        } else {
          this.changedSpecVal(index)
        }
      }

      if (this.selecterSpecVal[this.spec[index]]) {
        this.selecterSpecVal[this.spec[index]].splice(0)
        this.selecterSpecVal = JSON.parse(JSON.stringify(this.selecterSpecVal))
        this.specVal[index].splice(0)
      }

      // 取消已选择状态
      this.changedSpecVal(index)
      this.spec.splice(index, 1)
      this.selecterSpec.splice(index, 1)
      // 再删规格
      let specValMap = Object.keys(this.specVal).map(key => this.specVal[key])
      for (const key in specValMap) {
        if (specValMap[key].length == 0) {
          specValMap.splice(key, 1)
        }
      }
      this.specVal = specValMap
      for (const key in this.allSpecList) {
        // 改变选中状态
        if (this.spec.indexOf(this.allSpecList[key].id) == -1) {
          this.allSpecList[key].selected = false
        } else {
          this.allSpecList[key].selected = true
        }
      }

      // 没有了就不显示规格选择器
      if (this.selecterSpec.length === 0) {
        this.spec = []
        this.specVal = { 0: [] }
        this.selecterSpec = []
        this.selecterSpecVal = { 0: [] }
        this.hasSpec = false
      }
    },
    doDel() {
      this.delSpecseleter(this.delIndex)
      this.isDel = false
    },

    /**
     * 删除规格值选择器
     */
    delSpecValseleter(index, inx) {
      this.selecterSpecVal[this.spec[index]].splice(inx, 1)
      this.selecterSpecVal = JSON.parse(JSON.stringify(this.selecterSpecVal))
      this.specVal[index].splice(inx, 1)
      // 取消已选择状态
      this.changedSpecVal(index)
    },
    /**
     * 监听规格选择器值改变事件
     */
    changedSpec() {
      /**
       * 获取到之前的规格值，直接执行删除，再添加现在获取到的这个
       */
      let index = ''
      let oldId = ''
      if (
        this.oldspec.length == this.spec.length &&
        this.oldspec != this.spec
      ) {
        for (let i = 0; i < this.oldspec.length; i++) {
          if (this.oldspec[i] != this.spec[i]) {
            index = i
            oldId = this.oldspec[i]
          }
        }

        // 取消已选择状态
        if (this.allSpecList[oldId]) {
          let specValList = this.allSpecList[oldId].spec_val
          for (const key in specValList) {
            if (this.specVal[index].indexOf(specValList[key].id) > -1) {
              specValList[key].selected = true
            } else {
              specValList[key].selected = false
            }
          }
        }
        //删掉之前的规格
        this.selecterSpecVal[oldId].splice(0)
        this.selecterSpecVal = JSON.parse(JSON.stringify(this.selecterSpecVal))
        this.specVal[index].splice(0)
      }

      this.changedSpecVal(index)
      this.createTableInfo()
    },
    /**
     * 监听规格值选择器值改变事件
     */
    changedSpecVal(index) {
      if (this.allSpecList[this.spec[index]]) {
        let specValList = this.allSpecList[this.spec[index]].spec_val
        for (const key in specValList) {
          if (this.specVal[index].indexOf(specValList[key].id) > -1) {
            specValList[key].selected = true
          } else {
            specValList[key].selected = false
          }
        }
      }
      // 规格值选择器值改变后，更新SKU表格
      this.createTableInfo()
    },
    /**
     * 初始化规格组合表格
     */
    initTable() {
      // 如果商品本身已经有规格组合了
      if (this.group.length > 0) {
        // 需要赋值的变量有
        // 已选的规格ID this.spec
        // 已选的规格值ID this.specVal
        // 已选的规格选择器 this.selecterSpec
        // 已选的规格值选择器 this.selecterSpecVal
        // 所有规格和规格值 this.allSpecList
        for (let group of this.group) {
          let specValArr = group.spec_val_ids.split(',')
          for (let key in this.allSpecList) {
            let spec = this.allSpecList[key]
            for (let k in spec.spec_val) {
              let specV = spec.spec_val[k]
              if (specValArr.indexOf(specV.id.toString()) > -1) {
                spec.selected = true
                specV.selected = true
                // 如果不存在push
                if (this.spec.indexOf(spec.id) == -1) {
                  this.spec.push(spec.id)
                  this.selecterSpec.push('selecter')
                }
                if (this.specVal[this.spec.indexOf(spec.id)] == undefined) {
                  this.specVal[this.spec.indexOf(spec.id)] = []
                }
                // 如果不存在push
                if (
                  this.specVal[this.spec.indexOf(spec.id)].indexOf(specV.id) ==
                  -1
                ) {
                  this.specVal[this.spec.indexOf(spec.id)].push(specV.id)
                  if (this.selecterSpecVal[spec.id] == undefined) {
                    this.selecterSpecVal[spec.id] = []
                  }
                  this.selecterSpecVal[spec.id].push('selecter')
                }
                this.hasSpec = true
              }
            }
          }
        }
        this.createTableInfo()
      }
    },
    /**
     * 创建规格组合表的表头
     */
    createTableColumn() {
      let tempArr = []
      this.tableInfo.forEach(obj => {
        let o = {}
        o['key'] = obj.id
        o['title'] = obj.name
        tempArr.push(o)
      })
      let colArr = [
        {
          key: 'price',
          title: '价格'
        }
      ]
      // 为了让表头和表数据相对应
      for (let index1 = 0; index1 < tempArr.length - 1; index1++) {
        for (let index2 = 1; index2 < tempArr.length; index2++) {
          if (Number(tempArr[index1].key) > Number(tempArr[index2].key)) {
            let tempArrDetail = tempArr[index1]
            tempArr[index1] = tempArr[index2]
            tempArr[index2] = tempArrDetail
          }
        }
      }
      this.tableColumn = tempArr.concat(colArr)
    },

    /**
     * 创建规格组合表原始数据
     */
    createTableInfo() {
      this.tableInfo = []
      for (let key in this.specVal) {
        if (this.specVal[key] && this.specVal[key].length > 0) {
          let specObj = {}
          let ownObj = this.allSpecList[this.spec[key]]
          specObj.id = ownObj.id
          specObj.name = ownObj.name
          specObj.val = []
          specObj.id = ownObj.id
          specObj.name = ownObj.name
          this.specVal[key].forEach(k => {
            if (ownObj.spec_val[k]) {
              let o = {}
              if (ownObj.spec_val[k]) {
                o.id = ownObj.spec_val[k].id
                o.name = ownObj.spec_val[k].spec_val
                specObj.val.push(o)
              }
            } else {
              specObj.val = []
            }
          })
          this.tableInfo.push(specObj)
          // 重新排序，避免表格错位
          for (let index1 = 0; index1 < this.tableInfo.length - 1; index1++) {
            for (let index2 = 1; index2 < this.tableInfo.length; index2++) {
              if (
                Number(this.tableInfo[index1].id) >
                Number(this.tableInfo[index2].id)
              ) {
                let tempArrDetail = this.tableInfo[index1]
                this.tableInfo[index1] = this.tableInfo[index2]
                this.tableInfo[index2] = tempArrDetail
              }
            }
          }
        }
      }
      this.createTableColumn()
      this.createTableData()
    },
    /**
     * 创建规格组合表的数据
     */
    createTableData() {
      // 初始化表格数据
      let dataList = [{ price: 0 }]
      for (let i = 0; i < this.tableInfo.length; i++) {
        dataList = this.addColumn(dataList, this.tableInfo[i])
      }

      if (this.group.length > 0) {
        for (let key in dataList) {
          if (this.group[key]) {
            dataList[key].price = Number(
              convertPrice(this.group[key].group_price)
            )
          }
        }
      }
      // 防止删除得时候存在数据要确实传递空数组给接口
      if (this.tableInfo.length == 0) this.tableData = []
      else this.tableData = dataList
    },

    /**
     * 计算规格组合表数据
     */
    addColumn(dataList, attr) {
      let newList = []
      for (let i = 0; i < dataList.length; i++) {
        let oldRow = dataList[i]
        for (let j = 0; j < attr.val.length; j++) {
          let newRow = JSON.parse(JSON.stringify(oldRow))
          newRow[attr.id] = attr.val[j].name
          newList.push(newRow)
        }
      }
      return newList
    },

    /**
     * 获取组合信息，用于保存入库
     */
    getSpecGroup() {
      let group = []
      for (let row of this.tableData) {
        let object = {}
        let keys = Object.keys(row)
        let specVal = []
        let specValIds = []
        keys.forEach(key => {
          let obj = searchList(this.tableInfo, 'id', key)
          if (obj != null) {
            let o = searchList(obj.val, 'name', row[key])
            if (o != null) {
              specValIds.push(o.id)
              specVal.push(o.name)
            }
          }
        })
        object.spec_val_ids = specValIds.join(',')
        object.group_title = specVal.join('-')
        object.group_price = convertPrice(row.price, 'fen') //价格保留双精度
        group.push(object)
      }
      if (this.tableInfo.length != 0) {
        return group
      }
    },
    getPrice(data) {
      this.tableData[data.index].price = data.price
    }
  },
  mounted() {
    this.listSpec()
  },
  watch: {
    tableData() {
      this.loadSurvey = false
      this.$nextTick(() => {
        this.loadSurvey = true
      })
    },
    spec: {
      handler(n, o) {
        this.oldspec = o
      }
    }
  }
}
</script>

<style scope>
@import url('./spec.less');
.addBtn {
  background: #2d8cf0;
  color: #fff;
}
.startbuttom,
.add-spec {
  background: #2d8cf0;
  color: #fff;
  font-weight: 600;
}
.startbuttom {
  background: #2d8cf0;
}
.startbuttom:hover,
.add-spec:hover {
  border: 1px solid #57a3f3;
  cursor: pointer;
  color: #57a3f3;
  background: #fff;
}
.addBtn {
  background: #2d8cf0;
  color: #fff;
}
.startbuttom,
.add-spec {
  background: #2d8cf0;
  color: #fff;
  font-weight: 600;
}
.startbuttom:hover,
.add-spec:hover {
  border: 1px solid #57a3f3;
  cursor: pointer;
  color: #57a3f3;
  background: #fff;
}
.addBtn {
  background: #2d8cf0;
  color: #fff;
}
.startbuttom,
.add-spec {
  background: #2d8cf0;
  color: #fff;
  font-weight: 600;
}
.startbuttom:hover,
.add-spec:hover {
  border: 1px solid #57a3f3;
  cursor: pointer;
  color: #57a3f3;
  background: #fff;
}
</style>
