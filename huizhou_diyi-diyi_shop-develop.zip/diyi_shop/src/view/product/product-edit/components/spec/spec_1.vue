<template>
  <div>
    <!-- 添加 -->
    <div v-if="!hasSpec" @click="hasSpec = true;addSpecseleter();" class="startbuttom">添加规格项目</div>
    <ul v-if="hasSpec" class="spec-buttomdiv">
      <li v-for="(selecter, index) in selecterSpec" :key="index">
        <div class="spec-select">
          <h3>规格名：</h3>
          <!-- 规格选择器 -->
          <Select @on-change="changedSpec()" v-model="spec[index]" style="width:180px">
            <Option
              v-for="(item, indexs) in allSpecList"
              :disabled="item.selected"
              :key="indexs"
              :value="item.id"
            >{{item.name}}</Option>
          </Select>
        </div>
        <!-- spec[index] selecterSpecVal[spec[index]]-->
        <div v-if="spec[index]" class="spec-data">
          <h3>规格值：</h3>
          <!-- 规格值选择器 -->
          <div>
            <div
              v-for="(selecter, selecterKey) in  selecterSpecVal[spec[index]]"
              :key="selecterKey"
              style="position: relative;margin-right: 10px;display: inline-block;margin-bottom:10px;"
            >
              <Select
                @on-change="changedSpecVal(index, selecterKey)"
                v-model="specVal[index][selecterKey]"
                filterable
              >
                <Option
                  v-for="(opt, idx) in allSpecList[spec[index]].spec_val"
                  :disabled="opt.selected"
                  :key="idx"
                  :value="opt.id"
                >{{opt.spec_val}}</Option>
              </Select>
              <!--  删除规格值选择器 -->
              <div @click="delSpecValseleter(index, selecterKey)" class="del-optian">
                <Icon type="ios-close" />
              </div>
            </div>
          </div>
          <!-- 添加规格 值 事件 -->
          <Button size="small" v-if="specVal[0].length>=1" @click="addSpecValseleter(index)" shape="circle" class="addBtn">添  加</Button>
          <Button size="small" v-else @click="addSpecValseleter(index)" shape="circle" class="addBtn">添加规格值</Button>

        </div>
        <!--  删除规格选择器 -->
        <div @click="delSpecseleter(index)" class="del-optian">
          <Icon type="ios-close" />
        </div>
      </li>
      <!-- 添加规格  名 事件 -->
      <p class="add-spec" @click="addSpecseleter()">添加规格名</p>
      <div style="margin-top: 10px;">
        <p>规格组合值:</p>
        <!-- columns:表头、data:表的数据 -->
        <Table :columns="tableColumn" :data="tableData"></Table>
      </div>
    </ul>
    <!-- 实时表数据 -->
    <!-- <div class="spec-table">
    </div>-->
    <!-- buttom -->
    <!-- <Button @click="specpost" type="dashed">确认</Button> -->
  </div>
</template>

<script>
import { listSpeButtom } from '@/api/shop/shopeditspec'
import { searchList } from '@/libs/tools'
export default {
  props: {
    spec_group: {
      // type: Array,
      type:Object,
      default: function() {
        return []
      }
    }
  },
  data() {
    return {
      // 是否显示规格选择器
      hasSpec: false,
      // 所有的规格和规格值
      allSpecList: [],
      // 规格选择器的数量
      selecterSpec: [],
      // 规格值选择器的数量，必须要初始化 “0”为规格ID
      selecterSpecVal: { 0: [] },
      // 已选择的规格ID
      spec: [],
      // 已选择的规格值ID，必须要初始化 “0”为规格选择器的下标
      specVal: { 0: [] },
      // 当前规格值列表
      // specValList: [],
      // 规格组合表头
      tableColumn: [],
      // 规格组合表数据
      tableData: [],
      // 规格组合表原始数据
      tableInfo: []
    }
  },
  methods: {
    /**
     * 获取当前店铺所有的规格和规格值
     */
    listSpec() {
      const data = { key: '' }
      listSpeButtom(data)
        .then(res => {
          this.allSpecList = res.data.data.list
          this.initTable()
          console.log('listSpeButtom().res: ', res)
        })
        .catch(err => {
          console.error(err)
        })
    },
    /**
     * 添加规格选择器
     */
    addSpecseleter() {
      // 添加规格选择器
      if (this.selecterSpec.length === 5) {
        this.$Message.warning('最多只能添加5个规格')
      } else {
        this.selecterSpec.push('selecter')
        // 初始化存储规格值的变量
        if (this.selecterSpec.length > 1) {
          this.specVal[this.selecterSpec.length - 1] = []
        }
      }
    },
    /**
     * 添加规格值选择器
     * @param index 规格选择器索引
     */
    addSpecValseleter(index) {
      if (this.selecterSpecVal[this.spec[index]] != undefined) {
        if (this.selecterSpecVal[this.spec[index]].length === 5) {
          this.$Message.warning('最多只能添加5个规格值')
        } else {
          this.selecterSpecVal[this.spec[index]].push('selecter')
        }
      } else {
        this.selecterSpecVal[this.spec[index]] = ['selecter']
      }
      this.spec = JSON.parse(JSON.stringify(this.spec))
      console.log(typeof this.spec);
      
    },
    /**
     * 删除规格选择器
     */
    delSpecseleter(index) {
      // 要先删除其下的规格值
      this.specVal[index] = []
      this.changedSpecVal(index)
      // 再删规格
      this.selecterSpec.splice(index, 1)
      this.spec.splice(index, 1)
      this.changedSpec()
      // 没有了就不显示规格选择器
      if (this.selecterSpec.length === 0) this.hasSpec = false
    },
    /**
     * 删除规格值选择器
     */
    delSpecValseleter(index, inx) {
      this.selecterSpecVal[this.spec[index]].splice(inx, 1)
      // 需要刷新一下选择器
      this.selecterSpecVal = JSON.parse(JSON.stringify(this.selecterSpecVal))
      this.specVal[index].splice(index, 1)
      if (this.specVal[index].length == 0) this.specVal[index] = []
      // 取消已选择状态
      this.changedSpecVal(index)
    },
    /**
     * 监听规格选择器值改变事件
     */
    changedSpec() {
      for (let key in this.allSpecList) {
        this.allSpecList[key].selected = this.spec.indexOf(parseInt(key)) != -1
      }
    },
    /**
     * 监听规格值选择器值改变事件
     */
    changedSpecVal(index) {
      let specValList = this.allSpecList[this.spec[index]].spec_val
      for (let key in specValList) {
        specValList[key].selected =
          this.specVal[index].indexOf(parseInt(key)) != -1
      }
      // 规格值选择器值改变后，更新SKU表格
      this.createTableInfo()
    },
    /**
     * 初始化规格组合表格
     */
    initTable() {
      // 如果商品本身已经有规格组合了
      if (this.spec_group.length > 0) {
        // 需要赋值的变量有
        // 已选的规格ID this.spec
        // 已选的规格值ID this.specVal
        // 已选的规格选择器 this.selecterSpec
        // 已选的规格值选择器 this.selecterSpecVal
        // 所有规格和规格值 this.allSpecList
        for (let group of this.spec_group) {
          let specValArr = group.spec_val_ids.split(',')
          for (let key in this.allSpecList) {
            let spec = this.allSpecList[key]
            for (let k in spec.spec_val) {
              let specV = spec.spec_val[k]
              if (specValArr.indexOf(specV.id.toString()) > -1) {
                spec.selected = true
                specV.selected = true
                // 如果不存在push
                if (this.spec.indexOf(spec.id) == -1) {
                  this.spec.push(spec.id)
                  this.selecterSpec.push('selecter')
                }
                if (this.specVal[this.spec.indexOf(spec.id)] == undefined) {
                  this.specVal[this.spec.indexOf(spec.id)] = []
                }
                // 如果不存在push
                if (
                  this.specVal[this.spec.indexOf(spec.id)].indexOf(specV.id) ==
                  -1
                ) {
                  this.specVal[this.spec.indexOf(spec.id)].push(specV.id)
                  if (this.selecterSpecVal[spec.id] == undefined) {
                    this.selecterSpecVal[spec.id] = []
                  }
                  this.selecterSpecVal[spec.id].push('selecter')
                }
                this.hasSpec = true
              }
            }
          }
        }
        this.createTableInfo()
      }
    },
    /**
     * 创建规格组合表的表头
     */
    createTableColumn() {
      let tempArr = []
      this.tableInfo.forEach(obj => {
        let o = {}
        o['key'] = obj.id
        o['title'] = obj.name
        tempArr.push(o)
      })

      let colArr = [
        {
          key: 'price',
          title: '价格',
          render: (h, params) => {
            return h('div', [
              h('Input', {
                attrs: {
                  size: 'small',
                  type: 'number',
                  min: 0,
                  max: 999999,
                  value: params.row.price.toFixed(2)
                },
                on: {
                  // 手动完成v-model事件
                  'on-blur': e => {
                    // 不能直接赋值，input会失去焦点
                    // this.tableData[params.index].price = parseInt(e.target.value);
                    // 要先赋值给行数据,保留两位小数
                    params.row.price = parseInt(parseFloat(e.target.value))
                    this.tableData[params.index] = params.row
                  }
                }
              })
            ])
          }
        }
      ]
      this.tableColumn = tempArr.concat(colArr)
      
    },

    /**
     * 创建规格组合表原始数据
     */
    createTableInfo() {
      this.tableInfo = []
      for (let key in this.specVal) {
        if (this.specVal[key].length > 0) {
          let specObj = {}
          let ownObj = this.allSpecList[this.spec[key]]
          specObj.id = ownObj.id
          specObj.name = ownObj.name
          specObj.val = []
          this.specVal[key].forEach(k => {
            let o = {}
            o.id = ownObj.spec_val[k].id
            o.name = ownObj.spec_val[k].spec_val
            specObj.val.push(o)
          })
          this.tableInfo.push(specObj)
        }
      }
      this.createTableColumn()
      this.createTableData()
    },
    /**
     * 创建规格组合表的数据
     */
    createTableData() {
      // 初始化表格数据
      let dataList = [{ price: 0 }]
      for (let i = 0; i < this.tableInfo.length; i++) {
        dataList = this.addColumn(dataList, this.tableInfo[i])
        // console.log('初始化表的值',this.tableInfo[i],dataList);
      }
      if (this.spec_group.length > 0) {
        for (let key in dataList) {
          if (this.spec_group[key]) {
            dataList[key].price = this.spec_group[key].group_price
          }
        }
      }
      this.tableData = dataList 
    },

    /**
     * 计算规格组合表数据
     */
    addColumn(dataList, attr) {
      let newList = []
      for (let i = 0; i < dataList.length; i++) {
        let oldRow = dataList[i]
        for (let j = 0; j < attr.val.length; j++) {
          let newRow = JSON.parse(JSON.stringify(oldRow))
          newRow[attr.id] = attr.val[j].name
          newList.push(newRow)
        }
      }
      return newList
    },
    /**
     * 获取组合信息，用于保存入库
     */
    getSpecGroup() {
      let specGroup = []
      for (let row of this.tableData) {
        let object = {}
        let keys = Object.keys(row)
        let specVal = []
        let specValIds = []
        keys.forEach(key => {
          let obj = searchList(this.tableInfo, 'id', key)
          if (obj != null) {
            let o = searchList(obj.val, 'name', row[key])
            if (o != null) {
              specValIds.push(o.id)
              specVal.push(o.name)
            }
          }
        })
        object.spec_val_ids = specValIds.join(',')
        object.group_title = specVal.join('-')
        object.group_price = parseInt(row.price)
        specGroup.push(object)
      }
      return specGroup
    }
  },
  mounted() {
    this.listSpec()
    console.log('获取到的规格值++++',this.spec_group);
    
  }
}
</script>

<style scope>
@import url('./spec.less');
.addBtn{
  background: #2D8cf0;
  color: #fff;
}
.startbuttom,.add-spec{
  background: #2D8cf0;
  color: #fff;
  font-weight: 600;
}
.startbuttom{
  background: #2D8cf0;
}

</style>
