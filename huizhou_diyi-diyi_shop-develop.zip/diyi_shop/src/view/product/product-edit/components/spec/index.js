import Spec from './spec.vue'
export default Spec
