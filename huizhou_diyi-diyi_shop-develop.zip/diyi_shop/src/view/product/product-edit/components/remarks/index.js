import Remarks from './remarks.vue'
export default Remarks
