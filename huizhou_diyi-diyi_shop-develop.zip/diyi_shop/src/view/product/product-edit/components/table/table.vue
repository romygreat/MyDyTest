<template>
  <div>
    <table class="table table-bordered" border="1">
      <thead>
        <tr height=50>
          <th v-for="(headth, headindex) in tableHead" :key="headindex">{{headth.title}}</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item,index) in tableBody" :key="item.id">
          <td
            v-for="(value, ind) in Object.values(item)"
            :key="ind"
            :rowspan="Object.values(item)[HeadSize+ind*2]"
            :class="{hidden: Object.values(item)[HeadSize+ind*2+1]}"
            v-if="ind<HeadSize-1"
          >{{value}}</td>
          <td width="150">
            <input type="number" 
            :maxlength='40'
            v-model="item.price"
             @change="getPrice(item.price,index)"
             @mousewheel="stopMouse" />
          </td>
        </tr>
      </tbody>
    </table>

<Modal
      v-model="FalsePrice"
      title="输入错误"
      align="center"
      width="350"
      class-name="vertical"
      :footer-hide="true"
    >
      <div class="succimgbox">
        <div>
          <h3 class="vertical-item">商品价格不能低于0元！</h3>
        </div>
      </div>
    </Modal>

  </div>
</template>
<script>
export default {
  props: {
    tableHead: "",
    tableBody: ""
  },
  data() {
    return {
      HeadSize: 0,
      isShow: false,
      isFinish: false,
      FalsePrice:false
    };
  },
  created() {
    this.HeadSize = this.tableHead.length;
    this.getData(this.tableBody);
  },
  methods: {
    onEdit() {
      this.isShow = true;
      this.isFinish = true;
    },
    onComplete() {
      this.isShow = false;
      this.isFinish = false;
    },
    getData(list) {
      for (let z = 0; z < list.length; z++) {
        this.tableBody[z].price = parseFloat(this.tableBody[z].price);
        this.tableBody[z].price = this.tableBody[z].price.toFixed(2);
      }
      for (let field in list[0]) {
        let k = 0;
        let i = 0;
        while (k < list.length) {
          list[k][field + "span"] = 1;
          list[k][field + "dis"] = false;
          for (i = k + 1; i <= list.length - 1; i++) {
            if (list[k][field] === list[i][field] && list[k][field] !== "") {
              list[k][field + "span"]++;
              list[k][field + "dis"] = false;
              list[i][field + "span"] = 1;
              list[i][field + "dis"] = true;
            } else {
              break;
            }
          }
          k = i;
        }
      }
      return list;
    },
    getPrice(price, index) {
      let data = {};
      price = parseFloat(price);
      price = price.toFixed(2);
      if (price < 0) {
        this.FalsePrice = true;
        setTimeout(() => {
          this.getPrice(0.00, index)
          this.FalsePrice = false
        }, 1500);
      }
      
      data.price = price;
      data.index = index;
      this.$emit("sendPrice", data);
      
    },
    stopMouse(evt){
      // 移除点鼠标的滚动输入      
      evt = evt || window.event;  
    if(evt.preventDefault) {  
      // Firefox  
      evt.preventDefault();  
      evt.stopPropagation();  
    } else {  
      // IE  
      evt.cancelBubble=true;  
      evt.returnValue = false;  
  }  
  return false;
    }
  }
};
</script>

<style lang="less" scoped>
@import url("./table.less");
.hidden {
  display: none;
}
</style>