<template>
  <div>
    <table width="100%" border="1">
      <thead>
        <tr id="table-header">
          <td v-for="(value,index) in tableHead">{{value.title}}</td>
        </tr>
      </thead>
      <tbody id="table">
        <tr v-for="(trValue,trIndex) in tableBody">
          <td
            width="100"
            v-for="(thValue,thIndex) in Object.values(trValue)"
            v-if="thIndex!=rowlength[thIndex]-1"
          >{{thValue}}</td>
          <td width=100 v-else>
            <input
                type="number"
                v-model="trValue.price"
                @change="getPrice(trValue.price,trIndex)"
                @keyup="KeyUpPrice(trValue.price,trIndex)"
                @mousewheel="WouseWheelPrice(trValue.price,trIndex)"
              />
          </td>
        </tr>
      </tbody>
    </table>

    <Modal
      v-model="FalsePrice"
      title="输入错误"
      align="center"
      width="350"
      class-name="vertical"
      :footer-hide="true"
    >
      <div class="succimgbox">
        <div>
          <h3 class="vertical-item">商品价格不能低于0元！</h3>
        </div>
      </div>
    </Modal>
  </div>
</template>
<script>
export default {
  props: {
    tableHead: "",
    tableBody: ""
  },
  data() {
    return {
      rowlength: [],
      FalsePrice: false
    };
  },
  methods: {
    WouseWheelPrice(Price, index) {
      if (Price < 0) {
        this.FalsePrice = true;
        this.getPrice(1.0, index);
        setTimeout(() => {
          this.FalsePrice = false;
        }, 1500);
      }
    },
    KeyUpPrice(Price, index) {
      if (Price < 0) {
        this.FalsePrice = true;
        this.getPrice(0.0, index);
        setTimeout(() => {
          this.FalsePrice = false;
        }, 1500);
      }
    },
    dealTable() {
      let el = document.getElementById("table").rows;
      let row1 = 1,
        row2 = 1,
        row3 = 1,
        row4 = 1,
        row0 = 1;
      let index = 0;
      let rowindex = 0;
      for (let i = 0; i < this.tableBody.length; i++) {
        let list = Object.values(this.tableBody[i]);
        this.tableBody[i].price = parseFloat(this.tableBody[i].price);
        this.tableBody[i].price = this.tableBody[i].price.toFixed(2);
        this.rowlength.push(list.length);
      }
      for (let j = 0; j < el.length; j++) {
        if (j - 1 >= 0 && index < el[j].cells.length - 2) {
          if (
            el[j].cells[index].innerHTML == el[j - 1].cells[index].innerHTML
          ) {
            switch (index) {
              case 0:
                row0 += 1;
                rowindex = row0;
                break;
              case 1:
                row1 += 1;
                rowindex = row1;
                break;
              case 2:
                row2 += 1;
                rowindex = row2;
                break;
              case 3:
                row3 += 1;
                rowindex = row3;
                break;
              case 4:
                row4 += 1;
                rowindex = row4;
                break;

              default:
                break;
            }
          } else {
            this.showTable(index, rowindex, 2);
            index += 1;
          }
        }
      }
    },
    showTable(index, rowspanValue, noDetal) {
      let el = document.getElementById("table").rows;
      for (let j = 0; j < el.length; j++) {
        if (j - 1 >= 0 && el[j].cells.length > index + noDetal) {
          if (
            el[j].cells[index].innerHTML == el[j - 1].cells[index].innerHTML
          ) {
            el[j - 1].cells[index].setAttribute("rowspan", rowspanValue);
            el[j].cells[index].style.display = "none";
          }
        }
      }
    },
    // 修改输入的价格
    getPrice(price, index) {
      let data = {};
      price = parseFloat(price);
      price = price.toFixed(2);
      if (price < 0) {
        this.FalsePrice = true;
        setTimeout(() => {
          price = 0.0;
        }, 1500);
      }
      data.price = price;
      data.index = index;
      this.$emit("sendPrice", data);
    },
  },
  mounted() {
    this.dealTable();
  },
  watch: {}
};
</script>
<style lang="less" scoped>
@import url("./Oldtable.less");
</style>


