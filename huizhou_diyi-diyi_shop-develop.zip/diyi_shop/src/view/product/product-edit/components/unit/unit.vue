<template>
  <div style="width:200px">
    <div style="width:200px" id="select-unit">
      <Select
            @on-query-change="remotenull"
            @on-change="sdkinfo"
            @on-open-change='getProductUnitList'
            v-model="selectinfo"
            filterable
            remote
            :remote-method="remoteMethod2"
            :loading="loading2"
            placeholder="请选择计量单位"
      >
        <Option
          v-for="(option, index) in options2"
          :value="option.label"
          :key="index"
        >{{option.label}}</Option>
      </Select>
    </div>
  </div>
</template>

<script>
import { productUnitList } from '@/api/shop/shopProductUnit'
export default {
  props: ['unitName'],
  data() {
    return {
      selectinfo: [],
      loading2: false,
      options2: [],
      list: [],
      resselect: [],
      isoff:false
    }
  },
  methods: {
    getProductUnitList() {
      const data = {
        page: 1,
        rows: 50
      }
      console.log('触发覆盖')
      productUnitList(data).then(res => {
        this.list = JSON.parse(JSON.stringify(res.data.data.list))
        const listinfo = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        this.resselect = JSON.parse(JSON.stringify(listinfo))
        this.options2 = listinfo
      })
    },
    remoteMethod2(query) {
      if (query !== '') {
        this.loading2 = true
        setTimeout(() => {
          let arrlist = []
          this.loading2 = false
          const data = { name: query }
          productUnitList(data).then(res => {
            arrlist = JSON.parse(JSON.stringify(res.data.data.list))
            const listinfo = arrlist.map(item => {
              return {
                value: item.id,
                label: item.name
              }
            })
            this.options2 = listinfo.filter(
              item => item.label.toLowerCase().indexOf(query.toLowerCase()) > -1
            )
            console.log(this.options2,'Liebiao',listinfo)
            if(this.isoff){
              this.infosss()
              this.isoff = false
            }
            this.tovalue()
          })
        }, 200)
      } else {
        this.options2 = []
        console.log(this.selectinfo,1)
        this.tovalue()
      }
    },
    sdkinfo(i) {
      const listinfo = this.list.map(item => {
        return {
          value: item.id,
          label: item.name
        }
      })
      this.options2 = listinfo
      this.tovalue()
    },
    remotenull(v) {
      if (v === '') {
        const listinfo = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        this.options2 = listinfo
        this.tovalue()
      }
    },
    tovalue() {
      this.$emit('unitList', this.selectinfo)
    },
    infosss(){
      this.options2 = this.resselect 
      console.log('最后触发',this.options2,this.resselect )
    }
  },
  mounted() {
    this.getProductUnitList()
  },
  created() {  
    console.log(this.unitName,444)
    if (this.unitName != '' && this.unitName != undefined) {
      this.selectinfo = JSON.parse(JSON.stringify(this.unitName))
      this.isoff = true
    }
  }
}
</script>

<style>
#select-unit .ivu-select-selection{
  width: 180px !important;
}
</style>
