<template>
  <div>
    <!-- 添加 -->
    <div v-show="nolist" @click="nolist = false;lists.length = 1" class="startbuttom">添加</div>
    <ul v-show="!nolist" class="spec-buttomdiv">
      <li @mouseenter="mousindex(index)" v-for="(list, index) in lists" :key="index">
        <div class="spec-select">
          <h3>规格名：</h3>
          <Select @on-change="specdata" style="width:180px">
            <Option
              :disabled="yanlistArr.indexOf(item.id) !== - 1 ? true : false"
              v-for="(item, indexs) in oplist"
              :key="indexs"
              :value="item.id"
            >{{item.name}}</Option>
          </Select>
        </div>
        <div v-if="lists[index].spec_val.length" class="spec-data">
          <h3>规格值：</h3>
          <div>
            <figure
              @mouseenter="mousindexoptian(figindex)"
              v-for="(item, figindex) in lists[index].figlist"
              :key="figindex"
              style="position: relative;margin-right: 10px;display: inline-block"
            >
              <Select
                ref="stoplists"
                :clearable="isClearSelect"
                @on-change="stoplist"
                filterable
                remote
                :remote-method="remoteMethod"
              >
                <Option
                  :disabled="yanArr.indexOf(option.id) !== -1 ? true : false"
                  v-for="(option, indexsj) in  lists[index].spec_val"
                  :value="option.id"
                  :key="indexsj"
                >{{option.spec_val}}</Option>
              </Select>
              <div @click="deloptian(disSelect[mouse],figindex)" class="del-optian">
                <Icon type="ios-close"/>
              </div>
            </figure>
          </div>
          <!-- 添加规格 值 事件 -->
          <p class="add-spec_val" @click="addfiglist">添加规格值</p>
        </div>
        <!--  整体删除buttom -->
        <div class="del-optian">
          <Icon type="ios-close"/>
        </div>
      </li>
      <!-- 添加规格  名 事件 -->
      <p class="add-spec" @click="addspec">添加规格名</p>
    </ul>
    <!-- 实时表数据 -->
    <div class="spec-table">
      <!-- header -->
      <ul class="spec-t-heaber">
        <li
          v-for="(item,qindex) in headerName"
          :key="qindex"
          class="spec-t-heaber-spec"
        >{{item.name}}</li>
        <li>价格（元）</li>
        <li>库存</li>
        <li>规格编码</li>
        <li>成本价</li>
        <li>销售</li>
      </ul>
      <!-- body -->
      <table class="spec-t-tables">
        <tbody>
          <tr class="spec-t-tables-tr" v-for="(item,index) in specTablesList" :key="index">
            <td :rowspan="rowspan.one" class="spec-t-heaber-spec-tr">{{item.nameOne}}</td>
            <td
              :rowspan="rowspan.two"
              class="spec-t-heaber-spec-tr"
              v-if="item.nameTwo"
            >{{item.nameTwo}}</td>
            <td
              :rowspan="rowspan.there"
              class="spec-t-heaber-spec-tr"
              v-if="item.nameThere"
            >{{item.nameThere}}</td>
            <td>
              <Input
                :maxlength='40'
                style="width:90px; margin: 0 auto;display:block"
                v-model="item.group_price"
                placeholder="请输入价格"
              />
            </td>
            <td>
              <Input
                style="width:90px;margin: 0 auto;display:block"
                v-model="item.group_store"
                placeholder="请输入限量"
                :maxlength='40'
              />
            </td>
            <td>
              <Input
                style="width:90px;margin: 0 auto;display:block"
                v-model="item.group_code"
                :maxlength='40'
                placeholder="请输入规格编码"
              />
            </td>
            <td>
              <Input
                style="width:90px;margin: 0 auto;display:block"
                v-model="item.taid_price"
                placeholder="成本价"
                :maxlength='40'
              />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <!-- buttom -->
    <Button @click="specpost" type="dashed">确认</Button>
  </div>
</template>

<script>
import { listSpeButtom } from "@/api/shop/shopeditspec";
export default {
  data() {
    return {
      nolist: true,
      oplist: [],
      lists: [{ spec_val: [], figlist: [{}] }], // 规格li数目
      loading: false, // 搜索等待
      mouse: "",
      disSelect: [{ info: [] }], // 结果
      disOff: [], // 关掉重复值的索引集合
      opmouse: "", // 核对索引
      offtwo: true,
      offthere: true,
      yanArr: [], // 验证数组
      yanlistArr: [], // 验证初始id
      oldnum: "",
      oldyunnum: "",
      isClearSelect: false, // 重要，用于原地点规格名时候，清空所选数据
      // 实时动态表数据  //
      specTablesList: [], //动态表数据集合
      headerName: [],
      rowspan: {
        one: "",
        two: "",
        there: ""
      }
    };
  },
  methods: {
    // 判断区域
    mousindex(index) {
      this.mouse = index;
    },
    listSpe() {
      const data = {};
      listSpeButtom(data)
        .then(res => {
          this.oplist = res.data.data.list;
          console.log(res);
        })
        .catch(err => {
          console.error(err);
        });
    },
    // 分别赋值给每一个规格值
    specdata(v) {
      // 判断是否是原地点，将每次ID加入禁点名单
      if (this.yanlistArr.indexOf(v) === -1) {
        if (this.lists.length === this.yanlistArr.length) {
          this.oldnum = JSON.parse(JSON.stringify(v));
          this.yanlistArr.splice(this.yanlistArr.indexOf(this.oldnum), 1);
          this.yanlistArr.push(v);
          // 去除之前选择
          this.lists[this.mouse].figlist.splice(0);
          this.disSelect[this.mouse].info = [];
        } else {
          this.yanlistArr.push(v);
          // console.log('原地点',this.yanlistArr,this.lists,this.disSelect[this.mouse])
        }
      }
      let obj = v;
      this.oplist.forEach((element, index) => {
        if (element.id == obj) {
          this.$set(this.lists[this.mouse], "spec_val", element.spec_val);
          this.$set(this.headerName, this.mouse, element);
        }
      });
    },
    // 添加某个规格名下多条规格值
    addfiglist() {
      // 添加
      if (this.lists[this.mouse].figlist.length == 3) {
        this.$Message.warning("规格值最多只能添加3个");
      } else {
        if (
          this.lists[this.mouse].figlist.length ==
          this.disSelect[this.mouse].info.length
        ) {
          this.lists[this.mouse].figlist.push({});
        } else {
          this.$Message.warning("请填写规格值后再进行添加");
        }
      }
    },
    // 添加规格名事件
    addspec() {
      if (this.lists.length === 3) {
        this.$Message.warning("规格名最多只能添加3个");
      } else {
        this.lists.push({ spec_val: [], figlist: [{}] });
      }
    },
    // 针对选中不可再选
    stoplist(v) {
      if (this.mouse == 1 && this.offtwo) {
        this.offtwo = true;
      }
      if (this.mouse == 2 && this.offthere) {
        this.offtwo = true;
        this.offthere = false;
      }
      if (this.mouse !== 0 && this.offtwo) {
        this.disSelect.push({ info: [] });
        this.disSelect[this.mouse].info.push({ id: v });
        this.offtwo = false;
      }
      // 这个东西是真的复杂
      if (this.disSelect.length === 0) {
        this.disSelect[this.mouse].info = [];
        this.disSelect[this.mouse].info.push({ id: v });
        console.log(123);
      } else if (this.disSelect[this.mouse].info.length === 4) {
        this.disSelect[this.mouse].info.splice(this.opmouse, 1);
        this.disSelect[this.mouse].info.push({ id: v });
        console.log(456);
      } else {
        let num = [{ info: [] }];
        this.disSelect[this.mouse].info.forEach((element, index) => {
          num[index] = element.id;
        });
        if (num.indexOf(v) !== -1) {
          // this.disOff[this.mouse].info.push(this.disSelect[index].info.id)
        } else {
          if (this.mouse === 0) {
            console.log(789);
            this.disSelect[this.mouse].info[this.opmouse] = { id: v };
          } else {
            // 原地点规格值
            this.disSelect[this.mouse].info[this.opmouse] = { id: v };
          }
        }
      }
      // 给予核对数组
      this.disSelect[this.mouse].info.forEach((element, index) => {
        if (this.yanArr.indexOf(element.id) === -1) {
          this.yanArr[this.opmouse] = element.id;
        }
        // 给予name
        let sname = this.lists[this.mouse].spec_val.find(value => {
          if (value.id === element.id) {
            let title = value.spec_val;
            return title;
          }
        });
        this.disSelect[this.mouse].info[index].name = sname.spec_val;
      });
      this.specdataname();
    },
    // 规格值索引绑定
    mousindexoptian(index) {
      // console.log(index)
      this.opmouse = index;
    },
    // 日后远程搜索扩展
    remoteMethod() {},
    // 删除规格值
    deloptian(item, i) {
      console.log(this.mouse, "区域索引");
      console.log(item.info[i], "当前选择");
      console.log(this.disSelect, "最终结果");
      console.log(this.lists, "外围数组");
      console.log(this.yanArr, "核对数组");
      // 删除核对数组
      console.log(this.lists[this.mouse].figlist.length);
      if (this.lists[this.mouse].figlist.length !== 1) {
        if (this.yanArr.indexOf(item.info[i].id) !== -1) {
          let jindex = this.yanArr.indexOf(item.info[i].id);
          this.yanArr.splice(jindex, 1);
        }
        // // 删除外围数组
        if (this.lists[this.mouse].figlist.length >= i) {
          // console.log(this.lists[this.mouse].figlist.length >= i)
          this.lists[this.mouse].figlist.length--;
        }
        // 删除最终结果
        if (this.disSelect[this.mouse].info[i].id === item.info[i].id) {
          this.disSelect[this.mouse].info.splice(i, 1);
        }
      } else {
        console.log(5555);
        this.$Message.warning("规格值至少有一个");
      }
      this.specdataname();
    },
    //  动态赋值表 ************************************************* //
    specdataname() {
      // 给予表格数据
      // 给予name
      console.log(this.disSelect);
      let arr = [];
      for (let i in this.disSelect[0].info) {
        //  arr.push(this.disSelect[0].info[i].name)
        arr.push({
          nameOne: this.disSelect[0].info[i].name,
          spec_val_ids: `${this.disSelect[0].info[i].id}`,
          group_title: `${this.disSelect[0].info[i].name}`,
          group_price: "",
          group_store: "",
          group_code: "",
          taid_price: ""
        });
        if (this.disSelect[1]) {
          arr.splice(arr.length--);
          for (let j in this.disSelect[1].info) {
            //  arr.push(this.disSelect[0].info[i].name + this.disSelect[1].info[j].name)
            arr.push({
              nameOne: this.disSelect[0].info[i].name,
              nameTwo: this.disSelect[1].info[j].name,
              spec_val_ids: `${this.disSelect[0].info[i].id},${
                this.disSelect[1].info[j].id
              }`,
              group_title: `${this.disSelect[0].info[i].name}-${
                this.disSelect[1].info[j].name
              }`,
              group_price: "",
              group_store: "",
              group_code: "",
              taid_price: ""
            });
            if (this.disSelect[2]) {
              arr.splice(arr.length--);
              for (let q in this.disSelect[2].info) {
                // arr.push(this.disSelect[0].info[i].name + this.disSelect[1].info[j].name +  this.disSelect[2].info[q].name)
                arr.push({
                  nameOne: this.disSelect[0].info[i].name,
                  nameTwo: this.disSelect[1].info[j].name,
                  nameThere: this.disSelect[2].info[q].name,
                  spec_val_ids: `${this.disSelect[0].info[i].id},${
                    this.disSelect[1].info[j].id
                  },${this.disSelect[2].info[q].id}`,
                  group_title: `${this.disSelect[0].info[i].name}-${
                    this.disSelect[1].info[j].name
                  }-${this.disSelect[2].info[q].name}`,
                  group_price: "",
                  group_store: "",
                  group_code: "",
                  taid_price: ""
                });
              }
            }
          }
        }
      }
      this.specTablesList = arr;
      console.log("会合并的数值", this.rowspan);
    },
    specpost() {
      console.log(this.specTablesList);
      this.$emit("speclist", this.specTablesList);
    }
  },
  mounted() {
    this.listSpe();
    this.offtwo = true;
    this.offthere = true;
  }
};
</script>

<style scope>
@import url("./spec.less");
.addBtn{
  background: #2D8cf0;
  color: #fff;
}
/* .startbuttom,.add-spec{
  background: #2D8cf0;
  color: #fff;
  font-weight: 600;
}
.startbuttom{
  background: #2D8cf0;
}
.startbuttom:hover,.add-spec:hover{
  border: 1px solid #57a3f3;
  cursor: pointer;
  color: #57a3f3;
  background: #fff;
} */
</style>
