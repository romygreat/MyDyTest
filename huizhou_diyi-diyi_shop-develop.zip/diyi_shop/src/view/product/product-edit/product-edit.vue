<template>
  <div>
    <h3 class="title">{{editData.id ? '编辑商品':'添加商品'}}</h3>
    <Form
      ref="editData"
      :model="editData"
      :rules="editRuleValidate"
      style="width:1024px"
      :label-width="120"
    >
      <Row class="basics">
        <Col span="24">
          <FormItem
            style="width:300px"
            label="所属于分类:"
            prop="cate_id"
            class="ivu-form-item-required"
          >
            <Select v-model="editData.cate_id" style="width:220px" placeholder="选择商品分类">
              <Option
                v-for="item in cateName"
                :value="item.value"
                :key="item.value"
              >{{ item.label }}</Option>
            </Select>
          </FormItem>
          <FormItem label="品项名称" prop="name" style="width:300px;">
            <Input :maxlength="40" v-model="editData.name" placeholder="请填写品项名称" />
          </FormItem>
          <FormItem label="零售价(元)" style="width:300px;">
            <Input :maxlength="40" v-model="editData.price" placeholder="输入零售价" />
          </FormItem>
          <FormItem label="市场价(元)" style="width:300px;">
            <Input :maxlength="40" v-model="editData.market_price" placeholder="输入市场价" />
          </FormItem>
          <FormItem label="产品编号" prop="code" style="width:300px;">
            <Input :maxlength="40" v-model="editData.code" placeholder="输入产品编号" />
          </FormItem>
          <FormItem label="计量单位" style="width:300px; margin-bottom:12px">
            <Unit :unitName="editData.unit" v-on:unitList="unitList($event)" />
          </FormItem>
          <FormItem label="规格">
            <Spec ref="spec" :group="editData.group" v-on:speclist="speclist($event)" />
          </FormItem>
          <FormItem label="标签" style="width:300px">
            <Select
              @on-query-change="remotenull"
              @on-change="sdkinfo"
              v-model="selectinfo"
              multiple
              filterable
              remote
              :remote-method="remoteMethod2"
              :loading="loading2"
              placeholder="请选择或输入关键字"
            >
              <Option
                v-for="(option, index) in options2"
                :value="option.value"
                :key="index"
              >{{option.label}}</Option>
            </Select>
          </FormItem>
          <FormItem
            label="口味"
            style="display: inline-block;  margin-right:15px; margin-bottom:12px"
          >
            <Remarks :propsRemarks="propsRemarks" v-on:remarklist="remarklist($event)" />
          </FormItem>
          <FormItem label="商品置顶" style="margin-right:15px;">
            <RadioGroup v-model="editData.sign">
              <span v-for="(item,index) in options2" :key="index" @click="getSign(item.label)">
                <Radio :label="item.label"></Radio>
              </span>
            </RadioGroup>
          </FormItem>
          <FormItem label="开启配菜" style="display: block; margin-right:15px;">
            <div style="display: inline-block;">
              <i-switch v-model="editData_is_side_dish" size="large">
                <span slot="open">是</span>
                <span slot="close">否</span>
              </i-switch>
            </div>
            <div style="display: inline-block;position: absolute;">
              <Garnish
                :editData_is_side_dish="editData_is_side_dish"
                :propsGarnish="propsGarnish"
                v-on:garnishlist="garnishlist($event)"
                v-if="editData_is_side_dish == true"
              />
            </div>
          </FormItem>
          <FormItem label="做法选择" style="display: block;  margin-right:15px">
            <div style="display: inline-block; margin-right:15px;">
              <i-switch v-model="editData_is_procedure" size="large">
                <span slot="open">是</span>
                <span slot="close">否</span>
              </i-switch>
            </div>
            <div style="display: inline-block;position: absolute;">
              <Practice
                v-if="editData_is_procedure"
                :propsProcedure="editData.procedure"
                v-on:practice="practice($event)"
              />
            </div>
          </FormItem>
          <FormItem label="是否上架" style="margin-right:15px; margin-bottom:12px">
            <i-switch v-model="editData.is_sale" size="large">
              <span slot="open">是</span>
              <span slot="close">否</span>
            </i-switch>
          </FormItem>
          <FormItem label="是否估清" style="margin-right:15px; ">
            <i-switch v-model="editData.is_limit" size="large">
              <span slot="open">是</span>
              <span slot="close">否</span>
            </i-switch>
            <InputNumber
              :min="0"
              style="display: inline-block; width:50px; margin-left:15px;"
              v-if="editData.is_limit"
              v-model="editData.limit_num"
              placeholder="输入估清数"
            />
          </FormItem>
          <FormItem
            label="是否时价商品"
            style="display: inline-block;  margin-right:15px; margin-bottom:12px"
          >
            <i-switch v-model="editData.is_current" size="large">
              <span slot="open">是</span>
              <span slot="close">否</span>
            </i-switch>
          </FormItem>
          <FormItem
            label="是否称重商品"
            style="display: inline-block;  margin-right:15px; margin-bottom:12px"
          >
            <i-switch v-model="editData.is_editable" size="large">
              <span slot="open">是</span>
              <span slot="close">否</span>
            </i-switch>
          </FormItem>
          <FormItem label="排序" style="width:300px; margin-right:15px;">
            <InputNumber :min="0" v-model="editData.sort"></InputNumber>
          </FormItem>
          <FormItem label="产品描述" prop="describe">
            <Input
              :maxlength="40"
              v-model="editData.describe"
              type="textarea"
              placeholder="输入产品描述"
              style="width:280px"
            />
          </FormItem>
        </Col>
        <Col style="position: absolute;top: 0; left: 500px;  width: 500px;" span="2">
          <p style="margin-bottom: 10px;">图片上传：</p>
          <input type="hidden" v-model="editData.pic" />
          <Row>
            <Col span="12">
              <div v-if="imgPath">
                <img style="margin-top: 5px;; height: 250px;" :src="imgPath" />
              </div>
              <img v-else style="margin-top: 5px;; height: 250px;" :src="mpic" />
            </Col>
            <Col
              span="12"
              style="height:200px;display: flex; align-items: center;justify-content: center;flex-flow: row wrap;"
            >
              <p
                style="display:block;padding-left: 34px;"
              >点击图片选择要上传的菜单图片，请尽量上传正方形的图片，系统会自动将图片裁剪成1:1,大小不能超过2M，图片只能为jpg、png、gif格式</p>
              <Upload action="/" :before-upload="beforeUpload">
                <Button>上传图片</Button>
              </Upload>
            </Col>
          </Row>
        </Col>
      </Row>
      <FormItem>
        <Button style="margin-right:15px" type="primary" @click="saveProductInfo('editData')">确定</Button>
      </FormItem>
    </Form>
  </div>
</template>

<script>
import { productLabelList } from '@/api/shop/shopLabel'
import { listSpeButtom } from '@/api/shop/shopAttribute'
import { mapMutations } from 'vuex'
import { editDataButoom, optionCateButtom } from '@/api/shop/shopAdd'
import { getQnDomain, upload } from '@/libs/upload'
import { getToken } from '@/libs/util'
import Spec from './components/spec'
import Remarks from './components/remarks'
import Garnish from './components/garnish'
import Practice from './components/practice'
import Unit from './components/unit'
import { constants } from 'crypto'
import { getProduct, setProduct, convertPrice, cloneObj } from '@/libs/tools.js'
export default {
  name: 'product-edit',
  components: {
    Spec,
    Remarks,
    Garnish,
    Practice,
    Unit
  },
  data() {
    return {
      Topping: [],
      editData: {},
      editRuleValidate: {
        name: [
          { required: true, message: '商品名称不能为空', trigger: 'blur' }
        ],
        price: [
          { required: true, message: '零售价不能为空' },
          {
            type: 'number',
            message: '必须为数字',
            transform(value) {
              return Number(value)
            }
          }
        ],
        market_price: [
          {
            type: 'number',
            message: '必须为数字',
            transform(value) {
              return Number(value)
            }
          }
        ],
        cate_id: [
          {
            validator: (rule, value, callback) => {
              if (value) {
                return callback()
              }
              return callback(new Error('请选择一个分类'))
            },
            trigger: 'blur'
          }
        ],
        code: [
          {
            validator: (rule, value, callback) => {
              if (!value) {
                return callback()
              }
              if (value) {
                if (value > 999999) {
                  return callback(new Error('产品编码不能超过六位'))
                }
              }
              return callback()
            },
            trigger: 'blur'
          }
        ]
      },
      cateName: [],
      imgPath: '',
      mpic: require('../../../assets/images/mpic.jpg'),
      // 属性值
      social: [],
      socialData: [],
      // ****
      selectinfo: [],
      loading2: false,
      options2: [],
      list: [],
      resselect: [],
      editData_is_side_dish: false,
      editData_is_procedure: false,
      propsRemarks: [],
      caseId: ''
    }
  },
  created() {
    this.editData.is_sale = true
    if (getProduct()) {
      this.editData = getProduct()
      this.caseId = getProduct().cate_id
      this.editData.is_limit = this.editData.is_limit == 1
      this.editData.is_sale = this.editData.is_sale == 1
      this.editData.is_side_dish = this.editData.is_side_dish == 1
      this.editData_is_side_dish = this.editData.is_side_dish
      this.editData.is_editable = this.editData.is_editable == 1
      this.editData.editData_is_procedure = this.editData.is_procedure == 1
      this.editData.editData_is_procedure = this.editData.is_procedure
      this.editData.is_current = this.editData.is_current == 1
      this.imgPath = this.editData.pic
      this.editData.price = Number(convertPrice(this.editData.price))
      this.editData.market_price = Number(
        convertPrice(this.editData.market_price)
      )

      // 新添加置顶
      this.editData.sign = this.editData.sign

      // 逻辑赋值
      if (this.editData.label != undefined) {
        let arr = cloneObj(this.editData.label)
        for (let i in arr) {
          this.selectinfo[i] = arr[i].label_id
        }
      }
      this.editData.is_procedure == 1
        ? (this.editData_is_procedure = true)
        : (this.editData_is_procedure = false)
      // 双向绑定 配菜与备注
      this.propsRemarks = this.editData.taste
      this.propsGarnish = this.editData.contorno
    }
    if (this.editData.id == undefined && this.editData.is_sale == false) {
      this.editData.is_sale = true
    }
  },
  methods: {
    ...mapMutations(['closeTag']),
    optionCate() {
      const data = {}
      optionCateButtom(data)
        .then(res => {
          this.cateName = res.data.data
        })
        .catch(err => {
          console.error(err)
        })
    },
    // 修改 && 上传
    saveProductInfo(name) {
      this.$refs[name].validate(async valid => {
        if (valid) {
          let data = cloneObj(this.editData)
          this.imgPath = data.pic
          if (!data.pic) {
            this.$Message.info('请选择一张图片')
            return false
          } else {
            await getQnDomain().then(domain => {
              if (data.pic.indexOf(domain) !== -1) {
                data.pic = data.pic.substring(domain.length + 1)
              }
            })
          }
          // 将价格单位转成分，用于计算和入库
          data.price = convertPrice(data.price, 'fen')
          data.market_price = convertPrice(data.market_price, 'fen')
          data.is_editable == true
            ? (data.is_editable = 1)
            : (data.is_editable = 0)

          data.is_current == true
            ? (data.is_current = 1)
            : (data.is_current = 0)

          data.label_ids = this.resselect
          // 获取规格组合信息
          data.group = this.$refs.spec.getSpecGroup()

          this.editData_is_side_dish === true
            ? (data.is_side_dish = 1)
            : (data.is_side_dish = 0)
          this.editData_is_procedure === true
            ? (data.is_procedure = 1)
            : (data.is_procedure = 0)
          this.editData_is_taste === true
            ? (data.is_taste = 1)
            : (data.is_taste = 0)

          editDataButoom(data)
            .then(res => {
              this.$Message.info({
                content: res.data.message,
                duration: 5,
                closable: true
              })
              this.handleCloseTag()
              setProduct({})
              this.$router.push({
                name: 'productlist',
                query: {
                  caseId: this.caseId
                }
              })
            })
            .catch(err => {
              console.error(err)
            })
        } else {
          this.$Message.error('输入格式有误，请核对输入')
        }
      })
    },
    // 上传
    beforeUpload(file) {
      let fileIndex = 'file'
      if (file.type.indexOf('image') !== 0) {
        this.$Message.info({
          content: '请上传图片文件',
          duration: 5,
          closable: true
        })
      } else if (file.size > 2 * 1024 * 1024) {
        this.$Message.info({
          content: '文件大小不能大于2M',
          duration: 5,
          closable: true
        })
      } else {
        let param = new FormData() // 创建form对象
        param.append(fileIndex, file) // 通过append向form对象添加数据
        param.append('token', getToken())
        param.append('machine', 'shop')
        console.log('jojo',param)
        upload(param).then(res => {
          if (res.code == 1) {
            this.editData.pic = ''
            this.imgPath = ''
            getQnDomain().then(domain => {
              this.editData.pic = domain + '/' + res.data[fileIndex].url
              this.imgPath = domain + '/' + res.data[fileIndex].url
            })
          } else {
            this.$Message.info({
              content: '上传失败，请联系管理员',
              duration: 5,
              closable: true
            })
          }
        })
      }
      return false
    },
    handleCloseTag() {
      this.closeTag({
        name: 'product-edit'
      })
      this.$router.push({
        name: 'productlist'
      })
    },
    // 属性列表
    listSpec() {
      const data = {
        page: 1
      }
      listSpeButtom(data)
        .then(res => {
          this.socialData = res.data.data.list
        })
        .catch(err => {
          console.error(err)
        })
    },
    listSpecID(v) {
      this.editData.spec_val_ids = this.social.join(',')
    },
    // 标签列表
    productLabelList() {
      const resdata = {
        name: '',
        page: 1,
        sort: {
          sort: 'asc'
        }
      }
      productLabelList(resdata).then(res => {
        this.list = cloneObj(res.data.data.list)
        const listinfo = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        this.options2 = listinfo
      })
    },
    // 标签远程搜索
    remoteMethod2(query) {
      if (query !== '') {
        this.loading2 = true
        setTimeout(() => {
          let arrlist = []
          this.loading2 = false
          const data = { name: query }
          productLabelList(data).then(res => {
            arrlist = cloneObj(res.data.data.list)
            const listinfo = arrlist.map(item => {
              return {
                value: item.id,
                label: item.name
              }
            })
            this.options2 = listinfo.filter(
              item => item.label.toLowerCase().indexOf(query.toLowerCase()) > -1
            )
          })
        }, 200)
      } else {
        this.options2 = []
      }
    },
    sdkinfo(i) {
      const listinfo = this.list.map(item => {
        return {
          value: item.id,
          label: item.name
        }
      })
      this.options2 = listinfo
      this.resselect = []
      let arr = cloneObj(this.selectinfo)
      for (let i in arr) {
        this.resselect[i] = { label_id: arr[i] }
      }
    },
    remotenull(v) {
      if (v === '') {
        const listinfo = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        this.options2 = listinfo
      }
    },
    // 接受子组件规格值
    speclist(res) {
      this.editData.spec = res
    },
    // 接受子组件备注选择
    remarklist(res) {
      this.$set(this.editData, 'remark_ids', res)
    },
    // 接受子组件做法选择
    practice(res) {
      if (this.editData_is_procedure) {
        this.editData.editData_is_procedure = 1
      } else {
        this.editDataeditData_is_procedure = 0
      }
      this.$set(this.editData, 'procedure_ids', res)
    },
    // 接受子组件配菜选择
    garnishlist(res) {
      if (this.editData_is_side_dish) {
        this.editData.is_side_dish = 1
      } else {
        this.editData.is_side_dish = 0
      }
      this.editData.side_dish_ids = res
    },
    // 接受子组件单位选择
    unitList(res) {
      this.editData.unit = res
    },
    getSign(val) {
      if (this.editData.sign == val) {
        this.editData.sign = ''
      }
    }
    // checkInput() {
    //   console.log(this.editData.code)

    //   if (Number(this.editData.code)>999999) {
    //     let a = parseInt(Number(this.editData.code) % 10)
    //     console.log(a)

    //     if (a === 0) {
    //       this.editData.code = Number(this.editData.code) / 10
    //     }
    //     if (a != 0) {
    //       this.editData.code = (Number(this.editData.code) - a) / 10
    //       console.log(this.editData.code);

    //     }
    //     console.log(this.editData.code)
    //   }
    // }
  },
  mounted() {
    this.listSpec()
    this.optionCate()
    this.productLabelList()
  },
  watch: {}
}
</script>

<style>
@import './product-edit.css';
.ivu-select-selection {
  width: max-content;
}
</style>
