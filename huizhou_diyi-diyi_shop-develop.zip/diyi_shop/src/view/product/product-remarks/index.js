import ProductRemarks from './product-remarks'
export default ProductRemarks
