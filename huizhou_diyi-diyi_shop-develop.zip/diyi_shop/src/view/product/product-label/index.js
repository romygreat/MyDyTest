import Productlabel from './product-label'
export default Productlabel
