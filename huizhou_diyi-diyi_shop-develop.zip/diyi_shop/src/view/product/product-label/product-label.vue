<template>
  <div>
    <hgroup class="shopC-title">
      <h3>商品标签</h3>
      <p>这是您店内商品的标签，在这里可以修改添加</p>
    </hgroup>
    <!-- shopClassify search -->
    <div class="shopClass-search">
      <p class="shopClass-title">标签名称：</p>
      <Input
        :maxlength='40'
        clearable
        v-model="resdata.name"
        icon="search"
        placeholder="输入你要查询的属性名称"
        style="width: 200px; display: inline-block"
      />
      <Button style="display: inline-block; margin:0 0 0 15px;  " @click="search" type="primary">搜索</Button>
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="resdata.name='';search()"
        type="warning"
      >刷新</Button>
    </div>
    <Button @click="editreslist('添加')" type="primary" style="margin-bottom: 15px;">
      <span>
        <Icon type="md-add" />
        <span>新增标签</span>
      </span>
    </Button>
    <!-- data -->
    <Table :width="500" ref="selection" border :columns="columns" :data="shopData" stripe></Table>
    <div style="margin-top:20px; width:500px">
      <Page
        :total="Number(resdata.total)"
        :current="Number(resdata.page)"
        :page-size=" Number(resdata.rows)"
        @on-change="getShopData"
        class="page-buttom"
      ></Page>
    </div>
    <!-- madal -->
    <Modal v-model="editshow.show" :title="editshow.title" :footer-hide="true" width="350">
      <Form ref="operation" :model="editres" :rules="ruleValidate" :label-width="100">
        <FormItem label="属性名称：" prop="name">
          <Input :maxlength='40' style="width:180px" v-model="editres.name" placeholder="请输入标签名称" />
        </FormItem>
        <FormItem label="排序：" prop="sort">
          <Input :maxlength='40' style="width:180px" v-model="editres.sort" placeholder="请输入排序" />
        </FormItem>
        <FormItem>
          <Button type="primary" @click="handleSubmit('operation')">确认</Button>
          <Button @click="editshow.show = false" style="margin-left: 8px">取消</Button>
        </FormItem>
      </Form>
    </Modal>
  </div>
</template>

<script>
import {
  productLabelList,
  productLabelSave,
  productLabelDel
} from '@/api/shop/shopLabel'
export default {
  data() {
    return {
      resdata: {
        total: '',
        name: '',
        rows: 10,
        page: 1,
        sort: {
          sort: 'asc'
        }
      },
      editres: {
        name: '',
        id: '',
        sort: 0
      },
      columns: [
        { title: 'id', key: 'id' },
        { title: '标签名称', key: 'name' },
        { title: '排序', key: 'sort' },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      let arr = JSON.parse(JSON.stringify(params.row))
                      this.editres.name = arr.name
                      this.editres.id = arr.id
                      this.editres.sort = arr.sort
                      this.editreslist('修改')
                    }
                  }
                },
                '编辑'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      const data = { id: params.row.id }
                      this.productLabelDel(data)
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      shopData: [],
      editshow: {
        show: false,
        title: ''
      },
      ruleValidate: {
        name: [{ required: true, message: '标签名不能为空', trigger: 'blur' }]
      }
    }
  },
  methods: {
    search() {
      this.resdata.page = 1
      this.productLabelList()
    },
    getShopData(v) {
      this.resdata.page = v
      this.productLabelList()
    },
    // 请求数据
    productLabelList() {
      productLabelList(this.resdata).then(res => {
        console.log(this.resdata,'搜索参数');
        
        console.log(res)
        this.resdata.total = res.data.data.total
        this.shopData = res.data.data.list
      })
    },
    // 添加标签 && 修改标签
    editreslist(name) {
      if (name === '添加') {
        this.editres.name = ''
        this.editres.sort = 0
        this.editres.id = ''
      }
      this.editshow.title = name
      this.editshow.show = true
    },
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          if (this.editshow.title === '添加') {
            productLabelSave(this.editres).then(res => {
              console.log('添加的标签',res);
              

              this.$Message.info(res.data.message)
              this.productLabelList()
              this.editshow.show = false
              this.editres.name = ''
              this.editres.sort = 0
            })
          } else if (this.editshow.title === '修改') {
            productLabelSave(this.editres).then(res => {
              this.$Message.info(res.data.message)
              this.productLabelList()
              this.editshow.show = false
            })
          }
        } else {
          this.$Message.error('请按规则填写提交')
        }
      })
    },
    // 删除标签
    productLabelDel(data) {
      productLabelDel(data).then(res => {
        this.$Modal.confirm({
          title: '删除标签',
          content: '<p>当前进行删除商品标签操作，您确认删除吗？</p>',
          onOk: () => {
            this.$Message.info(res.data.message)
            this.resdata.page = 1
            this.productLabelList()
          },
          onCancel: () => {
            this.$Message.info('您取消了删除')
          }
        })
      })
    }
  },
  mounted() {
    this.productLabelList()
  }
}
</script>

<style scope>
@import url('./index.less');
</style>
