import ProductList from './product-list'
export default ProductList
