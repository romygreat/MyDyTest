<template>
  <div>
    <hgroup class="shopC-title">
      <h3>商品列表</h3>
      <p>请为您店内的商品仔细分类，以便于在客户端精确查找，排序号越小，显示位置越靠前</p>
    </hgroup>
    <div class="shopClass-search">
      <p class="shopClass-title">快速查找：</p>
      <Input
        :maxlength="40"
        clearable
        v-model="searchInfo"
        icon="search"
        placeholder="输入你要查询的商品名称"
        style="width: 250px; display: inline-block"
      />
      <Select
        clearable
        v-model="isCity"
        style="width:200px;margin-left:10px"
        placeholder="选择你要查询的商品分类"
      >
        <Option v-for="item in cateList" :value="item.id" :key="item.id">{{ item.name }}</Option>
      </Select>
      <Button style="display: inline-block; margin:0 0 0 15px;  " @click="search" type="primary">搜索</Button>
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="searchInfo='';search()"
        type="warning"
      >刷新</Button>
    </div>
    <!-- add shopClassify buttom -->
    <div class="clearinfo" >
      <Button style="float: left;display: block;" type="primary" class="addShopC" @click="addShopC()">
        <span>
          <Icon type="md-add" />
          <span>商品添加</span>
        </span>
      </Button>
      <Button style="float: left;display:block;margin-left:15px; margin-bottom: 16px;" type="primary"   @click="isModalShow = true">
        <span>
          <Icon type="md-add" />
          <span>批量商品添加</span>
        </span>
      </Button>
    </div>
    <!-- shopClass Tables -->
    <Table
      @on-selection-change="allselect"
      ref="selection"
      border
      :columns="columns"
      :data="shopData"
      stripe
    ></Table>
    <div style="margin-top:20px;">
      <Button type="error" @click="remove(1,1)">批量删除</Button>
      <Page
        show-elevator
        show-total
        :total="Number(pageData.total)"
        :current="Number(pageData.current)"
        :page-size=" Number(pageData.rows)"
        @on-change="getShopData"
        class="page-buttom"
      ></Page>
    </div>
    <!-- operation -->
    <allUpload v-on:modelCallBack='modelCallBack($event)'  :show='isModalShow' />
  </div>
</template>

<script>
import { getQnDomain } from '@/libs/upload'
import { getShopDataButtom } from '@/api/shop/shopClassify'
import { setProduct, convertPrice } from '@/libs/tools.js'
import {
  deloperationButtom,
  optionCateButtom,
  operationButtom,
  getShopDataButtominfo
} from '@/api/shop/shopList'
import allUpload from '../../../components/allUpload'
export default {
  components:{
    allUpload
  },
  data() {
    return {
      // tablse
      isModalShow:false,
      columns: [
        {
          type: 'selection',
          width: 60,
          align: 'center'
        },
        {
          title: '产品编号',
          key: 'code',
          align: 'center'
        },
        {
          title: '商品图片',
          key: 'pic',
          align: 'center',
          render: (h, params) => {
            if (params.row.pic) {
              return h('div', [
                h('img', {
                  attrs: {
                    src: params.row.pic
                  },
                  style: {
                    width: '40px',
                    height: '40px',
                    display: 'block',
                    margin: '0 auto'
                  }
                })
              ])
            } else {
              return h('div', '无')
            }
          }
        },
        {
          title: '品项名称',
          key: 'name',
          align: 'center'
        },
        {
          title: '所属分类',
          key: 'cate_name',
          align: 'center'
        },
        {
          title: '单位',
          key: 'unit',
          align: 'center'
        },
        {
          title: '价格',
          key: 'price',
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h('p', convertPrice(params.row.price) + ' ' + '元')
            ])
          }
        },
        {
          title: '排序',
          key: 'sort',
          align: 'center'
        },
        {
          title: '是否估清',
          key: 'is_limit',
          align: 'center',
          render: (h, params) => {
            const limitText = params.row.is_limit
            if (limitText == 0) {
              params.row.is_limit = '否'
            } else if (limitText == 1) {
              params.row.is_limit = '是'
            }
            return h('div', [h('p', params.row.is_limit)])
          }
        },
        {
          title: '估清数',
          key: 'limit_num',
          align: 'center',
          render: (h, params) => {
            if (params.row.is_limit == '否') {
              params.row.limit_num = '无'
            }
            return h('div', [h('p', params.row.limit_num)])
          }
        },
        {
          title: '是否上架',
          key: 'is_sale',
          align: 'center',
          render: (h, params) => {
            return h('i-switch', {
              props: {
                type: 'primary',
                value: params.row.is_sale == 1
              },
              on: {
                'on-change': value => {
                  if (value == true) {
                    params.row.is_sale = 1
                  } else {
                    params.row.is_sale = 0
                  }
                  this.idenswitch = 0 // 0表示是上架的标识
                  this.Saleswitch(
                    params.index,
                    params.row.is_sale,
                    this.idenswitch
                  )
                }
              }
            })
          }
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.show(params.index)
                    }
                  }
                },
                '编辑'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      // tablse data
      shopData: [],
      // page
      pageData: {
        total: '20',
        current: '1',
        rows: '10'
      },
      // add && edit
      operation: {
        operShow: false,
        operTitle: '',
        loading: false,
        // data
        cate_id: '',
        name: '',
        code: '',
        describe: '',
        price: '',
        market_price: '',
        pic: '',
        is_sale: '',
        is_limit: '',
        limit_num: '',
        remark: '',
        unit: '',
        id: '',
        cate_name: ''
      },
      ruleValidate: {
        operName: [
          { required: true, message: '分类名不能为空', trigger: 'blur' },
          { min: 4, message: '名称不能低于两个字', trigger: 'blur' }
        ]
      },
      searchInfo: '',
      data: {},
      idenswitch: '',
      alldelId: '',
      cateList: [],
      requestParam: {
        name: '',
        page: 1,
        rows: 50,
        sort: { sort: 'asc', id: 'desc' }
      },
      isCity: ''
    }
  },
  methods: {
    //  获取列表
    getShopData(value) {
      if (value) {
        this.pageData.current = value
      }

      const data = {
        page: this.pageData.current,
        rows: this.pageData.rows,
        search: this.searchInfo,
        cate_id: this.isCity,
        sort: {
          id: 'desc',
          sort: 'asc',
          create_time: 'asc'
        }
      }
      getShopDataButtominfo(data)
        .then(res => {
          this.pageData.total = res.data.data.total
          getQnDomain().then(domain => {
            res.data.data.list.forEach(item => {
              item.pic = domain + '/' + item.pic
            })
            this.shopData = res.data.data.list
          })
        })
        .catch(err => {
          console.error(err)
        })
    },
    async getCateList() {
      await getShopDataButtom(this.requestParam)
        .then(res => {
          this.cateList = res.data.data.list
        })
        .catch(err => {
          console.error(err)
        })
    },
    // 全选
    handleSelectAll(status) {
      this.$refs.selection.selectAll(status)
    },
    // 编辑buttom
    show(index) {
      // 跳转路由
      let editData = this.shopData[index]
      editData.limit_num = Number(editData.limit_num)
      editData.sort = Number(editData.sort)
      setProduct(editData)
      this.$router.push({ name: 'product-edit' })
    },
    // 删除buttom
    remove(index, type) {
      if (!type) {
        this.$Modal.confirm({
          title: '删除商品',
          content: '<p>当前正在进行删除商品操作，确认删除？</p>',
          onOk: () => {
            const data = {
              id: this.shopData[index].id
            }
            deloperationButtom(data).then(res => {
              this.getShopData()
            })
            this.$Message.info('已经删除')
          },
          onCancel: () => {
            this.$Message.info('取消了删除操作')
          }
        })
      } else {
        this.$Modal.confirm({
          title: '批量删除',
          content: '<p>确认批量删除？</p>',
          onOk: () => {
            const data = {
              id: this.alldelId
            }
            deloperationButtom(data).then(res => {
              this.getShopData()
            })
            this.$Message.info('已经批量删除')
          },
          onCancel: () => {
            this.$Message.info('取消了批量删除操作')
          }
        })
      }
    },
    // 查询
    search() {
      this.pageData.current = 1
      const data = {
        page: this.pageData.current,
        rows: this.pageData.rows,
        search: this.searchInfo,
        cate_id: this.isCity,
        sort: {
          id: 'desc',
          sort: 'asc',
          create_time: 'asc'
        }
      }
      getShopDataButtominfo(data)
        .then(res => {
          this.pageData.total = res.data.data.total
          getQnDomain().then(domain => {
            res.data.data.list.forEach(item => {
              item.pic = domain + '/' + item.pic
            })
            this.shopData = res.data.data.list
          })
        })
        .catch(err => {
          console.error(err)
        })
    },
    // 初始化
    newinfo() {
      this.operation.operName = ''
      this.operation.operPath = ''
    },

    addShopC() {
      sessionStorage.setItem('productMsg', {})
      this.operation.operTitle = '商品添加'
      let editData = this.operation
      const route = {
        name: 'product-edit',
        params: {
          editData
        },
        meta: {
          title: `商品添加`
        }
      }
      this.$router.push(route)
    },
    allselect(index) {
      let arr = []
      for (let i in index) {
        arr[i] = index[i].id
      }
      this.alldelId = arr.join(',')
    },
    Saleswitch(index, value, iden) {
      if (iden === 0) {
        this.shopData[index].is_sale = value
      }
      const sd = this.shopData[index]

      const data = {
        cate_id: sd.cate_id,
        name: sd.name,
        code: sd.code,
        price: sd.price,
        market_price: '150',
        pic: sd.pic,
        id: sd.id,
        is_sale: sd.is_sale
      }
      operationButtom(data)
        .then(res => {
          this.$Message.info(res.data.message)
        })
        .catch(err => {
          console.error(err)
        })
    },
    /**
     * @description 上传图片组件回调
     */
    modelCallBack(res) {
      this.isModalShow = res
      this.getShopData()
    }
  },
  mounted() {
    this.getShopData()
    this.getCateList()
  },
  created() {
    console.log(this.$route.query)
    if (this.$route.query) {
      this.isCity = this.$route.query.caseId
    } else {
      this.isCity = Number(sessionStorage.getItem('cateId'))
    }
    console.log(this.isCity)
  },
  watch: {
    isCity: {
      handler(n, o) {
        sessionStorage.setItem('cateId', n)
      }
    },
    $route: {
      handler(to, from) {
        console.log(to, from, 'sss')
      }
    }
  }
}
</script>
<style>
@import './product-list.css';
.clearinfo::after{
  content: '';
  display: block;
  width: 100%;
  height: 0;
  clear: both;
}
</style>
