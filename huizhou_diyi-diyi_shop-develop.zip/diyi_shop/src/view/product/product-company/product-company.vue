<template>
  <div>
    <hgroup class="shopC-title">
      <h3>单位列表</h3>
      <p>这里可以设置当前店铺的单位选择</p>
    </hgroup>
    <div class="shopClass-search">
      <p class="shopClass-title">快速查找：</p>
      <Input
        :maxlength="40"
        clearable
        v-model="resdata.name"
        icon="search"
        placeholder="输入你要查询的单位名称"
        style="width: 250px; display: inline-block"
      />
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="getRemarkList(true)"
        type="primary"
      >搜索</Button>
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="resdata.name='';getRemarkList(true)"
        type="warning"
      >刷新</Button>
    </div>
    <Button
      @click="addshow"
      style="display: inline-block; margin:5px 0 10px 0;  "
      type="primary"
    >+添加单位</Button>
    <Table border style="width:600px" :columns="columns" :data="shopData" stripe></Table>
    <div class="clearf" style="width:600px;margin:10px 0 10px 0;">
      <Page
        show-elevator
        show-total
        @on-change="avgPage"
        style="display: inline-block; float: right; "
        :page-size="parseInt(resdata.rows)"
        :total="Number(resdata.total)"
      />
    </div>
    <Modal v-model="delboxshow" width="360">
      <p slot="header" style="color:#f60;text-align:center">
        <Icon type="ios-information-circle"></Icon>
        <span>删除单位</span>
      </p>
      <div style="text-align:center">
        <p>当前正常进行删除单位操作</p>
        <p>您确认删除吗?</p>
      </div>
      <div slot="footer">
        <Button type="error" long size="large" @click="del">删除</Button>
      </div>
    </Modal>
    <Modal v-model="editarr.show" :title="editarr.title" @on-ok="edit(isedit)" width="350">
      <Form :label-width="80" ref="uselist" :model="uselist" :rules="ruleValidate">
        <FormItem label="名称" prop="name">
          <Input :maxlength="40" style="width:150px" v-model="uselist.name" placeholder="请输入单位名称" />
        </FormItem>
        <FormItem label="排序">
          <InputNumber :min="0" v-model="uselist.sort" placeholder="请输入单位排序" />
        </FormItem>
      </Form>
    </Modal>
  </div>
</template>

<script>
import {
  productUnitDataSet,
  productUnitList,
  productUnitDelete
} from '@/api/shop/shopProductUnit'
export default {
  data() {
    return {
      searchInfo: '',
      columns: [
        { key: 'id', title: 'ID', width: 50 },
        { key: 'name', title: '单位名称' },
        { key: 'sort', title: '排序', width: 70 },
        {
          title: '操作',
          key: 'action',
          width: 150,
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.editarr.title = '编辑单位'
                      this.uselist = JSON.parse(JSON.stringify(params.row))
                      this.uselist.sort = Number(this.uselist.sort)
                      this.isedit = 'edit'
                      this.editarr.show = true
                    }
                  }
                },
                '编辑'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.delboxshow = true
                      this.uselist = JSON.parse(JSON.stringify(params.row))
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      shopData: [],
      delboxshow: false,
      resdata: {
        sort: {
          sort: 'dec'
        },
        page: 1,
        rows: 10,
        name: '',
        total: ''
      },
      uselist: {
        price: 0,
        sort: 0
      },
      editarr: {
        show: false,
        title: ''
      },
      isedit: '',
      ruleValidate: {
        name: [{ required: true, message: '单位名称不能为空', trigger: 'blur' }]
      }
    }
  },
  methods: {
    // 获取
    getRemarkList(type) {
      if (type) {
        this.resdata.page = 1
      }
      productUnitList(this.resdata).then(res => {
        this.shopData = res.data.data.list
        this.resdata.total = Number(res.data.data.total)
      })
    },
    // 删除
    del() {
      const data = { id: this.uselist.id }
      productUnitDelete(data).then(res => {
        if (res.data.code == 1) {
          this.delboxshow = false
          this.$Notice.success({
            title: '该备注已经删除'
          })
          this.getRemarkList()
        } else {
          this.$Notice.error({
            title: res.data.message
          })
        }
      })
      this.uselist = {}
    },
    // 添加 & 删除
    edit(type) {
      if (type == 'edit') {
        if (this.uselist.name == '') {
          this.$Message.error('名称不得为空')
        } else {
          productUnitDataSet(this.uselist).then(res => {
            this.$Message.success(res.data.message)
            this.getRemarkList()
          })
        }
      } else {
        if (this.uselist.name != undefined) {
          productUnitDataSet(this.uselist).then(res => {
            this.$Message.success(res.data.message)
            this.getRemarkList()
          })
        } else {
          this.$Message.error('名称不得为空')
        }
      }
    },
    addshow() {
      this.isedit = 'add'
      this.uselist = {}
      this.uselist.sort = 0
      this.editarr.title = '添加单位'
      this.editarr.show = true
    },
    avgPage(v) {
      this.resdata.page = Number(v)
      this.getRemarkList()
    }
  },
  mounted() {
    this.getRemarkList()
  }
}
</script>

<style scope>
</style>
