function tableColumns (vue) {
  return [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'name', title: '备注名称·' },
    {
      key: 'price',
      title: '价格(元)',
      width: 130,
      render: (h, params) => {
        return h('div', [h('p', params.row.price + ' ' + '元')])
      }
    },
    { key: 'sort', title: '排序', width: 80 },
    {
      title: '操作',
      key: 'action',
      align: 'center',
      width: 130,
      render: (h, params) => {
        return h('div', [
          h(
            'Button',
            {
              props: {
                type: 'primary',
                size: 'small'
              },
              style: {
                marginRight: '5px'
              },
              on: {
                click: () => {
                  this.uselist = JSON.parse(JSON.stringify(params.row))
                  this.isedit = 'edit'
                  this.editarr.show = true
                  this.editarr.title = '编辑配菜'
                }
              }
            },
            '编辑'
          ),
          h(
            'Button',
            {
              props: {
                type: 'error',
                size: 'small'
              },
              on: {
                click: () => {
                  this.delboxshow = true
                  this.uselist = JSON.parse(JSON.stringify(params.row))
                }
              }
            },
            '删除'
          )
        ])
      }
    }
  ]
}
export default tableColumns
