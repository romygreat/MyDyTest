<template>
  <div>
    <hgroup class="shopC-title">
      <h3>商品配菜</h3>
      <p>这里可以设置每个商品的配菜选择</p>
    </hgroup>
    <div class="shopClass-search">
      <p class="shopClass-title">快速查找：</p>
      <Input
        :maxlength="40"
        clearable
        v-model="resdata.name"
        icon="search"
        placeholder="输入你要查询的商品编号或者名称"
        style="width: 250px; display: inline-block"
      />
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="getlist(true)"
        type="primary"
      >搜索</Button>
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="resdata.name='';getlist(true)"
        type="warning"
      >刷新</Button>
    </div>
    <Button
      @click="addshow"
      style="display: inline-block; margin:5px 0 10px 0;  "
      type="primary"
    >+添加</Button>
    <Table border style="width:600px" :columns="columns" :data="shopData" stripe></Table>
    <div class="clearf" style="width:600px;margin:10px 0 0 0;">
      <Page
        show-elevator
        show-total
        @on-change="avgPage"
        :total="Number(resdata.total)"
        :page-size="resdata.rows"
        style="display: inline-block;float: right; "
      />
    </div>
    <Modal v-model="delboxshow" width="360">
      <p slot="header" style="color:#f60;text-align:center">
        <Icon type="ios-information-circle"></Icon>
        <span>删除配菜</span>
      </p>
      <div style="text-align:center">
        <p>当前正常进行删除配菜操作</p>
        <p>您确认删除吗?</p>
      </div>
      <div slot="footer">
        <Button type="error" long size="large" @click="del">删除</Button>
      </div>
    </Modal>
    <Modal v-model="editarr.show" :title="editarr.title" @on-ok="edit(isedit)" width="350">
      <Form :label-width="80" ref="uselist" :model="uselist" :rules="ruleValidate">
        <FormItem label="名称" prop="name">
          <Input :maxlength="40" style="width:150px" v-model="uselist.name" placeholder="请输入配菜名称" />
        </FormItem>
        <FormItem label="价格">
          <Input :maxlength="40" style="width:150px" v-model="uselist.price" placeholder="请输入配菜名称" />
        </FormItem>
        <FormItem label="排序">
          <InputNumber :min="0" v-model="uselist.sort" placeholder="请输入配菜排序" />
        </FormItem>
      </Form>
    </Modal>
  </div>
</template>

<script>
import {
  listProductSideDish,
  delProductSideDish,
  saveProductSideDish
} from '@/api/shop/shopProductGarnish'
export default {
  data() {
    return {
      searchInfo: '',
      columns: [
        { key: 'id', title: 'ID', width: 80 },
        { key: 'name', title: '备注名称·' },
        {
          key: 'price',
          title: '价格(元)',
          width: 130,
          render: (h, params) => {
            return h('div', [h('p', params.row.price + ' ' + '元')])
          }
        },
        { key: 'sort', title: '排序', width: 80 },
        {
          title: '操作',
          key: 'action',
          align: 'center',
          width: 130,
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.uselist = JSON.parse(JSON.stringify(params.row))
                      this.isedit = 'edit'
                      this.editarr.show = true
                      this.editarr.title = '编辑配菜'
                    }
                  }
                },
                '编辑'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.delboxshow = true
                      this.uselist = JSON.parse(JSON.stringify(params.row))
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      shopData: [],
      delboxshow: false,
      resdata: {
        sort: {
          sort: 'desc'
        },
        page: 1,
        rows: 10,
        name: '',
        total: ''
      },
      uselist: {},
      editarr: {
        show: false,
        title: ''
      },
      isedit: '',
      ruleValidate: {
        name: [
          {
            required: true,
            message: 'The name cannot be empty',
            trigger: 'blur'
          }
        ]
      }
    }
  },
  methods: {
    del() {
      const data = { id: this.uselist.id }
      delProductSideDish(data).then(res => {
        this.getlist()
        this.delboxshow = false
        this.$Notice.success({
          title: res.data.message
        })
        this.uselist = {}
      })
    },
    getlist(type) {
      if (type) {
        this.resdata.page = 1
      }
      listProductSideDish(this.resdata).then(res => {
        this.shopData = res.data.data.list
        this.resdata.total = res.data.data.total
      })
    },
    avgPage(v) {
      this.resdata.page = v
      this.getlist()
    },
    addshow() {
      this.uselist = {}
      this.isedit = 'arr'
      this.editarr.title = '添加配菜'
      this.editarr.show = true
    },
    // 添加 & 删除
    edit(type) {
      console.log(this.uselist.name, this.uselist.price)
      if (type === 'edit') {
        if (this.uselist.name == '' && this.uselist.price == '') {
          this.$Message.error('名称或者价格不得为空')
          this.editarr.show = true
        } else {
          saveProductSideDish(this.uselist).then(res => {
            this.$Message.success(res.data.message)
            this.getlist()
          })
        }
      } else {
        if (this.uselist.name == undefined && this.uselist.price == undefined) {
          this.$Message.error('名称或者价格不得为空')
          this.editarr.show = true
        } else {
          console.log(this.uselist, 'user')
          saveProductSideDish(this.uselist).then(res => {
            this.$Message.success(res.data.message)
            this.getlist()
          })
        }
      }
    }
  },
  mounted() {
    this.getlist()
  }
}
</script>

<style scope>
@import url('./product-remarks.less');
</style>
