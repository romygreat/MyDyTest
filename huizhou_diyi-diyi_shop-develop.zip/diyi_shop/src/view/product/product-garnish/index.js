import ProductGarnish from './product-garnish'
export default ProductGarnish
