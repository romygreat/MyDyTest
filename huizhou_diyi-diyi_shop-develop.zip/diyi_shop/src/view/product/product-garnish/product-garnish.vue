<template>
  <div>
    <ListPage
      title="配菜列表"
      desc="在这里可以浏览到您店铺所有商品支持的配菜"
      ref="list_page"
      :route_edit="{name: 'product-garnish' }"
      data_url="/Product/ProductSideDish/listProductSideDish"
      save_url="/Product/ProductSideDish/saveProductSideDish"
      del_url="/Product/ProductSideDish/delProductSideDish"
      :search_params="search_params"
      :columns="table_columns"
      :width="String(600)"
    >
      <template slot="action">
        <Button type="primary" style="margin-bottom: 15px;" @click="addshow">
          <Icon type="md-add" />
          <span>添加配菜</span>
        </Button>
      </template>
    </ListPage>
    <Modal v-model="editarr.show" :title="editarr.title" @on-ok="edit(isedit)" width="350">
      <Form ref="editRuleValidate" :model="uselist" :rules="editRuleValidate" :label-width="80">
        <FormItem label="名称" prop="name">
          <Input :maxlength='40' style="width:150px" v-model="uselist.name" placeholder="请输入配菜名称" />
        </FormItem>
        <FormItem label="价格" prop="price">
          <Input id="price-input" style="width:150px" v-model="uselist.price" placeholder="请输入配菜价格" />
        </FormItem>
        <FormItem label="排序">
          <InputNumber :min="0" v-model="uselist.sort" placeholder="请输入配菜排序" />
        </FormItem>
      </Form>       
    </Form>
    </Modal>
    <Modal v-model="delboxshow" width="360">
      <p slot="header" style="color:#f60;text-align:center">
        <Icon type="ios-information-circle"></Icon>
        <span>删除配菜</span>
      </p>
      <div style="text-align:center">
        <p>当前正常进行删除配菜操作</p>
        <p>您确认删除吗?</p>
      </div>
      <div slot="footer">
        <Button type="error" long size="large" @click="del">删除</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import {
  listProductSideDish,
  delProductSideDish,
  saveProductSideDish
} from "@/api/shop/shopProductGarnish";
import ListPage from "@/components/list-page";
import { getStautsText, convertPrice } from "@/libs/tools";
import tableColumns from "./table_columns";
export default {
  naem: "product-practice",
  data() {
    var price=function(rule, value, callback){
    if (!value) {
        return callback(new Error('价格不能为空'));
    } else if(value){
      if (!Number(value)) {
      console.log(Number(value),value);
      callback(new Error('价格必须数字'));
        
      }
    }else{
        callback();
    }
};
    return {
      search_params: { name: "", status: "" },
      activityStatusList: [],
      editarr: {
        show: false,
        title: ""
      },
      isedit: "",
      uselist: {
      },
      refresh: false,
      delboxshow: false,
      
      table_columns: [
        { key: "id", title: "ID", width: 80 },
        { key: "name", title: "配菜名称" },
        {
          key: "price",
          title: "价格(元)",
          width: 130,
          render: (h, params) => {
            return h("div", [
              h("p", convertPrice(params.row.price) + " " + "元")
            ]);
          }
        },
        { key: "sort", title: "排序", width: 80 },
        {
          title: "操作",
          key: "action",
          align: "center",
          width: 130,
          render: (h, params) => {
            return h("div", [
              h(
                "Button",
                {
                  props: {
                    type: "primary",
                    size: "small"
                  },
                  style: {
                    marginRight: "5px"
                  },
                  on: {
                    click: () => {
                      this.uselist = JSON.parse(JSON.stringify(params.row));
                      this.uselist.price = Number(
                        convertPrice(this.uselist.price)
                      );
                      this.uselist.sort = Number(this.uselist.sort);
                      this.isedit = "edit";
                      this.editarr.show = true;
                      this.editarr.title = "编辑配菜";
                    }
                  }
                },
                "编辑"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "error",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.delboxshow = true;
                      this.uselist = JSON.parse(JSON.stringify(params.row));
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ],
      editRuleValidate: {
        name: [
          { required: true, message: '名称不能为空', trigger: 'blur' }
        ],
        price: [
          { required: true, message: '价格不能为空', trigger: 'blur' },
          { validator: price,trigger: 'blur'}
          
        ]
      },
    }
  },
  components: {
    ListPage
  },
  methods: {
    addshow() {
      this.uselist = {};
      this.isedit = "arr";
      this.editarr.title = "添加配菜";
      this.uselist.sort = 0
      this.editarr.show = true;
      console.log(this.uselist.price,'jia1');
      
      // this.uselist.price = 0
      // this.uselist.price = Number(this.uselist.price)
    },
    edit(type) {
      if (type === "edit") {
        if (this.uselist.name == "" || this.uselist.price == "") {
          this.$Message.error("名称或者价格不得为空");
          return;
        } else {
          this.uselist.price = convertPrice(this.uselist.price, "fen");
          saveProductSideDish(this.uselist).then(res => {
            this.$Message.success(res.data.message);
            this.$refs.list_page.getList(1);
          });
        }
      } else {
        if (this.uselist.name == undefined || this.uselist.price == undefined) {
          this.$Message.error("名称或者价格不得为空");
          return;
        } else {
          this.uselist.price = convertPrice(this.uselist.price, "fen");
          saveProductSideDish(this.uselist).then(res => {
            this.$Message.success(res.data.message);
            this.$refs.list_page.getList(1);
          });
        }
      }
    },
    del() {
      const data = { id: this.uselist.id };
      delProductSideDish(data).then(res => {
        this.$refs.list_page.getList(1);
        this.delboxshow = false;
        this.$Notice.success({
          title: res.data.message
        });
        this.uselist = {};
      });
    },
    getChange(){
      console.log('cahnmge',this.uselist.price,this.$refs.editRuleValidate.validateField('edit_price'));      
    }
  }
};
</script>

<style lang="less">
#price-input{
  .ivu-icon-ios-loading:before{
    display: none;
  }
}
</style>
