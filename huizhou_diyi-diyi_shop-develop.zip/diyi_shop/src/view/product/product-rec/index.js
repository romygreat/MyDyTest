import ProductRec from './product-rec'
export default ProductRec
