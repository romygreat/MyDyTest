<template>
  <div>
    <hgroup class="shopC-title">
      <h3>商品回收站</h3>
      <p>可以恢复删除的商品或者永久删除</p>
    </hgroup>
    <!-- shopClassify search -->
    <div class="shopClass-search">
      <p class="shopClass-title">快速查找：</p>
      <Input
      :maxlength='40'
        clearable
        v-model="searchInfo"
        icon="search"
        placeholder="输入你要查询的商品编号或者名称"
        style="width: 250px; display: inline-block"
      />
      <Button style="display: inline-block; margin:0 0 0 15px;  " @click="search" type="primary">搜索</Button>
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="searchInfo='';search()"
        type="warning"
      >刷新</Button>
    </div>
    <!-- shopClass Tables -->
    <Table
      @on-select="allLaunch"
      @on-select-all="allLaunchs"
      ref="selection"
      border
      :columns="columns"
      :data="shopData"
      stripe
    ></Table>
    <!-- <div style="margin-top:20px;"  >
            <Button class="ml-20" type="primary" @click="handleSelectAll(true)">设置全选</Button>
            <Button type="primary" @click="handleSelectAll(false)">取消全选</Button>
            <Page
              show-elevator
              show-total
              :total="Number(pageData.total)"
              :current='Number(pageData.current)'
              :page-size=' Number(pageData.rows)'
              @on-change='getShopData'
              class="page-buttom"
            >
            </Page>
    </div>-->
    <div class="oper-Buttom">
      <Button type="warning" @click="allreduc">批量还原</Button>
      <!-- <Button type="error" @click="alldel">批量删除</Button> -->
      <Page
        show-total
        show-elevator
        :total="Number(pageData.total)"
        :current="Number(pageData.current)"
        :page-size=" Number(pageData.rows)"
        @on-change="getShopData"
        class="page-buttom"
      ></Page>
    </div>
    <!-- operation -->
  </div>
</template>

<script>
import { deloperationButtom, getShopDataButtominfo } from '@/api/shop/shopList'
import { restoreButtom } from '@/api/shop/shopRec'
import { getQnDomain } from '@/libs/upload'
export default {
  data() {
    return {
      // tablse
      columns: [
        {
          type: 'selection',
          width: 60,
          align: 'center'
        },
        {
          title: 'ID',
          key: 'id',
          align: 'center'
        },
        {
          title: '产品编号',
          key: 'code',
          align: 'center'
        },
        {
          title: '商品图片',
          key: 'pic',
          align: 'center',
          render: (h, params) => {
            if (params.row.pic) {
              return h('div', [
                h('img', {
                  attrs: {
                    src: params.row.pic
                  },
                  style: {
                    width: '40px',
                    height: '40px',
                    display: 'block',
                    margin: '0 auto'
                  }
                })
              ])
            } else {
              return h('div', '无')
            }
          }
        },
        {
          title: '产品名称',
          key: 'name',
          align: 'center'
        },
        {
          title: '所属分类',
          key: 'cate_name',
          align: 'center'
        },
        {
          title: '单位',
          key: 'unit',
          align: 'center'
        },
        {
          title: '价格',
          key: 'price',
          align: 'center',
          render: (h, params) => {
            return h('div', [h('p', params.row.price + ' ' + '元')])
          }
        },
        {
          title: '排序',
          key: 'sort',
          align: 'center'
        },
        {
          title: '是否估清',
          key: 'is_limit',
          align: 'center'
        },
        {
          title: '估清数',
          key: 'limit_num',
          align: 'center'
        },
        {
          title: '是否上架',
          key: 'is_sale',
          align: 'center',
          render: (h, params) => {
            return h('i-switch', {
              props: {
                type: 'primary',
                disabled: true,
                value: params.row.is_sale == 1
              },
              on: {
                'on-change': value => {
                  if (value == true) {
                    params.row.is_sale = 1
                  } else {
                    params.row.is_sale = 0
                  }
                }
              }
            })
          }
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.show(params.index)
                    }
                  }
                },
                '还原'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                    }
                  }
                },
                '彻底删除'
              )
            ])
          }
        }
      ],
      // tablse data
      shopData: [],
      // page
      pageData: {
        total: '20',
        current: '1',
        rows: '10'
      },
      // add && edit
      operation: {
        operShow: false,
        operTitle: '',
        loading: false,
        // data
        cate_id: '',
        name: '',
        code: '',
        describe: '',
        price: '',
        market_price: '',
        pic: '',
        is_sale: '',
        is_limit: '',
        limit_num: '',
        remark: '',
        unit: '',
        id: '',
        cate_name: ''
      },
      searchInfo: '',
      idenswitch: '',
      allShopinfo: ''
    }
  },
  methods: {
    //  获取列表
    getShopData(value) {
      if (value) {
        this.pageData.current = value
      }
      const data = {
        page: this.pageData.current,
        rows: this.pageData.rows,
        trashed: 1
      }
      getShopDataButtominfo(data)
        .then(res => {
          getQnDomain().then(domain => {
            res.data.data.list.forEach(item => {
              if (item.pic) item.pic = domain + '/' + item.pic
            })
            this.shopData = res.data.data.list
            this.pageData.total = res.data.data.total
          })
        })
        .catch(err => {
          console.error(err)
        })
    },
    // 全选
    handleSelectAll(status) {
      this.$refs.selection.selectAll(status)
    },
    // 还原buttom
    show(index) {
      this.$Modal.confirm({
        title: '还原删除',
        content: '<p>确认还原删除？</p>',
        onOk: () => {
          const data = {
            id: this.shopData[index].id,
            del: 1
          }
          restoreButtom(data).then(res => {
            this.getShopData()
          })
          this.$Message.info('已经还原')
        },
        onCancel: () => {
          this.$Message.info('取消了还原删除操作')
        }
      })
    },
    // 删除buttom
    remove(index) {
      this.$Modal.confirm({
        title: '彻底删除',
        content: '<p>确认彻底删除？</p>',
        onOk: () => {
          const data = {
            id: this.shopData[index].id,
            del: 1
          }
          deloperationButtom(data).then(res => {
            this.getShopData()
          })
          this.$Message.info('已经删除')
        },
        onCancel: () => {
          this.$Message.info('取消了彻底删除操作')
        }
      })
    },
    allLaunch(data) {
      var Launch = []
      for (let i = 0; i < data.length; i++) {
        Launch.push(data[i].id)
      }
      this.allShopinfo = Launch.join(',')
    },
    allLaunchs(data) {
      var Launchs = []
      for (let i = 0; i < data.length; i++) {
        Launchs.push(data[i].id)
      }
      this.allShopinfo = Launchs.join(',')
    },
    alldel() {
      this.$Modal.confirm({
        title: '批量彻底删除',
        content: '<p>确认批量彻底删除？</p>',
        onOk: () => {
          const data = {
            id: this.allShopinfo,
            del: 1
          }
          deloperationButtom(data).then(res => {
            this.getShopData()
          })
          this.$Message.info('已经批量删除')
        },
        onCancel: () => {
          this.$Message.info('取消了批量彻底删除操作')
        }
      })
    },
    allreduc() {
      this.$Modal.confirm({
        title: '批量还原',
        content: '<p>确认将删除的批量还原？</p>',
        onOk: () => {
          const data = {
            id: this.allShopinfo,
            del: 1
          }
          restoreButtom(data).then(res => {
            this.getShopData()
          })
          this.$Message.info('已经批量还原')
        },
        onCancel: () => {
          this.$Message.info('取消了批量还原删除操作')
        }
      })
    },
    // 查询
    search() {
      this.pageData.current = 1
      const data = {
        page: this.pageData.current,
        rows: this.pageData.rows,
        search: this.searchInfo,
        trashed: 1
      }
      getShopDataButtominfo(data)
        .then(res => {
          getQnDomain().then(domain => {
            res.data.data.list.forEach(item => {
              if (item.pic) item.pic = domain + '/' + item.pic
            })
            this.shopData = res.data.data.list
            this.pageData.total = res.data.data.total
          })
        })
        .catch(err => {
          console.error(err)
        })
    }
  },
  mounted() {
    this.getShopData()
  }
}
</script>
<style>
@import './product-rec.css';
</style>
