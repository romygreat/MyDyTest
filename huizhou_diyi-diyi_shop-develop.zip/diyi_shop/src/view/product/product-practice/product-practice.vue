<template>
  <div>
    <ListPage
      title="做法列表"
      desc="在这里可以浏览到您店铺所有商品支持的做法"
      ref="list_page"
      :route_edit="{name: 'product-practice' }"
      data_url="/product/ProductProcedure/list"
      save_url="/product/ProductProcedure/dataSet"
      del_url="/product/ProductProcedure/delete"
      :search_params="search_params"
      :columns="table_columns"
      :width="String(600)"
    >
      <template slot="action">
        <Button type="primary" style="margin-bottom: 15px;" @click="addshow">
          <Icon type="md-add" />
          <span>添加做法</span>
        </Button>
      </template>
    </ListPage>
    <Modal v-model="editarr.show" :title="editarr.title" @on-ok="edit(isedit)" width="350">
      <Form :label-width="80" ref="uselist" :model="uselist" :rules="ruleValidate">
        <FormItem label="名称" prop="name">
          <Input :maxlength='40' style="width:150px" v-model="uselist.name" placeholder="请输入做法名称" />
        </FormItem>
        <FormItem label="价格" prop="price">
          <InputNumber
            :min="0"
            style="width:150px"
            v-model="uselist.proces_price"
            placeholder="请输入做法价格"
          />
        </FormItem>
        <FormItem label="排序">
          <InputNumber :min="0" v-model="uselist.sort" placeholder="请输入配菜排序" />
        </FormItem>
      </Form>
    </Modal>
    <Modal v-model="delboxshow" width="360">
      <p slot="header" style="color:#f60;text-align:center">
        <Icon type="ios-information-circle"></Icon>
        <span>删除配菜</span>
      </p>
      <div style="text-align:center">
        <p>当前正常进行删除配菜操作</p>
        <p>您确认删除吗?</p>
      </div>
      <div slot="footer">
        <Button type="error" long size="large" @click="del">删除</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import ListPage from "@/components/list-page";
import { getStautsText, convertPrice } from "@/libs/tools";
import { dataSet, deletePrac } from "@/api/shop/shopPractice";
import { log } from "util";
export default {
  naem: "product-practice",
  data() {
    return {
      isedit: "",
      uselist: {
        proces_price: 1
      },
      editarr: {
        show: false,
        title: ""
      },
      delboxshow: false,
      search_params: {},
      table_columns: [
        { key: "id", title: "ID", width: 80 },
        { key: "name", title: "做法名称·" },
        {
          key: "proces_price",
          title: "加工费",
          width: 130,
          render: (h, params) => {
            return h("div", [
              h("p", `${convertPrice(params.row.proces_price)} 元`)
            ]);
          }
        },
        { key: "sort", title: "排序", width: 80 },
        {
          title: "操作",
          key: "action",
          align: "center",
          width: 130,
          render: (h, params) => {
            return h("div", [
              h(
                "Button",
                {
                  props: {
                    type: "primary",
                    size: "small"
                  },
                  style: {
                    marginRight: "5px"
                  },
                  on: {
                    click: () => {
                      this.uselist = JSON.parse(JSON.stringify(params.row));
                      this.uselist.proces_price = Number(
                        convertPrice(this.uselist.proces_price)
                      );
                      this.uselist.sort = Number(this.uselist.sort);
                      this.isedit = "edit";
                      this.editarr.show = true;
                      this.editarr.title = "编辑做法";
                    }
                  }
                },
                "编辑"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "error",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.delboxshow = true;
                      this.uselist = JSON.parse(JSON.stringify(params.row));
                      this.uselist.sort = Number(
                        JSON.parse(JSON.stringify(params.row)).sort
                      );
                    }
                  }
                },
                "删除"
              )
            ]);
          }
        }
      ],
      ruleValidate:{
        name:[{ required: true, message: '做法名称不能为空', trigger: 'blur' }],
        price:[{ required: true, type:'number', message: '做法价格不能为空', trigger: 'blur' }]
      }
    }
  },
  components: {
    ListPage
  },
  methods: {
    addshow() {
      this.uselist = { proces_price: 0 };
      this.isedit = "arr";
      this.editarr.title = "添加做法";
      this.editarr.show = true;
      this.uselist.sort = 0
    },
    edit(type) {
      if (type === "edit") {
        if (this.uselist.name == "" || this.uselist.proces_price == "") {
          this.$Message.error("名称或者价格不得为空");
          return;
        } else {
          this.uselist.proces_price = Number(
            convertPrice(this.uselist.proces_price, "fen")
          );
          dataSet(this.uselist).then(res => {
            this.$Message.success(res.data.message);
            this.$refs.list_page.getList(1);
          });
        }
      } else {
        if (
          this.uselist.name == undefined ||
          this.uselist.proces_price == undefined
        ) {
          this.$Message.error("名称或者价格不得为空");
          return;
        } else {
          this.uselist.proces_price = Number(
            convertPrice(this.uselist.proces_price, "fen")
          );
          dataSet(this.uselist).then(res => {
            this.$Message.success(res.data.message);
            this.$refs.list_page.getList(1);
          });
        }
      }
    },
    del() {
      const data = { id: this.uselist.id };
      deletePrac(data).then(res => {
        this.$refs.list_page.getList(1);
        this.delboxshow = false;
        this.$Notice.success({
          title: res.data.message
        });
        this.uselist = {};
      });
    }
  }
};
</script>

<style>
</style>
