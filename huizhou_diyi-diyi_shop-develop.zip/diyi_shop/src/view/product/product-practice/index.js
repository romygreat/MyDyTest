import ProductPractice from './product-practice'
export default ProductPractice
