import ProductCate from './product-cate.vue'
export default ProductCate
