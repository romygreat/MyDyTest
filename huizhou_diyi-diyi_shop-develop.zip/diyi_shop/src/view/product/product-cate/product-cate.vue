<template>
  <div>
    <hgroup class="shopC-title">
      <h3>品项分类</h3>
      <p>请为您店内的商品仔细分类，以便于在客户端精确查找，排序号越小，显示位置越靠前</p>
    </hgroup>
    <!-- shopClassify search -->
    <div class="shopClass-search">
      <p class="shopClass-title">分类名称：</p>
      <Input
        :maxlength="40"
        clearable
        v-model="requestParam.name"
        icon="search"
        placeholder="输入你要查询的品项分类"
        style="width: 200px; display: inline-block"
      />
      <Button style="display: inline-block; margin:0 0 0 15px;  " @click="search" type="primary">搜索</Button>
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="requestParam.name='';search()"
        type="warning"
      >刷新</Button>
    </div>
    <!-- add shopClassify buttom -->
    <Button type="primary" style="margin-bottom: 15px;" @click="showEdit('add')">
      <span>
        <Icon type="md-add" />
        <span>新增分类</span>
      </span>
    </Button>
    <!-- shopClass Tables -->
    <Table :width="900" ref="selection" border :columns="columns" :data="cateList" stripe></Table>
    <div style="margin-top:20px; width:900px;">
      <!-- <Button class="ml-20" type="primary" @click="handleSelectAll(true)">设置全选</Button>
      <Button type="primary" @click="handleSelectAll(false)">取消全选</Button>-->
      <Page
        :current="requestParam.page"
        :page-size="requestParam.rows"
        show-total
        show-elevator
        :total="Number(pageTotal)"
        @on-change="getPageList"
        class="page-buttom"
      ></Page>
    </div>
    <!-- editCate -->
    <Modal v-model="isShowEdit" :title="editTitle" :footer-hide="true" width="450">
      <Form ref="editCate" :model="editCate" :rules="ruleValidate" :label-width="80">
        <FormItem label="分类名" prop="name">
          <Input
            :maxlength="40"
            v-model="editCate.name"
            placeholder="请输入分类名"
            style="width: 200px;"
          />
        </FormItem>
        <FormItem label="排序" prop="sort">
          <Input :maxlength="40" v-model="editCate.sort" placeholder="请输入排序" style="width: 110px;" />
        </FormItem>
        <FormItem label="分类图片">
          <input type="hidden" v-model="editCate.path" />
          <Upload action="/" :before-upload="beforeUpload">
            <Button icon="ios-cloud-upload-outline">请选择图片</Button>
          </Upload>
          <img v-show="imgPath" :src="imgPath" width="200" />
          <Button @click="clearimg(editCate.path)" v-show="imgPath" type="error">删除图片</Button>
        </FormItem>
        <FormItem>
          <Button type="primary" @click="handleSubmit('editCate')">确认</Button>
          <Button @click="isShowEdit = false" style="margin-left: 8px">取消</Button>
        </FormItem>
      </Form>
    </Modal>
  </div>
</template>

<script>
import { getQnDomain, upload } from '@/libs/upload'
import {
  deloperationButtom,
  operationButtom,
  getShopDataButtom
} from '@/api/shop/shopClassify'
import { getToken } from '@/libs/util'
import './index.less'
export default {
  data() {
    return {
      columns: [
        {
          title: 'ID',
          key: 'id',
          align: 'center'
        },
        {
          title: '分类名称',
          key: 'name',
          align: 'center'
        },
        {
          title: '图片',
          key: 'path',
          align: 'center',
          render: (h, params) => {
            if (params.row.path.trim()) {
              return h('div', [
                h('img', {
                  attrs: {
                    src: params.row.path
                  },
                  style: {
                    width: '40px',
                    height: '40px',
                    display: 'block',
                    margin: '0 auto'
                  }
                })
              ])
            } else {
              return h('div', '无')
            }
          }
        },
        // {
        //   title: '状态',
        //   key: 'store'
        // },
        {
          title: '排序',
          key: 'sort',
          align: 'center'
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.showEdit('edit', params.index)
                    }
                  }
                },
                '编辑'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      cateList: [],
      pageTotal: 0,
      requestParam: {
        name: '',
        page: 1,
        rows: 10,
        sort: { sort: 'asc', id: 'asc' }
      },
      editCate: {},
      ruleValidate: {
        name: [
          { required: true, message: '分类名不能为空', trigger: 'blur' },
          { min: 2, message: '名称不能低于两个字', trigger: 'blur' }
        ]
      },
      // 上传
      isShowEdit: false,
      editTitle: '',
      imgPath: ''
    }
  },
  methods: {
    //  获取列表
    getCateList(type) {
      if (type) {
        this.requestParam.page = 1
      }
      getShopDataButtom(this.requestParam)
        .then(res => {
          getQnDomain().then(domain => {
            res.data.data.list.forEach(item => {
              if (item.path) item.path = domain + '/' + item.path
            })
            this.cateList = res.data.data.list
            this.pageTotal = res.data.data.total
          })
        })
        .catch(err => {
          console.error(err)
        })
    },
    // 分页
    getPageList(page) {
      this.requestParam.page = page
      this.getCateList()
    },
    // 添加|编辑buttom
    showEdit(type, index) {
      this.isShowEdit = true
      this.imgPath = ''
      this.editCate = {}
      if (type == 'add') {
        this.editTitle = '添加分类'
        this.editCate.sort = 0
      } else {
        this.editTitle = '编辑分类'
        this.editCate = Object.assign({}, this.cateList[index])
        this.imgPath = this.editCate.path
      }
    },
    // 删除buttom
    remove(index) {
      this.$Modal.confirm({
        title: '彻底删除',
        content: '<p>确认彻底删除？</p>',
        onOk: () => {
          const data = {
            id: this.cateList[index].id
          }
          deloperationButtom(data).then(res => {
            this.getCateList()
          })
          this.$Message.info('已经删除')
        },
        onCancel: () => {
          this.$Message.info('取消了彻底删除操作')
        }
      })
    },
    // 添加 && 修改
    handleSubmit(name) {
      this.$refs[name].validate(async valid => {
        if (valid) {
          await getQnDomain().then(domain => {
            if (
              this.editCate.path &&
              this.editCate.path.indexOf(domain) !== -1
            ) {
              this.editCate.path = this.editCate.path.substring(
                domain.length + 1
              )
            }
          })
          operationButtom(this.editCate)
            .then(res => {
              this.$Message.success(res.data.message)
              this.getCateList()
              this.isShowEdit = false
            })
            .catch(err => {
              this.$Message.success(err)
            })
        } else {
          this.$Message.error('请按规则填写提交')
        }
      })
    },
    // 查询【暂时】
    search() {
      this.getCateList(true)
    },
    // 上传
    beforeUpload(file) {
      let fileIndex = 'file'
      if (file.type.indexOf('image') !== 0) {
        this.$Message.info({
          content: '请上传图片文件',
          duration: 5,
          closable: true
        })
      } else if (file.size > 2 * 1024 * 1024) {
        this.$Message.info({
          content: '文件大小不能大于2M',
          duration: 5,
          closable: true
        })
      } else {
        let param = new FormData() // 创建form对象
        param.append(fileIndex, file) // 通过append向form对象添加数据
        param.append('token', getToken())
        param.append('machine', 'shop')
        upload(param).then(res => {
          if (res.code == 1) {
            getQnDomain().then(domain => {
              this.editCate.path = domain + '/' + res.data[fileIndex].url
              this.imgPath = this.editCate.path
              console.log('this.editCate.path', this.editCate.path)
            })
          }
        })
      }
      return false
    },
    clearimg(imgshow) {
      this.editCate.path = ''
      this.imgPath = false
    }
  },
  mounted() {
    this.getCateList()
  }
}
</script>
<style>
@import './product-cate.css';
</style>
