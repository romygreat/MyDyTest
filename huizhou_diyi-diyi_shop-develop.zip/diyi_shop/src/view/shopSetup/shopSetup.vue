<template>
  <div>
    <hgroup class="shopC-title">
      <h3>门店设置</h3>
      <p>设置门店的基本属性</p>
    </hgroup>
    <Tabs style="margin-top:15px" value="name1">
      <TabPane label="基本设置" name="name1">
        <Form :label-width="120">
          <FormItem label="打印设置">
            <RadioGroup v-model="formValidate.shop_set.print_set" >
                <Radio v-for="(item, index) in printetKey"  :key="index" :label="item.value">{{item.name}}</Radio>
            </RadioGroup>
          </FormItem>
          <FormItem label="是否提示语音">
            <i-switch v-model="opirs" size="large">
              <span slot="open">开</span>
              <span slot="close">关</span>
            </i-switch>
          </FormItem>
          <FormItem label="开台必点">
            <ProductSwitch
              v-if="product_bindShow"
              :product_bind="product_bind"
              v-on:garProduct="garProduct($event)"
              style="width:200px"
            />
          </FormItem>
          <FormItem label="是否开启服务费">
            <i-switch v-model="serviceCharge" size="large">
              <span slot="open">开</span>
              <span slot="close">关</span>
            </i-switch>
            <InputNumber
              style="width:80px;margin-left:20px;"
              :min="0"
              v-if="serviceCharge"
              v-model="formValidate.shop_set.service_price"
              placeholder="请输入每人收费金额"
            />
            <span style="margin-left:10px;display: inline-block;transform: translateY(2px);">元</span>
          </FormItem>
          <FormItem label="是否开启餐具收费">
            <i-switch v-model="tablewareShow" size="large">
              <span slot="open">开</span>
              <span slot="close">关</span>
            </i-switch>
            <InputNumber
              style="width:80px;margin-left:20px;"
              v-if="tablewareShow"
              :min="0"
              v-model="formValidate.shop_set.tableware_fee"
              placeholder="请输入纸巾收费金额"
            />
            <span style="margin-left:10px;display: inline-block;transform: translateY(2px);">元</span>
          </FormItem>
          <FormItem label="支付方式">
            <CheckboxGroup v-model="checkboxArr">
              <Checkbox
                v-for="(item,index) in statusList"
                :key="index"
                :label="item.key"
                style="margin-left:10px"
              >{{item.name}}</Checkbox>
            </CheckboxGroup>
          </FormItem>
          <FormItem label="清台密码" prop="pwd">
            <Input
              style="width:200px"
              type="password"
              v-model="formValidate.shop_set.pwd"
              placeholder="默认初始密码为123456"
            />
            <span style="display:inline-block;font-size:10px;color:#C9C8CE;margin-left:12px;">提示：初始密码是：123456</span>
          </FormItem>
          <FormItem>
            <Button type="primary" @click="handleSubmit()">确定</Button>
          </FormItem>
        </Form>
      </TabPane>
      <TabPane label="支付设置" name="name2">
        <Form :label-width="90">
          <FormItem label="商户号" prop="merchantid">
            <Input
            :maxlength='40'
              :rows="1"
              :autosize="{minRows: 1,maxRows: 1}" 
              type="textarea"
              style="width:350px"
              v-model="formValidate.pay_set.merchantid"
              placeholder="请输入商户号"
            />
          </FormItem>
          <FormItem label="柜台代码" prop="posid">
            <Input    :autosize="{minRows: 1,maxRows: 1}"  :rows="1" type="textarea" style="width:350px; " v-model="formValidate.pay_set.posid" placeholder="请输入柜台代码" />
          </FormItem>
          <FormItem label="分行代码" prop="branchid">
            <Input
              :autosize="{minRows: 1,maxRows: 1}" 
              type="textarea"
              :rows="1"
              style="width:350px"
              v-model="formValidate.pay_set.branchid"
              placeholder="请输入分行代码"
            />
          </FormItem>
          <FormItem label="商户公钥" prop="public">
            <Input
              :autosize="{minRows: 8,maxRows: 8}" 
              type="textarea"
              :rows="5"
              style="width:350px"
              v-model="formValidate.pay_set.public"
              placeholder="请输入密钥后30位"
            />
          </FormItem>
          <FormItem>
            <Button type="primary" @click="setPayOpen()">确定</Button>
          </FormItem>
        </Form>
      </TabPane>
    </Tabs>
    <!-- <Button type="primary" @click="handleSubmit('formValidate')">确定</Button> -->
  </div>
</template>

<script>
import { getPayButtom, setPayButtom,setShop, getShop } from '../../api/shopSetup/shopSetup.js'
import { getToken } from '@/libs/util'
import { getStautsText, convertPrice } from "@/libs/tools.js";
import { cloneArray } from '@/libs/util.js'
import ProductSwitch from './components/productSwitch'
export default {
  components: { ProductSwitch },
  data() {
    return {
      // fruit: [],
      // fruitList: [{ key: 1, name: '苹果' }, { key: 2, name: '香蕉' }],
      //
      formValidate: {
        pay_set: {
          branchid: '',
          merchantid: '',
          posid: '',
          public: '',
          shop_id: ''
        },
        shop_set: {
          charge_price: '',
          charge_time: '',
          is_invoice: '',
          is_print: '',
          is_voice: '',
          pwd: '',
          salt: '',
          shop_id: '',
          ticket_head: '',
          ticket_tail: '',
          checkbox: [],
          tableware_fee: 0,
          service_price: 0,
          towel_fee: 0,
          print_set:1
        }
      },
      opirs: false,
      serviceCharge: false,
      tablewareShow: false,
      iftiem: '',
      statusList: [],
      checkboxArr: [],
      product_bind: '',
      product_bindShow: false,
      printetKey:[
        {name:'关闭',value:0},
        {name:'打印所有',value:1},
        {name:'只打印前台',value:2}
      ],
      sdk:'1'
    }
  },
  methods: {
    //  获取初始商户支付信息
    async getPay() {
          let resj = await getPayButtom()
          if (resj.data.data != null) {
            this.formValidate.pay_set = resj.data.data
          }
    },
    // 获取商户初始设置
    async setPay(){
          let res = await getShop({})
          if (res.data.data != null) {
            this.formValidate.shop_set = res.data.data
            this.product_bind = this.formValidate.shop_set.product_bind
            this.formValidate.shop_set.is_voice == 1
              ? (this.opirs = true)
              : (this.opirs = false)
            this.iftiem = this.formValidate.shop_set.charge_time
            if (res.data.data.pay_action.length) {
              this.checkboxArr = this.formValidate.shop_set.pay_action.split(
                ','
              )
            } else {
              this.formValidate.shop_set.checkbox = []
            }
            if (res.data.data.is_service) {
              res.data.data.is_service == 1
                ? (this.serviceCharge = true)
                : (this.serviceCharge = false)
            }
            this.formValidate.shop_set.service_price = Number(
                res.data.data.service_price / 100
            )
            if (res.data.data.is_tableware) {
              res.data.data.is_tableware == 1
                ? (this.tablewareShow = true)
                : (this.tablewareShow = false)
            }
            this.formValidate.shop_set.tableware_fee = Number(
              res.data.data.tableware_fee / 100
            )
            this.product_bindShow = true
          }
    },
    // 修改基本设置
    async handleSubmit() {
      let arr = this.formValidate
      const data = {
        service_price: convertPrice(arr.shop_set.service_price, "fen"),
        towel_fee: convertPrice(arr.shop_set.towel_fee, "fen"),
        tableware_fee: convertPrice(arr.shop_set.tableware_fee, "fen"),
        is_service: this.serviceCharge === true ? 1 : 0,
        is_tableware: this.tablewareShow === true ? 1 : 0,
        is_voice: this.opirs == true ? 1 : 0,
        product_bind: this.product_bind,
        print_set:arr.shop_set.print_set,
        pay_action: this.checkboxArr.join(','),
        is_reserve:1,
        pwd:arr.shop_set.pwd
      }
      await setShop(data)
        .then(res => {
          this.setPay()
          this.$Message.info(res.data.message)
        })
        .catch(err => {
          this.$Message.error('设置失败,请联系管理员')
        })
    },
    // 修改银行支付设置
    async setPayOpen(){
      let res = await setPayButtom(this.formValidate.pay_set)
      if(res.data.code === 1) {
         this.$Message.info('设置成功')
         this.getPay()
      } else {
        this.$Message.error('设置失败,请联系管理员')
      }
    },
    garProduct(res) {
      this.product_bind = res.join(',')
    }
  },
  mounted() {
    this.getPay()
    this.setPay()
  },
  created() {
    let arr = getStautsText('order.pay_action')
    this.statusList = []
    for (let i in arr) {
      let obj = { key: i, name: arr[i] }
      this.statusList.push(obj)
    }
  }
}
</script>

<style>
.ivu-tabs {
  min-height: 460px !important;
}
.fromTitle {
  display: block;
  font-size: 20px;
  font-weight: bold;
  padding-bottom: 15px;
}
.timedivinfo {
  position: relative;
  width: 45px;
}
.timedivinfo p {
  position: absolute;
  right: -25px;
  top: 0px;
  font-size: 16px;
  font-weight: bold;
  color: #515a6e;
  /* font-family: 'Sans-serif'; */
}
.timedivinfo input {
  border-radius: 5px;
  border: none;
  width: 45px;
  text-align: center;
}
@import '../order/orderList/orderList.css';
</style>
