<template>
  <div style="width:200px">
    <div style="margin-left:10px;">
      <Select
        @on-query-change="remotenull"
        @on-change="sdkinfo"
        v-model="selectinfo"
        multiple
        filterable
        remote
        :remote-method="remoteMethod2"
        :loading="loading2"
      >
        <Option
          v-for="(option, index) in options2"
          :value="option.value"
          :key="index"
        >{{option.label}}</Option>
      </Select>
    </div>
  </div>
</template>

<script>
import { cateProduct } from '@/api/cashSystem/cashSystem'
export default {
  props: ['product_bind'],
  data() {
    return {
      selectinfo: [],
      loading2: false,
      options2: [],
      list: [],
      resselect: [],
      resdata:{
       page: 1,
       rows: 50
      }
    }
  },
  methods: {
    async getCateProduct() {
      await cateProduct(this.resdata).then(res => {
        this.list = []
        res.data.data.list.forEach(el => {
          if(!el.contorno && !el.procedure && !el.taste && !el.group) {
            this.list.push(el)
          }
        })
        console.log(res, 'res')
        const listinfo = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        this.options2 = listinfo
      })
    },
    remoteMethod2(query) {
      if (query !== '') {
        this.loading2 = true
        setTimeout(() => {
          let arrlist = []
          this.loading2 = false
          const data = {page: 1, rows:100 , search: query }
          cateProduct(data).then(res => {
            // arrlist = JSON.parse(JSON.stringify(res.data.data.list))
              res.data.data.list.forEach(el => {
                if(!el.contorno && !el.procedure && !el.taste && !el.group) {
                  arrlist.push(el)
                }
              })
            const listinfo = arrlist.map(item => {
              return {
                value: item.id,
                label: item.name
              }
            })
            this.options2 = listinfo.filter(
              item => item.label.toLowerCase().indexOf(query.toLowerCase()) > -1
            )
            this.tovalue()
          })
        }, 200)
      } else {
        this.options2 = []
        this.tovalue()
      }
    },
    sdkinfo(i) {
      const listinfo = this.list.map(item => {
        return {
          value: item.id,
          label: item.name
        }
      })
      this.options2 = listinfo
      this.resselect = []
      let arr = JSON.parse(JSON.stringify(this.selectinfo))
      for (let i in arr) {
        this.resselect[i] = { label_id: arr[i] }
      }
      this.tovalue()
    },
    remotenull(v) {
      if (v === '') {
        const listinfo = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        this.options2 = listinfo
        this.tovalue()
      }
    },
    tovalue() {
      //  The world! 時間よ、止まって。!!!
      let arr = []
      this.selectinfo.forEach(element => {
        for (let i in this.list) {
          if (this.list[i].id == element) {
            arr.push(this.list[i].id)
          }
        }
      })
      if(!arr.length) {
        if(this.selectinfo[0] == undefined) {
           this.$emit('garProduct',[])
           return
        }
        console.log(arr , 'info',this.selectinfo[0])
        this.$emit('garProduct', this.selectinfo)
        return
      }
      console.log( 'info',this.selectinfo)
      this.$emit('garProduct', arr)
    }
  },
  async mounted() {
    this.product_bind = String(this.product_bind)
   if (this.product_bind && this.product_bind.split(',').length) {
      this.resdata.ids = this.product_bind
   }
    await this.getCateProduct()
    if (this.product_bind && this.product_bind.split(',').length) {
      // 双向绑定之前选择的小吃集合ID
      let arr = []
      this.list.forEach(el => {
        arr.push(Number(el.id))
      })
      this.product_bind.split(',').forEach(el => {
        el = Number(el)
        if (arr.indexOf(el) !== -1) {
          this.selectinfo.push(this.list[arr.indexOf(el)].id)
        }
      })
    }
  }
}
</script>

<style>
</style>
