<template>
  <div>
    <p class="adminTitle">员工列表</p>
    <!-- add admin buttom -->
    <Button class="m20" type="primary" @click="showEdit('add')">添加员工</Button>
    <div class="inline-div">
      <p class="inline-div search-title">账号查询：</p>
      <Input
        clearable
        v-model="requestParam.account"
        icon="search"
        placeholder="输入你要查询的管理员账号"
        style="width: 200px; display: inline-block"
      />
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        type="primary"
        @click="handleSearch"
      >查询</Button>

      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        type="warning"
        @click="requestParam.account='';requestParam.page = 1;handleSearch()"
      >刷新</Button>
    </div>
    <!-- search -->
    <!-- admin tables -->
    <Table border :columns="columns" :data="adminTableInfo" stripe style="width: 1024px;"></Table>
    <div style="margin: 10px 0;width: 1024px;text-align: right;">
      <Page
        show-total
        show-elevator
        :total="Number(pageTotal)"
        :current="Number(requestParam.page)"
        @on-change="handlePage"
      ></Page>
    </div>
    <!-- edit admin -->
    <Modal v-model="isShowEdit" :title="editTitle">
      <div>
        <span>账号：</span>
        <Input
          v-model.trim="editAdminInfo.account"
          placeholder="输入管理员账号手机号码"
          style="width: 200px; margin: 10px 0; "
        />
      </div>
      <div>
        <span>密码：</span>
        <Input
          v-model.trim="editAdminInfo.pwd"
          placeholder="输入密码"
          style="width: 200px; margin: 10px 0; "
        />
      </div>
      <div>
        <span>姓名：</span>
        <Input
          v-model.trim="editAdminInfo.realname"
          placeholder="输入管理员姓名"
          style="width: 200px; margin: 10px 0; "
        />
      </div>
      <div style="margin: 10px 0;">
        <span>角色：</span>
        <Select v-model.trim="editAdminInfo.role_id" style="width:150px">
          <Option v-for="item in roleLists" :value="item.id" :key="item.id">{{ item.name }}</Option>
        </Select>
      </div>
      <div style="margin: 20px 0;">
        <span>状态：</span>
        <i-switch v-model="adminInfoStatus" size="large">
          <span slot="open">正常</span>
          <span slot="close">禁用</span>
        </i-switch>
      </div>

      <div slot="footer">
        <Button type="text" size="large" @click="isShowEdit = false">取消</Button>
        <Button type="primary" size="large" @click="saveAdminInfo">确定</Button>
      </div>
    </Modal>
  </div>
</template>
<script>
import { getToken } from '@/libs/util'
import {
  Searchbuttom,
  deleteAdminButtom,
  saveAdmin,
  getAdminTablesButtom
} from '@/api/account/auth'
import { listSelectRole } from '@/api/account/role'
export default {
  data() {
    return {
      adminTableInfo: [],
      columns: [
        {
          title: '管理员ID',
          key: 'uid',
          width: 110,
          align: 'center',
          sortable: true,
          render: (h, params) => {
            return h('div', [h('strong', params.row.uid)])
          }
        },
        {
          title: '管理员账号',
          key: 'account',
          width: 160,
          align: 'center',
          sortable: true
        },
        {
          title: '姓名',
          key: 'realname',
          width: 142,
          align: 'center'
        },
        {
          title: '角色名',
          key: 'role_name',
          width: 150,
          align: 'center'
        },
        {
          title: '状态',
          key: 'status',
          width: 100,
          align: 'center',
          filters: [
            {
              label: '正常',
              value: 1
            },
            {
              label: '禁用',
              value: 2
            }
          ],
          filterMultiple: false,
          filterMethod(value, row) {
            if (value === 1) {
              return row.status == 1
            } else if (value === 2) {
              return row.status == 2
            }
          },
          render: (h, params) => {
            return h('span', params.row.status == 1 ? '正常' : '禁用')
          }
        },
        {
          title: '上次登陆时间',
          width: 200,
          align: 'center',
          key: 'last_login_time',
          render: (h, params) => {
            console.log(params.row.last_login_time, 123)
            return h(
              'span',
              params.row.last_login_time != null
                ? params.row.last_login_time
                : '最近没有登录'
            )
          }
        },
        {
          title: '编辑',
          key: 'action',
          width: 160,
          align: 'center',
          // fixed: 'right',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.showEdit('edit', params.index)
                    }
                  }
                },
                '修改'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                      this.deleteAdmin()
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      isShowEdit: false,
      editTitle: '',
      editAdminInfo: {},
      pageTotal: '',
      requestParam: {
        account: '',
        page: 1,
        rows: 10,
        sort: { uid: 'desc' }
      },
      roleLists: [],
      adminInfoStatus: true
    }
  },
  methods: {
    showEdit(type, index) {
      if (type == 'add') {
        this.editTitle = '添加员工'
        this.editAdminInfo = {}
        this.adminInfoStatus = true
      } else if (type == 'edit') {
        this.editTitle = '修改员工'
        this.editAdminInfo = Object.assign({}, this.adminTableInfo[index])
        this.adminInfoStatus = this.editAdminInfo.status == 1
      }
      this.isShowEdit = true
    },
    remove(index) {
      const editinfos = this.adminTableInfo[index]
      this.editinfo = editinfos
    },
    // 获取分页
    handlePage(value) {
      console.log(value, '调制')
      this.getAdminTables(value)
    },
    // 获取管理员列表
    getAdminTables(value) {
      if (value) {
        this.requestParam.page = value
      }
      getAdminTablesButtom(this.requestParam)
        .then(response => {
          let info = response.data.data.list
          this.pageTotal = Number(response.data.data.total)
          this.adminTableInfo = info
        })
        .catch(error => {
          console.error(error)
        })
    },
    // 获取角色组
    getRoleList() {
      listSelectRole()
        .then(response => {
          this.roleLists = response.data.data
        })
        .catch(error => {
          console.error(error)
        })
    },
    // 删除管理员
    deleteAdmin() {
      this.$Modal.confirm({
        title: '删除门店',
        content: '<p>你正在进行操作！确认要删除吗？</p>',
        onOk: () => {
          const deleteAdmininfo = {
            token: getToken(),
            id: 12,
            uid: this.editinfo.uid
          }
          deleteAdminButtom(deleteAdmininfo)
            .then(response => {
              this.$Message.info({
                content: '删除成功',
                duration: 10,
                closable: true
              })
              this.getAdminTables()
            })
            .catch(error => {
              console.error(error)
            })
        },
        onCancel: () => {
          this.$Message.info('取消了删除操作')
        }
      })
    },
    // 保存管理员信息
    saveAdminInfo(name) {
      if (!this.editAdminInfo.account) {
        this.$Message.info({
          content: '请输入管理员手机号码'
        })
      } else if (!this.editAdminInfo.account.match(/^1[3-9]\d{9}$/)) {
        this.$Message.info({
          content: '请输入正确的手机号'
        })
      } else if (!this.editAdminInfo.role_id) {
        this.$Message.info({
          content: '请选择一个角色'
        })
      } else {
        this.editAdminInfo.status = this.adminInfoStatus ? 1 : 0
        saveAdmin(this.editAdminInfo)
          .then(res => {
            this.isShowEdit = false
            this.$Message.info({
              content: res.data.message,
              duration: 5,
              closable: true
            })
            this.getAdminTables()
          })
          .catch(error => {
            console.error(error)
          })
      }
      return false
    },
    // 搜索管理员
    handleSearch() {
      this.requestParam.page = 1
      Searchbuttom(this.requestParam)
        .then(response => {
          this.adminTableInfo = response.data.data.list
          this.pageTotal = Number(response.data.data.total)
        })
        .catch(error => {
          console.error(error)
        })
    },
    // 获取树状
    datatree(data) {
      this.clickrole = data[0].id
      console.log(this.clickrole)
    }
  },
  mounted() {
    this.getAdminTables()
    this.getRoleList()
  }
}
</script>
<style>
.adminTitle {
  font-size: 18px;
  font-weight: bold;
}
.m20 {
  margin: 20px 0;
}
.inline-div {
  display: inline-block;
  margin: 0 10px;
}
.search-title {
  font-size: 14px;
}
</style>
