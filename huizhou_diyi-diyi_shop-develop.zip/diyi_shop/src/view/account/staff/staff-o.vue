<template>
    <div>
        <p class="adminTitle" >管理员列表</p>
        <!-- add admin buttom -->
        <Button class="m20" type="primary" @click="showAdd = true" >添加管理员</Button>
        <div class="inline-div" >
           <p  class="inline-div search-title" >账号查询： </p>
           <Input :maxlength='40' v-model="searchConName"  icon="search"   placeholder="输入你要查询的管理员账号"  style="width: 200px; display: inline-block" />
           <Button  style="display: inline-block; margin:0;  "  type="primary" @click="handleSearch" >查询</Button>
        </div>
        <!-- search -->
        <!-- admin tables -->
        <Table border :columns="columns7" :data="adminTableinfo" stripe></Table>
         <div style="float: right; margin: 10px 0">
            <Page
              :total="Number(pagetotal)"
              :page-size='5'
              @on-change='handlePage'
              >
            </Page>
        </div>
        <!-- edit admin -->
        <Modal
            v-model="editAdmin"
            title="修改管理员信息"
            :loading="loading"
            @on-ok="setAdmin"
            >
            <div>
                <span>当前管理员状态：</span>
                <RadioGroup v-model="adminStore" type="button">
                    <Radio label="1">正常</Radio>
                    <Radio label="2">禁止</Radio>
                </RadioGroup>
            </div>
            <div>
                <span>新姓名：</span>
                <Input :maxlength='40' v-model="adminName" placeholder="输入管理员姓名" style="width: 300px; margin: 10px 0; " />
            </div>
            <div>
                <span>角色组：</span>
                <Tree  :data="roleLists" @on-select-change='datatree'  ></Tree>
            </div>
        </Modal>
        <!-- add adnub -->
        <Modal
          v-model="showAdd"
          title="添加员工"
          @on-ok="addAdmins">
            <div>
              <span>账号： </span>
              <Input :maxlength='40'  v-model="addAccount" placeholder="输入管理员手机号码" style="width: 300px; margin: 10px 0; " />
            </div>
            <div>
              <span>密码： </span>
              <Input :maxlength='40' v-model="addPwd" placeholder="输入密码" style="width: 300px; margin: 10px 0; " />
            </div>
            <div>
                <span>设置管理员状态：</span>
                <RadioGroup v-model="adminStore" type="button">
                    <Radio label="1">正确</Radio>
                    <Radio label="2">禁止</Radio>
                </RadioGroup>
            </div>
            <div>
                <span>姓名：</span>
                <Input :maxlength='40' v-model="adminName" placeholder="输入管理员姓名" style="width: 300px; margin: 10px 0; " />
            </div>
            <div>
                <span>角色组：</span>
                <Tree  :data="roleLists" @on-select-change='datatree' ></Tree>
            </div>
        </Modal>
    </div>
</template>
<script>
import { getToken } from '@/libs/util'
import { getTreeRoleButtom } from '@/api/data'
import {
  Searchbuttom,
  addAdminsButtom,
  deleteAdminButtom,
  setAdminButtom,
  getAdminTablesButtom,
  handlePageButtom } from '@/api/account/auth'
export default {
  data () {
    return {
      adminTableinfo: [],
      columns7: [
        {
          title: '管理员ID',
          key: 'uid',
          width: 120,
          sortable: true,
          render: (h, params) => {
            return h('div', [
              h('Icon', {
                props: {
                  type: 'person'
                }
              }),
              h('strong', params.row.uid)
            ])
          }
        },
        {
          title: '管理员账号',
          key: 'account',
          sortable: true
        },
        {
          title: '上次登陆时间',
          key: 'last_login_time'
        },
        {
          title: '当前管理员状态',
          key: 'status'
        },
        {
          title: '姓名',
          key: 'realname'
        },
        {
          title: '管理员当前角色',
          key: 'name'
        },
        {
          title: '编辑',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.show(params.index)
                    }
                  }
                },
                '修改'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(params.index)
                      this.deleteAdmin()
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      editinfo: {},
      editAdmin: false,
      message: '',
      // 编辑角色组
      roleLists: [],
      // 编辑管理员状态挂载
      adminStore: '',
      adminName: '',
      clickrole: [],
      // 添加管理员
      showAdd: false,
      addAccount: '',
      addPwd: '',
      pageNum: '',
      pagetotal: '',
      // 搜索挂载
      searchConName: '',
      loading: true
    }
  },
  methods: {
    show (index) {
      // 当前所选修改
      const editinfos = this.adminTableinfo[index]
      this.adminStore = editinfos.status
      this.adminName = editinfos.realname
      console.log(4, this.clickrole)
      this.editinfo = editinfos
      this.editAdmin = true
    },
    remove (index) {
      const editinfos = this.adminTableinfo[index]
      this.editinfo = editinfos
    },
    // 获取分页
    handlePage (value) {
      this.pageNum = value
      const handlePageinfo = {
        id: '28',
        token: getToken(),
        page: this.pageNum,
        rows: 5
      }
      handlePageButtom(handlePageinfo).then((response) => {
        let info = response.data.data.list
        this.adminTableinfo = info
      }).catch(error => {
        console.error(error)
      })
    },
    // 获取管理员列表
    getAdminTables () {
      const getAdminTablesinfo = {
        token: getToken(),
        page: 1,
        rows: 5
      }
      getAdminTablesButtom(getAdminTablesinfo).then((response) => {
        let info = response.data.data.list
        this.pagetotal = Number(response.data.data.total)
        this.adminTableinfo = info
        console.log(this.adminTableinfo, 456)
      }).catch(error => {
        console.error(error)
      })
    },
    // 获取角色组
    getRoleList () {
      const getTreeRoleinfo = {
        token: getToken(),
        level_id: 1,
        is_tree: 1
      }
      getTreeRoleButtom(getTreeRoleinfo).then((response) => {
        this.roleLists = response.data.data
        console.log(this.roleLists, 12)
      }).catch(error => {
        console.error(error)
      })
    },
    // 修改管理员权限
    setAdmin () {
      const setAdmininfo = {
        token: getToken(),
        uid: this.editinfo.uid,
        account: this.editinfo.account,
        realname: this.adminName,
        role_id: this.clickrole,
        status: this.adminStore,
        affiliation_id: 0,
        terminal_id: 1
      }
      console.log(setAdmininfo)
      setAdminButtom(setAdmininfo).then((response) => {
        this.$Message.info({
          content: response.data.message,
          duration: 10,
          closable: true
        })
        this.getAdminTables()
      }).catch(error => {
        console.error(error)
      })
      setTimeout(() => {
        this.editAdmin = false
      }, 1000)
    },
    // 删除管理员
    deleteAdmin () {
      this.$Modal.confirm({
        title: '删除门店',
        content: '<p>你正在进行操作！确认要删除吗？</p>',
        onOk: () => {
          const deleteAdmininfo = {
            token: getToken(),
            id: 12,
            uid: this.editinfo.uid
          }
          deleteAdminButtom(deleteAdmininfo).then((response) => {
            this.$Message.info({
              content: '删除成功',
              duration: 10,
              closable: true
            })
            this.getAdminTables()
          }).catch(error => {
            console.error(error)
          })
        },
        onCancel: () => {
          this.$Message.info('取消了删除操作')
        }
      })
    },
    // 添加管理员
    addAdmins (name) {
      const addAdminsinfo = {
        token: getToken(),
        account: this.addAccount,
        pwd: this.addPwd,
        realname: this.adminName,
        role_id: this.clickrole,
        termainal_id: 1,
        agent_id: 0,
        id: 12
      }
      console.log(addAdminsinfo)
      addAdminsButtom(addAdminsinfo).then((response) => {
        console.log(response)
        this.$Message.info({
          content: response.data.message,
          duration: 10,
          closable: true
        })
        this.getAdminTables()
      }).catch(error => {
        console.error(error)
      })
      setTimeout(() => {
        this.showAdd = false
      }, 1000)
    },
    // 搜索管理员
    handleSearch () {
      const searinfo = {
        token: getToken(),
        id: '12',
        account: this.searchConName
      }
      Searchbuttom(searinfo).then((response) => {
        this.adminTableinfo = response.data.data.list
      }).catch(error => {
        console.error(error)
      })
    },
    // 获取树状
    datatree (data) {
      this.clickrole = data[0].id
      console.log(this.clickrole)
    }
  },
  mounted () {
    this.getAdminTables()
    this.getRoleList()
  }
}
</script>
<style>
.adminTitle{
  font-size: 18px;
  font-weight: bold;
}
.m20{
  margin: 20px 0;
}
.inline-div{
  display: inline-block;
  margin: 0 10px;
}
.search-title{
  font-size: 14px;
}
</style>
