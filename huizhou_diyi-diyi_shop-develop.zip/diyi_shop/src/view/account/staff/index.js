import Staff from './staff.vue'
export default Staff
