import RoleGroup from './role-group.vue'
export default RoleGroup
