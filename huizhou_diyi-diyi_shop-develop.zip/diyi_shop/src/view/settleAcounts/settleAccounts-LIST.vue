<template>
  <div>
    <hgroup class="shopC-title">
      <h3>信息列表</h3>
      <p>这是您店内的挂账信息列表，可查看对应的挂账信息</p>
    </hgroup>
    <div style="margin-bottom:10px;" class="shopClass-search">
      <p class="shopClass-title">筛选查找：</p>
      <div class="searchbox">
        <div>
          <p>公司名称：</p>
          <Input
          :maxlength='40'
            v-model="resdata.arrearage_company"
            clearable
            icon="search"
            placeholder="输入你要查询的公司名字"
            style="width: 220px; display: inline-block"
          />
        </div>
        <div>
          <p>挂账人姓名：</p>
          <Input
          :maxlength='40'
            v-model="resdata.accounts_name"
            clearable
            icon="search"
            placeholder="输入你要查询的挂账人姓名"
            style="width: 220px; display: inline-block"
          />
        </div>
        <div>
          <p>挂账人电话：</p>
          <Input
          :maxlength='40'
            v-model="resdata.accounts_phone"
            clearable
            icon="search"
            placeholder="输入你要查询的挂账人电话"
            style="width: 220px; display: inline-block"
          />
        </div>
        <!-- <div>
                <p>挂账类型：</p>
                <Select clearable v-model="resdata.type" style="width:150px">
                    <Option   v-for="item in oadata" :value="item.value" :key="item.value">{{ item.label }}</Option>
                </Select>
        </div>-->
        <div>
          <Button
            @click="oAListInfo(true)"
            clearable
            style="display:inline-block; margin:0 10px  "
            type="primary"
          >搜索</Button>
        </div>
      </div>
    </div>
    <Table style="width:900px;margin-top:10px" :columns="columns" :data="Tablesdata"></Table>
    <div style="width:900px;margin-top:10px;text-align: right;">
      <Page
        show-elevator
        show-total
        :page-size="resdata.rows"
        @on-change="change"
        :current="resdata.page"
        style=" display: inline-block;"
        :total=" Number(resdata.total)"
      />
    </div>
    <Modal cancel-text v-model="orderShow" title="挂账订单" width="750">
      <div class="settleAccOrder">
        <hgroup>
          <h3>订单号：{{moalList.order_no}}</h3>
          <h3>挂账时间：{{moalList.add_time}}</h3>
          <h3>挂账人：{{editdata.accounts_name}}</h3>
          <h3>挂账公司：{{editdata.arrearage_company}}</h3>
        </hgroup>
        <Table style="width:700px;margin-top:10px" :columns="columnsOrder" :data="TablesdataOrder"></Table>
      </div>
    </Modal>
  </div>
</template>

<script>
import {
  oAListInfo,
  getOrderDateByOrderId,
  oAEnd
} from '@/api/settleAcounts/settleAcounts'
import { getStautsText, convertPrice } from "@/libs/tools.js";
export default {
  data() {
    return {
      ggSettdata: {},
      editdata: {},
      orderShow: false,
      moalList: [],
      statusListinfo: [],
      resdata: {
        page: 1,
        rows: 10,
        total: ''
      },
      columns: [
        { key: 'accounts_name', title: '挂账人姓名', align: 'center' },
        { key: 'arrearage_company', title: '挂账人公司', align: 'center' },
        {
          key: 'arrearage_time',
          width: 150,
          title: '挂账时间',
          align: 'center'
        },
        { key: 'accounts_phone', title: '挂账人电话', align: 'center' },
        { key: 'arrearage_money', title: '挂账金额', align: 'center',
          render: (h, params) => {
            return h("div", [
              h("p", convertPrice(params.row.arrearage_money) + " " + "元")
            ]);
          }
        },
        {
          key: 'status',
          title: '状态',
          width: 80,
          align: 'center',
          filters: [
            {
              label: '未结清',
              value: 0
            },
            {
              label: '已结清',
              value: 1
            }
          ],
          filterMultiple: false,
          filterMethod(value, row) {
            if (value === 0) {
              return row.status == 0
            } else if (value === 1) {
              return row.status == 1
            }
          },
          render: (h, params) => {
            const payText = params.row.status
            let rgb
            if (payText === 0) {
              rgb = 'red'
            }
            return h('div', [
              h('p', { style: { color: rgb } }, this.statusListinfo[payText])
            ])
          }
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.editdata = params.row
                      this.getOrderDateByOrderId()
                    }
                  }
                },
                '查看'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'warning',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.ggSettdata.id = params.row.id
                      this.ggSettdata.order_id = params.row.order_id
                      this.$Modal.confirm({
                        title: '确定结算这个挂账吗？',
                        content: '当前正在进行结算挂账操作，请核实是否结清',
                        onOk: () => {
                          this.oAEnd()
                        },
                        onCancel: () => {
                          this.$Message.info('取消了结清挂账操作')
                        }
                      })
                    }
                  }
                },
                '结算'
              )
            ])
          }
        }
      ],
      Tablesdata: [],
      columnsOrder: [
        { key: 'name', title: '品项名称', align: 'center' },
        { key: 'product_cate', title: '所属分类', align: 'center' },
        { key: 'unit_price', title: '单价', align: 'center',
        render: (h, params) => {
            const payText = convertPrice(params.row.unit_price)
            return h('div', [h('p', `${payText}元`)])
          }
         },
        { key: 'num', title: '数量', align: 'center' },
        { key: 'unit', title: '单位', align: 'center', width: 80 },
        {
          key: 'mondy',
          title: '优惠',
          align: 'center',
          render: (h, params) => {
            const payText = convertPrice(params.row.mondy)
            return h('div', [h('p', `${0}元`)])
          }
        },
        {
          key: 'price',
          title: '订单金额（元）',
          align: 'center',
          render: (h, params) => {
            const payText = convertPrice(params.row.price);
            return h('div', [h('p', `${payText}元`)])
          }
        }
      ],
      TablesdataOrder: []
    }
  },
  methods: {
    oAListInfo(type) {
      if (type) {
        this.resdata.page = 1
      }
      oAListInfo(this.resdata).then(res => {
        this.Tablesdata = res.data.data.list
        this.resdata.total = res.data.data.total
      })
    },
    change(v) {
      this.resdata.page = v
      this.oAListInfo()
    },
    getOrderDateByOrderId() {
      getOrderDateByOrderId({ order_id: this.editdata.order_id }).then(res => {
        if (res.status === 200) {
          this.moalList = res.data.data
          this.orderShow = true
          this.TablesdataOrder = res.data.data.order_list
        }
      })
    },
    oAEnd() {
      oAEnd(this.ggSettdata).then(res => {
        if (res.data.data === true) {
          this.$Message.success('操作成功')
        }
        this.oAListInfo()
      })
    }
  },
  mounted() {
    this.oAListInfo()
    this.statusListinfo = getStautsText('order_arrearage.status')
  }
}
</script>

<style lang='less' scoped>
@import url('./index.less');
</style>
