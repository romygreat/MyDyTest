<template>
  <div>
    <hgroup class="shopC-title">
      <h3>挂账主体列表</h3>
      <p>这是您店内的挂账主体列表，可查看对应的挂账主体信息</p>
    </hgroup>
    <div style="margin-bottom:10px;" class="shopClass-search">
      <p class="shopClass-title">筛选查找：</p>
      <div class="searchbox">
        <div>
          <p>主体名称：</p>
          <Input
           :maxlength='40'
            clearable
            v-model="resdata.arrearage_company"
            icon="search"
            placeholder="输入您要查找的挂账主体"
            style="width: 220px; display: inline-block"
          />
        </div>
        <div>
          <p>挂账类型：</p>
          <Select clearable v-model="resdata.type" style="width:150px">
            <Option v-for="item in oadata" :value="item.value" :key="item.value">{{ item.label }}</Option>
          </Select>
        </div>
        <div>
          <Button
            clearable
            style="display:inline-block; margin:0 10px  "
            @click="getOAlist(true)"
            type="primary"
          >搜索</Button>
        </div>
      </div>
    </div>
    <Button
      @click="saveData = {};saveData.type='1';saveTitle = '添加主体';saveShow = true"
      type="primary"
    >添加主体</Button>
    <Table style="width:450px;margin-top:10px" :columns="columns" :data="Tablesdata"></Table>
    <div style="width:450px;margin-top:10px;text-align: right;">
      <Page
        show-total
        show-elevator
        @on-change="change"
        :current="resdata.page"
        :page-size="resdata.rows"
        style=" display: inline-block;"
        :total=" Number(resdata.total)"
      />
    </div>
    <Modal :footer-hide="true" v-model="saveShow" :title="saveTitle" width="400">
      <Form ref="saveData" :model="saveData" :rules="ruleValidate" :label-width="80">
        <FormItem label="主体名称" prop="arrearage_company">
          <Input :maxlength='40' v-model="saveData.arrearage_company" style="width:250px" placeholder="请输入主体名称..." />
        </FormItem>
        <FormItem label="主体类型" prop="type">
          <RadioGroup v-model="saveData.type">
            <Radio label="1">公司</Radio>
            <Radio label="2">个人</Radio>
          </RadioGroup>
          
        </FormItem>
        <FormItem>
          <Button type="primary" @click="handleSubmit('saveData')">确认</Button>
          <Button @click="handleReset('saveData')" style="margin-left: 8px">取消</Button>
        </FormItem>
      </Form>
    </Modal>
  </div>
</template>

<script>
import { oASave, oAList, oADel } from '@/api/settleAcounts/settleAcounts'
import { getStautsText } from '@/libs/tools.js'
import { log } from 'util'
export default {
  data() {
    return {
      statusListinfo: [],
      resdata: {
        arrearage_company: '',
        type: '',
        page: 1,
        rows: 10,
        sort: {},
        total: ''
      },
      oadata: [{ label: '公司', value: 1 }, { label: '个人', value: 2 }],
      columns: [
        { key: 'arrearage_company', title: '挂账公司', align: 'center' },
        {
          key: 'type',
          title: '类型',
          align: 'center',
          width: 80,
          render: (h, params) => {
            const payText = params.row.type
            return h('div', [h('p', this.statusListinfo[payText])])
          }
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.saveData = JSON.parse(JSON.stringify(params.row))
                      this.saveData.type = Number(this.saveData.type)
                      console.log(this.saveData.type, 'ssss')
                      this.saveData.type = String(this.saveData.type)
                      this.saveTitle = '编辑修改'
                      this.saveShow = true
                    }
                  }
                },
                '修改'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'warning',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.remove(JSON.parse(JSON.stringify(params.row)).id)
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      Tablesdata: [],
      saveShow: false,
      saveData: {},
      saveDataId: '',
      saveTitle: '添加挂账公司',
      ruleValidate: {
        arrearage_company: [
          { required: true, message: '挂账公司名称不得为空', trigger: 'blur' }
        ],
        type: [
          { required: true, message: '挂账公司类型不得为空', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    getOAlist(type) {
      if (type) {
        this.resdata.page = 1
      }
      oAList(this.resdata).then(res => {
        this.Tablesdata = res.data.data.list
        this.resdata.total = res.data.data.total
      })
    },
    search() {},
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          oASave(this.saveData).then(res => {
            if (res.data.code == 1) {
              this.$Message.success('操作成功')
              this.saveData = {}
              this.saveShow = false
              this.getOAlist()
            }
          })
        } else {
          this.$Message.error('请正确填写！')
        }
      })
    },
    handleReset(name) {
      this.$refs[name].resetFields()
      this.saveData = {}
      this.saveShow = false
    },
    change(v) {
      this.resdata.page = v
      this.getOAlist()
    },
    // 删除buttom
    remove(id) {
      this.$Modal.confirm({
        title: '删除主体',
        content: '<p>当前正在进行删除主体操作，确认删除？</p>',
        onOk: () => {
          const data = {
            id: id
          }
          oADel(data).then(res => {
            console.log(res)
            this.getOAlist()
          })
          this.$Message.info('已经删除')
        },
        onCancel: () => {
          this.$Message.info('取消了删除操作')
        }
      })
    }
  },
  mounted() {
    this.getOAlist()
    this.statusListinfo = getStautsText('order_arrearage.type')
    console.log(this.statusListinfo, 999)
  }
}
</script>

<style scoped>
@import url('./index.less');
</style>
