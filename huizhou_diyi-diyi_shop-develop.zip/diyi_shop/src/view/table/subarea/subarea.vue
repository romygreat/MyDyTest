<template>
  <div>
    <hgroup class="shopC-title">
      <h3>桌号分类</h3>
      <p>请按照店内的实际情况划分区域</p>
    </hgroup>
    <!-- shopClassify search -->
    <div class="shopClass-search">
      <p class="shopClass-title">桌号分类名称：</p>
      <Input
       :maxlength='40'
        clearable
        v-model="requestParam.title"
        icon="search"
        placeholder="输入你要查询的桌号分类名称"
        style="width: 200px; display: inline-block"
      />
      <Button style="display: inline-block; margin:0 0 0 15px;  " @click="search" type="primary">搜索</Button>

      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="requestParam.title='';search()"
        type="warning"
      >刷新</Button>
    </div>
    <!-- add shopClassify buttom -->
    <Button type="primary" style="margin-bottom: 15px;" @click="showEdit('add')">
      <span>
        <Icon type="md-add" />
        <span>新增分类</span>
      </span>
    </Button>
    <!-- shopClass Tables -->
    <Table :width="900" ref="selection" border :columns="columns" :data="subareaList" stripe></Table>
    <div style="margin-top:20px; width:900px;">
      <!-- <Button class="ml-20" type="primary" @click="handleSelectAll(true)">设置全选</Button>
      <Button type="primary" @click="handleSelectAll(false)">取消全选</Button>-->
      <Page show-total :total="Number(pageTotal)" @on-change="getPageList" class="page-buttom"></Page>
    </div>
    <!-- editSubarea -->
    <Modal v-model="isShowEdit" :title="editTitle" :footer-hide="true" width="450">
      <Form ref="editSubarea" :model="editSubarea" :rules="ruleValidate" :label-width="80">
        <FormItem label="分类名" prop="title">
          <Input :maxlength='40' v-model="editSubarea.title" placeholder="请输入分类名" style="width: 200px;" />
        </FormItem>
        <FormItem label="排序" prop="sort">
          <Input :maxlength='40' v-model="editSubarea.sort" placeholder="选填" style="width: 110px;" />
        </FormItem>
        <FormItem>
          <Button type="primary" @click="handleSubmit('editSubarea')">确认</Button>
          <Button @click="isShowEdit = false" style="margin-left: 8px">取消</Button>
        </FormItem>
      </Form>
    </Modal>
    <!-- alldel -->
    <Modal v-model="alldel" width="360">
      <p slot="header" style="color:#f60;text-align:center">
        <Icon type="ios-information-circle"></Icon>
        <span>删除失败</span>
      </p>
      <div style="text-align:center">
        <p>该分类已经绑定了台桌，你是否确认删除？</p>
      </div>
      <div slot="footer">
        <Button type="error" size="large" long @click="del">确认删除</Button>
      </div>
    </Modal>
  </div>
</template>

<script>
import { listSubarea, saveSubarea, delSubarea } from '@/api/shop/subarea'
import './index.less'
export default {
  data() {
    return {
      columns: [
        {
          title: 'ID',
          key: 'id',
          width: 80,
          align: 'center'
        },
        {
          title: '桌号分类名称',
          key: 'title',
          align: 'center'
        },
        {
          title: '排序',
          key: 'sort',
          width: 80,
          align: 'center'
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.showEdit('edit', params.index)
                    }
                  }
                },
                '编辑'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.delSubarea(params.index)
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      subareaList: [],
      pageTotal: 0,
      requestParam: {
        name: '',
        page: 1,
        rows: 10,
        sort: { sort: 'asc', id: 'asc' }
      },
      editSubarea: {},
      ruleValidate: {
        title: [
          { required: true, message: '分类名不能为空', trigger: 'blur' },
          { min: 2, message: '名称不能低于两个字', trigger: 'blur' }
        ]
      },
      // 上传
      isShowEdit: false,
      editTitle: '',
      alldel: false,
      alldelData: ''
    }
  },
  methods: {
    //  获取列表
    listSubarea(type) {
      if (type) {
        this.requestParam.page = 1
      }
      listSubarea(this.requestParam)
        .then(res => {
          this.subareaList = res.data.data.list
          this.pageTotal = res.data.data.total
        })
        .catch(err => {
          console.error(err)
        })
    },
    // 分页
    getPageList(page) {
      this.requestParam.page = page
      this.listSubarea()
    },
    // 添加|编辑buttom
    showEdit(type, index) {
      this.isShowEdit = true
      this.editSubarea = {}
      if (type == 'add') {
        this.editTitle = '桌台分类'
      } else {
        this.editTitle = '编辑区域'
        this.editSubarea = Object.assign({}, this.subareaList[index])
      }
    },
    // 删除buttom
    delSubarea(index) {
      this.$Modal.confirm({
        title: '彻底删除',
        content: '<p>确认彻底删除？</p>',
        onOk: () => {
          const data = {
            id: this.subareaList[index].id
          }
          delSubarea(data).then(res => {
            if (res.data.code === -20039) {
              this.alldelData = this.subareaList[index].id
              this.alldel = true
            } else {
              this.listSubarea()
              this.$Message.info(res.data.message)
            }
          })
        },
        onCancel: () => {
          this.$Message.info('取消了彻底删除操作')
        }
      })
    },
    del() {
      const data = {
        id: this.alldelData,
        del: 1
      }
      delSubarea(data).then(res => {
        this.$Message.info(res.data.message)
        this.listSubarea()
        this.alldel = false
      })
    },
    // 添加 && 修改
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          saveSubarea(this.editSubarea)
            .then(res => {
              this.$Message.success(res.data.message)
              this.listSubarea()
              this.isShowEdit = false
            })
            .catch(err => {
              this.$Message.success(err)
            })
        } else {
          this.$Message.error('请按规则填写提交')
        }
      })
    },
    // 查询
    search() {
      this.listSubarea(true)
    }
  },
  mounted() {
    this.listSubarea()
  }
}
</script>
<style>
@import './subarea.css';
</style>
