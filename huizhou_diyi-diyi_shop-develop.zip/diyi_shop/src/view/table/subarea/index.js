import Subarea from './subarea.vue'
export default Subarea
