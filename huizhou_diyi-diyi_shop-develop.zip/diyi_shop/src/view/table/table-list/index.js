import TableList from './table-list.vue'
export default TableList
