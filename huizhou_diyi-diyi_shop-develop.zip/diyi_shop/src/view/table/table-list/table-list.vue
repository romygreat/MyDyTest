<template>
  <div>
    <hgroup class="shopC-title">
      <h3>台桌列表</h3>
    </hgroup>
    <!-- shopClassify search -->
    <div class="shopClass-search">
      <p class="shopClass-title">台桌号：</p>
      <Input
        :maxlength='40'
        clearable
        v-model="requestParam.title"
        icon="search"
        placeholder="输入你要查询的台桌号"
        style="width: 200px; display: inline-block"
      />
      <Button style="display: inline-block; margin:0 0 0 15px;  " @click="search" type="primary">搜索</Button>
      <Button
        style="display: inline-block; margin:0 0 0 15px;  "
        @click="requestParam.title='';requestParam.page = 1;search()"
        type="warning"
      >刷新</Button>
    </div>
    <!-- add shopClassify buttom -->
    <Button type="primary" style="margin-bottom: 15px;" @click="showEdit('add')">
      <span>
        <Icon type="md-add" />
        <span>新增台桌</span>
      </span>
    </Button>
    <Button
      type="primary"
      style="margin-bottom: 15px;margin-left: 10px;"
      @click="isShowBatchEdit = true"
    >
      <span>
        <Icon type="md-add" />
        <span>批量新增台桌</span>
      </span>
    </Button>
    <!-- shopClass Tables -->
    <Table
      :width="1042"
      @on-selection-change="selectActive"
      ref="selection"
      border
      :columns="columns"
      :data="tableList"
      stripe
    ></Table>
    <div style="margin-top:20px; width:1042px;">
      <Button @click="alldel" type="error">批量删除</Button>
      <Page
        :current="Number(requestParam.page)"
        show-total
        show-elevator
        :total="Number(pageTotal)"
        @on-change="getPageList"
        class="page-buttom"
      ></Page>
    </div>
    <!-- editTable -->
    <Modal v-model="isShowEdit" :title="editTitle" :footer-hide="true" width="450">
      <Form ref="editTable" :model="editTable" :rules="ruleValidate" :label-width="80">
        <FormItem label="台桌名称" prop="title">
          <Input
            :maxlength="nameLength"
            v-model="editTable.title"
            @input="maxSize($event)"
            placeholder="请输入台桌名称"
            style="width: 200px;"
          />
        </FormItem>
        <FormItem label="厅面楼层" prop="subarea_id" class="ivu-form-item-required">
          <Select v-model="editTable.subarea_id" style="width:200px">
            <Option v-for="item in subareaList" :key="item.value" :value="item.value">{{item.lable}}</Option>
          </Select>
        </FormItem>
        <FormItem label="绑定序列号" prop="machine_id">
          <Select v-model="editTable.machine_id" style="width:200px">
            <Option value="0">清空</Option>
            <Option v-for="item in machineList" :key="item.value" :value="item.value">{{item.lable}}</Option>
          </Select>
        </FormItem>
        <FormItem label="可坐人数" prop="people_num">
          <InputNumber :max="30" :min="1" v-model="editTable.people_num"></InputNumber>
        </FormItem>
        <FormItem v-if="!showSwitch" label="桌台现状">
          <i-switch v-model="switchSta" size="large">
            <span slot="open">就餐</span>
            <span slot="close">空闲</span>
          </i-switch>
        </FormItem>
        <FormItem label="排序" prop="sort">
          <Input :maxlength='40' v-model="editTable.sort" placeholder="选填" style="width: 110px;" />
        </FormItem>
        <FormItem>
          <Button type="primary" @click="handleSubmit('editTable')">确认</Button>
          <Button @click="isShowEdit = false" style="margin-left: 8px">取消</Button>
        </FormItem>
      </Form>
    </Modal>
    <Modal v-model="isShowBatchEdit" title="批量新增台桌" :footer-hide="true" :width="450">
      <Form ref="editBatch" :model="editBatch" :rules="ruleValidate2" :label-width="80">
        <FormItem label="厅面楼层" prop="subarea_id" class="ivu-form-item-required">
          <Select v-model="editBatch.subarea_id" style="width:200px">
            <Option v-for="item in subareaList" :key="item.value" :value="item.value">{{item.lable}}</Option>
          </Select>
        </FormItem>
        <FormItem label="可坐人数" prop="people_num">
          <InputNumber :max="30" :min="1" v-model="editBatch.people_num"></InputNumber>
        </FormItem>
        <FormItem label="开始号码" prop="start_num">
          <InputNumber v-model="editBatch.start_num" :max="1000" :min="0"></InputNumber>
        </FormItem>
        <FormItem label="结束号码" prop="end_num">
          <InputNumber v-model="editBatch.end_num" :max="1000" :min="0"></InputNumber>
        </FormItem>
        <FormItem label="是否补零" prop="end_num">
          <i-switch v-model="editBatch.is_zero">
            <span slot="open">开</span>
            <span slot="close">关</span>
          </i-switch>
        </FormItem>
        <FormItem v-if="editBatch.is_zero" label="号码长度" prop="end_num">
          <InputNumber v-model="editBatch.length" :max="10" :min="1"></InputNumber>
        </FormItem>
        <FormItem label="前缀名称" prop="prefix">
          <Input :maxlength='40'  v-model="editBatch.prefix" placeholder="前缀名称" style="width: 200px;" />
        </FormItem>
        <FormItem label="后缀名称" prop="suffix">
          <Input :maxlength='40' v-model="editBatch.suffix" placeholder="后缀名称" style="width: 200px;" />
        </FormItem>
        <FormItem>
          <Button type="primary" @click="handleSubmit('editBatch')">确认</Button>
          <Button @click="isShowBatchEdit = false" style="margin-left: 8px">取消</Button>
        </FormItem>
      </Form>
    </Modal>
  </div>
</template>

<script>
import {
  setShopTable,
  listShopTable,
  saveShopTable,
  saveBatchTable,
  delShopTable
} from '@/api/shop/table'
import { optionSubarea } from '@/api/shop/subarea'
import { getStautsText } from '@/libs/tools.js'
import { optionMachine } from '@/api/device/machine'
import './index.less'
import { constants } from 'crypto'
export default {
  data() {
    return {
      nameLength: 8,
      columns: [
        {
          type: 'selection',
          width: 80,
          align: 'center'
        },
        {
          title: 'ID',
          key: 'id',
          width: 80,
          align: 'center'
        },
        {
          title: '台桌号',
          key: 'title',
          align: 'center',
          width: 120
        },
        {
          title: '厅面楼层',
          key: 'subarea_title',
          align: 'center',
          width: 130
        },
        {
          title: '设备序列号',
          key: 'sn',
          align: 'center',
          width: 200,
          render: (h, params) => {
            let text = params.row.machine_sn ? params.row.machine_sn : '未绑定'
            return h('div', text)
          }
        },
        {
          title: '状态',
          key: 'status',
          align: 'center',
          width: 120,
          filters: [
            {
              label: '空闲',
              value: 0
            },
            {
              label: '正常',
              value: 1
            },
            {
              label: '预约',
              value: 2
            }
          ],
          filterMultiple: false,
          filterMethod(value, row) {
            if (value === 0) {
              return row.status == 0
            } else if (value === 1) {
              return row.status == 1
            } else if (value == 2) {
              return row.status == 2
            }
          },
          render: (h, params) => {
            let index = params.row.status
            return h('div', this.statusList[index])
          }
        },
        {
          title: '人数',
          key: 'people_num',
          width: 80,
          align: 'center'
        },
        {
          title: '排序',
          key: 'sort',
          width: 80,
          align: 'center'
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.showEdit('edit', params.index)
                    }
                  }
                },
                '编辑'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.delShopTable(params.index)
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      tableList: [],
      subareaList: [],
      machineList: [],
      pageTotal: 0,
      requestParam: {
        name: '',
        sign: 1,
        page: 1,
        rows: 10,
        sort: { sort: 'asc', id: 'asc' }
      },
      editTable: {},
      ruleValidate: {
        title: [
          { required: true, message: '分类名不能为空', trigger: 'blur' },
          { min: 2, message: '名称不能低于两个字', trigger: 'blur' }
        ]
      },
      ruleValidate2: {
        subarea_id: [
          {
            validator: (rule, value, callback) => {
              if (value) {
                return callback()
              }
              return callback(new Error('请选择一个区域'))
            },
            trigger: 'blur'
          }
        ]
      },
      // 上传
      isShowEdit: false,
      editTitle: '',
      isShowBatchEdit: false,
      editBatch: {},
      // 批量上传
      delJoin: '',
      switchSta: false,
      showSwitch: false,
      statusList: []
    }
  },
  methods: {
    //  获取列表
    listShopTable() {
      setShopTable(this.requestParam)
        .then(res => {
          this.tableList = res.data.data.list
          this.pageTotal = res.data.data.total
        })
        .catch(err => {
          console.error(err)
        })
    },
    getOptionSubarea() {
      let param = {
        sort: { sort: 'asc' }
      }
      optionSubarea(param).then(res => {
        if (res.status == 200 && res.data.code == 1) {
          this.subareaList = res.data.data
        }
      })
    },
    getOptionMachine() {
      optionMachine().then(res => {
        if (res.status == 200 && res.data.code == 1) {
          this.machineList = res.data.data
        }
        console.log('machineList', this.machineList)
      })
    },
    // 分页
    getPageList(page) {
      this.requestParam.page = page
      this.listShopTable()
    },
    // 添加|编辑buttom
    showEdit(type, index) {
      this.editTable = {}
      if (type == 'add') {
        this.editTitle = '添加台桌'
        this.switchSta = false
        this.showSwitch = true
      } else {
        this.editTitle = '编辑台桌'
        this.editTable = Object.assign({}, this.tableList[index])
        if (this.editTable.status == 0) {
          this.switchSta = false
        } else {
          this.switchSta = true
        }
        this.showSwitch = false
      }
      this.isShowEdit = true
    },
    // 删除buttom
    delShopTable(index) {
      console.log(this.tableList[index], 123)
      if (this.tableList[index].machine_sn == '') {
        if (this.tableList[index].status) {
          this.$Message.error('该台桌正在使用中，请在台桌空闲后再执行此操作！')
          return
        }
        this.$Modal.confirm({
          title: '彻底删除',
          content: '<p>确认彻底删除？</p>',
          onOk: () => {
            const data = {
              id: this.tableList[index].id
            }
            delShopTable(data).then(res => {
              this.listShopTable()
            })
            this.$Message.info('已经删除')
          },
          onCancel: () => {
            this.$Message.info('取消了彻底删除操作')
          }
        })
      } else {
        this.$Message.error('请解除绑定再删除')
      }
    },
    // 添加 && 修改
    handleSubmit(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          if (name == 'editTable') {
            if (this.switchSta == false) {
              this.editTable.status = 0
            } else if (this.switchSta == true) {
              this.editTable.status = 1
            }
            saveShopTable(this.editTable)
              .then(res => {
                this.$Message.success(res.data.message)
                if (res.data.code > 0) {
                  this.listShopTable()
                  this.isShowEdit = false
                }
              })
              .catch(err => {
                this.$Message.success(err)
              })
          } else if (name == 'editBatch') {
            if (this.switchSta == false) {
              this.editTable.status = 0
            } else if (this.switchSta == true) {
              this.editTable.status = 1
            }
            saveBatchTable(this.editBatch)
              .then(res => {
                this.$Message.success(res.data.message)
                this.listShopTable()
                this.isShowBatchEdit = false
              })
              .catch(err => {
                this.$Message.success(err)
              })
          }
        } else {
          this.$Message.error('请按规则填写提交')
        }
      })
    },
    // 查询
    search() {
      this.requestParam.page = 1
      this.listShopTable()
    },
    // 批量删除
    selectActive(index) {
      let arr = []
      for (let i in index) {
        arr.push(index[i].id)
      }
      this.delJoin = arr.join(',')
    },
    alldel() {
      if (this.delJoin) {
        this.$Modal.confirm({
          title: '批量彻底删除',
          content: '<p>确认批量彻底删除？</p>',
          onOk: () => {
            const data = {
              id: this.delJoin
            }
            delShopTable(data).then(res => {
              this.listShopTable()
            })
            this.$Message.info('已经删除')
          },
          onCancel: () => {
            this.$Message.info('取消了彻底删除操作')
          }
        })
      } else {
        this.$Message.error('请选择要批量删除的台桌')
      }
    },

    //判断输入几个中文
    maxSize(e) {
      let Elen = 0
      let Clen = 0

      for (let i = 0; i < e.length; i++) {
        if (e[i].match(/[^\x00-\xff]/gi) != null)
          //全角
          Clen += 1
        else Elen += 0.5
      }
      switch (Clen) {
        case 4:
          this.nameLength = 5
          break
        case 3:
          this.nameLength = 6
          break
        case 2:
          this.nameLength = 7
          break
        case 1:
          this.nameLength = 8
        case 0:
          this.nameLength = 8
          break

        default:
          this.nameLength = 5
          break
      }
    }
  },
  mounted() {
    this.editBatch.start_num = 1
    this.editBatch.end_num = 1
    this.listShopTable()
    this.getOptionSubarea()
    this.getOptionMachine()
    this.statusList = getStautsText('shop_table.status')
  }
}
</script>
<style>
@import './table-list.css';
</style>
