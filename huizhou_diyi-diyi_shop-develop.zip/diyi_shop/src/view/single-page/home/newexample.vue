<template>
  <div style="background: none; position: relative;" >
      <hgroup class="zexian-title" >
          <!-- 标题 -->
          <h3>营业统计</h3>
      </hgroup>
      <div class="tab-butoom" >
          <div @click="tabCavc(1,'today')" :class="cavindex == 1 ? 'activeTab' : 'noactiveTab'" >当天营业</div>
          <div @click="tabCavc(2,'week')" :class="cavindex == 2 ? 'activeTab' : 'noactiveTab' " >本周营业</div>
          <div @click="tabCavc(3,'month')" :class="cavindex == 3 ? 'activeTab' : 'noactiveTab' " >本月营业</div>
          <div @click="tabCavc(4,'year')" :class="cavindex == 4 ? 'activeTab' : 'noactiveTab' " >本年营业</div>
      </div>
    <div id="container" style="height:350px;  background: #fff;  box-shadow: 0 0 1px 0px rgba(0,0,0,0.1); border: 1px solid #eee;   margin-top: 30px "></div>
  </div>
</template>

<script>
import { businessStatistics } from '@/api/home/home'
import echarts from 'echarts'
import { convertPrice } from "@/libs/tools.js";
export default {
  data () {
    return {
      xdata: [],
      ydata: [],
      ydatatwo: [],
      bigdata: [],
      resdata: {
        sort: {
          day: 'asc'
        },
        day: 'today'
      },
      cavindex: 1
    }
  },
  mounted () {
    this.hourSales()
  },
  methods: {
    initCran () {
      var dom = document.getElementById('container')
      var myChart = echarts.init(dom)
      let option = null
      option = {
        // title: {
        //   text: '时段经营报表'
        // },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: ['订单数', '营业金额'],
          top: 20
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        toolbox: {
          feature: {
            saveAsImage: {}
          },
          right: 50,
          top: 15
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: this.xdata
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: '订单数',
            type: 'line',
            stack: '总量',
            data: this.ydata
          },
          {
            name: '营业金额',
            type: 'line',
            stack: '总量',
            data: this.ydatatwo
          }
        ]
      }
      if (option && typeof option === 'object') {
        myChart.setOption(option, true)
      }
      // 自适应
      window.onresize = function () {
        myChart.resize()
      }
    },
    async hourSales () {
      this.xdata = []
      businessStatistics(this.resdata).then(res => {
        console.log(res,'营业统计');
        
        this.bigdata = res.data.data.list
        for (let i = 0; i < this.bigdata.length; i++) {
          this.$set(this.xdata, i, this.bigdata[i].day)
          this.$set(this.ydata, i, this.bigdata[i].order_num)
          this.$set(this.ydatatwo, i, convertPrice(this.bigdata[i].money));
          // 对天转换
          if (this.resdata.day == 'today') {
            let arr = JSON.parse(JSON.stringify(this.xdata))
            let newsarr = arr.map(item => {
              return item + '：00'
            })
            if (newsarr.length == this.bigdata.length) {
              this.xdata = newsarr
            }
          }
        }
        this.initCran()
      })
    },
    tabCavc (v, i) {
      this.cavindex = v
      this.resdata.day = i
      this.hourSales()
    }
  }
}
</script>

<style scope>
/* 选中 */
.activeTab{
  background: #ed3f14 !important;
  color: #fff !important;
  border-radius: 5px;
}
</style>
