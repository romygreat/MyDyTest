<template>
  <div>
    <Row :gutter="20">
       <Col  :md="12"  :xs='12' :sm='12' :lg="6">
           <div class="headerbox" >
               <img class="headerimg" :src="headerimgs.hamejpg01" alt="">
               <div>
                  <h3>{{tofix(headerText.amount)}}</h3>
                  <p>今日营业总额（元）</p>
               </div>
           </div>
       </Col>
       <Col  :md="12"  :xs='12' :sm='12' :lg="6">
           <div class="headerbox" >
               <img class="headerimg" :src="headerimgs.hamejpg02" alt="">
               <div>
                  <h3>{{headerText.num}}</h3>
                  <p>就餐人数（人）</p>
               </div>
           </div>
       </Col>
       <Col  :md="12"  :xs='12' :sm='12' :lg="6">
           <div class="headerbox" >
               <img class="headerimg" :src="headerimgs.hamejpg03" alt="">
               <div>
                  <h3>{{headerText.total}}</h3>
                  <p>今日订单数（单）</p>
               </div>
           </div>
       </Col>
       <Col  :md="12"  :xs='12' :sm='12' :lg="6">
           <div class="headerbox" >
               <img class="headerimg" :src="headerimgs.hamejpg04" alt="">
               <div>
                  <h3>{{tofix(headerText.avg)}}</h3>
                  <p>人均消费金额（元）</p>
               </div>
           </div>
       </Col>
    </Row>
    <Row >
       <Col span="10"  :xs='24' :lg='10'  >
        <section  class="tripshome" >
          <hgroup>餐厅提醒</hgroup>
          <div class="tripshome-box" >
            <div class="tripshome-box-text" v-if="tprisdata" >
                <aside>
                    <h3>菜品提醒：</h3>
                    <span>待上架的菜品 (<aside style="color:red;display: inline-block;">{{tprisdata.sale[0].no_sale}}</aside>)</span>
                    <span>已上架的菜品 (<aside style="color:red;display: inline-block;">{{tprisdata.sale[0].is_sale}}</aside>)</span>
                </aside>
                <aside>
                    <h3>挂账记录：</h3>
                    <span>未清挂账 (<aside style="color:red;display: inline-block;">0</aside>)</span>
                    <span>本月挂账 (<aside style="color:red;display: inline-block;">0</aside>)</span>
                    <span>今日挂账 (<aside style="color:red;display: inline-block;">0</aside>)</span>
                </aside>
                <!-- <aside>
                    <h3>免单记录：</h3>
                    <span>本月免单 (<aside style="color:red;display: inline-block;">0</aside>)</span>
                    <span>今日免单 (<aside style="color:red;display: inline-block;">0</aside>)</span>
                </aside> -->
                <aside>
                    <h3>退菜记录：</h3>
                    <span>本月退菜 (<aside style="color:red;display: inline-block;">0</aside>)</span>
                    <span>今日退菜 (<aside style="color:red;display: inline-block;">0</aside>)</span>
                </aside>
                <aside>
                    <h3>设备管理：</h3>
                    <span>未分配 (<aside style="color:red;display: inline-block;">{{tprisdata.device[0].undistributed}}</aside>)</span>
                    <span>正常使用 (<aside style="color:red;display: inline-block;">{{tprisdata.device[0].normal}}</aside>)</span>
                    <span>设备故障 (<aside style="color:red;display: inline-block;">{{tprisdata.device[0].breakdown}}</aside>)</span>
                    <span>设备返修 (<aside style="color:red;display: inline-block;">{{tprisdata.device[0].repair}}</aside>)</span>
                </aside>
            </div>
          </div>
        </section>
      </Col>
      <Col span="7"  :xs='14' :lg='7' >
          <section class="hamerank" >
              <div class="hamernkMune" >
                <hgroup>菜品排行榜<span @click="goroterlist('menuRank')">查看更多</span></hgroup>
                <div class="hamernkMune-box" >
                  <!-- 题头 -->
                  <ul class="hamernkMune-title" >
                    <li>排序</li>
                    <li>菜品</li>
                    <li>销售金额(元)</li>
                    <li>销售数量</li>
                  </ul>
                  <ul class="homernkMune-list" >
                    <li v-for="(item, index) in rankdata" :key="index" v-show="index<6">
                        <span><p>{{item.rank}}</p></span>
                        <span>{{item.name}}</span>
                        <span>{{(item.unit_price/100*item.sales).toFixed(2)}}元</span>
                        <span>{{parseInt(item.sales)}}</span>
                    </li>
                  </ul>
                </div>
              </div>
          </section>
      </Col>
      <Col span="5" :xs='10' :lg='7'  >
        <section class="quicklink" >
          <hgroup>快捷入口</hgroup>
          <div class="quicklink-box" >
            <!-- <div><img :src="headerimgs.link01" alt="" srcset=""><span>收银系统</span></div> -->
            <div @click="goroterlist('product-edit')" ><img :src="headerimgs.link02" alt="" srcset=""><span>添加产品</span></div>
            <div @click="goroterlist('orderList')"><img :src="headerimgs.link03" alt="" srcset=""><span>订单查询</span></div>
            <div @click="goroterlist('table-list')"><img :src="headerimgs.link04" alt="" srcset=""><span>桌号管理</span></div>
            <div @click="goroterlist('flowDetail')"><img :src="headerimgs.link05" alt="" srcset=""><span>统计报表</span></div>
            <div @click="goroterlist('staff')"><img :src="headerimgs.link06" alt="" srcset=""><span>员工管理</span></div>
            <div @click="goroterlist('order-machine')"><img :src="headerimgs.link07" alt="" srcset=""><span>设备管理</span></div>
            <div @click="edituser = true"><img :src="headerimgs.link08" alt="" srcset=""><span>修改密码</span></div>
          </div>
        </section>
      </Col>
    </Row>
    <div style="width:100%;height:0;clear:both; " ></div>
    <Card class="home-footer-box" style="background:none;box-shadow:none" shadow>
        <Nexample style="height: 350px;"/>
    </Card>
    </Row>

    <Modal
        v-model="edituser"
        title="修改密码"
        >
        <Form ref="modifyPwd" :model="users">
          <FormItem prop="rate">
            <Row class="form-row">
              <Col span="6"><div class="col1">当前密码：</div></Col>
              <Col span="16"><Input :maxlength='40' v-model="users.psd" placeholder="请输入当前密码，初始密码为123456"/></Col>
            </Row>
            <Row class="form-row">
              <Col span="6"><div class="col1">新密码：</div></Col>
              <Col span="16"><Input :maxlength='40' v-model="users.repsd" placeholder="密码长度6到32位"/></Col>
            </Row>
            <Row class="form-row">
              <Col span="6"><div class="col1">确认密码：</div></Col>
              <Col span="16"><Input :maxlength='40' v-model="users.repsds" placeholder="确认密码和新密码保持一致"/></Col>
            </Row>
          </formItem>
        </Form>
        <div slot="footer">
          <Button type="text" size="large" @click="edituser=false">取消</Button>
          <Button type="primary" size="large" @click=" modifyPwds">确定</Button>
        </div>
    </Modal>

  </div>
</template>

<script>
import InforCard from '_c/info-card'
import CountTo from '_c/count-to'
import { ChartPie, ChartBar } from '_c/charts'
import Example from './example.vue'
import Nexample from './newexample.vue'
import { headertext,salesProduct ,muneranks, notification,getStatus} from '@/api/home/home'
import hamejpg01 from '@/assets/images/heam (1).jpg'
import hamejpg02 from '@/assets/images/heam (2).jpg'
import hamejpg03 from '@/assets/images/heam (3).jpg'
import hamejpg04 from '@/assets/images/heam (4).jpg'
import link01 from '@/assets/images/ranklink (1).png'
import link02 from '@/assets/images/ranklink (2).png'
import link03 from '@/assets/images/ranklink (3).png'
import link04 from '@/assets/images/ranklink (4).png'
import link05 from '@/assets/images/ranklink (5).png'
import link06 from '@/assets/images/ranklink (6).png'
import link07 from '@/assets/images/ranklink (7).png'
import link08 from '@/assets/images/ranklink (8).png'
import { modifyPwd } from '@/api/account/account'
import { setStautsText , getStautsText, convertPrice } from '@/libs/tools.js'
import { mapActions } from 'vuex'
export default {
  name: 'home',
  components: {
    InforCard,
    CountTo,
    ChartPie,
    ChartBar,
    Example,
    Nexample
  },
  data () {
    return {
      users: {
        psd: '',
        repsd: '',
        repsds: ''
      },
      edituser: false,
      headerimgs: {
        hamejpg01,
        hamejpg02,
        hamejpg03,
        hamejpg04,
        link01,
        link02,
        link03,
        link04,
        link05,
        link06,
        link07,
        link08
      },
      rankdata: [],
      headerText: {
      },
      inforCardData: [
        { title: '新增用户', icon: 'md-person-add', count: 803, color: '#2d8cf0' },
        { title: '累计点击', icon: 'md-locate', count: 232, color: '#19be6b' },
        { title: '新增问答', icon: 'md-help-circle', count: 142, color: '#ff9900' },
        { title: '分享统计', icon: 'md-share', count: 657, color: '#ed3f14' }
        // { title: '新增互动', icon: 'md-chatbubbles', count: 12, color: '#E46CBB' },
        // { title: '新增页面', icon: 'md-map', count: 14, color: '#9A66E4' }
      ],
      pieData: [
        { value: 335, name: '直接访问' },
        { value: 310, name: '邮件营销' },
        { value: 234, name: '联盟广告' },
        { value: 135, name: '视频广告' },
        { value: 1548, name: '搜索引擎' }
      ],
      barData: {
        Mon: 13253,
        Tue: 34235,
        Wed: 26321,
        Thu: 12340,
        Fri: 24643,
        Sat: 1322,
        Sun: 1324
      },
      tprisdata: {
        device: [
          { undistributed: '',
            normal: '',
            breakdown: '',
            repair: '' }
        ],
        sale: [
          { no_sale: '',
            is_sale: '' }
        ]
      }
    }
  },
  async mounted () {
    this.munerank()

    this.headerinfo()
    this.notifica()
  //  this.getStatusinfo().then(res=>{     
  //     this.$router.push({
  //       name:'home'
  //     })
  //  })
    await this.getStatusinfo()
  },
  methods: {
    // 请求首页基本信息
    headerinfo () {
      const data = {
        branch: 4
      }
      headertext(data).then(res => {
        this.headerText = res.data.data
      })
    },
    // 菜品销售排行
    munerank () {
      const data = {
        page: 1,
        rows: 5
      }
      salesProduct(data).then(res => {
        this.rankdata = res.data.data.list
        
      })
      // this.rankdata.forEach((item,idx) => {
      //   item.rank = idx + 1
      // })
    },
    // 首页餐挺提醒
    notifica () {
      const data = {}
      notification(data).then(res => {
        this.tprisdata = res.data.data
      })
    },
    tofix (v) {
      return convertPrice(v).toFixed(2)
    },
    goroterlist (v) {
      this.$router.push({
        name: v
      })
    },
    modifyPwds () {
      if (this.users.psd.length < 6 || this.users.psd.length > 25) this.$Message.info('旧密码不正确')
      else if (this.users.repsd.length < 6 || this.users.repsd.length > 25) this.$Message.info('新密码长度应为6~25位')
      else if (this.users.repsds.length < 6 || this.users.repsds.length > 25) this.$Message.info('重复密码应长度为6~25位')
      else if (this.users.repsd != this.users.repsds) this.$Message.info('重复密码不一致~25位')
      else {
        let data = {
          oldpwd: this.users.psd,
          pwd: this.users.repsd,
          repwd: this.users.repsds
        }
        modifyPwd(data)
          .then((res) => {
            if (res.data.code > 0) {
              this.edituser = false
              this.$Message.info(res.data.message + ', 请重新登录')
              this.handleLogOut().then(() => {
                this.$router.push({
                  name: 'login'
                })
              })
            } else {
              this.$Message.info(res.data.message)
            }
          })
          .catch(err => {
          })
      }
    },
    //全局储存状态
    async getStatusinfo(){
      const data = {}
      await getStatus(data).then(res =>{        
        setStautsText(res.data.data)
      })
     
      return getStautsText('service.type')
    }
  }
}
</script>

<style lang="less" scope>
@import url('./index.less');
</style>
