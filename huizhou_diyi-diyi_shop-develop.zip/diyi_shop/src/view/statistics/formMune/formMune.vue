<template>
    <div>
        <hgroup class="shopC-title" >
            <h3>菜品销售统计表</h3>
        </hgroup>
        <!-- <div class="formDetail-buttom" >
            <Button :class="{activeButtom : isactive}" style='margin-right:15px'  type="dashed">菜品查询</Button>
            <Button type="dashed">订单查询</Button>
        </div> -->
        <section>
                <div class="formTablesss" >
                    <p>菜品名 : </p>
                    <Input :maxlength='40' style='display: inline-block; width:200px' v-model="resdata.title" placeholder="请输入您想要查询的菜品" clearable />
                    <Button @click="productStatiList" style="margin-left:10px" type="primary">查询</Button>
                </div>
            <div class="formSear" >
                <div>

                </div>
            </div>
            <div class="tablediv" style="width:800px"  >
              <Table :data="tableData" :columns="tableColumns" stripe></Table>
            </div>
            <div class="tablepage" style="width:800px"  >
                <Page @on-page-size-change='rowshant' @on-change='pagehant'  :page-size='resdata.rows' :total="resdata.total" show-total show-elevator show-sizer />
            </div>
        </section>
    </div>
</template>

<script>
import { productStati } from '@/api/report-form/formMune'
export default {
  data () {
    return {
      tableData: [],
      tableColumns: [
        { key: 'pic',
          title: '产品图片',
          align: 'center',
          width: 150,
          render: (h, params) => {
            if (params.row.pic) {
              return h('div', [
                h('img', {
                  attrs: {
                    src: this.$store.state.app.qiniuDomain + params.row.pic
                  },
                  style: {
                    width: '40px',
                    height: '40px',
                    display: 'block',
                    margin: '5px auto'
                  }
                })
              ])
            } else {
              return h('div', '无')
            }
          } },
        { key: 'title', title: '产品名称', align: 'center' },
        { key: 'product_code', title: '产品编号', align: 'center' },
        { key: 'num', title: '产品数量', align: 'center' },
        { key: 'unit_price',
          title: '产品单价',
          align: 'center',
          render: (h, params) => {
            let a = JSON.parse(JSON.stringify(params.row.unit_price))
            a = Number(a).toFixed(2)
            return h('div', [
              h('p', a + ' ' + '元')
            ])
          }
        },
        { key: 'price',
          title: '销售总价',
          align: 'center',
          render: (h, params) => {
            let a = JSON.parse(JSON.stringify(params.row.price))
            a = Number(a).toFixed(2)
            return h('div', [
              h('p', a + ' ' + '元')
            ])
          } }
      ],
      options: {
        shortcuts: [
          {
            text: '一周',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              return [start, end]
            }
          },
          {
            text: '一个月',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              return [start, end]
            }
          },
          {
            text: '三个月',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              return [start, end]
            }
          }
        ]
      },
      isactive: true,
      resdata: {
        page: 1,
        rows: 10,
        total: 100,
        title: ''
      }
    }
  },
  methods: {
    // 获取表格数据
    productStatiList () {
      productStati(this.resdata).then(res => {
        this.resdata.total = res.data.data.total
        this.tableData = res.data.data.list
      }).catch(err => {
        console.error(err)
      })
    },
    pagehant (index) {
      this.resdata.page = index
      this.productStatiList()
    },
    rowshant (index) {
      this.resdata.rows = index
      this.productStatiList()
    }
  },
  mounted () {
    this.productStatiList()
  }
}
</script>

<style>
@import url('../index.less');
/* 选中 */
.activeButtom{
    color: #57a3f3;
    border: 1px dashed #57a3f3
}
</style>
