import fromTables from './fromTables'
export default fromTables
