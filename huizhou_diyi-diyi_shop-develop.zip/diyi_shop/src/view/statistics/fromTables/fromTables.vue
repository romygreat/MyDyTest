<template>
    <div>
        <hgroup class="shopC-title" >
            <h3>台桌统计表</h3>
        </hgroup>
        <section>
          <hgroup>
                <div class="formTablesss" >
                    <p>台桌号 : </p>
                    <Input :maxlength='40' style='display: inline-block; width:200px' v-model="resdata.table_no" placeholder="请输入您想要查询的台桌" clearable />
                    <Button @click="tableNoStati" style="margin-left:10px" type="primary">查询</Button>
                </div>
            </hgroup>
            <div class="tablediv" style="width:800px"  >
              <Table :data="tableData" :columns="tableColumns" stripe></Table>
            </div>
            <div class="tablepage" style="width:800px" >
                <Page @on-page-size-change='rowshant' @on-change='pagehant'  :page-size='resdata.rows' :total="resdata.total" show-total show-elevator show-sizer />
            </div>
        </section>
    </div>
</template>

<script>
import { tableNoStatistics } from '@/api/report-form/fromTables'
export default {
  data () {
    return {
      tableData: [],
      tableColumns: [
        { key: 'id', title: 'ID' },
        { key: 'table_no', title: '桌号' },
        { key: 'paid_price',
          title: '金额',
          render: (h, params) => {
            let a = JSON.parse(JSON.stringify(params.row.paid_price))
            a = Number(a).toFixed(2)
            return h('div', [
              h('p', a + ' ' + '元')
            ])
          } },
        { key: 'tableware_num', title: '人数' }
      ],
      options: {
        shortcuts: [
          {
            text: '一周',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              return [start, end]
            }
          },
          {
            text: '一个月',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              return [start, end]
            }
          },
          {
            text: '三个月',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              return [start, end]
            }
          }
        ]
      },
      isactive: true,
      resdata: {
        page: 1,
        rows: 10,
        total: 100,
        table_no: ''
      }
    }
  },
  methods: {
    // 获取表格数据
    tableNoStati () {
      tableNoStatistics(this.resdata).then(res => {
        this.resdata.total = res.data.data.total
        this.tableData = res.data.data.list
        console.log(res)
      }).catch(err => {
        console.error(err)
      })
    },
    pagehant (index) {
      this.resdata.page = index
      this.tableNoStati()
    },
    rowshant (index) {
      this.resdata.rows = index
      this.tableNoStati()
    }
  },
  mounted () {
    this.tableNoStati()
  }
}
</script>

<style>
@import url('../index.less');
/* 选中 */
.activeButtom{
    color: #57a3f3;
    border: 1px dashed #57a3f3
}
</style>
