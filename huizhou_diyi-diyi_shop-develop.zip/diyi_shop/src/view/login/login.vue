<style lang="less">
  @import './login.less';
</style>

<template>
  <div class="login">
    
    <div class="login-top">
	    <img src="../../assets/images/login_title_@x1.png" />
	    <!-- <p class="login-top-permissions">管理员</p> -->
    </div>
    <div class="login-con">
      <div class="form-con">
        <login-form @on-success-valid="handleSubmit"></login-form>
      </div>
    </div>
    <div class="login-footer">
      <span>公司地址：广东省惠州市惠城区麦地路58号风尚国际大厦18F 邮编：516000 电话：0752-2520901</span>
      <span>粤ICP备17043255号-1 Copyright © 2019 广东迪溢商务服务有限公司. All rights reserved</span>
    </div>
  </div>
</template>

<script>
import LoginForm from '_c/login-form'
import { mapActions } from 'vuex'
export default {
  components: {
    LoginForm
  },
  methods: {
    ...mapActions([
      'handleLogin',
      'getUserInfo'
    ]),
    // 登陆事件
    handleSubmit ({ userName, password }) {
      this.handleLogin({ userName, password }).then(res => {
        console.log(111);
        if (res.code > 0) {
          this.$router.push({
            name: this.$config.homeName
          })
        } else {
          this.$Message.info(res.message)
        }
      })
    }
  }
}
</script>

<style>

</style>
