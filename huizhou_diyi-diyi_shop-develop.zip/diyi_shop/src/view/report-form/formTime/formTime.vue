<template>
  <div>
    <div id="container" style="height:350px"></div>
  </div>
</template>

<script>
import { hourSalesStatement } from '@/api/report-form/formTime'
import echarts from 'echarts'
import { convertPrice } from "@/libs/tools.js";
export default {
  data () {
    return {
      xdata: [],
      ydata: [],
      bigdata: []
    }
  },
  mounted () {
    this.hourSales()
  },
  methods: {
    initCran () {
      var dom = document.getElementById('container')
      var myChart = echarts.init(dom)
      let option = null
      option = {
        title: {
          text: '时段经营报表'
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: ['销售总额']
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        toolbox: {
          feature: {
            saveAsImage: {}
          },
          right: 50
        },
        xAxis: {
          type: 'category',
          boundaryGap: false,
          data: this.xdata
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: '销售总额',
            type: 'line',
            stack: '总量',
            data: this.ydata
          }
        ]
      }
      if (option && typeof option === 'object') {
        myChart.setOption(option, true)
      }
      // 自适应
      window.onresize = function () {
        myChart.resize()
      }
    },
    async hourSales () {
      const data = {}
      await hourSalesStatement(data).then(res => {
        this.bigdata = res.data.data.list
        this.bigdata.splice(7)
        for (let i = 0; i < this.bigdata.length; i++) {
          this.$set(this.xdata, i, this.bigdata[i].hour)
          this.$set(this.ydata, i, convertPrice(this.bigdata[i].paid_price));
        }
        this.initCran()
      })
    }
  }
}
</script>

<style>

</style>
