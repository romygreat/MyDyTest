<template>
  <div>
    <hgroup class="shopC-title">
      <h3>菜品销售排行</h3>
    </hgroup>
    <!-- 
    <div class="formDetail-buttom">
      <Button style="margin-right:15px" type="dashed">今天</Button>
      <Button type="dashed">昨天</Button>
      <Button type="dashed">本周</Button>
      <Button type="dashed">本月</Button>
      <Button type="dashed">近七天</Button>
    </div>-->
    <section>
      <hgroup class="formTitle">
        <h3>当前门店</h3>
        <div class="formTime">
          <p>日期选择 :</p>
          <DatePicker
            v-model="searchTime"
            type="daterange"
            :options="options"
            placement="bottom"
            placeholder="请选择查找的时间段"
            style="width: 200px"
          ></DatePicker>
          <Button style="margin-left:10px" type="primary" @click="SearchByTime()">查询</Button>
          <Button style="margin-left:10px" type="primary" @click="Refresh()">刷新</Button>
        </div>
      </hgroup>

      <div class="tablediv" style="width:600px">
        <Table :data="tableData" :columns="tableColumns" stripe>
        </Table>
      </div>
      <div class="tablepage" style="width:800px;text-align:left">
        <Page
          @on-page-size-change="rowshant"
          @on-change="pagehant"
          :page-size="resdata.row"
          :current="resdata.page"
          :total="total"
          show-total
          show-elevator
          show-sizer
        />
      </div>
    </section>
  </div>
</template>

<script>
import { rankList } from '@/api/report-form/menuRank'
import { convertPrice } from '@/libs/tools.js'
import { shopCate } from "@/api/home/home.js";
import { log } from 'util';

export default {
  data() {
    return {
      tableData: [],
      resShopCate: {
        sort: {
          sort: 'asc'
        }
      },
      tableColumns: [
        { key: 'rank', title: '销售排行', wdith: 80 },
        { key: 'name', title: '菜品名称', align: 'center' },
        { key: 'cate_name', title: '菜品类别', },
        { key: 'sales', title: '销售数量', align: 'center' },
        { title: '商品原价(元)', key: 'unit_price', align: 'center',
          render: (h, params) => {
            return h("div", [
              h("p", convertPrice(params.row.unit_price) + " " + "元")
            ]);
          }
        },
      ],
      options: {
        shortcuts: [
          {
            text: '一周',
            value() {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              return [start, end]
            }
          },
          {
            text: '一个月',
            value() {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              return [start, end]
            }
          },
          {
            text: '三个月',
            value() {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              return [start, end]
            }
          }
        ]
      },
      isactive: true,
      resdata: {
        page: 1,
        row: 10,
        sign: ''
      },
      total: 0,
      searchTime: [],
      shopCateList:{}
    }
  },
  methods: {
    // 获取表格数据
    salesProductList() {
      this.resdata.machine = 'cash'
      rankList(this.resdata)
        .then(res => {
          this.tableData = res.data.data.list
          this.total = res.data.data.total
          this.tableData.forEach((item,index)=>{
            this.tableData[index].cate_name = this.shopCateList[item.cate_id]
          })

        })
        .catch(err => {
          console.error(err)
        })
    },
    pagehant(index) {
      this.resdata.page = index
      this.salesProductList()
    },
    rowshant(index) {
      this.resdata.row = index
      this.salesProductList()
    },
    SearchByTime() {
      if (this.searchTime.length > 1 && this.searchTime[0] != '') {
        let startTime = new Date(this.searchTime[0])
        let endTime = new Date(this.searchTime[1])
        let time =
          startTime.getFullYear() +
          '-' +
          Number(startTime.getMonth() + 1) +
          '-' +
          startTime.getDate() +
          ' - ' +
          endTime.getFullYear() +
          '-' +
          Number(endTime.getMonth() + 1) +
          '-' +
          endTime.getDate()
        this.resdata.sign = time
        this.salesProductList()
      }
    },
    Refresh() {
      this.searchTime = ''
      this.resdata = {
        page: 1,
        row: 10,
        sign: ''
      }
      this.salesProductList()
    },
    async shopCateTitle() {
      await shopCate(this.resShopCate).then(res => {
        res.data.data.list.forEach(item => {
          this.shopCateList[item.id] = item.name
        });        
      })
    },
  },
  mounted() {
    this.salesProductList()
  },
created(){
  this.shopCateTitle()
}
}
</script>

<style>
@import url('../index.less');
/* 选中 */
.activeButtom {
  color: #57a3f3;
  border: 1px dashed #57a3f3;
}
</style>
