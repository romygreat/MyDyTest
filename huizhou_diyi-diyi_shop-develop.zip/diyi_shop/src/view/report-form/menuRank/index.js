import menuRank from './menuRank'
export default menuRank
