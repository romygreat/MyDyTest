<template>
    <div>
        <hgroup class="shopC-title" >
            <h3>月度营销汇总</h3>
        </hgroup>
        <!-- <div class="formDetail-buttom" >
            <Button :class="{activeButtom : isactive}" style='margin-right:15px'  type="dashed">菜品查询</Button>
            <Button type="dashed">订单查询</Button>
        </div> -->
        <section>
            <hgroup class="formTitle" >
                <!-- <h3>当前门店：{{shopname}}</h3> -->
                <div class="formTime" >
                    <p>月度选择 : </p>
                   <DatePicker  @on-change='timeove' type="month" placeholder="请输入您想要查找的月度" style="width: 200px"></DatePicker>
                    <Button @click="monthSales" style="margin-left:10px" type="primary">查询</Button>
                </div>
            </hgroup>
            <div class="tablediv" style="width:900px"  >
              <Table :data="tableData" :columns="tableColumns" stripe></Table>
            </div>
            <div class="tablepage" style="width:900px"  >
                <Page @on-page-size-change='rowshant' @on-change='pagehant'  :page-size='resdata.rows' :total="resdata.total" show-total show-elevator show-sizer />
            </div>
        </section>
    </div>
</template>

<script>
import { monthSalesStatement } from '@/api/report-form/formMonthly'
export default {
  data () {
    return {
      tableData: [],
      tableColumns: [
        { title: '日期', key: 'month' },
        { title: '交易数', key: 'transaction_number', align: 'center' },
        { title: '客人数', key: 'tableware_num', align: 'center' },
        { title: '实收',
          key: 'paid_price',
          align: 'center',
          render: (h, params) => {
            let a = JSON.parse(JSON.stringify(params.row.paid_price))
            a = Number(a).toFixed(2)
            return h('div', [
              h('p', a + ' ' + '元')
            ])
          }
        },
        { title: '平均订单价',
          key: 'avg_order',
          align: 'center',
          render: (h, params) => {
            let a = JSON.parse(JSON.stringify(params.row.avg_order))
            a = Number(a).toFixed(2)
            return h('div', [
              h('p', a + ' ' + '元')
            ])
          }
        },
        { title: '平均客单价',
          key: 'avg_tableware_num',
          align: 'center',
          render: (h, params) => {
            let a = JSON.parse(JSON.stringify(params.row.avg_tableware_num))
            a = Number(a).toFixed(2)
            return h('div', [
              h('p', a + ' ' + '元')
            ])
          } }
      ],
      options: {
        shortcuts: [
          {
            text: '一周',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              return [start, end]
            }
          },
          {
            text: '一个月',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              return [start, end]
            }
          },
          {
            text: '三个月',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              return [start, end]
            }
          }
        ]
      },
      isactive: true,
      resdata: {
        total: 100,
        rows: 10,
        pay_time: ''
      }
    }
  },
  methods: {
    // 获取表格数据
    monthSales () {
      monthSalesStatement(this.resdata).then(res => {
        this.resdata.total = res.data.data.total
        this.tableData = res.data.data.list
        console.log(res)
      }).catch(err => {
        console.error(err)
      })
    },
    pagehant (index) {
      this.resdata.page = index
      this.monthSales()
    },
    rowshant (index) {
      this.resdata.rows = index
      this.monthSales()
    },
    timeove (v, i) {
      this.resdata.pay_time = v
    }
  },
  mounted () {
    this.monthSales()
  }
}
</script>

<style>
@import url('../index.less');
/* 选中 */
.activeButtom{
    color: #57a3f3;
    border: 1px dashed #57a3f3
}
</style>
