<template>
    <div>
      <!-- 总店数据汇总 -->
        <hgroup class="shopC-title" >
            <h3>总店数据汇总</h3>
        </hgroup>
        <section>
            <hgroup class="formTitle" >
                <!-- <h3>当前门店：{{shopname}}</h3> -->
                <div class="formTime" >
                    <p>日期选择 : </p>
                    <DatePicker type="daterange" :options="options" placement="bottom" placeholder="请选择查找的时间段" style="width: 200px"></DatePicker>
                    <Button style="margin-left:10px" type="primary">查询</Button>
                </div>
            </hgroup>
            <div class="tablediv" >
              <Table :data="tableData" :columns="tableColumns" stripe></Table>
            </div>
            <div class="tablepage" >
                <Page :page-size='10' :total="100" show-total show-elevator show-sizer />
            </div>
        </section>
        <!-- 营业数据汇总 -->
        <hgroup class="shopC-title" >
            <h3>营业数据汇总</h3>
        </hgroup>
        <section>
            <hgroup class="formTitle" >
                <!-- <h3>当前门店：{{shopname}}</h3> -->
                <div class="formTime" >
                    <p>日期选择 : </p>
                    <DatePicker type="daterange" :options="options" placement="bottom" placeholder="请选择查找的时间段" style="width: 200px"></DatePicker>
                    <Button style="margin-left:10px" type="primary">查询</Button>
                </div>
            </hgroup>
            <div class="tablediv" >
              <Table :data="tableData" :columns="tableColumns" stripe></Table>
            </div>
            <div class="tablepage" >
                <Page :page-size='10' :total="100" show-total show-elevator show-sizer />
            </div>
        </section>
    </div>
</template>

<script>
export default {
  data () {
    return {
      shopname: '',
      options: {
        shortcuts: [
          {
            text: '一周',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              return [start, end]
            }
          },
          {
            text: '一个月',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              return [start, end]
            }
          },
          {
            text: '三个月',
            value () {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              return [start, end]
            }
          }
        ]
      },
      tableData: [],
      tableColumns: [
        {
          title: '暂时不知道',
          key: 'id'
        }
      ]
    }
  },
  created () {
    this.shopname = this.$store.state.user.adminInfo.shop.name
  }
}
</script>

<style scope>
@import '../index.less';
</style>
