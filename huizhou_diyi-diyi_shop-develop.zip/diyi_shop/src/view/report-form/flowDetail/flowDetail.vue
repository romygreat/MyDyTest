<template>
  <div>
    <hgroup class="shopC-title">
      <h3>营业流水明细</h3>
    </hgroup>
    <div class="formDetail-buttom">
      <Button
        @click="tabTables('1')"
        :class="{activeButtom : !isactive}"
        style="margin-right:15px"
        type="primary"
      >菜品查询</Button>
      <Button @click="tabTables('2')" :class="{activeButtom : isactive}" type="primary">订单查询</Button>
    </div>
    <section>
      <hgroup class="formTitle">
        <div class="formtable-no">
          <p>订单号 :</p>
          <Input
          :maxlength='40'
            style="width:180px"
            clearable
            v-model="resdata.order_no"
            placeholder="请输入您想要查询的订单号"
          />
        </div>
        <div class="formTime">
          <p>日期选择 :</p>
          <DatePicker
            type="daterange"
            :options="options"
            placement="bottom"
            placeholder="请选择查找的时间段"
            style="width: 250px"
            @on-change="timeove"
          ></DatePicker>
        </div>
        <div class="formTables">
          <p>台桌号 :</p>
          <Input
          :maxlength='40'
            style="width:180px"
            clearable
            v-model="resdata.table_no"
            placeholder="请输入您想要查询的台桌号"
          />
        </div>
        <Button @click="salesOrder" style="margin-left:10px" type="primary">查询</Button>
      </hgroup>
      <div class="formSear">
        <div></div>
      </div>
      <div class="tablediv">
        <Table v-if="isactive" :data="tableData" :columns="tableColumns" stripe></Table>
        <Table v-else :data="tableData" :columns="tableColumnsOrder" stripe></Table>
      </div>
      <div class="tablepage">
        <Page
          @on-page-size-change="rowshant"
          @on-change="pagehant"
          :page-size="resdata.rows"
          :total="resdata.total"
          :current="resdata.page"
          show-total
          show-elevator
          show-sizer
        />
      </div>
    </section>
  </div>
</template>

<script>
import { salesOrderDetails } from '@/api/report-form/flowDetail'
import dayjs from 'dayjs'
import Calc from 'number-precision'
import { convertPrice } from "@/libs/tools.js";
dayjs().format()
export default {
  data() {
    return {
      tableData: [],
      tableColumns: [
        { title: '订单号', key: 'order_no' },
        { title: '产品名称', key: 'name', width: 200, align: 'center' },
        { title: '桌台号', key: 'table_no', width: 80 },
        { title: '客人数', key: 'tableware_num', width: 80, align: 'center' },
        {
          title: '开台时间',
          key: 'add_time',
          align: 'center',
          render: (h, params) => {
            let newstime = params.row.add_time * 1000
            return <span>{dayjs(newstime).format('YYYY-MM-DD')}</span>
          }
        },
        {
          title: '结账时间',
          key: 'over_time',
          align: 'center',
          render: (h, params) => {
            let newstimeov = params.row.over_time * 1000
            return <span>{dayjs(newstimeov).format('YYYY-MM-DD')}</span>
          }
        },
        { title: '单价', key: 'unit_price', align: 'center',
          render: (h, params) => {
            return h("div", [
              h("p", convertPrice(params.row.unit_price) + " " + "元")
            ]);
          }
        },
        { title: '数量', key: 'num', width: 80, align: 'center' },
        {
          title: '应收(元)',
          key: 'paid_price',
          align: 'center',
          width: 120,
          render: (h, params) => {
            return h("div", [
              h("p", convertPrice(params.row.paid_price*100) + " " + "元")
            ]);
          }
        },
        {
          title: '实付(元)',
          key: 'real_price',
          align: 'center',
          width: 120,
          render: (h, params) => {
            return h("div", [
              h("p", convertPrice(params.row.real_price*100) + " " + "元")
            ]);
          }
        }
      ],
      tableColumnsOrder: [
        { title: '订单号', key: 'order_no' },
        { title: '下单时间', key: 'add_time' },
        { title: '结帐时间', key: 'pay_time' },
        {
          title: "实收金额",
          key: "paid_price",
          render: (h, params) => {
            return h("div", [
              h("p", convertPrice(params.row.paid_price) + " " + "元")
            ]);
          }
        },
        { title: '台桌号', key: 'table_no' },
        { title: '就餐人数', key: 'tableware_num' }
      ],
      options: {
        shortcuts: [
          {
            text: '一周',
            value() {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              return [start, end]
            }
          },
          {
            text: '一个月',
            value() {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              return [start, end]
            }
          },
          {
            text: '三个月',
            value() {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              return [start, end]
            }
          }
        ]
        // disabledDate (date) {
        //   return date && date.valueOf() > Date.now() - 86400000
        // }
      },
      isactive: true,
      resdata: {
        details: 'product',
        page: 1,
        rows: 10,
        total: 100,
        order_no: '',
        table_no: '',
        add_time: [],
        sort:{
          add_time:'desc'
        }
      }
    }
  },
  methods: {
    // 获取表格数据(菜品)
    salesOrder(type) {
      if (type) {
        console.log(type, 111)
        this.resdata.page = 1
      }
      salesOrderDetails(this.resdata)
        .then(res => {
          this.resdata.total = Number(res.data.data.total)
          this.tableData = res.data.data.list
          console.log(this.tableData,'流水明细')

        })
        .catch(err => {
          console.error(err)
        })
    },
    pagehant(index) {
      this.resdata.page = index
      this.salesOrder()
    },
    rowshant(index) {
      this.resdata.rows = index
      this.salesOrder()
    },
    timeove(v, i) {
      let arr = [String(v[0]), String(v[1])]
      this.resdata.add_time = arr
      console.log(this.resdata.add_time)
      if (v[0] == '') {
        this.resdata.add_time = []
      }
    },
    tabTables(index) {
      if (index == 2) {
        this.isactive = false
        this.resdata.details = 'order'
        this.salesOrder(true)
      } else {
        this.isactive = true
        this.resdata.details = 'product'
        this.salesOrder(true)
      }
    }
  },
  mounted() {
    this.salesOrder()
  }
}
</script>

<style scope>
@import url('../index.less');
/* 选中 */
.activeButtom {
  background: #aaa;
  border: 1px solid #aaa !important;
  color: #fff !important;
}
</style>
