import flowDetail from './flowDetail'
export default flowDetail
