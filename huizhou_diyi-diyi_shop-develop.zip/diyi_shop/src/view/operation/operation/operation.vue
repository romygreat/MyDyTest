<template>
    <div>
        <p class="adminTitle" >操作日志</p>
        <Table :columns="columns" :data="operData"></Table>
        <div style="float: right; margin: 10px 0">
            <Page
              :total="Number(pagetotal)"
              :current='1'
              :page-size='10'
              @on-change='handlePage'
              >
            </Page>
        </div>
        <Modal
           v-model="operText"
           title="操作详情"
           width="500"
           class="operinfo"
           cancel-text=''
        >
         <p>操作账户ID：{{operinfo.id}}</p>
         <p>操作账号：{{operinfo.account}}</p>
         <p>操作时间：{{operinfo.addtime}}</p>
         <p>操作ip地址：{{operinfo.ip}}</p>
         <p>操作事件：{{operinfo.title}}</p>
         <p>操作内容：{{operinfo.content}}</p>
        </Modal>
    </div>
</template>

<script>
import { getToken } from '@/libs/util'
import dayjs from 'dayjs'
import { operinfotext, getOperTablesButoom } from '@/api/account/action-log'
export default {
  data () {
    return {
      columns: [
        {
          title: 'id',
          key: 'id',
          width: 150
        },
        {
          title: '账号',
          key: 'account'
        },
        {
          title: '操作',
          key: 'title'
        },
        {
          title: 'ip地址',
          key: 'ip'
        },
        {
          title: ' 操作时间',
          key: 'addtime',
          render: (h, params) => {
            return (
              <span>{ dayjs(params.addtime).format('YYYY-MM-DD') }</span>
            )
          },
          sortable: true,
          sortType: 'desc'
        },
        {
          title: '查看',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.show(params.index)
                    }
                  }
                },
                '操作详情'
              )
            ])
          }
        }
      ],
      operData: [],
      pagetotal: '',
      pageNum: '',
      operText: false,
      operinfo: ''
    }
  },
  methods: {
    show (index) {
      const info = {
        token: getToken(),
        id: this.operData[index].id
      }
      operinfotext(info).then((response) => {
        this.operText = true
        this.operinfo = response.data.data
      }).catch(error => {
      })
    },
    handlePage (value) {
      this.pageNum = value
      const getOperTablesinfo = {
        token: getToken(),
        page: this.pageNum,
        rows: 10
      }
      getOperTablesButoom(getOperTablesinfo).then((response) => {
        this.operData = response.data.data.list
      }).catch(error => {
      })
    },
    getOperTables () {
      const getOperTablesinfo = {
        token: getToken(),
        page: 1,
        rows: 10
      }
      getOperTablesButoom(getOperTablesinfo).then((response) => {
        this.pagetotal = response.data.data.total
        this.operData = response.data.data.list
      }).catch(error => {
      })
    }
  },
  mounted () {
    this.getOperTables()
  }
}
</script>

<style>
.adminTitle{
  font-size: 18px;
  font-weight: bold;
}
.m20{
  margin: 20px 0;
}
.operinfo p {
    font-size: 14px;
    line-height: 26px;
    word-wrap:break-word;
    width: 100%;
}
</style>
