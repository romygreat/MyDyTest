import Operation from './operation.vue'
export default Operation
