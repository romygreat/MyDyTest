<template>
  <div style="width:300px">
    <div>
      <Select
        @on-query-change="remotenull"
        @on-change="sdkinfo"
        v-model="selectinfo"
        filterable
        remote
        :remote-method="remoteMethod2"
        :loading="loading2"
      >
        <Option
          v-for="(option, index) in options2"
          :value="option.value"
          :key="index"
        >{{option.label}}</Option>
      </Select>
    </div>
  </div>
</template>

<script>
import { printerManuList } from '@/api/print/print'
export default {
  props: ['manu_id'],
  data() {
    return {
      selectinfo: [],
      loading2: false,
      options2: [],
      list: [],
      resselect: []
    }
  },
  methods: {
    async getCateProduct() {
      const data = {}
      await printerManuList(data).then(res => {
        this.list = JSON.parse(JSON.stringify(res.data.data.list))
        console.log(res, 'res')
        const listinfo = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        this.options2 = listinfo
      })
    },
    remoteMethod2(query) {
      if (query !== '') {
        this.loading2 = true
        setTimeout(() => {
          let arrlist = []
          this.loading2 = false
          const data = { name: query }
          printerManuList(data).then(res => {
            arrlist = JSON.parse(JSON.stringify(res.data.data.list))
            const listinfo = arrlist.map(item => {
              return {
                value: item.id,
                label: item.name
              }
            })
            this.options2 = listinfo.filter(
              item => item.label.toLowerCase().indexOf(query.toLowerCase()) > -1
            )
            this.tovalue()
          })
        }, 200)
      } else {
        this.options2 = []
        this.tovalue()
      }
    },
    sdkinfo(i) {
      const listinfo = this.list.map(item => {
        return {
          value: item.id,
          label: item.name
        }
      })
      this.options2 = listinfo
      this.resselect = []
      let arr = JSON.parse(JSON.stringify(this.selectinfo))
      for (let i in arr) {
        this.resselect[i] = { label_id: arr[i] }
      }
      this.tovalue()
    },
    remotenull(v) {
      if (v === '') {
        const listinfo = this.list.map(item => {
          return {
            value: item.id,
            label: item.name
          }
        })
        this.options2 = listinfo
        this.tovalue()
      }
    },
    tovalue() {
      //  The world! 時間よ、止まって。!!!
      this.$emit('garPrinter', this.selectinfo)
            console.log(this.selectinfo, 12331)
    }
  },
  async mounted() {
    await this.getCateProduct()
    console.log(this.manu_id,'传进来')
    if (this.manu_id && this.manu_id != '') {
      // 双向绑定之前选择的小吃集合ID
      this.list.forEach(el => {
       if(el.id == this.manu_id) {
         this.selectinfo = this.manu_id
       }
      })
    }
  }
}
</script>

<style>
</style>