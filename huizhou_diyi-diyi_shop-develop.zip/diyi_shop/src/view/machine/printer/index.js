/*
 * @Author: 叶锦荣
 * @Date: 2019-11-15 09:01:21
 * @LastEditTime: 2019-11-15 09:01:57
 */
import printer from './printer.vue'
export default printer