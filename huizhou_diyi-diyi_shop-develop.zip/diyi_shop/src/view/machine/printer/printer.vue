<!--
 * @Author: 叶锦荣
 * @Date: 2019-11-14 17:29:12
 * @LastEditTime: 2019-12-13 15:08:36
 -->
<template>
  <div class="printer">
    <hgroup>
      <h3>打印机管理</h3>
      <p>管理各个打印机</p>
    </hgroup>
    <section class="main">
      <Button
        style="display:block;margin-bottom:10px"
        type="primary"
        @click="openPrint('add')"
      >添加打印机</Button>
      <Table width='1300' :columns="columns" :data="printerList.list"></Table>
      <div style="width:1300px;margin-top:10px;text-align: right;">
        <Page
          show-total
          :page-size="resParam.rows"
          :current="resParam.page"
          :total="printerList.total"
          @on-change="setList"
          class="page-buttom"
        />
      </div>
    </section>
    <Modal v-model="printerShow" :title=" modalTitle" footer-hide @on-ok="addPrint()">
      <div class="printerModal">
        <dl>
          <dt>打印机名称：</dt>
          <dd>
            <Input :maxlength='40' v-model="printerAddObj.title" placeholder="请输入打印机名称" style="width: 300px" />
          </dd>
        </dl>
        <dl>
          <dt>{{printerAddObj.type == 3 ? '打印机SN' : '打印机IP'}}</dt>
          <dd>
            <Input :maxlength='40' v-model="printerAddObj.target" placeholder="请输入打印机IP地址" style="width: 300px" />
          </dd>
        </dl>
        <dl>
          <dt>品牌：</dt>
          <dd>
            <printerMenu v-if="printerShow" :manu_id='printerAddObj.manu_id' v-on:garPrinter='garPrinter($event)' />
          </dd>
        </dl>
        <dl>
          <dt>打印纸宽度：</dt>
          <dd>
            <RadioGroup v-model="printerAddObj.size">
              <Radio v-for="(item, index) in paperSize" :key="index" :label="item">{{item}}mm</Radio>
            </RadioGroup>
          </dd>
        </dl>
        <dl>
          <dt>接口类型：</dt>
          <dd>
            <RadioGroup @on-change='infokey' v-model="printerAddObj.type">
              <Radio v-for="(item, index) in apiType" :key="index" :label="item.type">{{item.name}}</Radio>
            </RadioGroup>
          </dd>
        </dl>
        <dl v-if="printerAddObj.type == 3" >
          <dt>云打印Key：</dt>
          <Input   v-model="printerAddObj.key" placeholder="请输入云打印Key" style="width: 300px" />
        </dl>
        <dl>
          <dt>打印份数：</dt>
          <dd>
            <InputNumber v-model="printerAddObj.copies" :min="1" />
          </dd>
        </dl>
        <dl v-if="false">
          <dt>打印样式：</dt>
          <dd>
            <RadioGroup v-model="printerAddObj.style">
              <Radio v-for="(item, index) in printStyle" :key="index" :label="item.type">{{item.name}}</Radio>
            </RadioGroup>
          </dd>
        </dl>
        <dl v-if="false">
          <dt>蜂鸣提示：</dt>
          <dd>
            <i-switch v-model="is_voiceInfo" size="large">
              <span slot="open">开启</span>
              <span slot="close">关闭</span>
            </i-switch>
          </dd>
        </dl>
        <dl>
          <dt>菜品分类：</dt>
          <dd>
             <Tree ref="treeList" :data="menuList" show-checkbox></Tree>
          </dd>
        </dl>
        <dl >
          <dt>打印类型：</dt>
          <dd>
            <CheckboxGroup v-model="typesList"  >
              <Checkbox v-for="(item, index) in printerStub" :key="index"  :label="item.type">{{item.name}}</Checkbox>
            </CheckboxGroup>
          </dd>
        </dl>
        <dl>
          <dt>备住信息：</dt>
          <dl>
            <Input
              v-model="printerAddObj.remark"
              :maxlength="100"
              show-word-limit
              type="textarea"
              placeholder="请输入备住"
              style="width: 200px"
            />
          </dl>
        </dl>
        <div style="text-align:center;">
          <Button
            style="margin-right:10px"
            @click="addPrint"
            type="primary"
          >确认</Button>
          <Button @click="initialPrint(true)"   >取消</Button>
        </div>
      </div>
    </Modal>
  </div>
</template>
<script>
import { printerList, printerSave, printerManuList,printerDelete,shopCate} from '@/api/print/print'
import printerMenu from './components/printerMenu'
import { getStautsText } from '@/libs/tools.js'
export default {
  components: { printerMenu },
  data() {
    return {
      menuList:[],
      statusInfo: {},
      printerList: {
      },
      resParam: {
        sn: '',
        manu_id: '',
        page: 1,
        rows: 10
      },
      printerShow: false,
      printerAddObj: {
      },
      modalTitle: '添加打印机',
      paperSize: [58, 80],
      apiType: [
        { type: 1, name: '网口' },
        { type: 2, name: 'usb' },
        { type: 3, name: '云打印' }
      ],
      printStyle: [{ type: 1, name: '详细' }, { type: 2, name: '简单' }],
      printStatus: [
        { type: 0, name: '未分配' },
        { type: 1, name: '正常' },
        { type: 2, name: '故障' },
        { type: 3, name: '丢失' },
        { type: 4, name: '返修' }
      ],
      is_voiceInfo: false,
      columns: [
        { width: 100,align: 'center', title: '打印机名称', key: 'title' },
        { width: 130,align: 'center', title: '打印机品牌', key: 'manu_name' },
        { width: 130,align: 'center', title: '打印机IP', key: 'target' },
        { width: 100,align: 'center', title: '打印纸宽度', key: 'size',
          render:(h,params) => {
            return h('div', [h('p', `${params.row.size} mm`)])
          }
        },
        { width: 130,align: 'center', title: '打印份数', key: 'copies' },
        // { align: 'center', title: '添加时间', key: 'create_time' },
        // { align: 'center', title: '分配时间', key: 'allocate_time' },
        // { align: 'center', title: '打印样式', key: 'style' ,
        //         render: (h, params) => {
        //     let payText = params.row.style
        //     return h('div', [h('p',  this.statusInfo.style[payText])])
        //   } 
        // },
        {
           width: 100,
          align: 'center',
          title: '接口类型',
          key: 'type',
          render: (h, params) => {
            let payText = params.row.type
            return h('div', [h('p', this.statusInfo.type[payText])])
          }
        },
        {
          width: 300,
          align:'center',
          title:'打印类型',
          key:'types',
          render: (h,params) => {
            let arr = []
            let infoText = []
            arr = params.row.types.split(',')
            arr.forEach(el => {
              for(let key in this.statusInfo.stub) {
                if(key === el) infoText.push(this.statusInfo.stub[key])
              }
            })
            return h('div', [h('p', infoText.join(','))])
          }
        },
        // {
        //   align: 'center',
        //   title: '设备状态',
        //   key: 'status',
        //   render: (h, params) => {
        //     let payText = params.row.status
        //     return h('div', [h('p', this.statusInfo.status[payText])])
        //   }
        // },
        // { align: 'center', 
        //   title: '是否自带打印机',
        //   key: 'is_shop',
        //   render: (h, params) => {
        //     let payText = params.row.is_shop
        //     return h('div', [h('p', payText === 0 ? '否' : '是' )])
        //   }
        // },
        { align: 'center', title: '备注', key: 'remark', render: (h,params) => {
            
            return h('div', [h('p', params.row.remark==''?'无':params.row.remark)])
          }
          },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                     this.printerAddObj = JSON.parse(JSON.stringify(params.row))
                     this.is_voiceInfo = this.printerAddObj.is_voice === 0 ? false : true
                     this.openPrint('edit')
                    }
                  }
                },
                '编辑'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      if(params.row.is_shop === 0) {
                          this.$Message.error('该打印机非商家自带打印机，暂时无法删除')
                        return
                      }
                      this.toPrinterDelete(params.row.id)
                    }
                  }
                },
                '删除'
              )
            ])
          }
        }
      ],
      printerStub:[],
      typesList:[]
    }
  },
  methods: {
    /**
     * @description 获取当前打印机列表
     */
    async setList(v) {
      if (v) this.resParam.page = v
      else this.resParam.page = 1
      let res = (await printerList(this.resParam)).data.data
      this.printerList = res
    },
    /**
     * @description 触发添加事件 || 修改事件
     * @param {String} type 标识，判断是添加还是修改
     */
    openPrint(type) {
      if (type === 'add'){ 
        this.setShopCate()
        this.modalTitle = '添加打印机'
        this.initialPrint()
      }
      else {
        this.modalTitle = '修改打印机'
        // 处理tree数组结构
        if(this.printerAddObj.product_cate_ids != '') {
          let sulf = this.printerAddObj.product_cate_ids.split(',')
          this.typesList = this.printerAddObj.types.split(',')
          sulf.forEach(jl => {
            this.menuList[0].children.forEach(el => {
              if(el.id == jl) {
                 el.checked = true
              }
            })
          })
        } 
      }
      this.printerShow = true
    },
    /**
     * @description 添加打印机
     */
    async addPrint() {
      // 查找当前所选的菜品分类ID集合
      let sulf = this.$refs.treeList.getCheckedNodes()
      this.printerAddObj.product_cate_ids = []
      sulf.forEach(el => {
        if(el.id) this.printerAddObj.product_cate_ids.push(el.id)
      })
      this.printerAddObj.product_cate_ids = this.printerAddObj.product_cate_ids.join(',')
      this.printerShow = false    
      this.printerAddObj.is_voice =  this.is_voiceInfo ? 1 : 0
      this.printerAddObj.types =   this.typesList.join(',')
      console.log( this.printerAddObj.key,'muda',this.printerAddObj.type != 3)
      if(this.printerAddObj.type != 3) {
        this.printerAddObj.key = ''
      }
      if(this.modalTitle == '添加打印机') {
        delete this.printerAddObj.id
      }
      let res = (await printerSave(this.printerAddObj)).data
      if(res.code === 1) {
        if(this.modalTitle == '添加打印机') this.$Message.info('添加成功')
        else this.$Message.info('修改成功')
      }
      this.setList()
    },
    /** 
     * @description  初始化 &&  清除选择   [7.0]  9.0
     */
    initialPrint(type){
      if(type === true) this.printerShow = false
      this.printerAddObj.title =  ''
      this.printerAddObj.target = ''
      this.printerAddObj.size = this.paperSize[0]
      this.printerAddObj.type = this.apiType[0].type
      this.printerAddObj.copies = 1
      this.printerAddObj.style = this.apiType[0].type
      this.is_voiceInfo = false
      this.printerAddObj.remark = ''
      this.printerAddObj.manu_id = ''
      this.printerAddObj.key = ''
      this.typesList = []
    },
    /** 
     * @description 远程组件回调
     */
    garPrinter(res) {
      this.printerAddObj.manu_id = res
    },
    /** 
     * @description 删除打印机
     */
    toPrinterDelete(ids) {
      this.$Modal.confirm({
        title: '删除',
        content: '确认删除打印机吗？注意！删除后不可恢复',
        onOk: () => {
          const data = {
            id: ids
          }
          printerDelete(data).then(res => {
            if(res.data.code === 1) {
              this.$Message.info('删除成功')
            } else {
              this.$Message.info('删除失败')
            }
             this.setList()
          })
        },
        onCancel: () => {
          this.$Message.info('取消了删除操作')
        }
      })
    },
    /** 
     *  @description 菜品分类
     */
    async setShopCate(){
      const data = {
        page:1,
        rows:50
      }
      await shopCate(data).then(res => {
        // 处理成树状结构数组
        let arr = res.data.data.list
        arr.forEach(el => {
          el.expand = true
          el.checked = false
          el.title = el.name
        })
        this.menuList = [
          {
            title:'全部',
            selected: true,
            checked:true,
            children:arr
          }
        ]
      })
    },
    infokey(res) {
      this.printerAddObj.type = res
      this.$set(this.printerAddObj,'type',res)
    }
  },
  mounted() {
    this.setShopCate()
    this.setList()
    this.statusInfo = getStautsText('printer')
    let stub = getStautsText('printer.stub')
    for (let key in stub) {
      if (key != 7)  this.printerStub.push({name:stub[key],type:key})
    }
  }
}
</script>  
<style lang="less" scoped >
@import url('./printer.less');
</style>
<style lang="less">
.printerModal {
  > dl {
    margin: 15px 0;
    min-height: 32px;
    > dt {
      font-size: 14px;
      min-height: 100%;
      line-height: 32px;
      width: 100px;
      float: left;
      display: block;
    }
    > dd {
      width: 388px;
      float: left;
      display: block;
    }
  }
  > dl::after {
    content: '';
    display: block;
    width: 100%;
    height: 0;
    clear: both;
  }
}
</style>