<template>
  <hgroup class="manufactureer">
    <h3>打印机厂商管理</h3>
    <p>管理各个打印机</p>
  </hgroup>
</template>
<script>
export default {
  data() {
    return {}
  }
}
</script>
<style lang='less' scoped>
@import url('./manufacturer.less');
</style>
