/*
 * @Author: 叶锦荣
 * @Date: 2019-11-15 18:13:17
 * @LastEditTime: 2019-11-15 18:15:31
 */
import manufacturer from './manufacturer.vue'
export default manufacturer