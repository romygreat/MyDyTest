
<template>
  <div>
    <p style="display:inline-block" class="adminTitle">设备列表</p>
    <!-- add admin buttom -->
    <div class="inline-div">
      <p class="inline-div search-title">设备序列号查询：</p>
      <Input
        v-model="requestParam.sn"
        icon="search"
        placeholder="输入你要查询的设备序列号"
        style="width: 200px; display: inline-block"
      />
      <div style="display: inline-block; margin-left:20px; ">
        <p class="inline-div search-title">桌号查询：</p>
        <Input
          clearable
          v-model="requestParam.table_title"
          icon="search"
          placeholder="输入你要查询的桌号"
          style="width: 150px; display: inline-block"
        />
        <Button
          style="display: inline-block; margin:0 0 0 15px;  "
          type="primary"
          @click="handleSearch(true)"
        >查询</Button>
        <Button
          style="display: inline-block; margin:0 0 0 15px;  "
          type="warning"
          @click="requestParam.table_title='';requestParam.sn='';handleSearch(true)"
        >刷新</Button>
      </div>
    </div>
    <Button
      v-if="requestParam.type === 2"
      style="display:block;margin-bottom:10px"
      type="primary"
    >添加打印机</Button>
    <Row>
      <Table stripe border :columns="tableTitle" :data="tableData" style="width: 922px;"></Table>
      <div style="width: 922px;">
        <Page
          :total="Number(pageTotal)"
          show-total
          show-elevator
          :page-size="Number(requestParam.rows)"
          @on-change="handlePage"
          style="float:right; margin:15px 0;"
        ></Page>
      </div>
    </Row>
    <Modal v-model="editEx" :title="editTitle">
      <div>
        <span>序列号：</span>
        <Input
          disabled
          v-model="editInfo.sn"
          placeholder="输入SN码"
          style="width: 300px; margin: 10px 0; "
        />
      </div>
      <div style="margin: 10px 0; ">
        <span>设备状态：</span>
        <RadioGroup v-model="editInfo.status" type="button">
          <Radio label="1">正常</Radio>
          <Radio label="2">故障</Radio>
        </RadioGroup>
      </div>
      <div
        v-if="requestParam.type == 1 && editInfo.status ==1"
        style="margin-top: 20px; margin-bottom: 10px;"
      >
        <span>绑定台桌：</span>
        <Select
          v-model="editInfo.table_id"
          style="width:200px"
          :placeholder="editInfo.table_title ? editInfo.table_title : '请选择'"
        >
          <Option value="0">解绑定</Option>
          <Option
            v-for="item in tableOptionList"
            :key="item.value"
            :value="item.value"
          >{{item.lable}}</Option>
        </Select>
      </div>
      <div v-if="requestParam.type == 2" style="margin-top: 20px; margin-bottom: 10px;">
        <span>绑定任务：</span>
        <Select v-model="editInfo.apportion" style="width:200px" placeholder="请选择">
          <Option v-for="(item, idx) in apportions" :key="idx" :value="idx">{{item}}</Option>
        </Select>
      </div>
      <div>
        <span>设备备注：</span>
        <Input
          style="width:300px;margin:10px 0;"
          v-model="editInfo.remark"
          type="textarea"
          :rows="3"
          placeholder="请输入"
        />
      </div>

      <div slot="footer">
        <Button type="text" size="large" @click="editEx = false">取消</Button>
        <Button type="primary" size="large" @click="saveMacineInfo">确定</Button>
      </div>
    </Modal>
  </div>
</template>
<script>
import excel from '@/libs/excel'
import { getToken } from '@/libs/util'
import { getStautsText } from '@/libs/tools.js'
import { optionShopTable } from '@/api/shop/table'
import {
  allMachBangdingButtom,
  editMacineButtom,
  delMachineButtom,
  handleSearchMac,
  machineTablesButtom
} from '@/api/device/machine'
export default {
  name: 'export-excel',
  data() {
    return {
      exportLoading: false,
      tableTitle: [
        {
          title: 'ID',
          key: 'id',
          align: 'center',
          width: 80
        },
        {
          title: '序列号',
          key: 'sn',
          width: 220,
          align: 'center'
        },
        {
          title: '设备类型',
          key: 'type_name',
          width: 110,
          align: 'center'
        },
        {
          title: '状态',
          key: 'status',
          width: 110,
          align: 'center',
          filters: [
            { label: '未分配', value: 0 },
            { label: '正常', value: 1 },
            { label: '故障', value: 2 },
            { label: '丢失', value: 3 },
            { label: '返修', value: 4 }
          ],
          filterMultiple: false,
          filterMethod(value, row) {
            if (value === 0) {
              return row.status == '0'
            } else if (value === 1) {
              return row.status == '1'
            } else if (value === 2) {
              return row.status == '2'
            } else if (value == 3) {
              return row.status == '3'
            } else if (value == 4) {
              return row.status == '4'
            }
          },
          render: (h, param) => {
            return h('div', this.statusList[param.row.status])
          }
        },
        {
          title: '桌号',
          key: 'table_title',
          width: 110,
          align: 'center'
        },
        {
          title: '备注',
          key: 'remark',
          align: 'center',
          ellipsis: true,
          tooltip: true,
          render: (h, param) => {
            let text = param.row.remark
            if (param.row.apportion && param.row.apportion != 0) {
              text = '(' + this.apportions[param.row.apportion] + ') ' + text
            }
            return h('span', text)
          }
        },
        {
          title: '编辑',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.showEdit('edit', params.index)
                    }
                  }
                },
                '修改'
              )
            ])
          }
        }
      ],
      tableOptionList: [],
      tableData: [],
      pageTotal: 0,
      requestParam: {
        sn: '',
        type: 1,
        page: 1,
        rows: 10,
        table_title: '',
        sort: { id: 'desc' }
      },
      // 修改挂载
      editTitle: '',
      editEx: false,
      loading: false,
      editInfo: {},
      // 搜索
      loading1: false,
      options1: [],
      list: [],
      statusList: {}
    }
  },
  computed: {
    apportions() {
      return getStautsText('printer.apportion')
    }
  },
  methods: {
    showEdit(type, index) {
      if (type == 'edit') {
        this.editTitle = '编辑设备'
        this.editInfo = JSON.parse(JSON.stringify(this.tableData[index]))
        console.log(this.editInfo, 123)
        this.editInfo.status = this.editInfo.status.toString()
        // this.editInfo.type = this.editInfo.type.toString()
        // this.editInfo.apportion = this.editInfo.apportion.toString()
      } else if (type == 'add') {
        this.editTitle = '添加设备'
        this.editInfo = {}
      }
      this.editEx = true
      console.log(this.editEx, 123)
    },
    machineTables(type) {
      if (type) {
        this.requestParam.page = 1
      }
      machineTablesButtom(this.requestParam)
        .then(response => {
          this.tableData = response.data.data.list
          this.pageTotal = response.data.data.total
        })
        .catch(error => {
          console.error(error)
        })
    },
    handlePage(value) {
      this.requestParam.page = value
      this.machineTables()
    },
    handleSearch(type) {
      this.machineTables(true)
    },
    saveMacineInfo() {
      if (!this.editInfo.status) this.editInfo.status = 0
      editMacineButtom(this.editInfo)
        .then(response => {
          this.$Message.info({
            content: response.data.message,
            duration: 5,
            closable: true
          })
          if (response.data.code == 1) {
            this.editEx = false
            this.machineTables()
          }
        })
        .catch(error => {
          this.$Message.info({
            content: error,
            duration: 5,
            closable: true
          })
        })
    },
    // 动态添加或删除绑定台桌列
    spliceCol() {
      const col = {
        title: '绑定桌号',
        key: 'table_title',
        width: 110,
        align: 'center'
      }
      this.tableTitle.forEach((item, index) => {
        if (item.key == col.key) this.tableTitle.splice(index, 1)
      })
      if (this.requestParam.type == 1) {
        this.tableTitle.splice(4, 0, col)
      }
    },
    getTableOptionList() {
      optionShopTable().then(res => {
        if (res.data.code == 1) {
          this.tableOptionList = res.data.data
        }
      })
    }
  },
  mounted() {
    if (this.$route.meta.type) {
      this.requestParam.type = this.$route.meta.type
      this.spliceCol()
      this.machineTables()
    }
    this.machineTables()
    this.getTableOptionList()
    this.statusList = getStautsText('machine.status')
  },
  watch: {
    $route(to, from) {
      if (to.meta.type) {
        this.requestParam.type = to.meta.type
        this.spliceCol()
        this.machineTables()
      }
    }
  }
}
</script>
<style>
.adminTitle {
  font-weight: bold;
  font-size: 18px;
}
.search-title {
  display: inline-block;
  margin: 10px 0;
}
.inline-div {
  margin: 10px 0;
}
</style>
