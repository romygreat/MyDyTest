import OrderMachine from './machine.vue'
export default OrderMachine
