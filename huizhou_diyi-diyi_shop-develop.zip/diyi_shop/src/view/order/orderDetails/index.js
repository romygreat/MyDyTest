import OrderDetails from './orderDetails'
export default OrderDetails
