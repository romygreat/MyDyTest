<template>
  <div>
    <hgroup class="order-hg">
      <h3 class="order-title">订单详情</h3>
    </hgroup>
    <Steps class="stepNew" :current="Number(numberSta)">
      <Step
        v-for="(item, index) in dataStatus"
        :key="index"
        :title="item.label"
        :content="stepNewTime(item.value)"
      ></Step>
    </Steps>
    <!-- 订单基本信息 -->
    <h3 class="basic">基本信息</h3>
    <Table :columns="basicitle" :data="basicData"></Table>
    <h3 class="basic">商品信息</h3>
    <Table border :columns="productList" :data="detaiList"></Table>
    <div class="footerPrice">
      <div>优惠券：￥{{0}}</div>
      <figure>
        <!-- <div>纸巾（小计）：￥{{detailData.tableware_num * detailData.tableware_fee}}</div> -->
        <div>服务费：￥{{convertMoneyUnit(detailData.service_price)}}</div>
        <!-- <div>餐具费（小计）：￥{{detailData.towel_fee * detailData.towel_num}}</div> -->
      </figure>
      <div class="footerPriceBox">
        <p>应收： ￥{{convertMoneyUnit(detailData.total_price)}}</p>
        <p>优惠： -￥{{convertMoneyUnit(discountPrice)}}</p>
        <p>抹零： -￥{{convertMoneyUnit(detailData.pin_out)}}</p>
        <h3>实收：￥{{convertMoneyUnit(detailData.paid_price)}}</h3>
      </div>
      <aside v-if="detailData.remark !=  ''" class="detailDataRemark">备注：{{detailData.remark }}</aside>
    </div>
    <Modal v-model="operShow" :title="operTitle" :footer-hide="true">
      <Form ref="editOrder[0]" :model="editOrder[0]">
        <FormItem label="更改当前数量：">
          <InputNumber
            style="display: inline-block; width:100px;  "
            :min="1"
            placeholder="请输入数量"
            v-model="editOrder[0].edNum"
          />
        </FormItem>
        <p>
          更改后的总价为：
          <span style="color:red; margin-top: 20px;">{{this.priceSdk}}元</span>
        </p>
        <FormItem style="margin-top: 20px;">
          <Button type="primary" @click="handleSubmit('editOrder[0]')">确认</Button>
          <Button @click="operShow = false" style="margin-left: 8px">取消</Button>
        </FormItem>
      </Form>
    </Modal>
    <Modal width="360" v-model="basicEdit" title="修改订单" :footer-hide="true">
      <Form :model="basicData[0]">
        <FormItem label="更改状态：">
          <Select v-model="datapay" style="width:200px">
            <Option
              :disabled="(basicData[0].pay_way == 1 ? true : false ) && index == 0 "
              v-for="(item, index) in dataStatus"
              :value="item.value"
              :key="index"
            >{{ item.label }}</Option>
          </Select>
        </FormItem>
        <FormItem label="更改人数：">
          <InputNumber :min="1" v-model="newsNumber"></InputNumber>
        </FormItem>
        <FormItem style="margin-top: 20px;">
          <Button type="primary" @click="handpay(datapay,newsNumber)">确认</Button>
          <Button @click="basicEdit = false" style="margin-left: 8px">取消</Button>
        </FormItem>
      </Form>
    </Modal>
  </div>
</template>

<script>
import { getStautsText, convertPrice } from '@/libs/tools.js'
import {
  getStatusText,
  editOrderButtom,
  orderDetailButtom,
  editOrderBasicButtom,
  delorderButtom,
  newOrderDetailButtom
} from '@/api/order/orderDetails'
import Calc from 'number-precision'
export default {
  data() {
    return {
      statusListinfo: [],
      // 基本信息
      basicitle: [
        {
          title: '订单编号',
          key: 'order_no',
          align: 'center'
        },
        {
          title: '桌台号',
          key: 'table_no',
          align: 'center'
        },
        {
          title: '实收金额',
          key: 'paid_price',
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h('p', `${(Number(params.row.paid_price) / 100).toFixed(2)} 元`)
            ])
          }
        },
        {
          title: '人数',
          key: 'tableware_num',
          align: 'center'
        },
        {
          title: '支付方式',
          key: 'pay_way',
          align: 'center',
          render: (h, params) => {
            const payText = params.row.pay_action
            let payobj = this.statusListinfo[payText]
            return h('div', [h('p', payobj)])
          }
        },
        {
          title: '支付状态',
          key: status,
          align: 'center',
          render: (h, params) => {
            const statusText = params.row.status
            if (statusText == 0) {
              params.row.status = '未付款'
            } else if (statusText == 1) {
              params.row.status = '已付款'
            } else if (statusText == 2) {
              params.row.status = '已完成'
            } else if (statusText == 3) {
              params.row.status = '已挂账'
            } else if (statusText == 4) {
              params.row.status = '已撤单'
            }
            return h('div', [h('p', params.row.status)])
          }
        },
        {
          title: '下单时间',
          key: 'add_time',
          align: 'center'
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.newsNumber = params.row.tableware_num
                      if (params.row.status == '未付款') {
                        this.datapay = 0
                      } else if (params.row.status == '已付款') {
                        this.datapay = 1
                      } else if (params.row.status == '已完成') {
                        this.datapay = 2
                      } else if (params.row.status == '已挂账') {
                        this.datapay = 3
                      } else if (params.row.status == '已撤单') {
                        this.datapay = 4
                      }
                      if (this.datapay == 0) {
                        this.basicEdit = true
                      } else {
                        this.basicEdit = false
                      }
                    }
                  }
                },
                '修改'
              )
            ])
          }
        }
      ],
      basicData: [
        {
          order_no: '',
          table_no: '',
          paid_price: '',
          pay_way: '',
          add_time: '',
          status: '',
          tableware_num: '',
          pay_action: ''
        }
      ],
      basicEdit: false,
      // 总数据
      dataId: '',
      detailTradeNo: '',
      detailTableNo: '',
      detailData: [],
      detaiList: [],
      // 状态列表
      dataStatus: [
        { label: '未付款', value: 0 },
        { label: '已付款', value: 1 },
        { label: '已完成', value: 2 }
      ],
      datapay: '',
      newsNumber: 1,
      // 支付列表
      dataPay: [],
      numberSta: Number(''),
      offEdit: '',
      productList: [
        {
          title: '商品图片',
          key: 'pic',
          align: 'center',
          render: (h, params) => {
            if (params.row.pic) {
              return h('div', [
                h('img', {
                  attrs: {
                    src: this.$store.state.app.qiniuDomain + params.row.pic
                  },
                  style: {
                    width: '40px',
                    height: '40px',
                    display: 'block',
                    margin: '0 auto'
                  }
                })
              ])
            } else {
              return h('div', '无')
            }
          }
        },
        {
          title: '品项名称',
          key: 'name',
          align: 'center'
        },
        {
          title: '属性',
          key: 'spec_val',
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'p',
                `${
                  params.row.group == undefined
                    ? ''
                    : params.row.group.group_title
                }`
              ),
              h(
                'p',
                `${
                  params.row.procedure == undefined
                    ? ''
                    : params.row.procedure.name
                }`
              ),
              h(
                'p',
                `${
                  params.row.contorno == undefined
                    ? ''
                    : params.row.contorno.contorno_name
                }`
              )
            ])
          }
        },
        {
          title: '单价',
          key: 'unit_price',
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h('p', `${this.convertMoneyUnit(params.row.unit_price)} 元`)
            ])
          }
        },
        {
          title: '数量',
          key: 'num',
          align: 'center'
        },
        {
          title: '单位',
          key: 'unit',
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h('p', params.row.unit == '' ? '份' : params.row.unit)
            ])
          }
        },
        {
          title: '优惠',
          key: 'discount_amount',
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h('p', `${this.convertMoneyUnit(params.row.discount_amount)}元`)
            ])
          }
        },
        {
          title: '订单金额（元）',
          key: 'price',
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h('p', this.convertMoneyUnit(params.row.price) + '元')
            ])
          }
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            if (this.basicData[0].status == '未付款') {
              this.offEdit = false
            } else {
              this.offEdit = true
            }
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small',
                    disabled: this.offEdit
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.show(params.index)
                    }
                  }
                },
                '修改'
              )
              // h(
              //   'Button',
              //   {
              //     props: {
              //       type: 'error',
              //       size: 'small',
              //       disabled: this.offEdit
              //     },
              //     on: {
              //       click: () => {
              //         this.remove(params.index)
              //       }
              //     }
              //   },
              //   '删除'
              // )
            ])
          }
        }
      ],
      operShow: false,
      operTitle: '修改订单',
      // 修改
      editOrder: [
        {
          edId: '',
          edNum: Number(''),
          edprice: '',
          edunit_price: ''
        }
      ],
      // 支付接口合计
      paylistArr: [],
      // 优惠综合
      discountPrice: 0
    }
  },
  methods: {
    // 转换价格
    convertMoneyUnit(p) {
      return convertPrice(p)
    },
    // 表格数据
    orderDetail() {
      const data = {
        id: this.dataId,
        table_no: this.detailTableNo,
        trade_no: this.detailTradeNo
      }
      newOrderDetailButtom(data)
        .then(res => {
          this.detailData = res.data.data
          console.log(this.detailData, 'moling')

          this.detaiList = res.data.data.order_list.list
          if (res.data.data.pid == 0) {
            this.detaiList.push({
              name: '餐具',
              num: this.detailData.tableware_num,
              unit_price: this.detailData.tableware_fee,
              unit: '包',
              price:
                this.detailData.tableware_fee * this.detailData.tableware_num,
              discount_amount: 0
            })
          }

          if (this.detailData.status == '未付款') {
            this.numberSta = 0
          } else if (this.detailData.status == '已付款') {
            this.numberSta = 1
          } else {
            this.numberSta = 2
          }
          // 转换
          this.basicData[0].order_no = this.detailData.order_no
          this.basicData[0].table_no = this.detailData.table_no
          this.basicData[0].total_price = this.detailData.total_price
          this.basicData[0].paid_price = this.detailData.paid_price
          this.basicData[0].pay_way = this.detailData.pay_way
          this.basicData[0].add_time = this.detailData.add_time
          this.basicData[0].status = this.detailData.status
          this.basicData[0].pay_action = this.detailData.pay_action
          this.$set(
            this.basicData[0],
            'tableware_num',
            this.detailData.tableware_num
          )
          // 计算出总优惠数量
          this.detaiList.forEach((el, idx) => {
            if (el.discount_amount) {
              this.discountPrice = Calc.plus(
                this.discountPrice,
                el.discount_amount
              )
            }
          })
          if (this.detailData.discount_amount) {
            this.discountPrice = Calc.plus(
              this.discountPrice,
              this.detailData.discount_amount
            )
          }
        })
        .catch(err => {
          console.error(err)
        })
    },
    // 判断过程进度
    stepNewTime(value) {
      let stoTime = ''
      if (value == 0) {
        stoTime = '下单时间：' + ' ' + this.detailData.add_time
      } else if (value == 1) {
        if (this.detailData.pay_time) {
          stoTime = '支付时间：' + ' ' + this.detailData.pay_time
        } else {
          stoTime = '等待支付'
        }
      } else if (value == 2) {
        if (this.detailData.over_time) {
          stoTime = '完成时间：' + ' ' + this.detailData.over_time
        } else {
          stoTime = '订单尚未完成'
        }
      }
      return stoTime
    },
    show(index) {
      // 数量 id 总价
      this.editOrder[0].edId = this.detailData.order_list.list[index].id
      this.editOrder[0].edNum = this.detailData.order_list.list[index].num
      this.editOrder[0].edprice = this.detailData.order_list.list[index].price
      this.editOrder[0].edunit_price = this.detailData.order_list.list[
        index
      ].unit_price
      this.operShow = true
    },
    handleSubmit(name) {
      const data = {
        order_id: this.detailData.id,
        id: this.editOrder[0].edId,
        num: this.editOrder[0].edNum,
        price: this.priceSdk
      }
      editOrderButtom(data)
        .then(res => {
          this.$Message.info(res.data.message)
          if (res.data.code == 1) {
            this.orderDetail()
            this.operShow = false
          }
        })
        .catch(err => {
          console.error(err)
        })
    },
    // 修改支付状态
    handpay(v) {
      const data = {
        id: this.detailData.id,
        status: v,
        tableware_num: this.newsNumber,
        pay_way: this.basicData[0].pay_way
      }
      editOrderBasicButtom(data)
        .then(res => {
          this.$Message.info(res.data.message)
          this.orderDetail()
          this.basicEdit = false
        })
        .catch(err => {
          console.error(err)
        })
      this.orderDetail()
    },
    remove(index) {
      this.$Modal.confirm({
        title: '删除订单商品',
        content: '你正在进行删除操作，确认要删除吗？',
        onOk: () => {
          const data = {
            id: this.detailData.order_list.list[index].id,
            order_id: this.detailData.order_list.list[index].order_id,
            price: this.detailData.order_list.list[index].price
          }
          delorderButtom(data).then(res => {
            this.orderDetail()
            this.$Message.info(res.data.message)
          })
        },
        onCancel: () => {
          this.$Message.info('取消了删除操作')
        }
      })
    },
    // 支付方式接口
    getStatus() {
      const data = { name: 'order.pay_action' }
      getStatusText(data).then(res => {
        let arr = []
        for (let i in res.data.data) {
          arr.push(res.data.data[i])
        }
        this.paylistArr = arr
      })
    }
  },
  mounted() {
    this.getStatus()
    this.statusListinfo = getStautsText('order.pay_action')
  },
  created() {
    if (JSON.stringify(this.$route.params) != {}) {
      let obj = JSON.parse(sessionStorage.getItem('keys'))
      this.dataId = obj.detailId
      this.detailTableNo = obj.detailTable_No
      this.detailTradeNo = obj.detailTrade_No
      // this.dataStatus = obj.statusList
      this.dataPay = obj.payList
    } else {
      this.dataId = this.$route.params.detailId
      this.detailTable_No = this.$route.params.detailTable_No
      this.detailTrade_No = this.$route.params.detailTrade_No
      // this.dataStatus = this.$route.params.statusList
      this.dataPay = this.$route.params.payList
    }
    this.orderDetail()
  },
  computed: {
    priceSdk() {
      const endPrice = this.convertMoneyUnit(
        Number(this.editOrder[0].edunit_price) * Number(this.editOrder[0].edNum)
      )
      return endPrice
    }
  }
}
</script>

<style>
@import './orderDetails.css';
</style>
