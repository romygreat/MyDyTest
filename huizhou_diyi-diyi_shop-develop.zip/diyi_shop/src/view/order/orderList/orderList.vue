<template>
  <div class="orderListbox" style="width: 1212px;">
    <hgroup class="shopC-title">
      <h3>订单查询</h3>
      <p>查询每一个订单的情况</p>
    </hgroup>
    <div class="shopClass-search">
      <p class="shopClass-title">筛选查找：</p>
      <div class="searchbox">
        <div>
          <p>订单编号：</p>
          <Input
            clearable
            v-model="searchInfo.order_no"
            :maxlength='40'
            icon="search"
            placeholder="输入你要查询的订单号"
            style="width: 220px; display: inline-block"
          />
        </div>
        <!-- <div>
          <p>下单时间：</p>
          <Input
            clearable
            v-model="searchInfo.order_no"
            :maxlength='40'
            icon="search"
            placeholder="输入你要查询时间"
            style="width: 220px; display: inline-block"
          />
        </div> -->
        <div>
          <p>桌号：</p>
          <Input
            clearable
            :maxlength='40'
            v-model="searchInfo.table_no"
            icon="search"
            placeholder="输入你要查询桌号"
            style="width: 150px; display: inline-block"
          />
        </div>
        <div>
          <p>订单状态：</p>
          <Select clearable v-model="searchInfo.status" style="width:150px">
            <Option v-for="item in Status" :value="item.value" :key="item.value">{{ item.label }}</Option>
          </Select>
        </div>
        <div>
          <p>支付方式：</p>
          <Select clearable v-model="searchInfo.pay_action" style="width:150px">
            <Option
              v-for="item in payWay"
              :value="item.value"
              :key="item.value"
            >{{ item.label }}</Option>
          </Select>
        </div>
        <div>
          <Button
            clearable
            style="display:inline-block; margin:0 10px  "
            @click="search"
            type="primary"
          >搜索</Button>
          <Button
            clearable
            style="display:inline-block; margin::0 10px "
            @click="search('clear')"
            type="warning"
          >刷新</Button>
        </div>
      </div>
    </div>
    <div class="detalis">
    <Table :columns="columns" :data="shopData" size="small" ref="table" border stripe></Table>
      
      <span class="total-price">总价：<p>￥{{changeMoney(shopData.totalPrice)}}</p></span>
    </div>

    <div class="oper-Buttom">
      <!-- <Button style="display: inline-block;" type="primary" size="large" @click="exportData(1)">
        <Icon type="ios-download-outline"></Icon>导出订单
      </!-->
      <Page
        show-elevator
        show-total
        show-sizer
        :total="Number(searchInfo.total)"
        :current="Number(searchInfo.page)"
        :page-size=" Number(searchInfo.rows)"
        @on-change="orderData"
        @on-page-size-change="orderPage"
        class="page-buttom"
      ></Page>
    </div>
    <audio id="vio" style="height: 40px; display:block !important; width:40px; " :src="src"></audio>
    <Modal @on-ok="printSet" v-model="printBOX" title="打印小票" width="300">
      <RadioGroup v-model="apportion">
        <Radio :key="idx" v-for="(item,idx) in printerArr" :label="idx">
          <span>{{item}}</span>
        </Radio>
      </RadioGroup>
    </Modal>
  </div>
</template>
<script>
import voiceinfo from '@/assets/audio/a.mp3'
import dayjs from 'dayjs'
import print from 'print-js'
import User from '../../../store/module/user.js'
import OrderTips from '../../../store/module/orderTips'
import { orderDataButtom } from '@/api/order/orderList'
import { mapMutations } from 'vuex'
import { orderDetailButtom, indexOrder } from '@/api/order/orderDetails'
import { getStautsText, convertPrice } from '@/libs/tools.js'
import { replacementOrder } from '@/api/print/print'
import Calc from 'number-precision'
export default {
  data() {
    return {
      columns: [
        {
          title: 'ID',
          key: 'id',
          align: 'center',
          width: 80,
          sortable: true
        },
        {
          title: '订单编号',
          key: 'order_no',
          align: 'center',
          width: 200,
          render: (h, params) => {
            const isnews = params.row.is_new
            let switchs = false
            if (isnews != 0) {
              switchs = true
            } else {
              switchs = false
            }

            return h(
              'Badge',
              {
                props: {
                  dot: switchs
                }
              },
              params.row.order_no
            )
          }
        },
        {
          title: '桌号',
          key: 'table_no',
          align: 'center',
          width: 80,
          sortable: true
        },
        {
          title: '人数',
          key: 'tableware_num',
          align: 'center',
          width: 60,
          sortable: true
        },
        {
          title: '下单时间',
          key: 'add_time',
          align: 'center',
          width: 160
        },
        {
          title: '支付方式',
          key: 'pay_action',
          align: 'center',
          width: 120,
          filters: [
            {
              label: '线上支付',
              value: 1
            },
            {
              label: '餐后支付',
              value: 2
            }
          ],
          filterMultiple: false,
          filterMethod(value, row) {
            return row.pay_action == value
          },
          render: (h, params) => {
            const payText = params.row.pay_action
            return h('div', [h('p', this.statusListinfo.pay_action[payText])])
          }
        },
        {
          title: '状态',
          key: 'status',
          align: 'center',
          width: 120,
          filters: [
            { label: '未支付', value: 0 },
            { label: '已付款', value: 1 },
            { label: '已完成', value: 2 },
            { label: '挂账', value: 3 },
            { label: '撤单', value: 4 }
          ],
          filterMultiple: false,
          filterMethod(value, row) {
            return row.status == value
          },
          render: (h, params) => {
            const payText = params.row.status
            let rgb = ''
            if (params.row.status == 0) {
              rgb = 'red'
            }
            return h('div', [
              h(
                'p',
                { style: { color: rgb } },
                this.statusListinfo.status[payText]
              )
            ])
          }
        },
        {
          title: '开具发票',
          key: 'is_invoice',
          align: 'center',
          filters: [{ label: '不需要', value: 0 }, { label: '需要', value: 1 }],
          filterMultiple: false,
          filterMethod(value, row) {
            return row.is_invoice == value
          },
          render: (h, params) => {
            const payText = params.row.is_invoice
            return h('div', [h('p', this.statusListinfo.is_invoice[payText])])
          }
        },
        {
          title: '实付金额',
          key: 'paid_price',
          align: 'center',
          width: 120,
          render: (h, params) => {
            return h('div', [
              h('p', convertPrice(params.row.paid_price) + ' ' + '元')
            ])
          }
        },
        {
          title: '操作',
          key: 'action',
          width: 150,
          align: 'center',
          render: (h, params) => {
            return h('div', [
              h(
                'Button',
                {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.show(params.index)
                    }
                  }
                },
                '查看'
              ),
              h(
                'Button',
                {
                  props: {
                    type: 'warning',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.print( params.row)
                    }
                  }
                },
                '打印'
              )
            ])
          }
        }
      ],
      shopData: [],
      searchInfo: {
        table_no: '',
        order_no: '',
        status: '',
        statusinfo: [],
        pay_way: [],
        pay_wayinfo: '',
        page: 1,
        rows: 10,
        total: '',
        sort: {
          add_time: 'desc'
        },
        terminal: 'shop'
      },
      pageData: {
        total: 1,
        current: 1,
        rows: 10
      },
      noPrint: false,
      userData: {},
      printTime: '',
      priceSwich: '',
      printBOX: false,
      src: voiceinfo,
      statusList: {},
      statusListinfo: [],
      apportion: '',
      printer: {},
      printerArr: [],
      printerID: '',
      Status: [
        { label: '未支付', value: 0 },
        { label: '已付款', value: 1 },
        { label: '已完成', value: 2 },
        { label: '已挂账', value: 3 },
        { label: '已撤单', value: 4 },
        {label: '失败', value: -1}
      ],
      payWay: [
        {
          label: '线上支付',
          value: 1
        },
        {
          label: '餐后支付',
          value: 2
        }
      ]
    }
  },
  methods: {
    ...mapMutations(['clearNews']),
    printSet() {
      const data = {
        id: this.printerID,
        apportion: this.apportion + 1
      }
      replacementOrder(data).then(res => {
        if (res.data.code == 1) {
          this.$Message.success('正在打印中,请稍等')
        }
      })
    },
    orderData(value) {
      if (value) {
        this.searchInfo.page = value
      } else {
        this.searchInfo.page = 1
      }
      indexOrder(this.searchInfo)
        .then(res => {
          this.searchInfo.total = res.data.data.total
          this.shopData = res.data.data.list
          this.searchInfo.statusinfo = res.data.data.status
          this.searchInfo.pay_way = res.data.data.pay
          this.shopData.totalPrice = 0
          for (let i = 0; i < this.shopData.length; i++) {
            console.log(this.shopData[i].paid_price,this.shopData[i].status);
            if (this.shopData[i].status==1||this.shopData[i].status==2) {
              this.shopData.totalPrice = Calc.plus(this.shopData.totalPrice,this.shopData[i].paid_price)
            }
          }
          console.log(this.shopData.totalPrice,'this.shopData.totalPrice');
          
        })
        .catch(err => {
          console.error(err)
        })
    },
    // 查询
    search(type) {
      if (type === 'clear') {
        this.searchInfo = {
          table_no: '',
          order_no: '',
          status: '',
          statusinfo: [],
          pay_way: [],
          pay_wayinfo: '',
          page: 1,
          rows: 10,
          total: '',
          sort: {
            add_time: 'desc'
          },
          terminal: 'shop'
        }
        this.orderData()
      } else {
        this.orderData()
      }
    },
    show(index) {
      const detailId = this.shopData[index].id
      const detailTable_No = this.shopData[index].table_no
      const detailTrade_No = this.shopData[index].trade_no
      if (this.shopData[index].is_new == 1) {
        this.clearNewsinfo()
      }
      const route = {
        name: 'orderDetails',
        params: {
          detailId,
          detailTable_No,
          detailTrade_No,
          statusList: this.searchInfo.statusinfo,
          payList: this.searchInfo.pay_way
        }
      }
      const keysData = {
        detailId,
        detailTable_No,
        detailTrade_No,
        statusList: this.searchInfo.statusinfo,
        payList: this.searchInfo.pay_way
      }
      console.log(keysData, 'keysData')

      sessionStorage.setItem('keys', JSON.stringify(keysData))
      this.$router.push(route)
    },
    async printOrderInfoLook(v) {
      const data = {
        // machine: 'machine',
        id: this.shopData[v].id
      }
      await orderDetailButtom(data).then(res => {
        this.orderDelData = res.data.data
        if (res.data.data.status == 1) {
          this.priceSwich = true
        } else {
          this.priceSwich = false
        }
      })
      this.printTime = await dayjs().format('YYYY-MM-DD HH:mm:ss')
      this.noPrint = true
    },
    printOrderInfo() {
      printJS({
        printable: 'printDiv',
        type: 'html',
        scanStyles: false
      })
    },
    orderPage(index) {
      this.pageData.rows = index
      this.orderData()
    },
    clearNewsinfo() {
      this.clearNews()
    },
    playinfo() {
      document.getElementById('vio').play()
    },
    async print(item) {
      const data = {
        id: item.id,
        type: item.status === 0 ?  1 : 2
      }
      // console.log(await replacementOrder(data),2115)
      if (window.android) {
        let sulf = await replacementOrder(data)
        if(sulf.data.code == 1) {
          sulf.data.data.printer.forEach((el,idx) => {
            sulf.data.data.printerInfo = el
            window.android.printOneOrder(sulf.data.data.printerInfo.type, JSON.stringify(sulf.data.data))
          })
         this.$Message.success('已经成功打印，请稍等')
        } else {
          this.$Message.error("打印失败，请联系管理员")
        }
      }
    },
    changeMoney(val){
      return convertPrice(val)
    }
  },
  mounted() {
    this.orderData()
    this.userData = User.state.adminInfo
    this.statusListinfo = getStautsText('order')        
    this.printer = getStautsText('printer.apportion')
    for (let key of Object.keys(this.printer)) {
      this.printerArr.push(this.printer[key])
    }
  },
  watch: {
    tips() {
      this.orderData()
    }
  },
  computed: {
    tips() {
      return OrderTips.state.newsOrder
    }
  }
}
</script>
<style>
@import './orderList.css';
.orderListbox .ivu-badge-dot {
  left: -15px !important;
  top: 50% !important;
  transform: translateY(-50%) !important;
}
.total-price{
  width: 100%;
  display: block;
  margin-top: 10px;
  font-size: 18px;
  text-align: right;
}
.total-price p{
  display: inline;
  color: #ff9900;
}

@media print {
  .printDiv {
    width: 100%;
    padding: 1px;
  }
  .printDiv > hgroup {
    font-size: 10px;
    padding: 10px 0;
  }
  .printDiv > hgroup > h3 {
    font-size: 8px;
    display: block;
    text-align: center;
    padding: 2.5px 0;
    font-weight: bold;
  }
  .printDiv > hgroup > p {
    font-size: 6px;
    margin-top: 10px;
  }
  .print-title {
    padding: 5px 0;
    border-top: 2px solid #000;
    border-bottom: 2px solid #000;
  }
  .print-title::after {
    content: '';
    width: 100%;
    height: 0;
    display: block;
    clear: both;
  }
  .hg-div::after {
    content: '';
    width: 100%;
    height: 0;
    display: block;
    clear: both;
  }
  .hg-div p:nth-child(1) {
    display: block;
    float: left;
    width: 50%;
    font-size: 6px;
  }
  .hg-div p:nth-child(2) {
    display: block;
    float: left;
    font-size: 6px;
    width: 50%;
  }
  .fontbold {
    font-weight: bold;
  }
  .print-list::after {
    content: '';
    width: 100%;
    height: 0;
    display: block;
    clear: both;
  }
  .print-list div {
    padding: 5px 0;
    font-size: 12px;
  }
  .print-list {
    padding-bottom: 15px;
    padding-top: 15px;
    border-bottom: 2px solid #000;
  }
  .print-price div {
    padding: 5px 0;
    font-size: 12px;
  }
  .print-price-bold {
    font-weight: bold !important;
    font-size: 10px !important;
  }
  .print-price {
    padding: 15px 0;
    border-bottom: 2px solid #000;
  }
  .print-edit {
    padding: 10px 0;
  }
  .print-edit div {
    padding: 5px 0;
    font-size: 8px;
  }
  .print-footer {
    border-top: 2px dotted #000;
    padding: 15px 0;
  }
  .print-footer div {
    padding: 5px 0;
    font-size: 10px;
  }
}
</style>
