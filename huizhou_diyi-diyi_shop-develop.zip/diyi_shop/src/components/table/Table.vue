<template>
  <div>
    <table width="100%">
      <thead>
        <tr>
          <td v-for="(value, index) in tableHead" :key="index">{{value.title}}</td>
        </tr>
      </thead>
      <tbody id="table">
        <tr v-for="(value, index) in tableBody" :key="index">
          <td
            v-for="(list, i) in Object.values(value)"
            :key="i"
            v-if="Object.values(value).length-1>i"
          >{{list}}</td>
          <td v-else width="100">
            <input :maxlength='40' type="number" v-model="list" @change='getPrice(list,index)'/>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
export default {
  props: {
    tableHead: "",
    tableBody: ""
  },
  data() {
    return {
      tableList: []
    };
  },
  methods: {
    getPrice:(value,index)=>{
      console.log('input or change price',value,parseInt(parseFloat(value)),index);
    },
    dealTableBody() {
      let row = [];
      for (let i = 0; i < this.tableBody.length; i++) {
        this.tableList.push(Object.values(this.tableBody[i]));
      }
      for (let j = 0; j < this.tableList.length; j++) {
        for (let z = 0; z < this.tableList[j].length - 1; z++) {
          if (this.tableList[j].indexOf(this.tableList[j][z]) > -1) {
            if (row[j]) {
              row[j] += 1;
            } else {
              row[j] = 0;
            }
            break;
          }
        }
      }
    },
    dealTable() {
      //处理表成为合并列
      let el = document.getElementById("table").rows;
      let index = 0;
        let row1 = 1,
        row2 = 1,
        row3 = 1,
        row4 = 1;
      for (let i = 0; i < el.length; i++) {
        if (i - 1 >= 0) {
          if (el[i].cells.length - 2 > 0 && el[i].cells[index].innerHTML == el[i - 1].cells[index].innerHTML) {
            switch (index) {
              case 0:
                row1 += 1;
                break;
                case 1:
                row2 += 1;
                break;
                case 2:
                row3 += 1;
                break;
                case 3:
                row4 += 1;
                break;

              default:
                break;
            }
            
          } else {
            index +=1
          }
        }
      }

      for (let i = 0; i < el.length; i++) {
        if (i - 1 >= 0) {
          for (let j = 0; j < el[i].cells.length -1; j++) {
            if (el[i].cells.length>2) {
              if (el[i].cells[0].innerHTML==el[i-1].cells[0].innerHTML) {
              el[i-1].cells[0].setAttribute("rowspan",row1)
              el[i].cells[0].style.display = "none"
            }
            }
            if (el[i].cells.length >3) {
              if (el[i].cells[1].innerHTML==el[i-1].cells[1].innerHTML) {
              el[i-1].cells[1].setAttribute("rowspan",row2)
              el[i].cells[1].style.display = "none"
            }
            }
            if(el[i].cells.length >4){
              if (el[i].cells[2].innerHTML==el[i-1].cells[2].innerHTML) {
              el[i-1].cells[2].setAttribute("rowspan",row3)
              el[i].cells[2].style.display = "none"
            }
            }
            if(el[i].cells.length >5){
              if (el[i].cells[3].innerHTML==el[i-1].cells[3].innerHTML) {
              el[i-1].cells[3].setAttribute("rowspan",row4)
              el[i].cells[3].style.display = "none"
            }
            }
            
          }
        }
      }
    },
    
  },
  mounted() {
    this.dealTableBody();
    this.dealTable();    
  },
  computed: {},
  
};
</script>
<style lang="less" scoped>
@import url('./table.less');
</style>


