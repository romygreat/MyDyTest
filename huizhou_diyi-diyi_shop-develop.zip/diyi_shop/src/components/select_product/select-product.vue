<template>
  <div style="width: 800px;height:572px;border-radius: 5px;border: 1px solid #E8EAEC;">
    <Row>
      <Col span="8">
        <div style="width: 100%;padding: 10px;">
          <Input
            v-model="name"
            search
            @keyup.native.enter="search"
            placeholder="输入关键字并回车"
            style="width: 150px; margin: 0 10px;"
          />
          <Button type="info" @click="selectedList">已选</Button>
        </div>

        <ul class="cate_ul">
          <li
            v-for="(item, idx) in cate_list"
            :key="idx"
            class="cate_li"
            :class="{'active' : cur_inx === idx}"
            @click="clickCate(idx)"
          >{{item.name}}</li>
        </ul>
      </Col>
      <Col span="16">
        <Table
          :columns="columns"
          :data="product_list"
          class="table"
          @on-selection-change="selectionChange"
        >
          <template slot-scope="{ row, index }" slot="id">
            <span>{{ row.id }}</span>
          </template>

          <template slot-scope="{ row, index }" slot="name">
            <img
              class="product_img"
              :src="row.pic ? $store.state.app.qiniuDomain + row.pic : defaultPic"
            />
            <div class="product_name">
              <p>{{ row.name }}</p>
            </div>
          </template>

          <template slot-scope="{ row, index }" slot="price">
            <span>{{ row.price.toFixed(2) }}</span>
            <span class="tip" v-if="row._disabled">（高于活动价格）</span>
          </template>
        </Table>
      </Col>
    </Row>
  </div>
</template>

<script>
import defaultPic from '@/assets/images/mpic.jpg'
import ArrayPlus from '@/libs/ArrayPlus'
export default {
  name: 'SelectProduct',
  props: {
    cate_list_url: {
      type: String,
      default: '/product/ProductCate/shopCate'
    },
    product_list_url: {
      type: String,
      default: '/product/Product/cateProduct'
    },
    product_ids: {
      type: Array,
      default: () => []
    },
    maxPrice: {
      type: Number,
      default: -1
    }
  },
  data() {
    return {
      defaultPic,
      name: '',
      selectedIds: [],
      selected: {},
      columns: [
        {
          type: 'selection',
          width: 60,
          align: 'center'
        },
        {
          title: '商品',
          slot: 'name'
        },
        {
          title: '价格',
          slot: 'price'
        }
      ],
      cate_list: [],
      cur_inx: 0,
      product_list: []
    }
  },
  methods: {
    /**
     * 获取门店所有的分类信息
     */
    cateList() {
      let prarm = {
        url: this.cate_list_url,
        data: {
          sort: { sort: 'asc' }
        }
      }
      this.$http
        .request(prarm)
        .then(response => {
          if (response.status === 200 && response.data.code === 1) {
            this.cate_list = response.data.data.list
            this.productList(this.cate_list[0].id)
          }
        })
        .catch(error => {
          console.error(error)
        })
    },
    /**
     * 获取分类下的所有商品信息
     * @param cateId
     */
    productList(cateId) {
      let prarm = {
        url: this.product_list_url,
        data: {
          cate_id: cateId,
          name: this.name,
          sort: { sort: 'asc' }
        }
      }
      this.$http
        .request(prarm)
        .then(response => {
          if (response.status === 200 && response.data.code === 1) {
            this.name = ''
            this.product_list = response.data.data.list
            this.selected[cateId] = []
            for (let i = 0; i < this.product_list.length; i++) {
              this.product_list[i]._checked = false
              if (this.selectedIds.indexOf(this.product_list[i].id) !== -1) {
                this.product_list[i]._checked = true
                this.selected[cateId].push(this.product_list[i].id)
              }
              // 商品价格不能大于maxPrice的话就不能选择
              this.product_list[i]._disabled = false
              if (
                this.maxPrice >= 0 &&
                this.product_list[i].price > this.maxPrice
              ) {
                this.product_list[i]._disabled = true
              }
            }
          }
        })
        .catch(error => {
          console.error(error)
        })
    },
    /**
     * 分类点击事件
     */
    clickCate(idx) {
      this.cur_inx = idx
      this.productList(this.cate_list[idx].id)
    },
    /**
     * 选择事件
     */
    selectionChange(selection) {
      let selectedIds = ArrayPlus.fromArray(selection).columns('id')
      if (selectedIds.length === 0) {
        this.selectedIds = ArrayPlus.fromArray(
          this.selected[this.cate_list[this.cur_inx].id]
        ).difference(this.selectedIds)
      } else {
        this.selected[this.cate_list[this.cur_inx].id] = selectedIds
        this.selectedIds = []
        for (let idx in this.selected) {
          this.selectedIds = this.selectedIds.concat(this.selected[idx])
        }
      }
      this.$emit('change', this.selectedIds)
    },
    /**
     * 搜索商品
     */
    search() {
      this.name = this.name.trim()
      if (this.name === '') {
        return false
      }
      this.productList(0)
    },
    /**
     * 已选商品事件
     */
    selectedList() {
      let prarm = {
        url: '/activity/activity_product/selectedProduct',
        data: {
          ids: this.selectedIds
        }
      }
      this.$http
        .request(prarm)
        .then(response => {
          if (response.status === 200 && response.data.code === 1) {
            this.name = ''
            this.product_list = response.data.data
            for (let i = 0; i < this.product_list.length; i++) {
              this.product_list[i]._checked = false
              if (this.selectedIds.indexOf(this.product_list[i].id) !== -1) {
                this.product_list[i]._checked = true
                this.selected[this.product_list[i].cate_id].push(
                  this.product_list[i].id
                )
              }
              // 商品价格不能大于maxPrice的话就不能选择
              this.product_list[i]._disabled = false
              if (
                this.maxPrice >= 0 &&
                this.product_list[i].price > this.maxPrice
              ) {
                this.product_list[i]._disabled = true
              }
            }
          }
        })
        .catch(error => {
          console.error(error)
        })
    }
  },
  mounted() {
    this.selectedIds = this.product_ids
    this.cateList()
  }
}
</script>
<style scoped>
@import url('select-product.less');
</style>
