import SelectProduct from './select-product.vue'
export default SelectProduct
