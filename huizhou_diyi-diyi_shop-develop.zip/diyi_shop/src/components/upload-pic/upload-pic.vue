<template>
<div style="width: 420px;">
  <Row><Col><Progress v-show="progress != 0" :percent="progress" :stroke-width="5" /></Col></Row>
  <Row>
    <Col span="10">
      <Upload action="/" :before-upload="beforeUpload">
        <Button icon="ios-cloud-upload-outline">{{title}}</Button>
      </Upload>
      <p style="padding-right: 10px;">请尽量上传正方形的图片，系统会自动将图片裁剪成正方形，文件大小不能大于2M</p>
    </Col>
    <Col span="14">
      <slot>
        <div v-if="pic">
          <img class="img" :src="pic">
        </div>
        <img class="img" v-if="pic == ''" :src="defaultPic">
      </slot>
    </Col>
  </Row>
</div>
</template>

<script>
import defaultPic from '@/assets/images/mpic.jpg'
import { getToken } from '@/libs/util'
import axios from 'axios'
export default {
  name: 'UploadPic',
  props: {
    title: {
      type: String,
      default: '点击上传'
    },
    action: {
      type: String,
      default: '/qiniu/Upload/uploadFile'
    },
    pic: {
      type: String,
      default: ''
    },
    max_size: {
      type: Number,
      default: 2 * 1024 * 1024
    }
  },
  data () {
    return {
      defaultPic,
      progress: 0
    }
  },
  methods: {
    // 上传
    beforeUpload (file) {
      let fileIndex = 'file'
      if (file.type.indexOf('image') !== 0) {
        this.$Message.info({
          content: '请上传图片文件',
          duration: 5,
          closable: true
        })
      } else if (file.size > this.max_size) {
        this.$Message.info({
          content: '文件大小不能大于2M',
          duration: 5,
          closable: true
        })
      } else {
        let param = new FormData() // 创建form对象
        param.append(fileIndex, file) // 通过append向form对象添加数据
        param.append('token', getToken())
        let config = {
          // 添加请求头
          headers: { 'Content-Type': 'multipart/form-data', Behavior: 'api' },
          // 添加上传进度监听事件
          onUploadProgress: e => {
            this.progress = ((e.loaded / e.total * 100) | 0)
            console.log(this.progress)
          }
        }
        axios.post(this.action, param, config)
          .then(response => {
            if (response.status === 200) {
              if (response.data.code === 1) {
                let url = response.data.data[fileIndex].url
                this.$emit('complete', url)
              } else {
                this.$Message.info(response.data.message)
              }
            }
          })
          .catch(function (error) {
            console.error(error)
          })
      }
      return false
    }
  }
}
</script>

<style scope>
  @import url("upload-pic.less");
</style>
