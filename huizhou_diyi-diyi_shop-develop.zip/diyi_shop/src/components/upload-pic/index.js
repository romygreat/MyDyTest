import UploadPic from './upload-pic.vue'
export default UploadPic
