import ListPage from './list-page.vue'
export default ListPage
