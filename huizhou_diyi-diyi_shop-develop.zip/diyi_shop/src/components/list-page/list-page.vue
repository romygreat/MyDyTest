<template>
  <div>
    <MainTile :title="title" :desc="desc" />
    <div class="search">
      <slot name="search_input">
        <span>名称：</span>
        <Input :maxlength='40' v-model="search_params.name" clearable placeholder="输入你要查询的名称" style="width: 200px;"/>
      </slot>
      <Button
        @click="search"
        style="display: inline-block; margin:0 0 0 15px;"
        type="primary"
      >搜索</Button>
      <Button
        @click="refresh"
        style="display: inline-block; margin:0 0 0 15px;"
        type="warning"
      >刷新</Button>
    </div>

    <slot name="action">
      <Button type="primary" style="margin-bottom: 15px;" @click="toEdit()">
        <Icon type="md-add"/>
        <span>新增</span>
      </Button>
    </slot>

    <TableData
      ref="table_data"
      :columns="columns"
      :width='String(width)'
      :data_url="data_url"
      :save_url="save_url"
      :del_url="del_url"
      :route_edit="route_edit"
      :search_params="search_params"
      :list_param="list_param"
      @loading_complete="loading_complete"
    />
  </div>
</template>

<script>
import MainTile from '@/components/main-title'
import TableData from '@/components/table-data'
export default {
  name: 'ListPage',
  components: { MainTile, TableData },
  props: {
    title: String,
    desc: String,
    columns: {
      type: Array,
      required: true
    },
    data_url: {
      type: String,
      required: true
    },
    save_url: {
      type: String,
      required: true
    },
    del_url: {
      type: String,
      required: true
    },
    route_edit: {
      type: Object,
      required: true
    },
    search_params: {
      type: Object,
      default: function () {
        return {}
      }
    },
    list_param: {
      type: Object,
      default: function () {
        return {}
      }
    },
    width:{
      type:String || Number,
      default:'100%'
    }
  },
  data () {
    return {
    }
  },
  methods: {
    search () {
      this.$refs.table_data.getList(1)
    },
    refresh () {
      let keys = Object.keys(this.search_params)
      for (let i = 0; i < keys.length; i++) {
        this.search_params[keys[i]] = ''
      }

      this.$refs.table_data.getList()
    },
    loading_complete () {
    },
    /**
     * 跳到编辑页
     * @param id
     */
    toEdit () {
      this.$router.push(this.route_edit)
    },
    save (index, row) {
      this.$refs.table_data.save(index, row)
    },
    getList(page){
      this.$refs.table_data.getList(page)
    }
  }
}
</script>

<style scoped>
@import url("list-page.less");
</style>
