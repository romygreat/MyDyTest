<!--
 * @Author: 叶锦荣
 * @Date: 2019-07-16 08:43:16
 * @LastEditTime: 2019-11-29 17:09:28
 -->
<template>
  <div @click="handleClick" name="logout" class="clearUser afborder">
    <Icon :size="26" type="ios-power" />
    <span class="clearUserText">退出</span>
  </div>
</template>

<script>
import { setToken } from '@/libs/util'
import { mapActions } from 'vuex'
import { userLogout } from '@/api/data'
export default {
  methods: {
    ...mapActions(['handleLogOut']),
    handleClick() {
      this.$Modal.confirm({
        title: '退出登录',
        content: '<p>你是否确认退出登录？</p>',
        onOk: () => {
          const data = {}
          userLogout(data).then(res => {
            console.log(res.data.code == 1,'体哦草及')
            if (res.data.code == 1) {
              setToken('')
              this.$router.push({
                name: 'login'
              })
            }
          })
        }
      })
    }
  }
}
</script>

<style scope>
.clearUserText {
  padding-left: 5px;
  font-size: 14px;
}
.clearUser:hover {
  cursor: pointer;
}
</style>
