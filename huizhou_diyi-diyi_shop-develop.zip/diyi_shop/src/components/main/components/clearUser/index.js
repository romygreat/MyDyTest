import clearUser from './clearUser'
export default clearUser
