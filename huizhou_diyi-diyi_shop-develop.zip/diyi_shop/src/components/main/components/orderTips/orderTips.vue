<template>
  <div @click="clearNewsinfo" class="badge afborder">
    <Badge :count="Number(tipsNumber)">
      <Icon type="ios-notifications-outline" size="26"></Icon>
    </Badge>
    <p style="display: inline-block; font-size:14px;margin-left:5px; ">信息</p>
    <audio id="vio" style="height: 40px; display:block !important; width:40px; " :src="src"></audio>
    <audio
      id="vioServer"
      style="height: 40px; display:block !important; width:40px; "
      :src="vioServerInfo"
    ></audio>
  </div>
</template>

<script>
import { mapMutations } from 'vuex'
import voiceinfo from '@/assets/audio/a.mp3'
import { newOrderButtom } from '@/api/order/orderList'
import { setStautsText, getStautsText } from '@/libs/tools.js'
import vioServerInfo from '@/assets/audio/orderserver.mp3'
import { getStatus } from '@/api/home/home'
export default {
  data() {
    return {
      src: voiceinfo,
      swith: '0',
      sdk: true,
      statusListinfo: [],
      vioServerInfo
    }
  },
  methods: {
    ...mapMutations(['increase', 'clearNews', 'serverSetValue']),
    // 监听是否新订单
    isNewOrder() {
      let _this = this
      const data = {}
      setInterval(() => {
        newOrderButtom(data)
          .then(res => {
            this.$emit('getorderlogList', 1)
            _this.serverSetValue(res.data.data.no_service)
            if (res.data.data.is_play == 1) {
              this.playinfo()
              _this.increase(res.data.data.total)
            } else {
              _this.increase(res.data.data.total)
            }
            if (res.data.data.notifications != null) {
              let notificData = res.data.data.notifications
              if (this.statusListinfo[notificData.type] != undefined) {
                this.playVioServer()
                this.$Notice.success({
                  title: '通知',
                  desc: `台桌${notificData.table_name}需要${
                    this.statusListinfo[notificData.type]
                  }服务`,
                  duration: 60
                })
              }
            }
          })
          .catch(err => {
            console.error(err)
          })
      }, 5000)
    },
    // 清楚提示数字
    clearNewsinfo() {
      // this.clearNews()
      this.$router.push({
        name: 'orderList'
      })
    },
    playinfo() {
      document.getElementById('vio').play()
    },
    playVioServer() {
      document.getElementById('vioServer').play()
    },
    async getStatusinfo() {
      const data = {}
      await getStatus(data).then(res => {        
        setStautsText(res.data.data)
      })

      return getStautsText('service.type')
    }
  },
  computed: {
    tipsNumber() {
      return this.$store.state.orderTips.newsOrder
    }
  },
  mounted() {
    this.isNewOrder()
  },
  created() {
    this.getStatusinfo().then(res => {
      this.statusListinfo = getStautsText('service.type')
    })
    // this.statusListinfo = getStautsText('service.type')
  }
}
</script>

<style>
.badge {
  float: left !important;
}
.badge .ivu-badge-count {
  top: 15px !important;
  border: none;
  box-shadow: none;
  height: 15px;
  padding: 0 !important;
  max-width: 15px !important;
  line-height: 15px;
  min-width: 15px !important;
  border-radius: 50%;
  font-size: 10px;
  left: 5px;
}
.badge:hover {
  cursor: pointer;
}
.afborder {
  padding-left: 15px;
}
.afborder::after {
  content: '';
  display: inline-block;
  width: 1px;
  height: 20px;
  background: #334454;
  transform: translateY(50%);
  margin-bottom: 5px;
  margin-left: 20px;
}
.afborder i {
  font-size: 26px;
  line-height: 56px;
  height: 60px;
}
</style>
