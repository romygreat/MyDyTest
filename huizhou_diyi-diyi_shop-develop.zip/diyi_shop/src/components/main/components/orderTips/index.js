import orderTips from './orderTips.vue'
export default orderTips
