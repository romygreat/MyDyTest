<template>
  <div>
    <Table :width='String(width)'  ref="selection" border :columns="columns" :data="data_list" stripe>
      <template slot-scope="{ row, index }" slot="action">
        <Button type="primary" size="small" style="margin-right: 5px" @click="toEdit(row.id)" >编辑</Button>
        <Button type="error" size="small" @click="destroy(row.id)">删除</Button>
      </template>
    </Table>
    <div :style='styleObj' >
      <Page show-total :page-size='Number(request_params.data.rows)'  :current='Number(request_params.data.page)'  :total="Number(data_total)" @on-change="getList" class="page-buttom"></Page>
    </div>
  </div>
</template>
<script>
export default {
  name: 'TableData',
  props: {
    // 列信息
    columns: {
      type: Array,
      required: true
    },
    data_url: {
      type: String,
      required: true
    },
    save_url: {
      type: String,
      required: true
    },
    del_url: {
      type: String,
      required: true
    },
    route_edit: {
      type: Object,
      required: true
    },
    search_params: {
      type: Object,
      default: function () {
        return {}
      }
    },
    list_param: {
      type: Object,
      default: function () {
        return {}
      }
    },
    width:{
      type:String || Number,
      default:'100%'
    }
  },
  data () {
    return {
      data_list: [],
      data_total: 0,
      request_params: {
        url: '',
        data: {
          page: 1,
          rows: 10
        }
      },
      styleObj:{
        paddingTop:'10px',
        textAlign: 'right'
      }
    }
  },
  methods: {
    /**
     * 获取数据列表
     */
    getList (page) {
      if(page){
        this.request_params.data.page = page
      }
      this.request_params.url = this.data_url
      Object.assign(this.request_params.data, this.search_params, this.list_param)
      this.$http.request(this.request_params)
        .then(response => {
          this.data_list = response.data.data.list
          this.data_total = response.data.data.total
          this.$emit('loading_complete')
        }).catch(error => {
          console.error(error)
        })
    },
    /**
     * 跳到编辑页
     * @param id
     */
    toEdit (id) {
      id = id || 0
      this.route_edit.query = {}
      this.route_edit.query.id = id
      this.$router.push(this.route_edit)
    },
    /**
     * 删除数据
     * @param id
     */
    destroy (id) {
      this.$Modal.confirm({
        title: '彻底删除',
        content: '<p>确认彻底删除？</p>',
        onOk: () => {
          let params = { url: this.del_url, data: {} }
          params.data.id = id
          this.$http.request(params)
            .then(response => {
              let msg = {
                content: response.data.message,
                duration: 3
              }
              if (response.data.code === 1) {
                this.$Message.success(msg)
                this.getList()
              } else {
                this.$Message.warning(msg)
              }
              this.data_list = response.data.data.list
              this.data_total = response.data.data.total
            }).catch(error => {
              console.error(error)
            })
        },
        onCancel: () => {
        }
      })
    },
    save (index, row) {
      this.data_list[index] = row
      let params = { url: this.save_url, data: {} }
      params.data = row
      this.$http.request(params)
        .then(response => {
          let msg = {
            content: response.data.message,
            duration: 3
          }
          if (response.data.code === 1) {
            this.$Message.success(msg)
            this.getList()
          } else {
            this.$Message.warning(msg)
          }
        }).catch(error => {
          console.error(error)
        })
    }
  },
  created () {
    this.getList()
    console.log(this.width)
    this.styleObj.width = this.width + 'px' || 100 + '%'
  }
}
</script>

<style scoped>
</style>
