import TableData from './table-data.vue'
export default TableData
