<template>
  <Upload style="display:inline-block;" :action="action">
      <Button icon="ios-cloud-upload-outline">{{title}}</Button>
  </Upload>
</template>

<script>
import './upload-file.less'
export default {
  name: 'UploadFile',
  props: {
    action: String,
    title: {
      type: String,
      default: '点击上传'
    }
  },
  components: {
  }
}
</script>

