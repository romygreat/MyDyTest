import UploadFile from './upload-file.vue'
export default UploadFile
