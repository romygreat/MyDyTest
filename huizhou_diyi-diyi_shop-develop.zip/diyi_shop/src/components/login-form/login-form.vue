<template>
  <div class="logoMain">
    <Form ref="loginForm" :model="form" :rules="rules" @keydown.enter.native="handleSubmit">
      <FormItem prop="userName" class="form-row">
        <Input :maxlength="40" type="text" v-model="form.userName" placeholder="请输入手机号">
          <span slot="prepend">
            <Icon :size="26" type="md-person" color="#dadada"></Icon>
          </span>
        </Input>
      </FormItem>
      <FormItem prop="password" class="form-row">
        <Input :maxlength="40" type="password" v-model="form.password" placeholder="请输入密码">
          <span slot="prepend">
            <Icon :size="26" type="md-lock" color="#dadada"></Icon>
          </span>
        </Input>
      </FormItem>
      <!-- <FormItem class="form-row form-pwd">
        <span class="form-pwd-forget">
          <span>忘记密码？</span>
        </span>
      </FormItem> -->
      <FormItem class="form-row btn" style="margin-top:32px;">
        <Button
          style="background-image: linear-gradient(to right,#FFC600, #FEA801);border:none;font-size:18px;"
          shape="circle"
          @click="handleSubmit"
          long
        >登录</Button>
      </FormItem>
    </Form>
  </div>
</template>
<script>
export default {
  name: 'LoginForm',
  props: {
    userNameRules: {
      type: Array,
      default: () => {
        return [{ required: true, message: '账号不能为空', trigger: 'blur' }]
      }
    },
    passwordRules: {
      type: Array,
      default: () => {
        return [{ required: true, message: '密码不能为空', trigger: 'blur' }]
      }
    }
  },
  data() {
    return {
      form: {
        userName: '',
        password: ''
      }
    }
  },
  computed: {
    rules() {
      return {
        userName: this.userNameRules,
        password: this.passwordRules
      }
    }
  },
  methods: {
    handleSubmit() {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.$emit('on-success-valid', {
            userName: this.form.userName,
            password: this.form.password
          })
        }
      })
    }
  }
}
</script>
<style>
.ivu-input-group > .ivu-input:last-child,
.ivu-input-group-append,
.ivu-input-group-prepend {
  font-size: 18px;
  border: none !important;
  background-color: rgba(0, 0, 0, 0);
}
.ivu-form-item-content {
  margin: 0 8% 0 4%;
  width: 84% !important;
  border: none !important;
  background-color: rgba(0, 0, 0, 0);
  position: relative;
}
.logoMain .ivu-form-item-error-tip {
  width: 150px;
  height: 40px;
  line-height: 30px;
  font-size: 16px;
  border-radius: 10px;
  text-align: center;
  color: #ffffff;
  background-color: #ffc600;
  position: absolute;
  top: 0;
  left: 330px;
}
.logoMain .ivu-form-item-error-tip::after {
  width: 10px;
  height: 10px;
  content: '';
  transform: rotate(45deg) translateY(50%);
  background-color: #ffc600;
  position: absolute;
  bottom: 50%;
  left: 0;
}
.ivu-input-group {
  top: 1px !important;
}
.btn,
.btn .ivu-form-item-content,
.btn .ivu-form-item-content .ivu-btn {
  margin: 0;
  padding: 0;
  width: 100%;
  height: 100%;
  color: #ffffff;
  background-color: rgba(0, 0, 0, 0);
}
.logoMain .ivu-input {
  border: none !important;
  box-shadow: none !important;
  outline: none;
  font-size: 16px;
  line-height: 32px !important;
}
.logoMain .ivu-form-item-error .ivu-input {
  border: none !important;
}
.logoMain .ivu-form-item-error .ivu-input:focus {
  box-shadow: none !important;
}

.logoMainv .ivu-input:focus {
  border: none !important;
  box-shadow: none !important;
}
.logoMain .ivu-input:hover {
  border: none !important;
  box-shadow: none !important;
}
</style>
