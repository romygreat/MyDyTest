<template>
  <div>
    <div class="title">
      <h3>{{title}}</h3>
      <p>{{desc}}</p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MainTitle',
  props: {
    title: String,
    desc: String
  }
}
</script>

<style scoped>
@import url("main-title.less");
</style>
