import MainTitle from './main-title.vue'
export default MainTitle
