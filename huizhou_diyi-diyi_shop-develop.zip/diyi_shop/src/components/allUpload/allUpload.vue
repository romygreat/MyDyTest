<!--
 * @Author: 叶锦荣
 * @Date: 2019-12-18 17:23:35
 * @LastEditTime : 2019-12-18 18:06:38
 -->
<template>
    <Modal
        v-model="modalShow"
        title="批量上传"
        :footer-hide='true'
        @on-cancel='callBack'
        class="uploadBig"
        :width='450'
    >
        <Upload
            :before-upload="beforeUpload"
            :on-success="handleSuccess"
            :show-upload-list='false'
            multiple
            action="/product/Product/picToProduct">
            <div class="uploadDIV" >
                <Icon color='#2d8cf0' size='36' type="ios-cloud-upload-outline" />
                <p>上传图片</p>
            </div>
            <div class="textUp" >
                <p>上传图片格式：'商品名称-商品价格<span style="color:red;font-weight: bold;" >[价格单位为分]</span>-商品单位-商品所属分类' </p>
                <p>注意：上传格式只支持png以及jpg的图片格式，并且每张图片大小不超过2M</p>
            </div>
        </Upload>
    </Modal>
</template>
<script>
import { getToken } from '@/libs/util'
import { getQnDomain, multupload  } from '@/libs/upload'
export default {
    props:['show'],
    data(){
        return{
            modalShow:false
        }
    },
    methods:{
        /**
         * @desction 回调关闭
         */
        callBack() {
          this.modalShow = false
          this.$emit('modelCallBack',false)
        },
        /**
         * @description 上传
         */
        async beforeUpload(file){
            let fileIndex = 'files'
            if (file.type.indexOf('image') !== 0) {
                this.$Message.info({
                    content: '请上传图片文件',
                    duration: 5,
                    closable: true
                })
                return
            }
            if(file.size > 2 * 1024 * 1024) {
                this.$Message.info({
                    content: '文件大小不能大于2M',
                    duration: 5,
                    closable: true
                })
                return
            } 
            let param = new FormData()
            param.append(fileIndex,file)
            param.append('token', getToken())
            param.append('machine', 'shop')
            let res = await multupload (param)
            console.log(res,'回调',file)
            if(res.code === 1) {
                this.$Message.info({
                    content: `${file.name}上传成功`,
                    duration: 5,
                    closable: true
                })
                this.callBack()
            } else {
                this.$Message.info({
                content: res.message,
                duration: 5,
                closable: true
                })
            }
        },
            handleSuccess (res, file) {
                file.url = '/product/Product/picToProduct';
                console.log(res, file)
            },
    },
    watch: {
        show:{
            handler(n,o) {
                this.modalShow = n
            }
        }
    },
    mounted(){
        this.modalShow = this.show
    }
}
</script>
<style lang="less"  scoped>
@import url('./allUpload.less'); 
</style>
<style lang="less">
.uploadBig .ivu-upload{
    text-align: center !important;
}
.ivu-upload:hover{
    cursor: pointer;
}
</style>