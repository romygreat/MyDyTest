/*
 * @Author: 叶锦荣
 * @Date: 2019-12-18 17:23:41
 * @LastEditTime: 2019-12-18 17:24:42
 */
import allUpload from './allUpload.vue'
export default allUpload