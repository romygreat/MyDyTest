/*
 * @Author: 叶锦荣
 * @Date: 2019-12-10 09:33:08
 * @LastEditTime: 2019-12-10 18:47:40
 */
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import iView from 'iview'
import i18n from '@/locale'
import config from '@/config'
import Router from 'vue-router'
import importDirective from '@/directive'
import installPlugin from '@/plugin'
import httpRequest from '@/libs/api.request'
import 'iview/dist/styles/iview.css'
import './index.less'
import '@/assets/icons/iconfont.css'

const originalPush = Router.prototype.push

Vue.use(iView, {
  i18n: (key, value) => i18n.t(key, value)
})
/**
 * @description 注册admin内置插件
 */
installPlugin(Vue)
/**
 * @description 生产环境关掉提示
 */
Vue.config.productionTip = false
/**
 * @description 全局注册应用配置
 */
Vue.prototype.$config = config
/**
 * @description 全局注册request对象
 */
Vue.prototype.$http = httpRequest

// Router.prototype.push = function push(location) {
//   return originalPush.call(this, location).catch(err => err)
// }

/**
 * 注册指令
 */
importDirective(Vue)
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  i18n,
  store,
  render: h => h(App)
})
