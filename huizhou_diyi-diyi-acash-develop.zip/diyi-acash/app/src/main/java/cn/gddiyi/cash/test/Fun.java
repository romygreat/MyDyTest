package cn.gddiyi.cash.test;
public interface Fun {
    int funTest();
}
