package cn.gddiyi.cash.diyianimation;

import android.graphics.Canvas;



import java.util.Random;

import cn.gddiyi.cash.customview.EnterAnimLayout;


/**
 * Created by wpm on 2017/3/30.
 */

public class AnimQieRu extends Anim {
  static final int NUM=2;
    Random random=new Random();
    int showMethod=random.nextInt(10);
    int cur=showMethod%NUM;
    public AnimQieRu(EnterAnimLayout view)
    {
        super(view);
    }
    @Override
    public void handleCanvas(Canvas canvas, float rate) {
        if (cur==0){
        canvas.translate(w-w*rate,0);}
        else  if (cur==1){
            canvas.translate(h-h*rate,0);
        }
        canvas.save();
       }
    }

