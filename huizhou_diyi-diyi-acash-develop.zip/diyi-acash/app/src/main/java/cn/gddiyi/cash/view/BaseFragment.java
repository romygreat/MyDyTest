package cn.gddiyi.cash.view;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;


import cn.gddiyi.cash.YidiApplication;
import cn.gddiyi.cash.constant.VSConstances;
import cn.gddiyi.cash.controler.DiyiInterface;
import cn.gddiyi.cash.presenter.WifiAutoConnectPresenter;
import cn.gddiyi.cash.presenter.wifypresenter.WifyPresenterImpl;


/**
 * @author romygreat
 * 基类fragment方便统一管理
 */
public class BaseFragment extends Fragment implements View.OnTouchListener, DiyiInterface.SwitchPage {
    String TAG = getClass().getSimpleName();
    SharedPreferences mSharedPreferences;
    Context mContext;
    WifiManager mWifiManager;
    WifiAutoConnectPresenter wac;
    WifiInfo wifiInfo;
    FragmentTransaction fragmentTransaction;


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
        mWifiManager = (WifiManager) mContext.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifiInfo = mWifiManager.getConnectionInfo();
        wac = new WifiAutoConnectPresenter(mWifiManager);
        fragmentTransaction = ((FirstBootActivity) mContext).getSupportFragmentManager().beginTransaction();
        hideBottomUIMenu();
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        hideBottomUIMenu();

        return false;
    }

    @Override
    public void init(View view) {


    }

    @Override
    public void goWifiPage() {
        Intent intent = new Intent(mContext, FirstBootActivity.class);
        //设置wifi传递给firstBootActivity,键同样也是noNetWork，但是值为setWifi,有点别扭
        intent.putExtra("netWork", "setWifi");
        ((YidiApplication) getActivity().getApplication()).setWifiPage(true);
        ((YidiApplication) getActivity().getApplication()).setNoNetwork(false);
        startActivity(intent);
    }

    @Override
    public void goNonetWorkPage() {

    }

    @Override
    public void goMainPage() {

    }

    @Override
    public void goVideoPage() {

    }

    @Override
    public void handleException() {

    }

    public class MyWifyBrocastReceiver extends BroadcastReceiver {
        WifiManager wifiManager;

        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            Log.i(TAG, "onReceive:action " + action);
            wifiManager = WifyPresenterImpl.getmWifiManager();
            if (action.equals(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) {
//             wifi已成功扫描到可用wifi。
            }
        }
    }

    public void printMytips(String str) {
        if (mContext.getApplicationContext() != null) {
            try {
                Toast.makeText(mContext.getApplicationContext(), str, Toast.LENGTH_SHORT).show();
            } catch (NullPointerException e) {
                e.printStackTrace();
                Log.i(TAG, "printMytips: ");
            }
        }
    }
    public void saveConnectedWifiInfo(String wifiName, String wifiPassWord,boolean remenberPwd) {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putString(VSConstances.PREFIX+wifiName,(wifiPassWord+"|"+remenberPwd));
        Log.d(TAG, "saveConnectedWifiInfo: "+(wifiPassWord+"|"+remenberPwd));
        editor.commit();
    }

    public void setSharePreference(String SSID, String passWord) {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        if (SSID != null) {
            editor.putString(getString(cn.gddiyi.cash.cashier.R.string.SSID), SSID);
        }
        if (passWord != null) {
            editor.putString(getString(cn.gddiyi.cash.cashier.R.string.password), passWord);
        }
        editor.commit();//提交修改
    }
    public void setSharePreference1(String SSID, String passWord) {
        SharedPreferences.Editor editor = mSharedPreferences.edit();
        if (SSID != null) {
            editor.putString(getString(cn.gddiyi.cash.cashier.R.string.SSID1), SSID);
        }
        if (passWord != null) {
            editor.putString(getString(cn.gddiyi.cash.cashier.R.string.password), passWord);
        }
        editor.commit();//提交修改
    }

    protected void hideBottomUIMenu() {
        //隐藏虚拟按键，并且全屏
        View decorView = ((FirstBootActivity) mContext).getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        decorView.setSystemUiVisibility(uiOptions);
    }

    public boolean hasWifyConnected() {
        ConnectivityManager connectivity = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = connectivity.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isAvailable()) {
            if (netInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                //WiFi网络
                return true;
            } else if (netInfo.getType() == ConnectivityManager.TYPE_MOBILE) {

            } else {
                //网络错误
            }
        } else {
            //网络错误
        }
        return false;
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) mContext
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo=connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null) {
            return false;
        } else {
            if (networkInfo.isConnected()){
                Log.d(TAG, "isNetworkAvailable: connected");
                return true;
            }
        }
        return false;
    }
}
