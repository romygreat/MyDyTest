package cn.gddiyi.cash.customview.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;


import cn.gddiyi.cash.cashier.R;
import lombok.Getter;
import lombok.Setter;

public class UnBindTableListDialog extends Dialog {
    Context mContext;
    ListView listView;
    String[] tableArray;
    @Getter
    @Setter
    ItemClick itemClick;

    public UnBindTableListDialog(Context context, int themeResId, String[] tableAllArray) {
        super(context, themeResId);
        mContext=context;
        tableArray=tableAllArray;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view = LayoutInflater.from(mContext).inflate(R.layout.bindtablelistdialog, null);
        setContentView(view);
        listView=view.findViewById(R.id.MyTableList);
        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<>(mContext,R.layout.tablenumtextview,R.id.tableListView,
                tableArray);
        if (tableArray.length<=6){
            LinearLayout.LayoutParams layoutParams=(LinearLayout.LayoutParams) listView.getLayoutParams();
            int width=layoutParams.width;
            LinearLayout.LayoutParams layoutParams1=new LinearLayout.LayoutParams(width,AbsListView.LayoutParams.WRAP_CONTENT);
            listView.setLayoutParams(layoutParams1);
        }
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (itemClick!=null){
                    //跑到unbindDialog中来了
                    itemClick.onClickItem(tableArray[position]);
                }
            }
        });
    }
   public interface ItemClick{
        void onClickItem(String selectedItem);
   }
}
