package cn.gddiyi.cash.presenter;

import android.content.Context;



import org.json.JSONException;
import org.json.JSONObject;

import cn.gddiyi.cash.constant.VSConstances;
import cn.gddiyi.cash.model.dto.ResponseUnbindTableList;
import cn.gddiyi.cash.service.PostService;
import okhttp3.RequestBody;
import retrofit2.Call;

public class RequestPresenter {
    Context mContext;
    String mToken;

    public RequestPresenter(Context context, String token) {
        mContext = context;
        mToken = token;
    }

    public Call<ResponseUnbindTableList> getUnbindTableList() {
        GenernalPresenter genernalPresenter = new GenernalPresenter();
        PostService postService = genernalPresenter.createPostService(VSConstances.SERVICE_INTERFACE);
        RequestBody requestBody = genernalPresenter.createRequestBody(getRequestJson());
        Call<ResponseUnbindTableList> responseUnbindTableListCallback = postService.getUnboundShopTable(requestBody);
        //需要实现enque回调方法
        return responseUnbindTableListCallback;
    }

    public JSONObject getRequestJson() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("token", mToken );
            jsonObject.put(VSConstances.MACHINE, VSConstances.MACHINE);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObject;
    }
}
