package cn.gddiyi.cash.jsinterface;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.webkit.JavascriptInterface;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import java.util.ArrayList;

import cn.gddiyi.cash.constant.ConigInfo;
import cn.gddiyi.cash.printer.MainActivity;
import cn.gddiyi.cash.printer.vendor.jiabo.ddo.PrintData;
import cn.gddiyi.cash.printer.vendor.jiabo.ddo.PrintItem;
import cn.gddiyi.cash.printer.vendor.jiabo.dto.PrinterMessage;
import cn.gddiyi.cash.service.WakeUpService;
import cn.gddiyi.cash.view.CrossWalkActivity;


public class JavaScriptinterface {

    Context mContext;
    String TAG = getClass().getSimpleName();
    NoticefyPay mNoticefyPay;
    public final static String SN = "test01";
    public static int jsMethodId = 0;

    public JavaScriptinterface(Context c) {
        mContext = c;
        mNoticefyPay = (NoticefyPay) c;
    }

    /**
     * 与js交互时用到的方法，在js里直接调用的
     */

    @JavascriptInterface
    public String getSn() {
        //来自javaScript
        Log.i(TAG, "getSn: " + getSerialNumber());
        jsMethodId = 1;
        return getSerialNumber();
//        return "000";
    }

    @JavascriptInterface
    public String canPrintTest(String ip, String printerMessage) {
        Log.d(TAG, "canPrintTest:ip= " + ip);
        Log.d(TAG, "canPrintTest: " + printerMessage);
        ((MainActivity) mContext).canPrintTest(ip, printerMessage);
        return "true";
    }

    @JavascriptInterface
    public boolean finishPay(int time) {
        Log.i(TAG, "finishPay: 来自JS== " + time);
        // time=0表示支付不成功,time=1表示支付成功
        if (mNoticefyPay != null) {
            boolean returnResult = mNoticefyPay.finishPay(time);
            return returnResult;
        }
        return false;
    }

    @JavascriptInterface
    public boolean isNeedOpenCodeImg() {
        boolean b = false;
        if (mNoticefyPay != null) {
            Log.d(getClass().getSimpleName(), "isNeedOpenCodeImg()");
            b = mNoticefyPay.isNeedOpenCodeImg();
        }
        return b;
    }

    @JavascriptInterface
    public void unCharge() {
        Log.i(TAG, "unCharge: shutdown123");
//        Log.i(TAG, "unCharge close" + LedAndChargeManager.switchCharge(LedAndChargeManager.SWITCH_OFF));
//        Log.i(TAG, "unCharge:close  " + LedAndChargeManager.setLedColor(LedAndChargeManager.BLUE_CLOSE));
        //顾客充电时间到，已经支付设置为false
        if (mNoticefyPay != null) {
            Log.i(TAG, "unCharge: is not null");
            mNoticefyPay.unCharge();
        }

//        ((CrossWalkActivity) mContext).setWify();
    }

    //添加WIFI设置JS交
    @JavascriptInterface
    public void openWifySetting() {
        Log.i(TAG, "openWifySetting: ");
        ((CrossWalkActivity) mContext).setWify();
    }

    @JavascriptInterface
    public void tmpBilPay(String requestUrl) {
        Log.i(TAG, "tmpBilPay: " + requestUrl);
    }

    @JavascriptInterface
    public boolean setttingActivity() {
        Log.d(TAG, "setttingActivity: ");
        ((MainActivity) mContext).startSettingActivity();
        return true;
    }

    @JavascriptInterface
    public String getHtml(String html) {
        return html;
    }

    @JavascriptInterface
    public void sendMessage(int type) {
        Log.d(TAG, "sendMessage: " + type);
        switch (type) {
            case 0:
                ((CrossWalkActivity) mContext).playAdNow();
                break;
            case 2:
                ((MainActivity) mContext).hideInputMethod();
                break;
            default:
                break;
        }
    }

    public interface NoticefyPay {
        boolean readyPay();

        boolean isNeedOpenCodeImg();

        boolean finishPay(int time);

        boolean unCharge();
    }

    @SuppressLint("MissingPermission")
    public static String getSerialNumber() {
        String sn = Build.SERIAL;
        return sn;
    }

    //打印订单
    @JavascriptInterface
    public String printOrder(int printType, String data) {
        Log.d(TAG, "sendMessage: " + printType);
        switch (printType) {
            case 0:
                ((MainActivity) mContext).printFromJs(printType, data);
                break;
            default:
                break;
        }
        return "测试结果中";
    }

    @JavascriptInterface
    public String printOneOrder(int type, String json) {
        //打印时间未再该字段中
        Log.d(TAG, "printOrder: " + type);
        Log.d(TAG, "processPrinters:"+type+"原始数据= "+json);
//        MainActivity.gson.fromJson()
        String ret = null;
        if (type == ConigInfo.ZHIZUO_ORDER) {
            Log.d(TAG, "制作单: "+json);
            Log.d(TAG, "printOneOrder:制作单 ");
            processMakeOrder(type, json);
        } else {
            //循环打印机处理
            processPrinters(type,json);
        }
        if (ret != null) {
            return ret;
        }
        return "false";
    }

    private void processPrinters(int type, String json) {

        try {
            PrintData printData = MainActivity.gson.fromJson(json, PrintData.class);
            PrinterMessage[] printerMessages = printData.getPrinter();
            Log.d(TAG, "processPrinters: length="+printData.getPrinter().length);
            int i=0;
            if (printerMessages != null && printerMessages.length > 0) {
                for (PrinterMessage printerMessage : printerMessages) {
                    Log.d(TAG, "processPrinters:打印机数据IP= "+printerMessage.getPrinter().getIp());
                    printerMessages[0] = printerMessage;
                    if (printerMessages[0] == null) {
                        continue;
                    }
                    type=printerMessage.getType();
                    Log.d(TAG, "processPrinters: i=="+(i++));
                    Log.d(TAG, "processPrinters: 打印类型="+type);
                    printData.setPrinter(printerMessages);
                    json = MainActivity.gson.toJson(printData);
                    ((MainActivity) mContext).printFromJs(type, json);
                }
            }

        } catch (JsonSyntaxException e) {
            e.printStackTrace();
        }
    }

    private void processMakeOrder(int type, String json) {
        try {
            PrintData printData = MainActivity.gson.fromJson(json, PrintData.class);
            for (int i = 0; i < printData.getPrintItems().size(); i++) {
                Log.d(TAG, "processMakeOrder:size= " + printData.getPrintItems().size());
                PrinterMessage[] printerMessage = printData.getPrintItems().get(i).getPrinter();
                if (printerMessage!=null&&printerMessage.length>0){
                    for (int j=0;j<printerMessage.length;j++){
                        if (printerMessage[j] == null) {
                            continue;
                        }
                        Log.d(TAG, "processMakeOrder: printerMessage" + printerMessage);
                        PrinterMessage[] printerMessagesArray = new PrinterMessage[1];
                        printerMessagesArray[0] = printerMessage[j];
                        printData.setPrinter(printerMessagesArray);
                        // TODO: 2019/12/14 修改，不需要又转换Json字符串
                        printData.setOrderInfo(printData.getPrintItems().get(i));
                        json = MainActivity.gson.toJson(printData);
                        ((MainActivity) mContext).printFromJs(type, json);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void processMakeOrder1(int type, String json) {
//        try {
//            PrintData printData = MainActivity.gson.fromJson(json, PrintData.class);
//            for (int i = 0; i < printData.getPrintItems().size(); i++) {
//                Log.d(TAG, "processMakeOrder:size= " + printData.getPrintItems().size());
//                PrinterMessage printerMessage = printData.getPrintItems().get(i).getPrinter();
//                if (printerMessage == null) {
//                    continue;
//                }
//                Log.d(TAG, "processMakeOrder: printerMessage" + printerMessage);
//                PrinterMessage[] printerMessagesArray = new PrinterMessage[1];
//                printerMessagesArray[0] = printerMessage;
//                printData.setPrinter(printerMessagesArray);
//                // TODO: 2019/12/14 修改，不需要又转换Json字符串
//                printData.setOrderInfo(printData.getPrintItems().get(i));
//                json = MainActivity.gson.toJson(printData);
//                ((MainActivity) mContext).printFromJs(type, json);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

    }
    @JavascriptInterface
    public String setIpList(String list) {
        Log.d(TAG, "setIpList: " + list);
        return "nul";
    }

    @JavascriptInterface
    public String connectPrinter(String ip) {
        Log.d(TAG, "connectPrinter: " + ip + "==port==");
        ((MainActivity) mContext).tryConnectprinter(ip);
        return "";
    }

    @JavascriptInterface
    public String getIpList(String IpList) {
        Log.d(TAG, "getIpList: " + IpList);
        String ret = ((MainActivity) mContext).getIpList(IpList);
        return "";
    }

    @JavascriptInterface
    public String saveIp(String printInfo) {

        String ret = ((MainActivity) mContext).saveOneIp(printInfo);
        return "nul";
    }
    @JavascriptInterface
    public String beforeSaveOneIp(String printInfo) {

        String ret = ((MainActivity) mContext).beforeSaveIp(printInfo);
        return "nul";
    }
    @JavascriptInterface
    public String queryprinterStatus(String json){
        //根据传过来的json格式查询打印机状态
        String ret = ((MainActivity) mContext).queryPrinterFromJs(json);
        return "";
    }
    @JavascriptInterface
    public String startServiceVoice(String voiceContent){
        Log.d(TAG, "voicePlay: "+voiceContent);
        String ret = ((MainActivity) mContext).playVoice(voiceContent);
        return "";
    }
}