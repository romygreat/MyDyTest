package cn.gddiyi.cash.view;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.text.SpannableString;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;



import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;

import cn.gddiyi.cash.YidiApplication;
import cn.gddiyi.cash.constant.VSConstances;
import cn.gddiyi.cash.controler.MyThreadPool;
import cn.gddiyi.cash.customview.dialog.UpdateDialog;
import cn.gddiyi.cash.jsinterface.JavaScriptinterface;
import cn.gddiyi.cash.presenter.AppUpgradePresenter;
import cn.gddiyi.cash.presenter.CrossWalkPresenter;
import cn.gddiyi.cash.presenter.UpgradePresenter;
import cn.gddiyi.cash.utils.DeleteFileUtil;
import cn.gddiyi.cash.utils.netutils.DownloadUtil;

public class SettingActivity extends BaseActivity implements
        View.OnClickListener, UpdateDialog.CallBack {
    String TAG = getClass().getSimpleName();
    TextView serialTv;
    TextView updateTv;
    TextView exitTv;
    TextView freshTv;
    TextView currenTableNameTv;
    TextView connectedWifiNameTv;

    TextView currentVersionTv;
    ProgressBar progressBar;
    LinearLayout checkUpdatell, wifill, clearCachell, videoll;
    UpgradePresenter upgradePresenter;
    UpdateDialog updateDialog;

    boolean isNeedUpdate = false;

    int updataTvGraverty;
    int serveAppVersionCode;
    String serveApkPath;
    String serveMd5;
    String serverAppName;
    AppUpgradePresenter.CallBack appCallBack = new AppUpgradePresenter.CallBack() {
        @Override
        public void UpgradeInfo(String json) {
            Log.d(TAG, "UpgradeInfo: " + json);
            try {
                JSONObject jsonObject = new JSONObject(json);
                int version = (int) jsonObject.get("versionCode");
                serveMd5 = (String) jsonObject.get("md5");
                serverAppName = (String) jsonObject.get("appName");
                Log.d(TAG, "UpgradeInfo:version= " + version);
                serveApkPath = VSConstances.APP_UPGRADE_URL_PATH + serverAppName;
                Log.d(TAG, "UpgradeInfo: apkPath=" + serveApkPath);
                Log.d(TAG, "UpgradeInfo:md5= " + serveMd5);
                Log.d(TAG, "UpgradeInfo:appName " + serverAppName);
                serveAppVersionCode = version;
            } catch (JSONException e) {
                e.printStackTrace();
                return;
            }


        }
    };

    //-------------更新相关变量------------------------


    boolean restartAPP = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(cn.gddiyi.cash.cashier.R.layout.settingactivity);
        setWify = true;
        restartApk = true;
        initView();
        initData();

    }

    private void initData() {
        // TODO: 2019/11/26
        serialTv.setText(JavaScriptinterface.getSerialNumber());

        currentVersionTv.setText(getVerName());

        if (getConnectedWifiName() != null) {
            Log.d(TAG, "initData: ");
            connectedWifiNameTv.setText(getConnectedWifiName());
        } else {
        }
        //获取是否需要更新判断
        upgradePresenter = new UpgradePresenter(this, this);
        checkUpdateAPP();
        connectedWifiNameTv.postDelayed(new Runnable() {
            @Override
            public void run() {
                checkUpdateAPP();
            }
        },3000);



    }


    AppUpgradePresenter appUpgradePresenter = new AppUpgradePresenter(this, appCallBack);
  boolean  isSetRedDot=false;
    private void checkUpdateAPP() {
        //实例化UpgradePresenter，并且得到token,得到token请求并通知返回数据，仅仅是一个是否需要更新的数据
        Log.d(TAG, "checkUpdateAPP: ");
        if (appUpgradePresenter.isNeedtoUpdate(serveAppVersionCode)) {
            Log.d(TAG, "checkUpdateAPP: ");
            isNeedUpdate = true;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (updateDialog != null) {
                        updateDialog.updateTvTips.setText("检查到有新版本，是否立刻更新");
                    }
                }
            });
            if (isSetRedDot==false){
                isSetRedDot= setSuperScriptSpan(updateTv);}
        } else {
            showLastVersion(updateTv);
        }

    }


    public void showLastVersion(final TextView testView) {
        testView.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                testView.setText("检查新版本");

            }
        });
    }

    private void initView() {
        serialTv = findViewById(cn.gddiyi.cash.cashier.R.id.serialNum);
        updateTv = findViewById(cn.gddiyi.cash.cashier.R.id.updateTv);
        exitTv = findViewById(cn.gddiyi.cash.cashier.R.id.testView);
        freshTv = findViewById(cn.gddiyi.cash.cashier.R.id.freshSetting);
        currenTableNameTv = findViewById(cn.gddiyi.cash.cashier.R.id.currentTableName);
        connectedWifiNameTv = findViewById(cn.gddiyi.cash.cashier.R.id.connectedWifiName);
        progressBar = findViewById(cn.gddiyi.cash.cashier.R.id.progressBar);

        checkUpdatell = findViewById(cn.gddiyi.cash.cashier.R.id.checkUpdatell);
        clearCachell = findViewById(cn.gddiyi.cash.cashier.R.id.clearCache);
        videoll = findViewById(cn.gddiyi.cash.cashier.R.id.setting_video);
        wifill = findViewById(cn.gddiyi.cash.cashier.R.id.wifiLinearLayout);
        currentVersionTv = findViewById(cn.gddiyi.cash.cashier.R.id.currentVersion);

        checkUpdatell.setOnClickListener(this);
        clearCachell.setOnClickListener(this);
        wifill.setOnClickListener(this);
        exitTv.setOnClickListener(this);
        videoll.setOnClickListener(this);
        freshTv.setOnClickListener(this);

        showLastVersion(updateTv);
        progressBar.setVisibility(View.INVISIBLE);
        updataTvGraverty = updateTv.getGravity();
    }

    public boolean setSuperScriptSpan(final TextView testView) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                SpannableString spanText = appUpgradePresenter.getSpannableString();
                testView.setGravity(Gravity.NO_GRAVITY);
                testView.append(spanText);
            }
        });
        return true;
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (restartAPP) {
            restartAPP(this);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case cn.gddiyi.cash.cashier.R.id.bindTableList:
                //注意序列号需要写入sdcard/serial中，自己输入的序列号可能导致无效的结果
                break;
            case cn.gddiyi.cash.cashier.R.id.checkUpdatell:
                Log.i(TAG, "onClick: ");
                if (updateDialog == null) {
                    if (isNeedUpdate) {
                        updateDialog = new UpdateDialog(SettingActivity.this,
                                cn.gddiyi.cash.cashier.R.style.dialog_download, "检查到有新版本，是否立刻更新", true);
                    } else {
                        updateDialog = new UpdateDialog(SettingActivity.this, cn.gddiyi.cash.cashier.R.style.dialog_download, false);
                    }
                }
                if (!updateDialog.isShowing()) {
                    updateDialog.setCallBack(this);
                    updateDialog.show();
                }
                break;
            case cn.gddiyi.cash.cashier.R.id.testView:
                //退出键
                Log.d(TAG, "onClick: exit");
                restartApk = false;
                this.finish();
                break;
            case cn.gddiyi.cash.cashier.R.id.wifiLinearLayout:
                Log.i(TAG, "onClick: wifiLinearLayout");
                CrossWalkPresenter mCrossWalkPresenter = new CrossWalkPresenter(this);
                mCrossWalkPresenter.resetSSID(this);
                mCrossWalkPresenter.removewifiBySsid(this);
                Intent intent = new Intent(this, FirstBootActivity.class);
                //设置wifi传递给firstBootActivity,键同样也是noNetWork，但是值为setWifi,有点别扭
                intent.putExtra("netWork", "setWifi");
                ((YidiApplication) getApplication()).setWifiPage(true);
                ((YidiApplication) getApplication()).setNoNetwork(false);
                startActivity(intent);
                restartApk = false;
                //因为wifi需要清理，所以这个也销毁
                CrossWalkActivity.mThis.finish();
                this.finish();
                break;
            case cn.gddiyi.cash.cashier.R.id.clearCache:
                restartAPP = true;
                clearCache();
                break;
            case cn.gddiyi.cash.cashier.R.id.freshSetting:
                ((YidiApplication) getApplication()).setFresh(true);
                printMytips("刷新中");
                this.finish();
                break;
            case cn.gddiyi.cash.cashier.R.id.setting_video:
                //进入视频广告
                startActivity(new Intent(this, VideoActivity.class));
                break;
            default:
                break;
        }
    }


    public void clearCache() {
        restartApk = true;
//        deleteCacheFile(new File("data/data/" + getPackageName() + "/app_xwalkcore"));
        deleteCacheFile(new File("data/data/" + getPackageName() + "/app_webview"));

        this.finish();
    }

    @NonNull
    public DownloadUtil.OnDownloadListener getListener() {
        return new DownloadUtil.OnDownloadListener() {
            @Override
            public void onDownloadSuccess() {
                MyThreadPool.startThread(new Runnable() {
                    @Override
                    public void run() {
                        File file = new File(VSConstances.DOWNLOADAPP_ABS_SAVEDIR + serverAppName);
                        Log.d(TAG, "run:appName= " + serverAppName);
                        if (file.exists()) {
                            Log.d(TAG, "run: 存在文件=" + file.getName());
                            if (!SettingActivity.this.isFinishing()) {
                                //APk下载安全认证，比对MD5，如果无法通过认证，下载后一直会这么提示
                                checkMd5(file);
                            }
                        }
                    }
                });
            }

            @Override
            public void onDownloading(final int progress) {
                progressBar.setProgress(progress);
            }

            @Override
            public void onDownloadFailed() {
                Log.d(TAG, "onDownloadFailed: 什么情况？");
            }
        };
    }

    private void checkMd5(final File file) {
        String md5 = AppUpgradePresenter.getFileMD5(file).trim();
        Log.d(TAG, "nativeMd5= " + md5);
        Log.d(TAG, "serveMd5=" + serveMd5);
        if (md5 == null) {
            return;
        }
        //验证需要从eclipse获取MD5的值
        if (md5.equals(serveMd5.trim())) {
            upgradePresenter.installApk(file, SettingActivity.this);
        } else {
            //需要在主线程中
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(SettingActivity.this, "下载应用出现故障，请检查网络是否正常", Toast.LENGTH_LONG).show();
                    AlertDialog.Builder alertDialog = new AlertDialog.Builder(SettingActivity.this);
                    alertDialog.setTitle("验证码不一致，建议重新下载，是否重新下载？");
                    alertDialog.setPositiveButton("重新下载", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //重新下载
                            windowSettingImpls.hideBottomUIMenu(SettingActivity.this);
                            DeleteFileUtil.deleteDirectory(Environment.getExternalStorageDirectory().getPath() + "/downloadAPP");
                            progressBar.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    printMytips("准备下再中");
                                    upgradePresenter.downLoadAPP(serveApkPath, VSConstances.DOWNLOADAPP_SAVEDIR, getListener());
                                }
                            }, 3_000);

                        }
                    });
                    alertDialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
//                            upgradePresenter.installApk(file, SettingActivity.this);
                        }
                    });
                    alertDialog.show();
                }
            });

        }
    }

    void printMytips(final String str) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onClickUpdate(UpdateDialog updateDialog) {
        //更新app
        windowSettingImpls.hideBottomUIMenu(this);
        if (isNeedUpdate) {
            progressBar.setVisibility(View.VISIBLE);
            updateDialog.dismiss();
            Log.d(TAG, "onClickUpdate: " + serveApkPath);
            upgradePresenter.downLoadAPP(serveApkPath, VSConstances.DOWNLOADAPP_SAVEDIR, getListener());
        } else {
            updateDialog.updateTvTips.setText("当前已是最新版本");
        }
    }


    @Override
    public void onBackPressed() {
        windowSettingImpls.hideBottomUIMenu(this);
    }

    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.SETTING_ACTIVITY);
    }


}
