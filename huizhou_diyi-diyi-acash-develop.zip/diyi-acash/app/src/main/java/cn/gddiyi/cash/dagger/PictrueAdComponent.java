package cn.gddiyi.cash.dagger;



import cn.gddiyi.cash.view.CrossWalkActivity;
import dagger.Component;

@Component(modules = {PicModule.class})
public interface PictrueAdComponent {
     void inject(CrossWalkActivity crossWalkActivity);
}
