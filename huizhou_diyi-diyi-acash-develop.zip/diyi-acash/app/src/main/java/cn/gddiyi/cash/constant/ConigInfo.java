package cn.gddiyi.cash.constant;


import lombok.Getter;
import lombok.Setter;

public class ConigInfo {
    //桌台号
    @Getter
    @Setter
    public static String tableNum;
    //充电时间
    /**
     * 打印订单的类型
     * //-----
     * 1: 预结单
     * 2：结帐单
     * 3：传菜单
     * //-----
     * 4：制作单
     * 5：退菜单
     * 6：转台单
     * 7：催菜单
     */
    public static final int YUJIE_ORDER=1;
    public static final int JIEZHAANG_ORDER=2;
    public static final int CHUANCAI_ORDER=3;
    public static final int SONGCHU_ORDER=3;
    public static final int ZHIZUO_ORDER=7;
    public static final int TUICAI_ORDER=5;
    public static final int ZHUANGTAI_ORDER=6;
    public static final int CUICAI_ORDER=4;

}
