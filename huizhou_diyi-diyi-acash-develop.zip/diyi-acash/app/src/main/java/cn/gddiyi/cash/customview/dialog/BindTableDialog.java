package cn.gddiyi.cash.customview.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.StyleRes;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;



import java.util.HashMap;
import java.util.Iterator;

import cn.gddiyi.cash.customview.Myspinner;
import cn.gddiyi.cash.jsinterface.JavaScriptinterface;
import lombok.Getter;
import lombok.Setter;

public class BindTableDialog extends Dialog implements View.OnClickListener {
    String TAG = getClass().getSimpleName();
    private Context mContext;
//    private ConfirmImagegeView cancel_button;
    private ImageView cancel_button;
    private TextView serialDialogTv;
//    private ConfirmImagegeView cofirm_button;
    private ImageView cofirm_button;
    public Myspinner spinner;
    @Setter
    @Getter
    public OnClickListener onClickListener;
    public String[] arr;
    public ArrayAdapter<String> adapter;
    private HashMap unbindTableMap;
    String[] tableAllArray;
    View view;

    public BindTableDialog(@NonNull Context context, @StyleRes int themeResId, String[] tableArray) {
        super(context, themeResId);
        mContext = context;
        tableAllArray = new String[tableArray.length];
        for (int i = 0; i <= tableArray.length - 1; i++) {
            tableAllArray[i] = tableArray[i];
        }
    }

    public BindTableDialog(@NonNull Context context, @StyleRes int themeResId, HashMap tableMap) {
        super(context, themeResId);
        mContext = context;
        unbindTableMap = tableMap;
        tableAllArray = new String[tableMap.size()];
        int i = 0;
        for (Iterator iterator = tableMap.keySet().iterator(); iterator.hasNext(); i++) {
            tableAllArray[i] = (String) iterator.next();
        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        view = LayoutInflater.from(mContext).inflate(cn.gddiyi.cash.cashier.R.layout.bindtabledialog, null);
        setContentView(view);
        initView(view);
        initData();

    }

    private void initData() {
        Log.d(TAG, "initData: ");
        serialDialogTv.setText(JavaScriptinterface.getSerialNumber());
        if (tableAllArray.length>0)
        {
            adapter = new ArrayAdapter(mContext, cn.gddiyi.cash.cashier.R.layout.myspinner, new String[]{"请选择桌台号"});
            spinner.setTableArray(tableAllArray);
        }
        else{
           adapter = new ArrayAdapter(mContext, cn.gddiyi.cash.cashier.R.layout.myspinner, new String[]{"无台桌"});
        }
        adapter.setDropDownViewResource(cn.gddiyi.cash.cashier.R.layout.checkview1);
        spinner.setPrompt("请选择桌台号");
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.i(TAG, "onItemSelected: " + tableAllArray[position]);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case cn.gddiyi.cash.cashier.R.id.cofirm_button_show:
                String selectedItem = (String) spinner.getSelectedItem();
                Log.d(TAG, "onClick:cofirm_button_show= "+selectedItem);
                if (onClickListener != null) {
                    onClickListener.onConfirmClick(v, selectedItem);

                }
                break;
            case cn.gddiyi.cash.cashier.R.id.cancel_button_show:
                this.dismiss();
                break;
            default:
                break;
        }
    }

    private void initView(View view) {
        cofirm_button = view.findViewById(cn.gddiyi.cash.cashier.R.id.cofirm_button_show);
        cancel_button = view.findViewById(cn.gddiyi.cash.cashier.R.id.cancel_button_show);
        serialDialogTv = view.findViewById(cn.gddiyi.cash.cashier.R.id.serialDialog);
        spinner = view.findViewById(cn.gddiyi.cash.cashier.R.id.spinner);
        cancel_button.setOnClickListener(this);
        cofirm_button.setOnClickListener(this);

    }

    public void showSelectedItem(String selectedItem) {
        adapter = new ArrayAdapter(mContext, cn.gddiyi.cash.cashier.R.layout.myspinner, new String[]{selectedItem});
        spinner.setPrompt(selectedItem);
        spinner.setAdapter(adapter);

    }

    public interface OnClickListener {
        boolean onConfirmClick(View view, String selectedId);
    }
}
