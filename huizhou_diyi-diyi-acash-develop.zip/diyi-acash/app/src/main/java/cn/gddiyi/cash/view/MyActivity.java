package cn.gddiyi.cash.view;

import android.app.Activity;
import android.os.Bundle;

import cn.gddiyi.cash.cashier.R;


public class MyActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layouttestedit);
    }
}
