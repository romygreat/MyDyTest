package cn.gddiyi.cash.test;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class OneTest {

    /**
     * id : 10468
     * shop_id : 62
     * pid : 0
     * order_no : 20191203102444826275
     * trade_no : 120310250111139
     * add_time : 2019-12-03 10:24:44
     * pay_time : 2019-12-03 10:25:01
     * status : 2
     * close_reason : 0
     * total_price : 101
     * paid_price : 101
     * pay_action : 2
     * pay_way : 2
     * delete_time : 0
     * change_status : 0
     * table_no : D0022
     * is_invoice : 0
     * over_time : 2019-12-03 10:25:01
     * service_price : 0
     * tableware_num : 1
     * tableware_fee : 0
     * remark :
     * is_new : 0
     * real_price : 3600
     * change_price : 3499
     * preferential_way : 0
     * discount_amount : 0
     * discount_reason :
     * append : 0
     * discount_rate : 10
     * pin_out : 0
     * printer : [
     *            {"id":264,"shop_id":62,"printer_id":148,"product_cate_id":0,"type":2,
     *            "printer":{"id":148,"title":"真测试","ip":"192.168.0.168","size":88,"copies":3,"style":1,"type":2,"is_voice":1}}]
     * shop_name : 138测试
     * address : 啊是大
     * phone : 13888888888
     * order_list : [{"id":19338,"shop_id":62,"order_id":10468,"product_id":605,"set_meal_id":0,"group_spec_id":0,"contorno_ids":"0","taste_id":0,"procedure_id":0,"name":"纸巾","pic":"shop/6f8d82787a75c52cd171192b60669040.jpg","product_code":"ZJ","num":"1","unit_price":100,"reduce_money":0,"price":100,"final_price":100,"preferential_way":0,"discount_rate":"10","discount_amount":0,"discount_reason":"","status":0,"type":0,"urge":0,"unit":"包","close_reason":0,"is_editable":0,"is_exists_edit":0,"is_exists_current":0,"is_current":0,"is_pack":0,"remark":"","refund_status":0,"cate_id":130,"sales_time":1575339884,"switch":true},{"id":19339,"shop_id":62,"order_id":10468,"product_id":608,"set_meal_id":0,"group_spec_id":0,"contorno_ids":"0","taste_id":0,"procedure_id":0,"name":"测试0.01","pic":"shop/068427a3b3b8926a406a786da1c134af.jpg","product_code":"CESHI","num":"1","unit_price":1,"reduce_money":0,"price":1,"final_price":1,"preferential_way":0,"discount_rate":"10","discount_amount":0,"discount_reason":"","status":0,"type":0,"urge":0,"unit":"例","close_reason":0,"is_editable":0,"is_exists_edit":0,"is_exists_current":0,"is_current":0,"is_pack":0,"remark":"","refund_status":0,"cate_id":124,"sales_time":1575339884,"switch":true}]
     */

    private int id;
    private int shop_id;
    private int pid;
    private String order_no;
    private String trade_no;
    private String add_time;
    private String pay_time;
    private int status;
    private int close_reason;
    private int total_price;
    private int paid_price;
    private int pay_action;
    private int pay_way;
    private int delete_time;
    private int change_status;
    private String table_no;
    private int is_invoice;
    private String over_time;
    private int service_price;
    private int tableware_num;
    private int tableware_fee;
    private String remark;
    private int is_new;
    private String real_price;
    private String change_price;
    private int preferential_way;
    private int discount_amount;
    private String discount_reason;
    private int append;
    private String discount_rate;
    private String pin_out;
    private String shop_name;
    private String address;
    private String phone;
    private List<PrinterBeanX> printer;
    private List<OrderListBean> order_list;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getShop_id() {
        return shop_id;
    }

    public void setShop_id(int shop_id) {
        this.shop_id = shop_id;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getTrade_no() {
        return trade_no;
    }

    public void setTrade_no(String trade_no) {
        this.trade_no = trade_no;
    }

    public String getAdd_time() {
        return add_time;
    }

    public void setAdd_time(String add_time) {
        this.add_time = add_time;
    }

    public String getPay_time() {
        return pay_time;
    }

    public void setPay_time(String pay_time) {
        this.pay_time = pay_time;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getClose_reason() {
        return close_reason;
    }

    public void setClose_reason(int close_reason) {
        this.close_reason = close_reason;
    }

    public int getTotal_price() {
        return total_price;
    }

    public void setTotal_price(int total_price) {
        this.total_price = total_price;
    }

    public int getPaid_price() {
        return paid_price;
    }

    public void setPaid_price(int paid_price) {
        this.paid_price = paid_price;
    }

    public int getPay_action() {
        return pay_action;
    }

    public void setPay_action(int pay_action) {
        this.pay_action = pay_action;
    }

    public int getPay_way() {
        return pay_way;
    }

    public void setPay_way(int pay_way) {
        this.pay_way = pay_way;
    }

    public int getDelete_time() {
        return delete_time;
    }

    public void setDelete_time(int delete_time) {
        this.delete_time = delete_time;
    }

    public int getChange_status() {
        return change_status;
    }

    public void setChange_status(int change_status) {
        this.change_status = change_status;
    }

    public String getTable_no() {
        return table_no;
    }

    public void setTable_no(String table_no) {
        this.table_no = table_no;
    }

    public int getIs_invoice() {
        return is_invoice;
    }

    public void setIs_invoice(int is_invoice) {
        this.is_invoice = is_invoice;
    }

    public String getOver_time() {
        return over_time;
    }

    public void setOver_time(String over_time) {
        this.over_time = over_time;
    }

    public int getService_price() {
        return service_price;
    }

    public void setService_price(int service_price) {
        this.service_price = service_price;
    }

    public int getTableware_num() {
        return tableware_num;
    }

    public void setTableware_num(int tableware_num) {
        this.tableware_num = tableware_num;
    }

    public int getTableware_fee() {
        return tableware_fee;
    }

    public void setTableware_fee(int tableware_fee) {
        this.tableware_fee = tableware_fee;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public int getIs_new() {
        return is_new;
    }

    public void setIs_new(int is_new) {
        this.is_new = is_new;
    }

    public String getReal_price() {
        return real_price;
    }

    public void setReal_price(String real_price) {
        this.real_price = real_price;
    }

    public String getChange_price() {
        return change_price;
    }

    public void setChange_price(String change_price) {
        this.change_price = change_price;
    }

    public int getPreferential_way() {
        return preferential_way;
    }

    public void setPreferential_way(int preferential_way) {
        this.preferential_way = preferential_way;
    }

    public int getDiscount_amount() {
        return discount_amount;
    }

    public void setDiscount_amount(int discount_amount) {
        this.discount_amount = discount_amount;
    }

    public String getDiscount_reason() {
        return discount_reason;
    }

    public void setDiscount_reason(String discount_reason) {
        this.discount_reason = discount_reason;
    }

    public int getAppend() {
        return append;
    }

    public void setAppend(int append) {
        this.append = append;
    }

    public String getDiscount_rate() {
        return discount_rate;
    }

    public void setDiscount_rate(String discount_rate) {
        this.discount_rate = discount_rate;
    }

    public String getPin_out() {
        return pin_out;
    }

    public void setPin_out(String pin_out) {
        this.pin_out = pin_out;
    }

    public String getShop_name() {
        return shop_name;
    }

    public void setShop_name(String shop_name) {
        this.shop_name = shop_name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public List<PrinterBeanX> getPrinter() {
        return printer;
    }

    public void setPrinter(List<PrinterBeanX> printer) {
        this.printer = printer;
    }

    public List<OrderListBean> getOrder_list() {
        return order_list;
    }

    public void setOrder_list(List<OrderListBean> order_list) {
        this.order_list = order_list;
    }

    public static class PrinterBeanX {
        /**
         * id : 264
         * shop_id : 62
         * printer_id : 148
         * product_cate_id : 0
         * type : 2
         * printer : {"id":148,"title":"真测试","ip":"192.168.0.168","size":88,"copies":3,"style":1,"type":2,"is_voice":1}
         */

        private int id;
        private int shop_id;
        private int printer_id;
        private int product_cate_id;
        private int type;
        private PrinterBean printer;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getShop_id() {
            return shop_id;
        }

        public void setShop_id(int shop_id) {
            this.shop_id = shop_id;
        }

        public int getPrinter_id() {
            return printer_id;
        }

        public void setPrinter_id(int printer_id) {
            this.printer_id = printer_id;
        }

        public int getProduct_cate_id() {
            return product_cate_id;
        }

        public void setProduct_cate_id(int product_cate_id) {
            this.product_cate_id = product_cate_id;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public PrinterBean getPrinter() {
            return printer;
        }

        public void setPrinter(PrinterBean printer) {
            this.printer = printer;
        }

        public static class PrinterBean {
            /**
             * id : 148
             * title : 真测试
             * ip : 192.168.0.168
             * size : 88
             * copies : 3
             * style : 1
             * type : 2
             * is_voice : 1
             */

            private int id;
            private String title;
            private String ip;
            private int size;
            private int copies;
            private int style;
            private int type;
            private int is_voice;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getIp() {
                return ip;
            }

            public void setIp(String ip) {
                this.ip = ip;
            }

            public int getSize() {
                return size;
            }

            public void setSize(int size) {
                this.size = size;
            }

            public int getCopies() {
                return copies;
            }

            public void setCopies(int copies) {
                this.copies = copies;
            }

            public int getStyle() {
                return style;
            }

            public void setStyle(int style) {
                this.style = style;
            }

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public int getIs_voice() {
                return is_voice;
            }

            public void setIs_voice(int is_voice) {
                this.is_voice = is_voice;
            }
        }
    }

    public static class OrderListBean {
        /**
         * id : 19338
         * shop_id : 62
         * order_id : 10468
         * product_id : 605
         * set_meal_id : 0
         * group_spec_id : 0
         * contorno_ids : 0
         * taste_id : 0
         * procedure_id : 0
         * name : 纸巾
         * pic : shop/6f8d82787a75c52cd171192b60669040.jpg
         * product_code : ZJ
         * num : 1
         * unit_price : 100
         * reduce_money : 0
         * price : 100
         * final_price : 100
         * preferential_way : 0
         * discount_rate : 10
         * discount_amount : 0
         * discount_reason :
         * status : 0
         * type : 0
         * urge : 0
         * unit : 包
         * close_reason : 0
         * is_editable : 0
         * is_exists_edit : 0
         * is_exists_current : 0
         * is_current : 0
         * is_pack : 0
         * remark :
         * refund_status : 0
         * cate_id : 130
         * sales_time : 1575339884
         * switch : true
         */

        private int id;
        private int shop_id;
        private int order_id;
        private int product_id;
        private int set_meal_id;
        private int group_spec_id;
        private String contorno_ids;
        private int taste_id;
        private int procedure_id;
        private String name;
        private String pic;
        private String product_code;
        private String num;
        private int unit_price;
        private int reduce_money;
        private int price;
        private int final_price;
        private int preferential_way;
        private String discount_rate;
        private int discount_amount;
        private String discount_reason;
        private int status;
        private int type;
        private int urge;
        private String unit;
        private int close_reason;
        private int is_editable;
        private int is_exists_edit;
        private int is_exists_current;
        private int is_current;
        private int is_pack;
        private String remark;
        private int refund_status;
        private int cate_id;
        private int sales_time;
        @SerializedName("switch")
        private boolean switchX;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getShop_id() {
            return shop_id;
        }

        public void setShop_id(int shop_id) {
            this.shop_id = shop_id;
        }

        public int getOrder_id() {
            return order_id;
        }

        public void setOrder_id(int order_id) {
            this.order_id = order_id;
        }

        public int getProduct_id() {
            return product_id;
        }

        public void setProduct_id(int product_id) {
            this.product_id = product_id;
        }

        public int getSet_meal_id() {
            return set_meal_id;
        }

        public void setSet_meal_id(int set_meal_id) {
            this.set_meal_id = set_meal_id;
        }

        public int getGroup_spec_id() {
            return group_spec_id;
        }

        public void setGroup_spec_id(int group_spec_id) {
            this.group_spec_id = group_spec_id;
        }

        public String getContorno_ids() {
            return contorno_ids;
        }

        public void setContorno_ids(String contorno_ids) {
            this.contorno_ids = contorno_ids;
        }

        public int getTaste_id() {
            return taste_id;
        }

        public void setTaste_id(int taste_id) {
            this.taste_id = taste_id;
        }

        public int getProcedure_id() {
            return procedure_id;
        }

        public void setProcedure_id(int procedure_id) {
            this.procedure_id = procedure_id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPic() {
            return pic;
        }

        public void setPic(String pic) {
            this.pic = pic;
        }

        public String getProduct_code() {
            return product_code;
        }

        public void setProduct_code(String product_code) {
            this.product_code = product_code;
        }

        public String getNum() {
            return num;
        }

        public void setNum(String num) {
            this.num = num;
        }

        public int getUnit_price() {
            return unit_price;
        }

        public void setUnit_price(int unit_price) {
            this.unit_price = unit_price;
        }

        public int getReduce_money() {
            return reduce_money;
        }

        public void setReduce_money(int reduce_money) {
            this.reduce_money = reduce_money;
        }

        public int getPrice() {
            return price;
        }

        public void setPrice(int price) {
            this.price = price;
        }

        public int getFinal_price() {
            return final_price;
        }

        public void setFinal_price(int final_price) {
            this.final_price = final_price;
        }

        public int getPreferential_way() {
            return preferential_way;
        }

        public void setPreferential_way(int preferential_way) {
            this.preferential_way = preferential_way;
        }

        public String getDiscount_rate() {
            return discount_rate;
        }

        public void setDiscount_rate(String discount_rate) {
            this.discount_rate = discount_rate;
        }

        public int getDiscount_amount() {
            return discount_amount;
        }

        public void setDiscount_amount(int discount_amount) {
            this.discount_amount = discount_amount;
        }

        public String getDiscount_reason() {
            return discount_reason;
        }

        public void setDiscount_reason(String discount_reason) {
            this.discount_reason = discount_reason;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }

        public int getUrge() {
            return urge;
        }

        public void setUrge(int urge) {
            this.urge = urge;
        }

        public String getUnit() {
            return unit;
        }

        public void setUnit(String unit) {
            this.unit = unit;
        }

        public int getClose_reason() {
            return close_reason;
        }

        public void setClose_reason(int close_reason) {
            this.close_reason = close_reason;
        }

        public int getIs_editable() {
            return is_editable;
        }

        public void setIs_editable(int is_editable) {
            this.is_editable = is_editable;
        }

        public int getIs_exists_edit() {
            return is_exists_edit;
        }

        public void setIs_exists_edit(int is_exists_edit) {
            this.is_exists_edit = is_exists_edit;
        }

        public int getIs_exists_current() {
            return is_exists_current;
        }

        public void setIs_exists_current(int is_exists_current) {
            this.is_exists_current = is_exists_current;
        }

        public int getIs_current() {
            return is_current;
        }

        public void setIs_current(int is_current) {
            this.is_current = is_current;
        }

        public int getIs_pack() {
            return is_pack;
        }

        public void setIs_pack(int is_pack) {
            this.is_pack = is_pack;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public int getRefund_status() {
            return refund_status;
        }

        public void setRefund_status(int refund_status) {
            this.refund_status = refund_status;
        }

        public int getCate_id() {
            return cate_id;
        }

        public void setCate_id(int cate_id) {
            this.cate_id = cate_id;
        }

        public int getSales_time() {
            return sales_time;
        }

        public void setSales_time(int sales_time) {
            this.sales_time = sales_time;
        }

        public boolean isSwitchX() {
            return switchX;
        }

        public void setSwitchX(boolean switchX) {
            this.switchX = switchX;
        }
    }
}
