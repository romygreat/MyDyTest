package cn.gddiyi.cash.test;
import android.support.annotation.NonNull;
import java.util.stream.Collectors;
import java.util.stream.Stream;



public class MyTest extends Class1 implements Fun {
    public static void main(String[] args) {
        Stream<String> stringStream= Stream.of("one","two","three");
        stringStream
                .filter((item)->item.contains("th"))
                .collect(Collectors.toList())
                .forEach(System.out::println);

    }

    @Override
    public int funTest() {
        System.out.println("testMethod");
        return 0;
    }

    public void funTest1() {
        System.out.println("testMethod");

    }

    public static void Hello(String content){
        System.out.println("Hello Method"+content);
    }
    @NonNull
    @Override
    public String toString() {
        return getClass().getSimpleName();
    }
}
