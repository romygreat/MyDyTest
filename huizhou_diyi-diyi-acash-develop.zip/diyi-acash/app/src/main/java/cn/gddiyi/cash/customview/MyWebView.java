package cn.gddiyi.cash.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;

import cn.gddiyi.cash.controler.MyThreadPool;
import cn.gddiyi.cash.printer.MainActivity;


public class MyWebView extends WebView {
    final  static String TAG="MyWebView";
    Context mContext;
    public MyWebView(Context context) {
        super(context);
        this.getSettings().setMediaPlaybackRequiresUserGesture(false);
        Log.d(TAG, "MyWebView: 1");
    }

    public MyWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext=context;
        this.getSettings().setMediaPlaybackRequiresUserGesture(false);
        //在这里加载WebView
        Log.d(TAG, "MyWebView: 2");
    }

    public MyWebView(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr,0);
        this.getSettings().setMediaPlaybackRequiresUserGesture(false);
        Log.d(TAG, "MyWebView: 3");
    }

    public MyWebView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        this.getSettings().setMediaPlaybackRequiresUserGesture(false);
        Log.d(TAG, "MyWebView: 4");
    }
    @Override
    public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
    //设置隐藏键盘
    final InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
    if (MainActivity.mHideInputMethod){
        MyThreadPool.startThread(new Runnable() {
            @Override
            public void run() {
                while (MainActivity.mHideInputMethod){
                    imm.hideSoftInputFromWindow(MyWebView.this.getWindowToken(), 0);
                }
            }
        });
        this.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (imm.isActive()) {
                    imm.hideSoftInputFromWindow(MyWebView.this.getWindowToken(), 0);
                    MainActivity.mHideInputMethod=false;
                }
            }
        },200);
        imm.hideSoftInputFromWindow(MyWebView.this.getWindowToken(), 0);
        //再一次调用
        imm.hideSoftInputFromWindow(MyWebView.this.getWindowToken(), 0);
    }
        return super.onCreateInputConnection(outAttrs);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
//        if (ev.getAction()==2){
//            Log.d(TAG, "dispatchTouchEvent: 不让长按");
//            return true;
//        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        return super.onTouchEvent(event);
    }
}
