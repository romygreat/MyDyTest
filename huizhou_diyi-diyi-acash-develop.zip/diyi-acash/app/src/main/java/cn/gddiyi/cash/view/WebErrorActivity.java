package cn.gddiyi.cash.view;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import cn.gddiyi.cash.YidiApplication;
import cn.gddiyi.cash.constant.VSConstances;
import cn.gddiyi.cash.jsinterface.JavaScriptinterface;
import cn.gddiyi.cash.model.dto.RequestJsonSn;
import cn.gddiyi.cash.presenter.CrossWalkPresenter;
import cn.gddiyi.cash.presenter.RetrofitPresenter;
import cn.gddiyi.cash.presenter.WifiAutoConnectPresenter;
import cn.gddiyi.cash.utils.LogUtil;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * 该类是在无网络的时候进入的界面
 * 首次安装，由于没有网络，也会进来该页面，之后执行isFirstInstall方法进入wifi设置界面
 * 实际运行时看起来不会进来这个PingFailActivity
 */
public class WebErrorActivity extends BaseActivity implements
        BaseActivity.CallBackPingService, View.OnClickListener {
    public static final int handlePing = 1;
    public static final int handleConnect = 2;
    public static final int handleFinishThis = 3;
    private static final int handleFinishCrossWalk = 5;
    boolean isPing = false;
    WifiManager mWifiManager;
    WifiAutoConnectPresenter wac;
    SharedPreferences mSharedPreferences;
    String SSID = null;
    String paasWord;
    String TAG = getClass().getSimpleName();
    static final int handleDeLay2s = 4;
    ImageView left_choiceWifiImg;
    ImageView right_reconnectImg;
    int toalPing = 5;
    int currentPingCount = 0;
    TextView errorTv;
    Toast toast, onClickToast;
    //默认标志自动连接
    boolean autoConnect = false;

    int errorInfo;

    @Override
    protected void onResume() {
        super.onResume();
        LogUtil.d("pingFailActivity onResume");
        isPing = true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: 2019/6/20 目前发现平板可能出现的一个小概率问题，及进入wifi界面可能进来该Activity
        // 去掉setWify = true;
        setWify = true;
        mWifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        //提前打开wifi
        mWifiManager.setWifiEnabled(true);
        setContentView(cn.gddiyi.cash.cashier.R.layout.fragment_nonetwork);
        initView();
        setmCallBackPing(this);
        Intent intent = getIntent();
        errorInfo = intent.getIntExtra(getString(cn.gddiyi.cash.cashier.R.string.errorInfo), 0);
        wac = new WifiAutoConnectPresenter(mWifiManager);
        //检查是否首次安装，首次安装将进入wifi页面
        checkIsFirstInstall();
        //该页面不放广告，在CrossWalk的onResume中设置为true,实际在进入主界面前重新设置为true
        ((YidiApplication) getApplication()).setPlayAd(false);
        //异步信息传递，这里主要用来消息的延迟
        //wac.mWebViewHandler，出现内存泄漏，导致会跳转到pingFailActivity
        wac.mHandler = new Handler(getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case handlePing:
                        //自动连接会进入该代码，自动连接的次数为totalPing次
                        currentActivity();
                        if (currentPingCount <= toalPing) {
                            handleMyPing();
                        }
                        break;
                    case handleConnect:
                        //重新连接wifi
                        connectWifi();
                        break;
                    case VSConstances.CONNECTED_SUCEESS:
                        Log.i(TAG, "handleMessage: VSConstances.CONNECTED_SUCEESS");
                        if (ping("wifi连接成功")) {
                            Log.i(TAG, "handleMessage:wifi连接成功 ");
                            sendEmptyMessageDelayed(handleDeLay2s, 0);
                        } else {
                            //在线的时候断网了，继续ping
                            //netError,并不会去跳转
                            Log.i(TAG, "pingFail else");
                            sendEmptyMessageDelayed(handlePing, 6000);
                        }
                        //由被坑的break,代码被漏掉了
                        break;
                    case handleFinishThis:
                        WebErrorActivity.this.finish();
                        break;
                    default:
                        break;
                }

            }
        };

        //自动连接启动0.5s后开始尝试
        errorTv.setText("无法连接服务器，代码"+errorInfo);
        currentActivity();
        Log.d(TAG, "onCreate: ");

    }

    /**
     * 将数据保存的wifi与密码取出来
     */
    private void checkIsFirstInstall() {
        //首次密码获取？
        mSharedPreferences = getSharedPreferences(getString(cn.gddiyi.cash.cashier.R.string.diyi), Context.MODE_PRIVATE);
        paasWord = mSharedPreferences.getString(getString(cn.gddiyi.cash.cashier.R.string.password), "nulll");
        SSID = mSharedPreferences.getString(getString(cn.gddiyi.cash.cashier.R.string.SSID1), "nulll");
        Log.i(TAG, "checkIsFirstInstall: ssid=" + SSID + "password=" + paasWord);
        isFirstInstall();
    }

    /**
     * 判断是否首次安装的应用，就是通过判断是否有设置过保存到wifi的密码，
     * 如果是首次安装，释放主界面
     */
    private void isFirstInstall() {
        Log.d(TAG, "isFirstInstall: ");
        if ("nulll".equals(SSID) || "nulll".equals(paasWord)) {
            Intent intent = new Intent(this, FirstBootActivity.class);
            intent.putExtra("netWork", "setWifi");
            ((YidiApplication) getApplication()).setWifiPage(true);
            ((YidiApplication) getApplication()).setNoNetwork(false);
            //注意顺序，有可能出现bug
            Log.d(TAG, "isFirstInstall: "+SSID);
            startActivity(intent);
            if (CrossWalkActivity.mThis != null) {
                Log.i(TAG, "onCreate: CrossWalkActivity.mThis.finish()");
            }
            //退出该应用,此时退出Activity,否则一直判断网络检查
            Log.d(TAG, "isFirstInstall:yes ");
            //在这里finish不应该
//            this.finish();
        }
    }

    private void initView() {
        left_choiceWifiImg = findViewById(cn.gddiyi.cash.cashier.R.id.left_choiceWifi);
        right_reconnectImg = findViewById(cn.gddiyi.cash.cashier.R.id.right_reconnect);
        errorTv=findViewById(cn.gddiyi.cash.cashier.R.id.failTips);
        left_choiceWifiImg.setOnClickListener(this);
        right_reconnectImg.setOnClickListener(this);

    }

    private void handleMyPing() {
        boolean b = ping("handleMyPing Method");
        if (toast != null) {
            toast.cancel();
        }
        currentPingCount++;
        if (!b) {
            //wifi已经连接，但是网络断了的情况
            if (!isNetworkAvailable()) {
                //连接成功后，异步消息发送到VSConstances.CONNECTED_SUCEESS，如果为false，继续ping
                wac.mHandler.sendEmptyMessage(handleConnect);
                toast = Toast.makeText(this, "wifi没连接,请选择wifi连接", Toast.LENGTH_LONG);
                if (!autoConnect) {
                    toast.show();
                }
            } else {
                toast = Toast.makeText(this, "无法连接外网,正在尝试重新连接", Toast.LENGTH_LONG);
                isNetOuterAvailable("无法连接外网");
                if (!autoConnect) {
                    toast.show();
                }
                wac.mHandler.sendEmptyMessageDelayed(handlePing, 6000);
            }
        } else {
            //网络已经连接的情况,也要注意先后顺序
            if (!autoConnect) {
                Toast.makeText(this, "重新连接", Toast.LENGTH_SHORT).show();
            }
            goCrossWalkActivity("else handleMyPing");
        }
    }

    //进入点餐界面
    private void goCrossWalkActivity(String str) {
        isPing = false;
        Log.d(TAG, "goCrossWalkActivity: "+str);
        if (CrossWalkActivity.mThis!=null){
            CrossWalkActivity.mThis.finish();
        }
        ((YidiApplication)getApplicationContext()).setPlayAd(true);
        ((YidiApplication)getApplicationContext()).setWifiPage(false);
        ((YidiApplication)getApplicationContext()).setNoNetwork(true);
        ((YidiApplication)getApplicationContext()).setClickChoiceWifi(false);
        Intent intent = new Intent(this, CrossWalkActivity.class);
        startActivity(intent);
        //可以重新播放广告

    }


    public static void restartAPP(Context context) {
        Intent intent = new Intent(context, CrossWalkActivity.class);
        @SuppressLint("WrongConstant") PendingIntent
                restartIntent = PendingIntent.getActivity(context, 0, intent,
                Intent.FLAG_ACTIVITY_NEW_TASK);
        AlarmManager mgr = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        assert mgr != null;
        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 50,
                restartIntent);
        // 1秒钟后重启应用
        android.os.Process.killProcess(android.os.Process.myPid());
//        System.exit(1);
    }

    private void connectWifi() {
        //这里可以去掉这个判断，在onCreate方法中做了判断
        if (!"nulll".equals(SSID)) {
            //将结果自动发送到handler CONNECTED_SUCEESS中
            {
                Log.d(TAG, "connectWifi: SSID="+SSID);
                Log.d(TAG, "connectWifi: paasWord="+paasWord);
                wac.connect(SSID, paasWord, WifiAutoConnectPresenter.WifiCipherType.WIFICIPHER_WPA);
            }
        } else {
            //然后接着handleping
            currentPingCount++;
            if (currentPingCount <= toalPing) {
                wac.mHandler.sendEmptyMessageDelayed(handlePing, 5000);
            } else {//不再ping
                removeHandleMessage();
            }
        }
    }


    @Override
    public void onBackPressed() {

    }

    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.PINGFAIL_ACTIVITY);
    }

    @Override
    public void onClick(View v) {
        removeHandleMessage();
        if (v.getId() == cn.gddiyi.cash.cashier.R.id.left_choiceWifi) {
            //进入WiFi连接
            currentPingCount = 6;
            ((YidiApplication) getApplication()).setWifiPage(true);
            ((YidiApplication) getApplication()).setClickChoiceWifi(true);
            removeHandleMessage();
            CrossWalkPresenter mCrossWalkPresenter = new CrossWalkPresenter(this);
            mCrossWalkPresenter.resetSSID(this);
            mCrossWalkPresenter.removewifiBySsid(this);
            Intent intent = new Intent(this, FirstBootActivity.class);
            //设置wifi传递给firstBootActivity,键同样也是noNetWork，但是值为setWifi,有点别扭
            intent.putExtra("netWork", "setWifi");
            ((YidiApplication) getApplication()).setWifiPage(true);
            ((YidiApplication) getApplication()).setNoNetwork(false);
            mCrossWalkPresenter.checkToast(toast);
            startActivity(intent);
            this.finish();
        } else if (v.getId() == cn.gddiyi.cash.cashier.R.id.right_reconnect) {
            autoConnect = false;
            currentPingCount = 0;
            //尝试重新连接
            wac.mHandler.sendEmptyMessageDelayed(handlePing, 50);
            if (!autoConnect) {
                onClickToast = Toast.makeText(this, "正在为您尝试重新连接", Toast.LENGTH_SHORT);
                onClickToast.show();
            }

            Log.d(TAG, "onClick: ");

        }

    }

    public void removeHandleMessage() {
        if (wac.mHandler.hasMessages(handlePing)) {
            wac.mHandler.removeMessages(handlePing);
        }
        if (wac.mHandler.hasMessages(handleConnect)) {
            wac.mHandler.removeMessages(handleConnect);
        }
    }

    @Override
    public int pingSuccess(String code) {
        return 0;
    }

    @Override
    public int pingFail(String code) {
        return 0;
    }

    @Override
    public int pingException(String code) {
        return 0;
    }

    @Override
    boolean isNetOuterAvailable(final String code) {
        mPrensenter = new RetrofitPresenter();
        //response sn,当SN出问题，容易出现问题
        mPrensenter.setCallBackResponsebody(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> r) {
                //服务器问题出现空指针
                ((YidiApplication) getApplication()).setNoNetwork(false);
                ((YidiApplication) getApplication()).setOutNetWorkAvailable(true);
                Log.d(TAG, "onResponse: 外网连接正常");
//                goCrossWalkActivity("isNetOuterAvailable");
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                //设置网络是否成功
                ((YidiApplication) getApplication()).setNoNetwork(true);
                ((YidiApplication) getApplication()).setOutNetWorkAvailable(false);

            }
        });
        RequestJsonSn requestJsonSn = new RequestJsonSn();
        //这里的序列号出现了问题，导致容易掉线
        requestJsonSn.setSn(JavaScriptinterface.getSerialNumber());
        String urlSN = VSConstances.URL_SN;
        mPrensenter.retrofitPostSn(urlSN, mPrensenter.postJsonString(requestJsonSn));
        return true;
    }

    @Override
    protected void onDestroy() {
        //解决首次加载去网络后出现跳转到PingFailActvity问题,不然导致内存泄漏
        if (wac.mHandler!=null
//                &&wac.mWebViewHandler.hasMessages(handlePing)
                ){
                wac.mHandler.removeCallbacksAndMessages(null);
            }
        super.onDestroy();

    }
}


