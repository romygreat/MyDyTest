package cn.gddiyi.cash.view;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;


import cn.gddiyi.cash.YidiApplication;
import cn.gddiyi.cash.constant.VSConstances;
import cn.gddiyi.cash.controler.MyThreadPool;

public class InitActivity extends BaseActivity implements BaseActivity.CallBackPingService {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(cn.gddiyi.cash.cashier.R.layout.initlayout);
        initPermission();
        if (PackageManager.PERMISSION_GRANTED ==
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_NETWORK_STATE)) {
            setmCallBackPing(this);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        MyThreadPool.startThread(new Runnable() {
            @Override
            public void run() {
                ping("Init");
            }
        });
    }

    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.INIT_ACTIVITY);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        MyThreadPool.startThread(new Runnable() {
            @Override
            public void run() {
                ping("Init");
            }
        });
    }

    @Override
    public int pingSuccess(String code) {
        Intent intent = new Intent(this, CrossWalkActivity.class);
        startActivity(intent);
        this.finish();
        return 0;
    }

    @Override
    public int pingFail(String code) {
        Intent intent = new Intent(this, PingFailActivity.class);
        intent.putExtra(getString(cn.gddiyi.cash.cashier.R.string.LOG),"InitActivity");
        startActivity(intent);
        this.finish();
        return 0;
    }

    @Override
    public int pingException(String code) {
        return 0;
    }
}
