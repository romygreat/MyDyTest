package cn.gddiyi.cash.model.dto;

public class RequestTableList {

    /**
     * token : 01d6037a7e3fe94128dc2966150919bb
     * machine : machine
     * sort : {"sort":"desc"}
     */

    private String token;
    private String machine;
    private SortBean sort;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getMachine() {
        return machine;
    }

    public void setMachine(String machine) {
        this.machine = machine;
    }

    public SortBean getSort() {
        return sort;
    }

    public void setSort(SortBean sort) {
        this.sort = sort;
    }

    @Override
    public String toString() {
        return "RequestTableList{" +
                "token='" + token + '\'' +
                ", machine='" + machine + '\'' +
                ", sort=" + sort +
                '}';
    }

    public static class SortBean {
        /**
         * sort : desc
         */

        private String sort;

        public String getSort() {
            return sort;
        }

        public void setSort(String sort) {
            this.sort = sort;
        }
    }
}
