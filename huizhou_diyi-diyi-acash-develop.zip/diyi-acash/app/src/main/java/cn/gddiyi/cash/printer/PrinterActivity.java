package cn.gddiyi.cash.printer;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.WindowManager;

import cn.gddiyi.cash.YidiApplication;
import cn.gddiyi.cash.constant.VSConstances;
import cn.gddiyi.cash.printer.vendor.jiabo.DeviceConnFactoryManager;
import cn.gddiyi.cash.view.BaseActivity;

public  class PrinterActivity extends BaseActivity {
    public static final String TAG="PrinterActivity";
    Handler printerActivityHandler=new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(Message msg) {
            if (!isNetworkAvailable()){
                startPingFailActivity("dispatch");
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        super.onCreate(savedInstanceState);

    }
    public String getConnDeviceInfo(int id) {
        String str = "";
        DeviceConnFactoryManager deviceConnFactoryManager = DeviceConnFactoryManager.getDeviceConnFactoryManagers()[id];
        if (deviceConnFactoryManager != null
                && deviceConnFactoryManager.getConnState(id)) {
            str += "WIFI\n";
            str += "IP: " + deviceConnFactoryManager.getIp(id) + "\t";
            str += "Port: " + deviceConnFactoryManager.getPort();

        }
        return (str);
    }
    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.PRINTER_ACTIVITY);
    }

    public void startPingFailActivity(final String code) {
        //注意修改wifiFragment与pingFailActivity中的CrossWalkActivity改为本printer中的MainActivity
        ((YidiApplication) getApplication()).setPlayAd(false);
        int currentActivity = ((YidiApplication) getApplication()).getCurrentActivityPage();
            startPingFailBaseActivity(code);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if ( MotionEvent.ACTION_DOWN==ev.getAction()){
            Log.d(TAG, "dispatchTouchEvent: ");
            removeIfHasHandleMessage(0);
            printerActivityHandler.sendEmptyMessageDelayed(0,4000);
        }
        return super.dispatchTouchEvent(ev);
    }

    private void removeIfHasHandleMessage(int what) {
        if (printerActivityHandler != null && printerActivityHandler.hasMessages(what)) {
            printerActivityHandler.removeMessages(what);
        }
    }
//    public void initPermission() {
//        String permissions[] = {
////                Manifest.permission.RECORD_AUDIO,
//                Manifest.permission.READ_PHONE_STATE,
//                Manifest.permission.WRITE_EXTERNAL_STORAGE,
//                Manifest.permission.ACCESS_COARSE_LOCATION,
//                Manifest.permission.ACCESS_FINE_LOCATION,
//                Manifest.permission.ACCESS_WIFI_STATE,
//                Manifest.permission.READ_EXTERNAL_STORAGE,
//                Manifest.permission.WRITE_EXTERNAL_STORAGE
//
//        };
//        ArrayList<String> toApplyList = new ArrayList<String>();
//        for (String perm : permissions) {
//            if (PackageManager.PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this, perm)) {
//                toApplyList.add(perm);
//                // 进入到这里代表没有权限;
//            }
//        }
//        String tmpList[] = new String[toApplyList.size()];
//        if (!toApplyList.isEmpty()) {
//            ActivityCompat.requestPermissions(this, toApplyList.toArray(tmpList), REQUEST_PERCODE);
//        }
//    }
}
