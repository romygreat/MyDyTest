package cn.gddiyi.cash.customview.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.StyleRes;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;


import cn.gddiyi.cash.customview.ConfirmImagegeView;
import cn.gddiyi.cash.presenter.UpgradePresenter;
import lombok.Getter;
import lombok.Setter;

public class UpdateDialog extends Dialog implements View.OnClickListener {
    String TAG = getClass().getSimpleName();
    private Context mContext;
    private ConfirmImagegeView cancel_button;
    public TextView updateTvTips;

    private ConfirmImagegeView cofirm_button;
    @Setter
    @Getter
    UpgradePresenter upgradePresenter;
    @Setter
    @Getter
    CallBack callBack;
    String updateInfo;
    boolean isUpdate=true;

    public UpdateDialog(@NonNull Context context, @StyleRes int themeResId ,boolean isUpdate) {
        super(context, themeResId);
        mContext = context;
        this.isUpdate=isUpdate;
    }
    public UpdateDialog(@NonNull Context context, @StyleRes int themeResId,String updateString,boolean isUpdate ) {
        super(context, themeResId);
        mContext = context;
        updateInfo= updateString;
        this.isUpdate=isUpdate;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (isUpdate){
        View view = LayoutInflater.from(mContext).inflate(cn.gddiyi.cash.cashier.R.layout.updatedialog, null);
        setContentView(view);
        initView(view);}
        else{
            View view = LayoutInflater.from(mContext).inflate(cn.gddiyi.cash.cashier.R.layout.notupdatelayout, null);
            setContentView(view);
        }

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case cn.gddiyi.cash.cashier.R.id.cofirm_button:
                if (callBack != null) {
                    callBack.onClickUpdate(this);
                }
                break;
            case cn.gddiyi.cash.cashier.R.id.cancel_button:
                this.dismiss();
                break;
            default:
                break;
        }
    }

    private void initView(View view) {
        cofirm_button = findViewById(cn.gddiyi.cash.cashier.R.id.cofirm_button);
        cancel_button = findViewById(cn.gddiyi.cash.cashier.R.id.cancel_button);
        updateTvTips=findViewById(cn.gddiyi.cash.cashier.R.id.updateTips);

        cancel_button.setOnClickListener(this);
        cofirm_button.setOnClickListener(this);

        if (updateInfo!=null){
            updateTvTips.setText(updateInfo);
        }
    }
    public void  setText(final String text){
        updateTvTips.post(new Runnable() {
            @Override
            public void run() {
                updateTvTips.setText(text);
            }
        });

    }
   public interface CallBack{
       void onClickUpdate(UpdateDialog updateDialog);
    }
}
