package cn.gddiyi.cash.service;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import com.baidu.speech.EventListener;
import com.baidu.speech.EventManager;
import com.baidu.speech.EventManagerFactory;
import com.baidu.speech.asr.SpeechConstant;
import com.baidu.tts.client.SpeechError;
import com.baidu.tts.client.SpeechSynthesizerListener;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

import cn.gddiyi.cash.YidiApplication;
import cn.gddiyi.cash.controler.MyThreadPool;
import cn.gddiyi.cash.controler.VoiceInterface;
import cn.gddiyi.cash.model.dto.ResponseReg;
import cn.gddiyi.cash.presenter.SpeechSynthesisPresenter;
import cn.gddiyi.cash.presenter.VoiceCrossWalkPresenter;
import cn.gddiyi.cash.view.QrCodeActivity;
import lombok.Getter;
import lombok.Setter;

public class WakeUpService extends Service implements EventListener, SpeechSynthesizerListener {
    private static final int HANDLE_CHECK_NETWORK = 0;
    String TAG = getClass().getSimpleName();
    Handler mHandler;

    @Setter
    @Getter
    VoiceInterface mVoiceInterFace;
    public static SpeechSynthesisPresenter mSpeechSynthesisPresenter;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mHandler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case HANDLE_CHECK_NETWORK:
                        boolean currentNetWork = ((YidiApplication) getApplication()).getNoNetwork();
                        if (!currentNetWork) {
                            Log.i(TAG, "handleMessage:检查网络正常，注册语音");
                            if (mSpeechSynthesisPresenter == null) {
                                mSpeechSynthesisPresenter = new SpeechSynthesisPresenter(getApplicationContext());
                                mSpeechSynthesisPresenter.setSpeechSynthesizerListener(WakeUpService.this);
                            }
                        } else {
                            sendEmptyMessageDelayed(HANDLE_CHECK_NETWORK, 5000);
                        }
                        break;
                    default:
                        break;
                }

            }
        };

        mSpeechSynthesisPresenter = new SpeechSynthesisPresenter(getApplicationContext());
        mSpeechSynthesisPresenter.setSpeechSynthesizerListener(WakeUpService.this);
    }

    @Override
    public void onEvent(String name, String params, byte[] data, int i, int i1) {

    }


    BufferedOutputStream   ttsFileBufferedOutputStream;
    @Override
    public void onSynthesizeStart(String s) {
        String filename =   "a003.pcm";
        File  ttsFile = new File("/sdcard", filename);
        Log.i(TAG, "try to write audio file to " + ttsFile.getAbsolutePath());
        try {
            if (ttsFile.exists()) {
                ttsFile.delete();
            }
            ttsFile.createNewFile();
            // 创建FileOutputStream对象
            FileOutputStream ttsFileOutputStream = new FileOutputStream(ttsFile);
            // 创建BufferedOutputStream对象
             ttsFileBufferedOutputStream = new BufferedOutputStream(ttsFileOutputStream);
        } catch (IOException e) {
            // 请自行做错误处理
            e.printStackTrace();

            throw new RuntimeException(e);
        }

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        //这一参数很重要，当该服务被系统kill掉后，需要重新拉起服务
        return START_STICKY;
    }

    @Override
    public void onSynthesizeDataArrived(String s, byte[] bytes, int i) {
        Log.d(TAG, "onSynthesizeDataArrived: ");
        try {
            ttsFileBufferedOutputStream.write(bytes);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onSynthesizeFinish(String s) {

    }

    @Override
    public void onSpeechStart(String s) {

    }

    @Override
    public void onSpeechProgressChanged(String s, int i) {

    }

    @Override
    public void onSpeechFinish(String s) {
        Log.i(TAG, "onSpeechFinish: " + s);


    }

    @Override
    public void onError(String s, SpeechError speechError) {

    }
}
