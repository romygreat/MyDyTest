package cn.gddiyi.cash.presenter;



import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import cn.gddiyi.cash.constant.VSConstances;
import cn.gddiyi.cash.model.PlayData;
import cn.gddiyi.cash.model.VideoPlayAll;
import cn.gddiyi.cash.model.dto.ResponseJsonVideo;

import static cn.gddiyi.cash.model.VideoPlayAll.getInstance;


/**
 * @author romy
 * @time 2018/1/12
 * 保存与操作下载网络视频的类
 */
public class VideoPresenter {

    int count;
    String doMain;
    String path;
    String videoName;
    final String TAG = "VideoPresenter";
    //该类很重要，通过该类的访问得到视频路径，本地路径等信息
    VideoPlayAll<PlayData> sparseArray;

    public void setDownloadVideReady(DownloadVideoReady downloadVideReady) {
        this.downloadVideReady = downloadVideReady;
    }

    DownloadVideoReady downloadVideReady;

    public void setDoMain(String doMain) {
        this.doMain = doMain;
    }

    public String getDoMain() {
        return doMain;
    }

    public VideoPresenter() {

    }

    //将在请求视频回来的数据保存到VideoPlayAll类中，方便管理
    public VideoPlayAll<PlayData> saveVideoPrsenter(ResponseJsonVideo.DataBean dataBeans) {
        saveVideoName(dataBeans);
        if (downloadVideReady != null) {
            downloadVideReady.noticefyDownLoadReady(sparseArray);
        }
        return sparseArray;
    }

    public void saveVideoName(ResponseJsonVideo.DataBean dataBeans) {
        count = dataBeans.getCount();
        List<ResponseJsonVideo.DataBean.ListBean> listBean = dataBeans.getList();
        sparseArray = getInstance();
        sparseArray.setCount(count);
        for (int i = 0; i < dataBeans.getCount(); i++) {
            String netPath;
            path = listBean.get(i).getPath();
            netPath = "http://" + getDoMain() + "/" + path;
            //去掉前缀ad/
            videoName = path.substring(3);
            PlayData playData = new PlayData(videoName, netPath);
            playData.setLocalPath(videoName);
            sparseArray.getSaveData().put(i, playData);
        }
    }

    //通知可以正式下载视频接口
    public interface DownloadVideoReady {
        void noticefyDownLoadReady(VideoPlayAll<PlayData> sparseArray);

        void noticefyUpdate(VideoPlayAll<PlayData> sparseArray, ArrayList list);
    }


    //以json的形式写入本地文件，并没有使用数据库存储方式
    synchronized public JsonObject save2LocalFile(VideoPlayAll<PlayData> sparseArray) {
        JsonObject jsonObject = new JsonObject();
        JsonArray jsonArrayLocalPath = new JsonArray();
        JsonArray jsonArrayNetPath = new JsonArray();

        for (int i = 0; i < sparseArray.getCount(); i++) {
            jsonArrayLocalPath.add(sparseArray.get(i).getLocalPath());
            jsonArrayNetPath.add(sparseArray.get(i).getNetVideoPath());
        }
        jsonObject.add("localPath", jsonArrayLocalPath);
        jsonObject.add("netPath", jsonArrayNetPath);

        //创建本地json文件
        FileIoPrensenter fileIoPrensenter = new FileIoPrensenter();
        fileIoPrensenter.writeFile(VSConstances.JSONFILEPATH, jsonObject.toString());

        return jsonObject;
    }

    //读取本地文件
    synchronized public String readJsonFile(int code) {
        FileIoPrensenter fileIoPrensenter = new FileIoPrensenter();
        String stringjson = fileIoPrensenter.ReadFile(VSConstances.JSONFILEPATH);
        return stringjson;
    }

    //是否更新检查，如果有同时通知更新
    public boolean checkUpdate() {
        String localName = readJsonFile(0);
        String[] tmpPathName = null;
        org.json.JSONObject jsonObject1 = null;
        String[] notsavePathAName = null;
        try {
            jsonObject1 = new JSONObject(localName);
            org.json.JSONArray localPathArray1 = (org.json.JSONArray) jsonObject1.get(VSConstances.LOCALPATH);
            tmpPathName = new String[localPathArray1.length()];

            notsavePathAName = sparseArray.getAllLocalVideoPath();
            tmpPathName = new String[localPathArray1.length()];
            for (int i = 0; i < localPathArray1.length(); i++) {
                tmpPathName[i] = (String) localPathArray1.get(i);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        boolean isCheckUpdate = Arrays.equals(tmpPathName, notsavePathAName);

        {
            try {
                ArrayList<Integer> arrayList = new ArrayList<>();
                String[] fileNames = getALlSDadVideoNames();
                for (int i = 0; i < notsavePathAName.length; i++) {
                    boolean isNeedtoUPdate = true;
                    for (int j = 0; j < fileNames.length; j++) {
                        if (notsavePathAName[i].equals(fileNames[j])) {
                            isNeedtoUPdate = false;
                        }
                    }
                    if (isNeedtoUPdate) {
                        arrayList.add(i);
                    }
                }
                downloadVideReady.noticefyUpdate(sparseArray, arrayList);
            } catch (Exception e) {
                save2LocalFile(sparseArray);
            }
        }
        return isCheckUpdate;
    }

    public String[] getALlSDadVideoNames() {
        File fileDir = new File(VSConstances.SDdir);
        String[] fileNames = null;
        if (fileDir.exists() && fileDir.isDirectory()) {
            File[] files = fileDir.listFiles();
            fileNames = new String[files.length];
            for (int i = 0; i < files.length; i++) {
                fileNames[i] = files[i].getName();
            }
        }
        return fileNames;
    }

    synchronized public void deleteSDadVideo() {
        //删除文件，播放广告时不会去删除广告，避免广告播放中出现异常的退出，添加广告播放的标志
        String localName = readJsonFile(2);
        String[] tmpPathName = getALlSDadVideoNames();
        org.json.JSONObject jsonObject1 = null;
        try {
            jsonObject1 = new JSONObject(localName);
            org.json.JSONArray localjsonFile = (org.json.JSONArray) jsonObject1.get(VSConstances.LOCALPATH);
            for (int i = 0; i < tmpPathName.length; i++) {
                boolean isNeedDeleteVideo = true;
                for (int j = 0; j < localjsonFile.length(); j++) {
                    if (tmpPathName[i].equals(localjsonFile.get(j))) {
                        isNeedDeleteVideo = false;
                    }
                }
                if (isNeedDeleteVideo) {
                    String deleteVideoName = tmpPathName[i];
                    String fileName = "sdcard/ad/" + deleteVideoName;
                    File file = new File(fileName);
                    file.delete();

                }
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

}
