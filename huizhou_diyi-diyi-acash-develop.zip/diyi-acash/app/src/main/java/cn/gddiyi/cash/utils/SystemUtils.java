package cn.gddiyi.cash.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.util.Log;

public class SystemUtils {
    public static final String TAG="SystemUtils";
    public static String getRunningPackageName(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        //完整类名
        String runningActivity = activityManager.getRunningTasks(1).get(0).topActivity.getClassName();
        String contextActivity = runningActivity.substring(runningActivity.lastIndexOf(".") + 1);
        String packageName = runningActivity.substring(0,runningActivity.lastIndexOf("."));
        Log.d(TAG, "getRunningPackageName:packageName "+packageName);
        return runningActivity;
    }

}
