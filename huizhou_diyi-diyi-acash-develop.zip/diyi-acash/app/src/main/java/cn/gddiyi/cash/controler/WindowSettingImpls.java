package cn.gddiyi.cash.controler;

import android.app.Activity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import cn.gddiyi.cash.presenter.SoftKeyBoardListener;


public class WindowSettingImpls implements DiyiInterface.WindowSetting {
    @Override
    public void fullScreen(Activity context) {
        // 隐藏标题
        context.requestWindowFeature(Window.FEATURE_NO_TITLE);
        context.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    @Override
    public void setWindowListener(final Activity activity) {
        SoftKeyBoardListener.setListener(activity, new SoftKeyBoardListener.OnSoftKeyBoardChangeListener() {

            @Override
            public void keyBoardShow(int height) {
                hideBottomUIMenu(activity);
            }

            @Override
            public void keyBoardHide(int height) {
                hideBottomUIMenu(activity);
            }

        });
    }

    @Override
    public void hideNavigationBar(Activity context) {
        int uiFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION // hide nav bar
                | View.SYSTEM_UI_FLAG_FULLSCREEN; // hide status bar

        if (android.os.Build.VERSION.SDK_INT >= 19) {
            uiFlags |= View.SYSTEM_UI_FLAG_IMMERSIVE;
            //0x00001000; // SYSTEM_UI_FLAG_IMMERSIVE_STICKY: hide
        } else {
            uiFlags |= View.SYSTEM_UI_FLAG_LOW_PROFILE;
        }
        context.getWindow().getDecorView().setSystemUiVisibility(uiFlags);
    }

    /**
     * 除了在onCreate()方法中调用，
     * 也可在其它的任何地方进行调用不会报错
     */
    @Override
    public void hideBottomUIMenu(Activity activity) {
        //隐藏虚拟按键，并且全屏
        View decorView = activity.getWindow().getDecorView();
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        decorView.setSystemUiVisibility(uiOptions);
    }
}
