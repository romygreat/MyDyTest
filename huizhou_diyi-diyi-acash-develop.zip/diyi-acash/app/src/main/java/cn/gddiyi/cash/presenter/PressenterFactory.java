package cn.gddiyi.cash.presenter;

public class PressenterFactory {
    RetrofitPresenter mRetrofitPresenter;
    VideoPresenter mVideoPresenter;
    VoiceCrossWalkPresenter mVoiceCrossWalkPresenter;
    StartServicePresenter mStartServicePresenter;
    static PressenterFactory mPressenterFactory;

    private PressenterFactory() {
    }

    public RetrofitPresenter createRetrofitPresenter() {
        if (mRetrofitPresenter == null) {
            mRetrofitPresenter = new RetrofitPresenter();
        }
        return mRetrofitPresenter;
    }

    public StartServicePresenter createStartServicePresenter() {
        if (mStartServicePresenter == null) {
            mStartServicePresenter = new StartServicePresenter();
        }
        return mStartServicePresenter;
    }

    public VoiceCrossWalkPresenter createVoiceCrossWalkPresenter() {
        if (mVoiceCrossWalkPresenter == null) {
            mVoiceCrossWalkPresenter = VoiceCrossWalkPresenter.getInstance();
        }
        return mVoiceCrossWalkPresenter;
    }

    public VideoPresenter createVideoPresenter() {
        if (mVideoPresenter == null) {
            mVideoPresenter = new VideoPresenter();
        }
        return mVideoPresenter;
    }

    public static PressenterFactory getInstance() {
        if (mPressenterFactory == null) {
            mPressenterFactory = new PressenterFactory();
        }
        return mPressenterFactory;
    }
}
