package cn.gddiyi.cash.customview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Build;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import cn.gddiyi.cash.cashier.R;


public class ConfirmImagegeView extends android.support.v7.widget.AppCompatImageView {
    Context context;
    String text;
    int color;
    DisplayMetrics displayMetrics;
    float dp = 0;

    public ConfirmImagegeView(Context context) {
        this(context, null);
    }

    public ConfirmImagegeView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ConfirmImagegeView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;

        displayMetrics = getDisplayMetrics(context);
        dp=displayMetrics.density;

        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.ConfirmImagegeView);
        for (int i = 0; i < typedArray.getIndexCount(); i++) {
            //就是我们自定义的属性的资源id
            int attr = typedArray.getIndex(i);
            switch (attr) {
                case R.styleable.ConfirmImagegeView_text:
                    text = typedArray.getString(attr);
                    break;
                case R.styleable.ConfirmImagegeView_color:
                    color = typedArray.getColor(attr, Color.WHITE);
                default:
                    break;
            }
        }
        typedArray.recycle();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Rect rect = new Rect();
        Paint paint = new Paint();
        paint.setTextSize(getResources().getDimension(R.dimen.sp9));
        paint.setAntiAlias(true);
        paint.setDither(true);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.getTextBounds(text, 0, text.length(), rect);

        int width = getWidth();
        int height = getHeight();
        paint.setColor(color);
        canvas.drawText(text, width / 2 - rect.width() / 2, height / 2+rect.height()/3, paint);
        canvas.save();
    }

    public static DisplayMetrics getDisplayMetrics(Context context) {
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            windowManager.getDefaultDisplay().getRealMetrics(displayMetrics);
        } else {
            windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        }
        return displayMetrics;

    }

    public  Bitmap big(Bitmap b, float x, float y)
    {
        int w = b.getWidth();
        int h = b.getHeight();
        float sx = (float) x / w;
        //要强制转换，不转换我的在这总是死掉。
        float sy = (float) y / h;
        Matrix matrix = new Matrix();
        matrix.postScale(dp, dp);
        // 长和宽放大缩小的比例
        Bitmap resizeBmp = Bitmap.createBitmap(b, 0, 0, w,h, matrix, true);
        return resizeBmp;
    }

}
