package cn.gddiyi.cash.view;


import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.text.InputType;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;


import java.io.File;
import java.util.HashMap;

import javax.inject.Inject;

import cn.gddiyi.cash.YidiApplication;
import cn.gddiyi.cash.cashier.R;
import cn.gddiyi.cash.constant.VSConstances;
import cn.gddiyi.cash.controler.DiyiInterface;
import cn.gddiyi.cash.controler.MyThreadPool;
import cn.gddiyi.cash.controler.VoiceInterface;
import cn.gddiyi.cash.customview.EnterAnimLayout;
import cn.gddiyi.cash.customview.MyWebView;

import cn.gddiyi.cash.dagger.DaggerPictrueAdComponent;
import cn.gddiyi.cash.jsinterface.JavaScriptinterface;
import cn.gddiyi.cash.model.dto.ResponseUpdateAppInfo;
import cn.gddiyi.cash.presenter.CrossWalkPresenter;
import cn.gddiyi.cash.presenter.PictrueAdPresenter;
import cn.gddiyi.cash.presenter.VoiceCrossWalkPresenter;
import cn.gddiyi.cash.service.WakeUpService;
import cn.gddiyi.cash.utils.AndroidBug5497Workaround;
import cn.gddiyi.cash.utils.LogUtil;



/**
 * @author romygreat
 * @date 2019-02-21
 * 这个是launcher界面，如果后台运行中,可能报错
 * 2019-08-27
 */
public class CrossWalkActivity extends BaseActivity implements View.OnTouchListener,
        JavaScriptinterface.NoticefyPay, View.OnLongClickListener,
        BaseActivity.CallBackPingService, DiyiInterface.NetWorkChangeListsener {
    public static final int ERR_INTERNET_DISCONNECTED = -2;
    public static final int HANDLE_CHECK_BLANK = 1112;
    private static final int HANDLE_CHECK_UPDATE_AD = 1113;


    public MyWebView mWebView;
    private static final int HANDLE_NET_TIMEOUT = 110;
    private static final int HANDLE_TIME_FRESH = 1111;
    static CrossWalkActivity mThis;
    final static String TAG = "CrossWalkActivity";
    JavaScriptinterface javaScriptinterface;
    Handler mHandler;
    int mCount = 0;
    LinearLayout linearLayout;
    ImageView imageView;
    Bundle outState1;
    WebSettings settings;
    TextView tipTextView;
    Toast toast;
    boolean wideNetWorkErr = false;
    boolean netWorkAvailable = true;
    private boolean hideWebViewAndLoadMainUrl = false;
    public static final int pingFailTimes = 2;
    int mCurpingFailTimes = 0;
    boolean isFirstPing = true;
    boolean isPlayAdNow = false;
    String picName = "index.html";
    File file;


    private boolean pingSucess = true;
    boolean noNetWorkShow = false;
    private boolean handleBlank = false;
    VoiceCrossWalkPresenter mVoiceCrossWalkPresenter;
    int loadURLTime = 0;
    CrossWalkPresenter mCrossWalkPresenter;

    boolean hasWakeUpedService = false;
    long failTime = 0;
    Toast netStableToast;
    int touchCount = 0;
    boolean picAdShow = true;
    boolean webViewShow = false;
    boolean loadFinish = true;
    long touchTime = 0;

    boolean errorReload = false;
    int checkOutNetFailCount = 0;
    boolean progressPercentageHundred = false;
    boolean mWebViewHasShowed = false;
    boolean onCreated = false;
    int netLostCount = 0;

    /**
     * onXWalkReady调用在onResume之后
     * webview初始化设置
     * 无网络时不可做耗时的操作
     */

    private static final int HANDLE_DELAY_15s = 150;
    ImageView picImageView;
    @Inject
    PictrueAdPresenter mPictrueAdPresenter;
    EnterAnimLayout enterAnimLayout;

    private int alwaylsTouchCount;
    private Toast netToast;
    private WifiManager mWifiManager;

    /**
     * onReusme后进入该函数
     * onXWalkReady是最为主要的函数之一
     */
    @Override
    protected void onXWalkReady() {
        if (mWebView != null) {
            //这段代码用于去掉复制功能
            mWebView.setLongClickable(false);
            mWebView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    return true;
                }
            });
            //先隐藏webview
            hideWebview("onXWalkReady");
            setWebSettings();
            mHandler = new Handler(getMainLooper()) {
                @Override
                public void handleMessage(Message msg) {
                    switch (msg.what) {
                        case CrossWalkPresenter.HANDLE_AD:
                            //广告播放时间的误差小于0.02秒
                            //设置加载是否超时,如果还是白屏，需要在三小时后设置刷新代码
                            if (!hasSdAds()) {
                                reStartTimer();
                                //尝试下载广告
                                startDownloadService();
                            } else {
                                picAdOnShow();
                            }

                            break;
                        case HANDLE_TIME_FRESH:
                            break;
                        case CrossWalkPresenter.HANDLE_SERVICE:
                            Log.d(TAG, "handleMessage:HANDLE_SERVICE ");
                            startDownloadService();
                            break;
                        case CrossWalkPresenter.HANDLE_INIT_TIMER:
                            break;
                        case CrossWalkPresenter.HANDLE_TIMER:
                            sendEmptyMessage(CrossWalkPresenter.HANDLE_AD);
                        case CrossWalkPresenter.HANDLE_TOAST:
                            mCrossWalkPresenter.checkToast(toast);
                            //隐藏底部虚拟按键
                            windowSettingImpls.hideBottomUIMenu(CrossWalkActivity.this);
                            break;
                        case CrossWalkPresenter.HANDLE_DELAY_2S:
                            if ((mWebView.getVisibility() == View.GONE)
                                    || (mWebView.getVisibility() == View.INVISIBLE)) {
                                mHandler.sendEmptyMessage(CrossWalkPresenter.HANDLE_LOAD_MAIN_URL);
                            }
                            break;
                        case CrossWalkPresenter.HANDLE_NO_NET_WORK_TIPS:
                            hanleNetWorkTip();
                            break;
                        case CrossWalkPresenter.HANDLE_TOUCH_PING:
                            //代码冗余，调试使用
                            isNetOuterAvailable("checkNetworkAvailable");
                            break;
                        case CrossWalkPresenter.HANDLE_SHOW_WEB_VIEW:
                            handleBlank = false;
                            showWebView();
                            break;
                        case CrossWalkPresenter.HANDLE_SUCCESS:
                            setAnimationBackgroud(file);
                            break;
                        case CrossWalkPresenter.HANDLE_DISS_ALERTDIALOG:
                            Log.i(TAG, "handleMessage:HANDLE_DISS_ALERTDIALOG: ");
                            //是否有wifi
                            if (!ping("HANDLE_DISS_ALERTDIALOG")) {
                                Log.i(TAG, "handleMessage:!ping ");
                                startPingFailActivity("HANDLE_DISS_ALERTDIALOG");
                            }
                            break;
                        case CrossWalkPresenter.HANDLE_ABOUT_BLANK:
                            //白屏再次加载url
                            Log.d(TAG, "handleMessage: mWebView.getTitle="+mWebView.getTitle());
                            if (xwalkWebviewReady && (mWebView != null)) {
                                if (mWebView.getTitle().equals(getString(cn.gddiyi.cash.cashier.R.string.filterurl))) {
                                    Log.d(TAG, "handleMessage: 处于白屏页面");
                                    handleBlank = true;
                                }else {
                                    Log.d(TAG, "handleMessage:getTitle= "+mWebView.getTitle());
                                    Log.d(TAG, "handleMessage:getUrl= "+mWebView.getUrl());
                                    if ((mWebView.getVisibility() == View.GONE)
                                            || (mWebView.getVisibility() == View.INVISIBLE)) {
                                        mWebView.setVisibility(View.VISIBLE);
                                        linearLayout.setVisibility(View.INVISIBLE);
                                    }
                                }
                                //白屏继续加载
                                if (handleBlank) {
                                    Toast.makeText(getApplicationContext(), "当前网速慢，请耐心等待", Toast.LENGTH_LONG).show();
                                    mWebView.loadUrl(VSConstances.MAIN_URL, requestHeader);
                                    startTimer();
                                }
                            }

                            break;
                        case HANDLE_CHECK_BLANK:
                            int currentActivityPage = ((YidiApplication) getApplication()).getCurrentActivityPage();
                            if (VSConstances.CROSSWALK_ACTIVITY == currentActivityPage) {
                                checkWhiteScreen("HANDLE_CHECK_BLANK");
                            }
                            break;
                        case HANDLE_DELAY_15s:
                            Log.d(TAG, "handleMessage: HANDLE_DELAY_15s");
                            if (mWebView != null) {
                                //检查白屏，如果白屏进行处理，通过检查内容判断白屏
                                checkWhiteScreen("from 15s  ad loop");
                            }
                            //避免不放广告
                            picAdOnShow();
                            break;
                        case HANDLE_NET_TIMEOUT:
                            handleTimeOut();
                            break;
                        case HANDLE_CHECK_UPDATE_AD:
                            LogUtil.d("HANDLE_CHECK_UPDATE_AD,Update Ad startDownLoadService ");
                            startDownloadService();
                            sendEmptyMessageDelayed(HANDLE_CHECK_UPDATE_AD, VSConstances.HALF_DAY);
                            break;
                        default:
                            break;
                    }
                }
            };
            if (!xwalkWebviewReady) {
                startTimer();

            }
            xwalkWebviewReady = true;
        }
        windowSettingImpls.setWindowListener(this);
        mThis = this;
        mWebView.loadUrl(VSConstances.MAIN_URL, requestHeader);
        //延期检查小猫跑动的可见性，超时仍然可见，需要重新加载,设置超时时间为15s
        checkStartedVisibility();
        loadURLTime = (int) System.currentTimeMillis();
        Log.d(TAG, "onXWalkReady: loadURLTime-beginTime=" + loadURLTime);
        mVoiceCrossWalkPresenter = mPressenterFactory.createVoiceCrossWalkPresenter();
        mVoiceCrossWalkPresenter.setMContext(this);
        mVoiceCrossWalkPresenter.setVoice2CrossWalkActivity(getMyOrderVoice());
        //半天更新一次广告
        mHandler.sendEmptyMessageDelayed(HANDLE_CHECK_UPDATE_AD, VSConstances.HALF_DAY);
        mWebView.setOnTouchListener(this);
        Log.d(TAG, "onXWalkReady:url== "+mWebView.getUrl());

    }

    boolean hadSdAds = false;

    /**
     * Sd卡上是否保存有广告
     *
     * @return
     */
    public boolean hasSdAds() {
        File files = new File(VSConstances.SDdir);
        //满足三个条件
        if (files.exists() && files.isDirectory() && (files.listFiles() != null) && (files.listFiles().length > 0)) {
            hadSdAds = true;
            return true;
        }
        Log.d(TAG, "hasSdAds: false");
        return false;
    }

    private void checkStartedVisibility() {
        long failReloadTime = 12_000;
        mWebView.postDelayed(new Runnable() {
            @Override
            public void run() {
                //返回结果在网络监听中checkStartedVisibility
                isNetOuterAvailable("checkStartedVisibility");
            }
        }, failReloadTime);
    }

    public void handleTimeOut() {
        isNetOuterAvailable("checkNetworkAvailable");
    }

    @NonNull
    private VoiceInterface.VoiceURL getMyOrderVoice() {
        return new VoiceInterface.VoiceURL() {
            @Override
            public void voiceOrder() {
                //呼叫点餐点餐，重新刷新URL
                mWebView.loadUrl(VSConstances.MAIN_URL, requestHeader);
            }

            @Override
            public void voiceAddDishes() {
                //语音带有更新应用
            }

            @Override
            public void voiceQrCharge() {
                Toast.makeText(getApplicationContext(), "无法打开扫码充电页面,23，谢谢", Toast.LENGTH_LONG).show();
            }

            @Override
            public void voiceTmpBillPay() {
                //账单接口，语音呼叫首先是小迪点餐，我要买单
                if (WakeUpService.mSpeechSynthesisPresenter != null) {
                    WakeUpService.mSpeechSynthesisPresenter.speak("好的，买单请扫我吧");
                }
                Log.d(TAG, "voiceTmpBillPay: ");
                payBillByVoice();
            }

            @Override
            public void voiceIntroFood() {

            }

        };
    }

    public void payBillByVoice() {
        picAdOnHide("payBillByVoice");
        Log.d(TAG, "payBillByVoice: ");
        mWebView.evaluateJavascript("javascript:payBillByVoice()", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                //value即为js返回值
                //注意网络丢失情况
                reStartTimer();
            }
        });
    }

    /**
     * 播放广告时进入该函数
     */
    public void picAdOnShow() {
        //当无网络切换后，此时已经播放着广告，可能首次闪过广告
        AndroidBug5497Workaround.setIsPlayAd(true);
        if (((YidiApplication) getApplication()).isPlayAd()) {
            picAdShow = true;
            isPlayAdNow = true;
            if (linearLayout.getVisibility() == View.VISIBLE) {
                loadFinish = false;
                linearLayout.setVisibility(View.INVISIBLE);
            }
            enterAnimLayout.setVisibility(View.VISIBLE);
            removeIfHasHandleMessage(HANDLE_DELAY_15s);
            mHandler.sendEmptyMessageDelayed(HANDLE_DELAY_15s, VSConstances.PIC_SHOW_NEXT);
            // TODO: 2019/10/28
            //currentAdFileCount=0;
            picAdLoad();
            mPictrueAdPresenter.setAnimation(enterAnimLayout);
            if (mWebView != null) {
                mWebView.setVisibility(View.INVISIBLE);
            }
        } else {
            //如果不播放广告，重新开始
            startTimer();
            if (mWebView != null) {
                if (mWebView.getVisibility() == View.VISIBLE) {
                    ((YidiApplication) getApplication()).setPlayAd(true);
                }
            }
        }
    }

    /**
     * 点击广告后返回，隐藏广告播放
     * 重新返回webView页面
     */
    public void picAdOnHide(String requestCode) {
        //添加不可见
        AndroidBug5497Workaround.setIsPlayAd(false);
        picAdShow = false;
        //外面去判断是否在播放广告的标志位，使用
        isPlayAdNow = false;
        removeIfHasHandleMessage(HANDLE_TIME_FRESH);
        removeIfHasHandleMessage(HANDLE_DELAY_15s);
        removeIfHasHandleMessage(CrossWalkPresenter.HANDLE_SUCCESS);
        enterAnimLayout.setVisibility(View.INVISIBLE);
        if (mWebView != null) {
            mWebView.setVisibility(View.VISIBLE);
            if (mWebView.getUrl() == null || mWebView.getTitle() == null) {
                mWebView.loadUrl(VSConstances.MAIN_URL, requestHeader);
            }
        } else {
            restartAPP(this);
        }
        //loadFinish在picAdOnShow中设置代码，根据判断小猫动画的可见性
        //小猫可见为加载未完成，重新加载
        if (!loadFinish) {
            mWebView.loadUrl(VSConstances.MAIN_URL, requestHeader);
        } else {
            Log.d(TAG, "picAdOnHide: " + requestCode);
            mHandler.sendEmptyMessageDelayed(HANDLE_CHECK_BLANK, 12_000);
        }
        //重新启动定时器，以播放广告
        reStartTimer();
        checkNetworkAvailable();
        currentAdFileCount = 0;

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "onRestart: ");
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        windowSettingImpls.hideBottomUIMenu(CrossWalkActivity.this);
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        //直接禁用输入法了
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM,
//                WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
        super.onCreate(savedInstanceState);
        mWifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        //先设置ping回调接口，否则网络ping网络可能导致不会回调
        requestHeader.put("Cache-Control", "max-age=86400");
        requestHeader.put("Progma", "max-age=3600");
        requestHeader.put("Connection", "keep-alive");
        requestHeader.put("meta", "charset=\"UTF-8\"");
        setmCallBackPing(this);
        //先请求权限设置
        if (!initPermission()) {
            onDestroy();
            this.finish();
        } else {
            initOnCreate();
        }
        Log.d(TAG, "onCreate: testDebug");
    }

    private void initOnCreate() {
        if (!isNetworkAvailable()) {
            startPurePingFailActivity();
            this.finish();
            return;
        } else {
            //不应该是这个函数调用
//            startPingService("onCreatePing");
            isNetOuterAvailable("onCreate");
            setContentView(cn.gddiyi.cash.cashier.R.layout.crosswalk);
            initView();
            //网络监听回调，通过checkOutNetAvailable
            setNetWorkChangeListsener(this);
            mWebView = findViewById(cn.gddiyi.cash.cashier.R.id.xwalkWebView);
            mBaseHandler.sendEmptyMessageDelayed(HANDLE_DOWNLOAD_SERVICE, VSConstances.TIME_UNIT_MIN / 2);
            //从activity中
            DaggerPictrueAdComponent.create().inject(this);
            //广告View不可见
            enterAnimLayout.setVisibility(View.INVISIBLE);

        }
    }

    private void startPurePingFailActivity() {
        startPingFailActivity("startPurePingFailActivity");
    }

    int currentAdFileCount = 0;

    private void picAdLoad() {
        Log.d(TAG, "picAdLoad: linearLayout.getVisibility()="+linearLayout.getVisibility());
        //走两个原因是可能网络原因导致的adFileNames为空
        enterAnimLayout.setVisibility(View.VISIBLE);
        if (VSConstances.adFileNames != null) {
            Log.d(TAG, "picAdLoad:adFileNames= " + VSConstances.adFileNames.length);
            if (currentAdFileCount >= VSConstances.adFileNames.length) {
                currentAdFileCount = 0;
            }
            if (this != null || (!this.isDestroyed())) {
                Log.d(TAG, "picAdLoad: "+this.isDestroyed());
                Glide.with(this)
                        .load(getAdFile(VSConstances.adFileNames[currentAdFileCount]))
                        .apply(new RequestOptions().diskCacheStrategy(DiskCacheStrategy.NONE))
                        .into(picImageView);
                Log.d(TAG, "picAdLoad: name="+getAdFile(VSConstances.adFileNames[currentAdFileCount]));
            }

            mPictrueAdPresenter.setAnimation(enterAnimLayout);
            if (currentAdFileCount != 0) {
                //广告背景
                setAnimationBackgroud(getAdFile(VSConstances.adFileNames[currentAdFileCount - 1]));
            } else {
                //首张图片显示的背景为最后一张
                setAnimationBackgroud(getAdFile(VSConstances.adFileNames[VSConstances.adFileNames.length - 1]));
                Log.d(TAG, "animationTestBg= " + VSConstances.adFileNames[VSConstances.adFileNames.length - 1]);
            }
            currentAdFileCount++;
        } else {
            //最开始手动加载图片
            startDownloadService();
            if (hasSdAds()) {
                picAdLoad3();
            } else {
                Log.d(TAG, "picAdLoad: no ad");
                picAdOnHide("no ad");
                removeIfHasHandleMessage(HANDLE_DELAY_15s);
            }
        }

    }

    private File getAdFile(String relativePath) {
        File adFile = new File("/sdcard/ad/" + relativePath);
        if (adFile.exists()) {
            return adFile;
        }
        return null;
    }

    /**
     * 该函数为广告加载的旧函数，当网络出现问题
     * 不能加载广告数据回来时执行此段代码
     */
    synchronized private void picAdLoad3() {
        file = mPictrueAdPresenter.ShowPicIndex();
        String currentAdName = file.getName();
        Log.d(TAG, "picAdLoad3: getName=" + currentAdName);
        if (file.exists()) {
            if (this != null || (!this.isDestroyed())) {
                Glide.with(this)
                        .load(file)
//                        .apply(new RequestOptions().diskCacheStrategy(DiskCacheStrategy.NONE))
                        .into(picImageView);
            }
            mPictrueAdPresenter.setAnimation(enterAnimLayout);
            // TODO: 2019/8/21
            mHandler.sendEmptyMessageDelayed(CrossWalkPresenter.HANDLE_SUCCESS, 6_000);
        }
    }

    String bgAdPath = "";

    private void setAnimationBackgroud(File file) {
        Log.d(TAG, "setAnimationBackgroud:file.exists= " + file.exists());
        if (file.exists()) {
            if (!picName.equals(file.getName())) {
                String myJpgPath = file.getAbsolutePath();
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 2;
                Bitmap bm = BitmapFactory.decodeFile(myJpgPath, options);
                BitmapDrawable bitmapDrawable = new BitmapDrawable(bm);
                enterAnimLayout.setBackground(bitmapDrawable);
                bgAdPath = file.getAbsolutePath();
                picName = file.getName();
            }
        }
    }

    private void setWebSettings() {
        //解决输入法的问题
        AndroidBug5497Workaround.assistActivity(this);
        settings = mCrossWalkPresenter.setWebViewSettings(mWebView);
        javaScriptinterface = new JavaScriptinterface(this);
        mWebView.addJavascriptInterface(javaScriptinterface, "android");
        mWebView.setWebChromeClient(getWebChromeClient());
        mWebView.setWebViewClient(getWebViewClient());
        //网络出现问题
        mWebView.getSettings().setBlockNetworkImage(false);
        //调试
        WebView.setWebContentsDebuggingEnabled(true);
    }


    private WebChromeClient getWebChromeClient() {
        WebChromeClient webChromeClient = new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d(TAG, "onConsoleMessage: " + consoleMessage.message());
                if (consoleMessage.message().contains("Error: Network Error") &&
                        (((YidiApplication) getApplication()).getCurrentActivityPage() == VSConstances.CROSSWALK_ACTIVITY)) {
                    if (netStableToast != null) {
                        netStableToast.cancel();
                        netStableToast = null;
                    }
                    netLostCount++;
                    if (netLostCount == 3) {
                        //再首页面中有效,在有网络的情况下错误的进入failActivity
                        netLostCount = 0;
                        //异步操作，检查网络失败了checkOutnetWork方法，并最后调用到failActivity,代替旧方法，避免直接进入了网络异常页面
                        //如果首次没设置密码，直接断网出现自动连接的bug
                        //这里应当上面弹出网络连接出现故障，应当去除网络的检查结果跳转到PingFailActivity
                        isNetOuterAvailable("consoleMessage");
                        return super.onConsoleMessage(consoleMessage);
                    }
                }
                // TODO: 2019/9/28  
//                if (consoleMessage.message() != null && consoleMessage.message().contains("undefined")) {
//                    undefinedErrorCome = true;
//                    checkWhiteScreen("from consoleMessage undefined");
//                }
                return super.onConsoleMessage(consoleMessage);

            }
        };
        return webChromeClient;
    }

    int errorCount = 0;
    Toast toast1;

    private WebViewClient getWebViewClient() {
        WebViewClient webViewClient = new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                mCrossWalkPresenter.setZoom(settings);
                Log.d(TAG, "onPageStarted: " + url);
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url.equals(getString(cn.gddiyi.cash.cashier.R.string.filterurl))) {
                    //重定向导致的白屏
                    handleBlank = true;
                    Log.d(TAG, "onPageFinished:filterurl= " + getString(cn.gddiyi.cash.cashier.R.string.filterurl));
                    mHandler.sendEmptyMessageDelayed(CrossWalkPresenter.HANDLE_ABOUT_BLANK, 6_500);
                    //直接返回？
                }
                else {
                    //白屏不调转，这里是否有问题？
                    super.onPageFinished(view, url);
                }
                //外网可以正常访问以及没有白屏，显示已加载的view
                Log.d(TAG, "onPageFinished: url="+url);
                if (!wideNetWorkErr) {
                    //没有错误，直接执行
                    Log.d(TAG, "onPageFinished: 2");
                    handleBlank = false;
//                    mWebView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
                    wideNetWorkErr = false;
                    if (!onCreated) {
                        onCreated = true;
                        checkFilterUrl(view);
                    }
                } else {
                    //出现了异常，判断是否需要因内容为空而重新刷新
                    if (VSConstances.CROSSWALK_ACTIVITY == getCurrentActivity()) {
                        Log.d(TAG, "onPageFinished: isPlayAdNow=" + isPlayAdNow);
                        //检查白屏与否
                        checkWhiteScreen("wideNetWorkErr");
                        wideNetWorkErr = false;
                    }
                }
                super.onPageFinished(view, url);
            }

            @TargetApi(Build.VERSION_CODES.M)
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                //每次掉网重新加载
                wideNetWorkErr = true;
                Log.d(TAG, "onReceivedError: getErrorCode=" + error.getErrorCode());
                Log.d(TAG, "onReceivedError: getDescription=" + error.getDescription());
                int currentActivityPage = ((YidiApplication) getApplication()).getCurrentActivityPage();
                Log.d(TAG, "onReceivedError:currentActivityPage= "+currentActivityPage);
                if (getString(R.string.NET_DISCONNECTED).equals(error.getDescription())) {
                    //网络走丢后的代码
                    Log.d(TAG, "onReceivedError: 网络走丢了");
                } else {
                    //出现一直刷新的bug
                    wideNetWorkErr = true;
                }
                if (VSConstances.CROSSWALK_ACTIVITY == currentActivityPage){
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        switch (error.getErrorCode()) {
                            //与unReachable相同
                            case ERR_INTERNET_DISCONNECTED:
                                errorReload = true;
                                if (toast1 != null) {
                                    toast1.cancel();
                                }
                                toast1 = Toast.makeText(CrossWalkActivity.this, "无法连接互联网", Toast.LENGTH_SHORT);
                                toast1.show();
                                errorCount++;
                                //在主页面可能会进入该程序
                                startPingFailActivity("网络异常");
                                break;
                            case VSConstances.ERR_CONNECTION_TIMED_OUT:
                                    Toast.makeText(CrossWalkActivity.this, "网页走丢了，建议重启平板", Toast.LENGTH_LONG).show();
                                    getDelayHtmlContent(1);
                                break;
                            case VSConstances.ERR_CONNECTION_ABORTED:
                                //net::ERR_CONNECTION_REFUSED
                                //ERR_CONNECTION_ABORTED 网络出现未知错误
                                getDelayHtmlContent(3);
                                Toast.makeText(CrossWalkActivity.this, "网页加载异常 ", Toast.LENGTH_LONG).show();
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        };
        return webViewClient;

    }

    private void checkFilterUrl(WebView view) {
        //需要比较长的时间才得到这个URL，导致白屏
        boolean filter = VSConstances.MAIN_URL.equals(view.getUrl()) ||
                (VSConstances.MAIN_URL + "init").equals(view.getUrl());
        Log.d(TAG, "onPageFinished: " + filter);
        if (filter) {
            {   mWebViewHasShowed = true;
                progressPercentageHundred = true;
                mHandler.sendEmptyMessageDelayed(CrossWalkPresenter.HANDLE_SHOW_WEB_VIEW, 0);
                mHandler.sendEmptyMessage(CrossWalkPresenter.HANDLE_TOAST);
            }
        }

    }

    private void getDelayHtmlContent(final int requestCode) {
        mWebView.postDelayed(new Runnable() {
            @Override
            public void run() {
                getHtmlContent(requestCode);
            }
        }, 5000);
    }

    private void startConsoleActivity(int a) {

        Intent intent = new Intent(CrossWalkActivity.this, WebErrorActivity.class);
        intent.putExtra(getString(cn.gddiyi.cash.cashier.R.string.errorInfo), a);
        startActivity(intent);
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.WEBERROR_ACTIVITY);
        //后面都是需要重启的
        this.finish();
    }

    private boolean showWebView() {
        //考虑重新加载,这个标志用于避免白屏，还没使用
        touchCount = 0;
        if (mWebView == null) {
            linearLayout.setVisibility(View.INVISIBLE);
            onXWalkReady();
        } else if ((mWebView.getVisibility() == View.GONE)
                || (mWebView.getVisibility() == View.INVISIBLE)) {
            mWebView.setVisibility(View.VISIBLE);
            //开始计时播放广告，新添加,是否需要？
            reStartTimer();
            webViewShow = true;
            //延迟1s多显示数据
            linearLayout.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Log.d(TAG, "run: 1800");
                    linearLayout.setVisibility(View.INVISIBLE);
                    isNetOuterAvailable("progressPercentageHundred");
                    if (mWebView.getTitle().equals("")) {
                        //没有加载到网页，导致的问题，开发需要屏蔽此段
                         startConsoleActivity(400);
                         Log.d(TAG, "run: getTitle=");
                    }else {
                        //注意遇到刚好加载的时间，应用重启的时候，出现同时刷新的概率很低，后期观察，情况
                       mHandler.sendEmptyMessageDelayed(HANDLE_CHECK_BLANK,15_000);
                       mHandler.sendEmptyMessageDelayed(CrossWalkPresenter.HANDLE_SERVICE,15_000);
                    }
                    Log.d(TAG, "run:testNetWork= " );
                }
                //延迟时间显示视图，正常显示，默认1200ms
            }, 1800);

            return true;
        }
        return false;
    }


    @Override
    public boolean onTouch(View v, MotionEvent event) {
        failTime = System.currentTimeMillis();
        BACKPRESS_TIME = 0;
        if (v.hasFocus()) {
            Log.d(TAG, "onTouch: hasfocus="+event.toString());

        }
        mCount++;
        noNetWorkShow = true;
        if (touch) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    //有按下动作时取消定时
                    callStartSetttingActivityMethod = 0;
                    touchTime = System.currentTimeMillis();
                    mCrossWalkPresenter.removeNoNetworkTips(mHandler);
                    removeIfHasHandleMessage(HANDLE_CHECK_BLANK);
                    stopTimer();
                    if (picAdShow) {
                        picAdOnHide("onTouch=" + event.getAction());
                        picAdShow = false;
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    //抬起时启动定时
                    touchTime = System.currentTimeMillis() - touchTime;
                    touchActionUp();
                    //触摸检查的白屏，性质还是不一样
                    mHandler.sendEmptyMessageDelayed(HANDLE_CHECK_BLANK, 20_000);
                    break;
                default:
                    break;
            }

        }
        return false;
    }

    private void removeIfHasHandleMessage(int what) {
        if (mHandler != null && mHandler.hasMessages(what)) {
            mHandler.removeMessages(what);
        }
    }

    public void checkNetworkAvailable() {
        //添加判断，原因偶现进入无网络检查界面，以避免
        if (callStartSetttingActivityMethod == 0) {
            if (mHandler != null) {
                removeIfHasHandleMessage(HANDLE_NET_TIMEOUT);
                if (!isNetworkAvailable()) {
                    mHandler.sendEmptyMessageDelayed(HANDLE_NET_TIMEOUT, 15_000);
                } else {
                    //异步操作，这里返回到netWrokChange函数中
                    mHandler.sendEmptyMessageDelayed(CrossWalkPresenter.HANDLE_TOUCH_PING, 20);
                }
            }
        }
    }

    public void touchActionUp() {
        checkNetworkAvailable();
        if (touchTime > 12_000) {
            alwaylsTouchCount++;
            if (alwaylsTouchCount >= 1) {
                if (mWebView != null) {
                    mWebView.loadUrl(VSConstances.MAIN_URL, requestHeader);
                }
            }
        } else {
            alwaylsTouchCount = 0;
        }
        touchCount++;
        startTimer();
        if (xwalkWebviewReady) {
            //默认触摸放大，需要禁止浏览器有放大功能，
            settings.setTextZoom(100);
        }
        //隐藏底部状态栏
        windowSettingImpls.hideBottomUIMenu(CrossWalkActivity.this);
        if (mWebView != null) {
            if (mWebView.getVisibility() == View.VISIBLE) {
                //设置是否可以播放广告
                ((YidiApplication) getApplication()).setPlayAd(true);
            }
        }

    }

    @Override
    public boolean readyPay() {
        //一、准备支付阶段，取消定时功能，使用stoptimer
        //二、同时使用一个boolean,变量为touch=false,触摸屏幕临时失效
        super.readyPay();
        stopTimer();
        touch = false;
        if (isAreadyPay) {
        }
        return true;
    }

    @Override
    public boolean finishPay(int time) {
        Log.i(TAG, "finishPay: 1");
        if (time == 1 && (!isAreadyPay)) {

        }
        //基类BaseActivity中进行
        boolean b = super.finishPay(time);
        //一、完成支付，无论是否为0，此时应该重新打开计时功能
        //二、同时将touch变量设置为一个boolean=true
        //三、将时间time保存，开启充电功能后，开启线程定时，定时取消充电功能
        //支付完成后，屏幕可以重新触摸计时监听
        touch = true;
        reStartTimer();
        Log.i(TAG, "finishPay:返回:" + b);
        return b;
    }

    public void reStartTimer() {
        stopTimer();
        startTimer();
    }

    @Override
    public boolean onLongClick(View v) {
        mWebView.setLongClickable(false);
        return true;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        //这里返回的数据影响
        Log.i(TAG, "dispatchKeyEvent:getKeyCode= " + event.getKeyCode());
        //4表示当前按下的是返回键且是发布版本，那么就不让退出
        if (event.getKeyCode() == 4 && (VSConstances.isPublish)) {
            //25表示当前的SDK版本如果低于25，不让退出刷新
            if (Build.VERSION.SDK_INT < 25) {
                return false;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    /**
     * 有重新加载网页导致平板加载时会出现闪屏情况，原因时手机或平板放久了可能出现白屏
     * 后期定制的平板应该尝试去掉重新加载网页，reloadWebView去掉，提高用户体验
     */
    @Override
    protected void onResume() {
        super.onResume();
        //检查网络回调接口设置
        Log.d(TAG, "onResume: GoogleWebView");
        setmCallBackPing(this);
        mCrossWalkPresenter = new CrossWalkPresenter(this);
        //性能测试，检查加载网页消耗时间
        errorCount = 0;
        loadURLTime = 0;
        //设置touch
        touch = true;
        //启动timer
        startTimer();
        reStartTimer();
        ((YidiApplication) getApplication()).setPlayAd(true);
        //通过设置点击刷新后，进行刷新
        boolean isFreshWebView = ((YidiApplication) getApplication()).isFresh();
        if (isFreshWebView) {
            //该代码应该检查HTML元素是否为空，然后在进行刷新
            Log.d(TAG, "onResume: reFresh"+isFreshWebView);
            ((YidiApplication) getApplication()).setFresh(false);
            if (xwalkWebviewReady) {
                // TODO: 2019/9/26 页面切换回来
                ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.CROSSWALK_ACTIVITY);
                mWebView.reload();
                //可能出现刷新的情况
                mHandler.sendEmptyMessageDelayed(HANDLE_CHECK_BLANK, 15_000);
                return;
            }
        }
        //没有点击触发WiFi按键时设置
        setWify = false;
        callStartSetttingActivityMethod = 0;
        ((YidiApplication) getApplication()).
                setCurrentActivityPage(VSConstances.CROSSWALK_ACTIVITY);
        checkOutNetFailCount = 0;
        netLostCount = 0;
        if (!xwalkWebviewReady) {
            allNetAvailable();
            onXWalkReady();
        } else {
            //不是首次加载时，且不是刷新状态
            checkNetworkAvailable();
            Log.d(TAG, "onResume: else");
            mHandler.sendEmptyMessageDelayed(HANDLE_CHECK_BLANK, 8_000);
        }
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.CROSSWALK_ACTIVITY);
    }

    /**
     * 重新加载webView
     */
    private void reloadMyWebView() {
        //修改可见性
        mWebView.reload();
        mWebView.setVisibility(View.INVISIBLE);
        linearLayout.setVisibility(View.VISIBLE);
        mWebView.postDelayed(new Runnable() {
            @Override
            public void run() {
                mWebView.setVisibility(View.VISIBLE);
                linearLayout.setVisibility(View.INVISIBLE);
            }
        }, 100);

//添加代码，无内容的数据

    }

    private void allNetAvailable() {
        if (!isNetworkAvailable()) {
            //没有网络，直接判定没有wifi连接
            is2WifiFragment();
        }
    }

    private void startPingFailActivity(final String code) {
        netWorkAvailable = false;
        restartApk = true;
        ((YidiApplication) getApplication()).setPlayAd(false);
        if (netToast != null) {
            netToast.cancel();
        }
        int currentActivity = ((YidiApplication) getApplication()).getCurrentActivityPage();
        if (currentActivity == VSConstances.CROSSWALK_ACTIVITY) {
            startPingFailBaseActivity(code);
        }
        if (currentActivity == VSConstances.FIRSTBOOT_ACTIVITY) {
            errorReload = true;
        }

    }


    private void hanleNetWorkTip() {
        pingReulst = ping("hanleNetWorkTip");
        if (!pingReulst) {
            toast = Toast.makeText(this, "哎呀，网络无法连接网,请找服务员吧", Toast.LENGTH_SHORT);
            toast.show();
            hideWebViewAndLoadMainUrl = true;
        } else {
            hideWebViewAndLoadMainUrl();
        }
    }


    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause: ");
        stopTimer();

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //通过此方式保存webview
        if (xwalkWebviewReady && mWebView != null) {
            outState1 = outState;
            mWebView.saveState(outState);
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if (xwalkWebviewReady) {
            mWebView.restoreState(savedInstanceState);
        }
    }

    @Override
    public int pingSuccess(String code) {
        ((YidiApplication) getApplication()).setNoNetwork(false);
        errorCount = 0;
        checkOutNetFailCount = 0;
        pingSucess = true;
        isFirstPing = false;
        mCurpingFailTimes = 0;
        setWify = false;
        Log.d(TAG, "pingSuccess: 将唤醒服务移到ping中");
        if (!(hasWakeUpedService)) {
            //启动唤醒服务
            mBaseHandler.sendEmptyMessageDelayed(HANDLE_WAKEUP_SERVICE, 6_000);
            hasWakeUpedService = true;
        }
        return 0;
    }

    @Override
    public int pingFail(String code) {
        //排除wifi设置影响
        ((YidiApplication) getApplication()).setNoNetwork(true);
        //进入wifi就无需判断
        if (!setWify) {
            //三个地方传入，分别在onCreateping,netAvailable、和webView解析异常中
            if (chckPingAgain(code)) {
                return 4;
            }
        }
        return 0;
    }

    public boolean chckPingAgain(String code) {
        //判断一次，就可以了
        if (pingSucess) {
            pingSucess = false;
            ping("chckPingAgain");
        }
        //再一次检查网络确认
        if ("chckPingAgain".equals(code) || "hideWebview".equals(code)) {
            startPingFailActivity(code);
            pingSucess = false;
            return true;
        }
        return false;
    }

    @Override
    public int pingException(String code) {
        //不是pingFail
        return 0;
    }

    /**
     * 在pingFail中被调用，有pingFail，重新ping
     * 开启新的线程判断网络情况
     *
     * @param code
     */
    public void startPingService(final String code) {
        MyThreadPool.startThread(new Runnable() {
            @Override
            public void run() {
                ping(code);
            }
        });

    }

    private void hideWebview(String code) {
        //在隐藏的webView中
        //将视图前置测试
        linearLayout.setVisibility(View.VISIBLE);
        tipTextView.setVisibility(View.VISIBLE);
        if (mWebView != null) {
            mWebView.setVisibility(View.INVISIBLE);
        } else {
            this.finish();
        }
    }

    /**
     * 加载Webview显示前的小猫动画
     */
    public void loadReady() {
        if (this != null) {
            Glide.with(this).load(cn.gddiyi.cash.cashier.R.mipmap.loading_circle).into(imageView);
        }
    }

    private void initView() {
        linearLayout = findViewById(cn.gddiyi.cash.cashier.R.id.web_started);
        imageView = findViewById(cn.gddiyi.cash.cashier.R.id.started_gif);
        tipTextView = findViewById(cn.gddiyi.cash.cashier.R.id.tips);
        enterAnimLayout = findViewById(cn.gddiyi.cash.cashier.R.id.adpiclayout);
        picImageView = findViewById(cn.gddiyi.cash.cashier.R.id.adImage);
        enterAnimLayout.setOnTouchListener(this);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                restartApk = true;
                restartAPP(CrossWalkActivity.this);
            }
        });
        loadReady();
        netToast = Toast.makeText(getApplicationContext(), "咦，网络走丢了", Toast.LENGTH_SHORT);
    }

    /**
     * wifi设置代码
     */
    public void setWify() {
        setWify = true;
        final EditText inputedit = new EditText(this);
        AlertDialog.Builder alertdialog = new AlertDialog.Builder(this);
        alertdialog.setTitle(getString(cn.gddiyi.cash.cashier.R.string.wifipertips));
        alertdialog.setView(inputedit);
        inputedit.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
        alertdialog.setNegativeButton(getString(cn.gddiyi.cash.cashier.R.string.cancel), null);
        alertdialog.setPositiveButton(getString(cn.gddiyi.cash.cashier.R.string.confirm), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String editTextString = inputedit.getText().toString();
                if (editTextString.isEmpty()) {
                    //重新设置SSID到数据库
                    mCrossWalkPresenter.resetSSID(CrossWalkActivity.this);
                    mCrossWalkPresenter.removewifiBySsid(CrossWalkActivity.this);
                    Intent intent = new Intent(CrossWalkActivity.this, FirstBootActivity.class);
                    //设置wifi传递给firstBootActivity,键同样也是noNetWork，但是值为setWifi,有点别扭
                    intent.putExtra("netWork", "setWifi");
                    ((YidiApplication) getApplication()).setWifiPage(true);
                    ((YidiApplication) getApplication()).setNoNetwork(false);
                    mCrossWalkPresenter.checkToast(toast);
                    startActivity(intent);
                }
            }
        });
        alertdialog.show();
    }


    private void hideWebViewAndLoadMainUrl() {
        if (hideWebViewAndLoadMainUrl) {
            hideWebview("hideWebViewAndLoadMainUrl");
            hideWebViewAndLoadMainUrl = false;
            mWebView.loadUrl(VSConstances.MAIN_URL, requestHeader);
        }
    }

    private void startTimer() {
        mCrossWalkPresenter.startTimer(touch, mHandler);
    }

    private void stopTimer() {
        mCrossWalkPresenter.stopTimer(touch, mHandler);
    }

    @Override
    public String getUpgradeInfo(ResponseUpdateAppInfo upgradeInfo) {
        //升级信息
        return super.getUpgradeInfo(upgradeInfo);
    }

    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.CROSSWALK_ACTIVITY);
    }

    private void is2WifiFragment() {
        // TODO: 2019/8/29 ,优化此段代码，已经没有视频播放器了 
        //没有wifi情况的设置
        String video = ((YidiApplication) getApplication()).getVideo();
        if ("playVideo".equals(video)) {
            ((YidiApplication) getApplication()).setVideo("noPlayVideo");
            Toast.makeText(this, "没有连接WIFI网络", Toast.LENGTH_LONG).show();
        } else {
            {  //启动wifi,或者无网络尝试连接
                startPingFailActivity("is2WifiFragment");
            }
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.d(TAG, "onNewIntent: ");
        setIntent(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy:lifeCircle ");
        //静态变量注意释放
        VSConstances.setContext(null);
        //移除所有的信息
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);

        }//清除缓存
        if (mWebView!=null){
            mWebView.clearCache(true);
        }
    }

    public void startSettingActivity() {
        restartApk = true;
        callStartSetttingActivityMethod = 1;
        setWify = true;
        Intent intent = new Intent(this, SettingActivity.class);
        startActivity(intent);
        Log.d(TAG, "startSettingActivity: ");
    }

    @Override
    public void noticeNetWorkChange(int state, String code) {
        //异步调用checkNetworkAvailable时，返回到该函数
        //state=0表示正常，如果state=1为异常
        //初始化SN出现的问题
        if (state == 0) {
            checkOutNetFailCount = 0;
            netLostCount = 0;
            return;
        }
        checkOutnetWork(state, code);
        checkWebViewHasShow(state, code);

    }

    private void checkWebViewHasShow(int state, String code) {
        boolean b = "checkStartedVisibility".equals(code) || "progressPercentageHundred".equals(code);
        if (state == 1 && b) {
            //是否进入网络错误信息
            errorReload = true;
            startPingFailActivity("checkWebViewHasShow");
        }
    }

    int netErrorCode = 200;

    public void checkOutnetWork(int state, String code) {
        int currentActivity = ((YidiApplication) getApplication()).getCurrentActivityPage();
        if (state == 1) {
            if (VSConstances.CROSSWALK_ACTIVITY == currentActivity && "consoleMessage".equals(code)) {
                //首次没有设置密码，会进入自动连接页面，这个问题解决？
                //这里给出提示，不再跳入PingFailActivity中,问题出现在这
//                startPingFailActivity(code);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(CrossWalkActivity.this, "请检查网络", Toast.LENGTH_SHORT).show();
                    }
                });
            }
            if (VSConstances.CROSSWALK_ACTIVITY == currentActivity && "onCreate".equals(code)) {
                //首次没有设置密码，会进入自动连接页面，这个问题解决？
                netErrorCode = VSConstances.ERROR_404;
                startPingFailActivity(code);
                netErrorCode = 200;
            }
            if (VSConstances.CROSSWALK_ACTIVITY == currentActivity && VSConstances.ERROR.equals(code)) {
                //首次没有设置密码，会进入自动连接页面，这个问题解决？
                netErrorCode = VSConstances.ERROR_404;
                startPingFailActivity(code);
                ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.PINGFAIL_ACTIVITY);
            }
            if ("checkNetworkAvailable".equals(code)) {
                if (checkOutNetFailCount >= VSConstances.CHECK_OUT_NETFAIL_COUNTS) {
                    mCrossWalkPresenter.removeHandleTouch(mHandler);
                    if (netToast != null) {
                        netToast.cancel();
                    }
                    startPingFailActivity("noticeNetWorkChange");
                } else {
                    //咦，网络走丢了
                    if (VSConstances.CROSSWALK_ACTIVITY == currentActivity) {
                        netToast.show();
                        checkOutNetFailCount++;
                        delayCheckNet();
                    }
                }
            }
        }
    }

    public void delayCheckNet() {
        if (picImageView != null) {
            long waitTime = 15_000;
            picImageView.postDelayed(new Runnable() {
                @Override
                public void run() {
                    isNetOuterAvailable("checkNetworkAvailable");
                }
            }, waitTime);
        }
    }

    /**
     * webView出现title未定义标志
     */
    boolean undefinedErrorCome = false;
    /**
     * 添加请求头部分，设置缓存时间
     */
    HashMap<String, String> requestHeader = new HashMap();

    /**
     * 检查白屏
     *
     * @param requestCode
     */
    public void checkWhiteScreen(final String requestCode) {
        //可能出现闪屏的可能，降低白屏的可能性
        //问题，切换到其他url,也会跟着改变到原始的URL
        //如果webView为空直接返回
        if (mWebView == null) {
            return;
        }
        mWebView.evaluateJavascript(VSConstances.CHECK_HTML_BY_APP_ID, new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                //不存在时返回null,net::ERR_INSUFFICIENT_RESOURCES -15
                Log.d(TAG, "onReceiveValue: " + value.length());
                Log.d(TAG, "onReceiveValue: requestCode=" + requestCode);
                if (value == null) {
                    //执行白屏函数
                    if ("wideNetWorkErr".equals(requestCode) || "HANDLE_CHECK_BLANK".equals(requestCode)) {
                        //广告隐藏也会出现问题，再有网络的情况下白屏
                        Toast.makeText(getApplicationContext(), "网络不佳，请耐心等待", Toast.LENGTH_LONG).show();
                        reloadMyWebView();
                    } else {
                        //尝试重新加载？
                        Log.d(TAG, "onReceiveValue: null need fresh");
//                        whiteSreenReload(requestCode);
                    }

                } else {
                    if (value.length() <= VSConstances.CONETNT_LENGTH) {
                        //出现一次是无值，实际情况不是白屏,需要reload,没有做，执行白屏函数
                        Log.d(TAG, "onReceiveValue:123 ");
                        if ("picAdOnHide".equals(requestCode)) {
                            whiteSreenReload(requestCode);
                        }
                        if ("wideNetWorkErr".equals(requestCode) || "HANDLE_CHECK_BLANK".equals(requestCode)) {
                            //handleBlank,此时白屏
                            //Toast.makeText(getApplicationContext(), "服务器或网络故障", Toast.LENGTH_LONG).show();
                            reloadMyWebView();
                        }
                        if ("getHtmlContent".equals(requestCode)){
                            //在网络超时的情况出现的
                            Toast.makeText(getApplicationContext(), "网络连接超时", Toast.LENGTH_LONG).show();
                            reloadMyWebView();
                        }
                    } else {
                        if (undefinedErrorCome) {
                            undefinedErrorCome = false;
                        }
                    }
                }
            }
        });
    }

    void getHtmlContent(final int requestCode) {
        Log.d(TAG, "getHtmlContent: " + requestCode);
//      String var="javascript:window.android.getHtml(document.getElementsByTagName('html').innerHTML)";
        String var = "javascript:window.android.getHtml(document.body.innerHTML)";
        Log.d(TAG, "getHtmlContent: ");
        mWebView.evaluateJavascript(var, new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                //获取结果
                Log.d(TAG, "onReceiveValue:getHtmlContent= " + value);
                if (value != null) {
                    if (value.contains("网页无法加载")) {
                        //出现了异常
                        Log.d(TAG, "onReceiveValue: "+requestCode);
                        startConsoleActivity(requestCode);
                    }else {
                        checkWhiteScreen("getHtmlContent");
                    }

                } else {
                    //没有显示网页无法加载
                    startConsoleActivity(requestCode);
                }
            }
        });
    }


    public void whiteSreenReload(final String reqestCode) {
        mWebView.postDelayed(new Runnable() {
            @Override
            public void run() {
                //获取webView当前的url
                mWebView.loadUrl(mWebView.getUrl(), requestHeader);
                isNetOuterAvailable("checkNetworkAvailable");
                //需要做一个网络检查反馈
            }
        }, 3000);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            //声音键按下的动作
            if (mWebView != null && mWebView.getUrl().contains("executeQuery")) {
                Toast.makeText(this, "t", Toast.LENGTH_SHORT).show();
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onStop() {
        Log.d(TAG, "onStop:lifeCircle ");
        super.onStop();
    }

    /**
     * 广告播放，来自JS
     */
    public void playAdNow() {
        Log.d(TAG, "playAdNow: ");
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (hadSdAds) {
                    picAdOnShow();
                } else {
                    hasSdAds();
                }
            }
        });
    }


    public void downLoad(View view) {
        Log.d(TAG, "downLoad: ");
        if (WakeUpService.mSpeechSynthesisPresenter != null) {
            WakeUpService.mSpeechSynthesisPresenter.speak("好的，买单请扫我吧");
        }
    }

}

