package cn.gddiyi.cash.customview.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.StyleRes;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;


import cn.gddiyi.cash.cashier.R;
import lombok.Getter;
import lombok.Setter;


/**
 * Created by John on 2017/4/7.
 */

public class WifiLinkDialog extends Dialog implements View.OnClickListener{

String TAG=getClass().getSimpleName();
    private TextView text_name;

    private EditText password_edit;

    private Button cancel_button;

    private Button cofirm_button;

    private String text_nameString;
    private CheckBox checkBoxPassWord;
    boolean remenberPassWord;
    @Setter
    @Getter
    public CallBackEdit mCallBackEdit;

    private Context mContext;


    public WifiLinkDialog(@NonNull Context context, @StyleRes int themeResId, String text_nameString) {
        super(context, themeResId);
        this.text_nameString = text_nameString;
         mContext = context;

    }
    public WifiLinkDialog(@NonNull Context context, @StyleRes int themeResId, String text_nameString,boolean remenberPassWord) {
        super(context, themeResId);
        this.text_nameString = text_nameString;
        mContext = context;
        this.remenberPassWord=remenberPassWord;

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view = LayoutInflater.from(mContext).inflate(R.layout.setting_wifi_link_dialog, null);
        setContentView(view);
        initView(view);
        text_name.setText(text_nameString);
        initListener();
    }

    private void initListener() {
        cancel_button.setOnClickListener(this);
        cofirm_button.setOnClickListener(this);
        checkBoxPassWord.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (getMCallBackEdit()!=null){
                    mCallBackEdit.setRemberPassword(isChecked);
                    Log.d(TAG, "onCheckedChanged: "+isChecked);
                }
            }
        });
    }

    private void initView(View view) {
        text_name = view.findViewById(R.id.wifi_title);
        password_edit = view.findViewById(R.id.password_edit);
        cancel_button = view.findViewById(R.id.cancel_button);
        cofirm_button = view.findViewById(R.id.cofirm_button);
        checkBoxPassWord=view.findViewById(R.id.checkboxRemenberPassWord);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.cofirm_button:{
              if (getMCallBackEdit()!=null){
                  mCallBackEdit.setEditText(password_edit);
              }
                dismiss();
                break;
            }
            case R.id.cancel_button:{
                dismiss();
                break;
            }
            default:break;
        }
    }
  public  interface CallBackEdit{
        String setEditText(EditText inputedit);
        String setRemberPassword(boolean b);
    }
}
