package cn.gddiyi.cash;

import android.app.Application;
import android.content.Context;
import android.util.Log;
import android.view.WindowManager;

import cn.gddiyi.cash.constant.VSConstances;

import lombok.Getter;
import lombok.Setter;

public class YidiApplication extends Application {

    String TAG = getClass().getSimpleName();
    public static YidiApplication yidiApplication;
    private static Context mContext;
    boolean WifiPage = true;
    @Setter
    @Getter
    boolean isClickChoiceWifi =false;
    @Getter
    @Setter
    public int currentActivityPage=0;
    @Getter
    @Setter
    public boolean isFresh=false;

    @Setter
    @Getter
    boolean playAd = true;

    @Setter
    @Getter
    boolean isNeedUpdateAdFile=false;

    @Setter
    @Getter
    boolean outNetWorkAvailable=true;

    public boolean getNoNetwork() {
        return noNetwork;
    }

    public void setNoNetwork(boolean noNetwork) {
        this.noNetwork = noNetwork;
    }

    boolean noNetwork = false;

    public void setVideo(String video) {
        this.video = video;
    }

    String video = "noPlayVideo";

    public String getVideo() {
        return video;
    }

    public boolean getWifiPage() {
        return WifiPage;
    }

    public void setWifiPage(boolean wifiPage) {
        WifiPage = wifiPage;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        VSConstances.setContext(getApplicationContext());
        yidiApplication=(YidiApplication) getApplicationContext();
        Log.d(TAG, "onCreate: "+getApplicationContext());
        mContext = getApplicationContext();
    }

    public static Context getContext() {
        return mContext;
    }
    private WindowManager.LayoutParams wmParams=new WindowManager.LayoutParams();
    public WindowManager.LayoutParams getMywmParams(){
        return wmParams;
    }

}