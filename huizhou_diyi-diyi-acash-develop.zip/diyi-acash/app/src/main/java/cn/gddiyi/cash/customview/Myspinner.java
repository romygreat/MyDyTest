package cn.gddiyi.cash.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

import cn.gddiyi.cash.customview.dialog.UnBindTableListDialog;
import lombok.Getter;
import lombok.Setter;

public class Myspinner extends android.support.v7.widget.AppCompatSpinner {
    Context mContext;
    String TAG = getClass().getSimpleName();
    @Getter
    @Setter
    UnBindTableListDialog unBindTableListDialog;

    public void setTableArray(String[] tableArray) {
        this.tableArray = tableArray;
    }

    String[] tableArray;

    public Myspinner(Context context) {
        super(context);
        mContext = context;
    }


    public Myspinner(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
    }

    public Myspinner(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == 0) {
            if (this.getUnBindTableListDialog() != null) {
                unBindTableListDialog.show();
            }
        }
        return true;
    }
}
