package cn.gddiyi.cash.dagger;




import cn.gddiyi.cash.presenter.PictrueAdPresenter;
import dagger.Module;
import dagger.Provides;

@Module
public class PicModule {
    @Provides
   public PictrueAdPresenter createPictrueAdPresenter(){
        return new PictrueAdPresenter();
    }
}
