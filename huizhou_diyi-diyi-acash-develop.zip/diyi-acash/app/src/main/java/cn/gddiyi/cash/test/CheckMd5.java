package cn.gddiyi.cash.test;


import android.support.annotation.NonNull;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import cn.gddiyi.cash.cashier.BuildConfig;
import cn.gddiyi.cash.presenter.AppUpgradePresenter;

import static com.baidu.tts.tools.FileTools.createDir;

public class CheckMd5 {
  public static final  String appReleasePath="E:\\GITproject\\diyi-acash\\app\\release\\app-release.apk";
  public static  String appName = "";
    /**
     *  APP与json存储路径
     */
    public static  String basePath = "C:\\Users\\diyi\\Desktop\\迪溢APP\\release\\cash\\";
    public static void main(String[] args) {
        //APP名称

        //版本号
        int code = BuildConfig.VERSION_CODE;
        //版本名称
        String versionName = BuildConfig.VERSION_NAME;
        versionName ="1.0.1";
        //升级信息
        String upgradeInfo = "第一次测试";
        //自动获取
        String md5;
         appName="cash-"+versionName+".apk";
        String path = "C:\\Users\\diyi\\Desktop\\迪溢APP\\release\\cash\\" +versionName+"\\"+ appName;

        createDir(basePath+"//"+versionName);
        basePath=basePath+"//"+versionName+"//";
        File baseFile=new File(basePath);
        if (!baseFile.exists()){
            baseFile.mkdirs();
        }
        move2Postion(appName,versionName);
        File file = new File(path);
        System.out.println("path=:" + path);
        md5 = AppUpgradePresenter.getFileMD5(file);
        write2JsonFile(appName, code, versionName, upgradeInfo, md5);
        System.out.println("MD5:" + md5);
        System.out.println("APP存储的路径在\n" +file.getParentFile().getAbsolutePath());
    }

    private static void move2Postion(String appname,String versionName) {
        System.out.println("basePath=:" + basePath);
        File file=new File(appReleasePath);
        if (file.exists()){
            file.renameTo(new File(basePath+appname));
        }
    }

    private static void write2JsonFile(String appName, int code, String versionName, String upgradeInfo, String md5) {
        String jsonPath =basePath +versionName+"_Md5.txt";

        File file1 = new File(jsonPath);
        if (!file1.exists()) {
            try {
                file1.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        String branchName= getBranchName();
        String json=null;
        if (branchName!=null&& branchName.contains("release")){
             json= "\n\n当前是"+branchName+"分支\n"+getString(appName, code, versionName, upgradeInfo, md5);

        }else {
            json = "\n\n当前不不不不是"+branchName+"分支"
                    +"请注意"
                    +getString(appName, code, versionName, upgradeInfo, md5);
        }
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file1);

            try {
                fileOutputStream.write(json.getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            System.out.println("文件不存在");
            e.printStackTrace();
        }

    }

    @NonNull
    private static String getString(String appName, int code, String vserionName, String upgradeInfo, String md5) {
        String json;
        json=
                "\n" + " {\n" +
                "  \"appName\":" + "\"" + appName + "\"" + ",\n" +
                "  \"versionCode\":" + code + ",\n" +
                "  \"versionName\":" + "\"" + vserionName + "\"" + ",\n" +
                "  \"upgradeInfo\": " + "\"" + upgradeInfo + "\"" + ",\n" +
                "  \"md5\": \"" + md5 + "\"\n" +
                " }";
        return json;
    }

    public static String getBranchName() {
        Runtime runtime = Runtime.getRuntime();
        String ret = null;
        Process process = null;
        try {
            int r = -1;
            StringBuffer stringBuffer = new StringBuffer();
            process = runtime.exec(" git symbolic-ref --short -q HEAD");
            try {
                process.waitFor();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            while ((r = process.getInputStream().read()) != -1) {
                stringBuffer.append((char) r);
            }
            ret = stringBuffer.toString();
            System.out.println("当前分支名称：" + ret);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (process != null) {
                process.destroy();
            }
        }
        return ret;
    }
}
