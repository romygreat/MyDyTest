package cn.gddiyi.cash.service;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;



import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.NonNull;
import android.util.Log;




import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ExecutorService;

import cn.gddiyi.cash.YidiApplication;
import cn.gddiyi.cash.constant.ConigInfo;
import cn.gddiyi.cash.constant.VSConstances;
import cn.gddiyi.cash.controler.MyThreadPool;
import cn.gddiyi.cash.jsinterface.JavaScriptinterface;
import cn.gddiyi.cash.model.PlayData;
import cn.gddiyi.cash.model.VideoPlayAll;
import cn.gddiyi.cash.model.dto.RequestJsonSn;
import cn.gddiyi.cash.model.dto.RequestJsonVideo;
import cn.gddiyi.cash.model.dto.ResponseJsonSn;
import cn.gddiyi.cash.model.dto.ResponseJsonVideo;
import cn.gddiyi.cash.presenter.PressenterFactory;
import cn.gddiyi.cash.presenter.RetrofitPresenter;
import cn.gddiyi.cash.presenter.VideoPresenter;
import cn.gddiyi.cash.utils.netutils.CallBackUtil;
import cn.gddiyi.cash.utils.netutils.DownloadUtil;
import cn.gddiyi.cash.utils.netutils.OkhttpUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import rx.Observable;
import rx.Subscriber;
import rx.schedulers.Schedulers;

/**
 * 广告下载服务，使用intentService，避免ANR异常
 */
public class DownLoadService extends IntentService implements Callback<ResponseJsonVideo>, VideoPresenter.DownloadVideoReady {
    RetrofitPresenter mPrensenter;
    VideoPresenter mVideoPrensenter;
    String token;
    String doMainName;
    String realVideoPath;
    ExecutorService executorService;
    int downloadSuccess;
    SharedPreferences sharedPreferences;
    int updateSuccess;
    Handler mHandler;
    private static final int HANDLE_REQ_SN = 0;
    private int HANDLE_RESPONSE = 1;
    String TAG=getClass().getSimpleName();


    /**
     * Creates an IntentService.  Invoked by your subclass's constructor.
     */
    public DownLoadService() {
        super("DownLoadservice");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        Log.d(TAG, "onHandleIntent: ");
        mVideoPrensenter = new VideoPresenter();
        mVideoPrensenter.setDownloadVideReady(this);
        sharedPreferences = getSharedPreferences(getString(cn.gddiyi.cash.cashier.R.string.diyi), Context.MODE_PRIVATE);
        mHandler = new Handler(getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                // TODO: 2019/8/30 重新请求获取一次
                // 理论上添加不会造成影响，但不确定是否因读写并发造成问题，添加此代码需要进行测试

            }
        };
        try {
            mPrensenter = PressenterFactory.getInstance().createRetrofitPresenter();
            //response 根据sn请求，得到token和充电时长，进一步通过token下载广告，通过充电时长控制充电时间
            // 代码是链式的，根据token值作为post参数之一，请求广告下载，最后分发保存
            //这里的代码使用retrofit2,rxjava，okhttp框架完成广告下载
            mPrensenter.setCallback(new Callback<ResponseJsonSn>() {
                @Override
                public void onResponse(Call<ResponseJsonSn> call, final retrofit2.Response<ResponseJsonSn> response) {
                    Log.d(TAG, "onResponse: downLoadService");
                    HANDLE_RESPONSE = 2;
                    Observable.create(getOnSubscribe(response))
                            .observeOn(Schedulers.io())
                            .subscribe(getSubscriber());



                }

                @Override
                public void onFailure(Call<ResponseJsonSn> call, Throwable t) {
                    //需要检查网络问题是否正常，这个问题比较棘手，设置网络加载失败
                    //网络走丢了,进入网页错误页面,当SN号是测试号，也会出现这个问题，需要注意
                    Log.d(getClass().getSimpleName(), "onFailure: Req_SN");
                    startErrorActivity(0);
                    //okhttp加载失败，需要对webview重新加载
                }
            });
            //fist step,get the sn from server,in order to get the unique token
            //这里才是真正开始请求sn
            RequestJsonSn requestJsonSn = new RequestJsonSn();
            requestJsonSn.setSn(JavaScriptinterface.getSerialNumber());
            String urlSN = VSConstances.URL_SN;
            mPrensenter.retrofitPost(urlSN, mPrensenter.postJsonString(requestJsonSn));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void startErrorActivity(int requestCode) {
        //在这里有一个刷新的操作，注意否则引起无法加载页面的情况
        ((YidiApplication) getApplication()).setFresh(true);
        int currentActivity = ((YidiApplication) getApplication()).getCurrentActivityPage();
        //可能在WIFI页面出现异常跳转
        if (currentActivity == VSConstances.CROSSWALK_ACTIVITY) {
            //网络连接问题，暂不做处理
//            Intent intent = new Intent(getApplicationContext(), PingFailActivity.class);
//            intent.putExtra(getString(R.string.LOG), requestCode + "DownLoadService");
//            DownLoadService.this.startActivity(intent);
        }
    }

    @NonNull
    public Subscriber<String> getSubscriber() {
        return new Subscriber<String>() {
            @Override
            public void onCompleted() {
                if (token != null) {
                    //获取广告
                    getVideo();
                }

            }

            @Override
            public void onError(Throwable e) {
                e.printStackTrace();

            }

            @Override
            public void onNext(String s) {

            }
        };
    }

    @NonNull
    public Observable.OnSubscribe<String> getOnSubscribe(final Response<ResponseJsonSn> response) {
        return new Observable.OnSubscribe<String>() {
            @Override
            public void call(final Subscriber<? super String> subscriber) {
                ResponseJsonSn r = response.body();
                saveDeviceArgs(r);
                //获取token
                token = r.getData().getToken();
                subscriber.onNext(token);
                String url = VSConstances.REQUEST_DOMAINURL;
                JSONObject postDoMainData = new JSONObject();
                try {
                    postDoMainData.put("token", token);
                    postDoMainData.put(VSConstances.MACHINE, VSConstances.MACHINE);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                OkhttpUtil.okHttpPostJson(url, postDoMainData.toString(), new CallBackUtil() {
                    @Override
                    public Object onParseResponse(okhttp3.Call call, okhttp3.Response response) {
                        try {
                            final JSONObject tokenJsonObject;
                            tokenJsonObject = new JSONObject(response.body().string());
//                            doMainName = tokenJsonObject.getString("data");
                            doMainName = VSConstances.IMG_PATH;
                            mVideoPrensenter.setDoMain(doMainName);
                            realVideoPath = doMainName;
                            subscriber.onCompleted();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        return null;
                    }

                    @Override
                    public void onFailure(okhttp3.Call call, Exception e) {

                    }

                    @Override
                    public void onResponse(Object response) {

                    }
                });
            }
        };
    }

    public void saveDeviceArgs(ResponseJsonSn r) {
        int chargeTime = Integer.parseInt(r.getData().getShop_set().getCharge_time());
        SharedPreferences.Editor editor = sharedPreferences.edit();
        //获取充电时长
        editor.putInt(getString(cn.gddiyi.cash.cashier.R.string.chargeTime), chargeTime);
        ConigInfo.tableNum = r.getData().getTable_title();
        editor.commit();
    }

    @Override
    public void onCreate() {
        super.onCreate();

    }

    public void getVideo() {
        try {
            RequestJsonVideo requestJsonVideo = postVideoBody();
            mPrensenter.setCallbackVideo(this);
            String url = VSConstances.POST_VIDEO_PATH;
            //请求下载图片，异步执行，最后得到的返回结果在该类的onResponse中，
            mPrensenter.retrofitPostVideo(url, mPrensenter.postJsonString(requestJsonVideo));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private RequestJsonVideo postVideoBody() {
        RequestJsonVideo requestJsonVideo = new RequestJsonVideo();
        requestJsonVideo.setToken(token);
        requestJsonVideo.setMachine("machine");
        RequestJsonVideo.SortBean sortBean = new RequestJsonVideo.SortBean();
        sortBean.setSort("desc");
        sortBean.setId("asc");
        sortBean.setShop_id("desc");
        requestJsonVideo.setSort(sortBean);
        return requestJsonVideo;
    }
    ResponseJsonVideo.DataBean dataBean;
    //获取所有的视频信息,真实路径
    @Override
    public void onResponse(Call<ResponseJsonVideo> call, Response<ResponseJsonVideo> response) {
        //空指针异常判断
        Log.d(TAG, "onResponse: "+response.body().toString());
        if (response != null && response.body() != null) {
            //还要判空操作
            if (response.body().getData() != null) {
                File file = new File("/sdcard/ad");
                if (!file.exists()) {
                    file.mkdir();
                }
                dataBean = response.body().getData();
                Collections.sort(dataBean.getList());
                mVideoPrensenter.saveVideoPrsenter(dataBean);
            }
        } else {  //可能需要删除视频，手动执行OnFail操作
            onFailure(call, new Throwable("手动抛出onFail"));
        }
    }

    @Override
    public void onFailure(Call<ResponseJsonVideo> call, Throwable t) {
        //报错了，采用okhttp3进行尝试下载视频信息，返回的是空的数据时处理

        OkhttpUtil.okHttpPostJson(VSConstances.POST_VIDEO_PATH, mPrensenter.postJsonString(postVideoBody()), new CallBackUtil() {
            @Override
            public Object onParseResponse(okhttp3.Call call, okhttp3.Response response) {
                try {
                    String dataNullArray = response.body().string();

                    if (dataNullArray.trim().contains("data:[]")) {
                        //删除视频文件
                        Log.d(TAG, "onParseResponse: data:[]");
                        File fileDir = new File(VSConstances.SDdir);
                        if (fileDir.exists() && fileDir.isDirectory()) {
                            //删除视频操作
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            public void onFailure(okhttp3.Call call, Exception e) {

            }

            @Override
            public void onResponse(Object response) {

            }
        });


    }

    //第一次安装使用下载视频使用时走的方法
    @Override
    public void noticefyDownLoadReady(final VideoPlayAll<PlayData> sparseArray) {
        boolean isFirstBoot = sharedPreferences.getBoolean("firstBoot", true);
        setSharePreference(sparseArray.getCount());
        if (isFirstBoot) {
            goFirtBoot(sparseArray);
        } else {
            //非首次启动
            notFirstBoot(sparseArray);
        }

    }

    public void goFirtBoot(VideoPlayAll<PlayData> sparseArray) {
        setSharePreference(VSConstances.NA);
        save2SdcardAd(sparseArray);
        for (int i = 0; i < sparseArray.getCount(); i++) {
            String downLoadPath = sparseArray.get(i).getNetVideoPath();
            if (!downLoadPath.contains("[]")) {
                downLoadOneByOne(sparseArray, downLoadPath);
            }
        }
    }

    public void notFirstBoot(VideoPlayAll<PlayData> sparseArray) {
        if (mVideoPrensenter.checkUpdate()) {

        } else {
            if (sparseArray != null) {
                save2SdcardAd(sparseArray);
                ((YidiApplication) getApplication()).setNeedUpdateAdFile(true);
            }
        }
        //检查需要删除的广告
        MyThreadPool.startThread(new Runnable() {
            @Override
            public void run() {
                //删除广告
                mVideoPrensenter.deleteSDadVideo();
            }
        });
    }

    public void downLoadOneByOne(final VideoPlayAll<PlayData> sparseArray, final String downLoadPath) {
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                DownloadUtil.get().download(downLoadPath, VSConstances.AD,
                        new DownloadUtil.OnDownloadListener() {
                            @Override
                            public void onDownloadSuccess() {
                                if (sparseArray.getCount() == downloadSuccess) {
                                    //服务停止代码
                                    downloadSuccess = 0;
                                }
                            }

                            @Override
                            public void onDownloading(int progress) {
                            }

                            @Override
                            public void onDownloadFailed() {

                            }
                        });
            }
        };
        MyThreadPool.startThread(runnable);
    }

    public void save2SdcardAd(final VideoPlayAll<PlayData> sparseArray) {
        MyThreadPool.getExeCutor().execute(new Runnable() {
            @Override
            public void run() {
                //需要一个变量，保存当前广告顺序,以及定时更新处理
                if (VSConstances.adFileNames==null){
                    updateAdFileNames(sparseArray);
                }else if (VSConstances.adFileNames.length!=sparseArray.getCount()){
                    updateAdFileNames(sparseArray);
                }
            }
        });
    }

    private void updateAdFileNames(VideoPlayAll<PlayData> sparseArray) {
        if (sparseArray != null) {
            VSConstances.adFileNames = new String[sparseArray.getCount()];
            for (int i = 0; i < sparseArray.getCount(); i++) {
                VSConstances.adFileNames[i] = sparseArray.get(i).getVideoName();
                //dev分支上的广告没有引发播放的问题
                //可以继续播放
            }
            mVideoPrensenter.save2LocalFile(sparseArray);
        }
    }

    //视频下载的接口
    //应该忽略改方法
    @Override
    public void noticefyUpdate(final VideoPlayAll<PlayData> sparseArray, final ArrayList list) {
        save2SdcardAd(sparseArray);
        setSharePreference(sparseArray.getCount());
        for (int i = 0; i < list.size(); i++) {
            final String name = sparseArray.get((int) list.get(i)).getVideoName();
            final int downLoadNum = list.size();
            //广告一张一张的下载
            DownloadUtil.get().download(sparseArray.get((int) list.get(i)).getNetVideoPath(), "ad", new DownloadUtil.OnDownloadListener() {
                @Override
                public void onDownloadSuccess() {
                    Log.d("DownLoadService", "onDownloadSuccess: "+name);
                    updateSuccess++;
                    if (updateSuccess == downLoadNum) {
                        //这里停止写掉服务代码
                        updateSuccess = 0;
                    }
                }

                @Override
                public void onDownloading(int progress) {

                }

                @Override
                public void onDownloadFailed() {

                }
            });
        }
    }

    //设置更改为否为首次启动
    public void setSharePreference(int a) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        //测试时候修改该参数为true
        editor.putBoolean("firstBoot", false);
        if (a != VSConstances.NA) {
            editor.putInt(VSConstances.VIDEOCOUNT, a);
        }
        editor.commit();//提交修改
    }
}
