package cn.gddiyi.cash.service;

import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.util.Log;


import java.io.IOException;

//未使用
public class PingService extends Service {
    int i = 0;

    public static void setActivity(Activity activity) {
        activity1 = activity;
    }
   static Activity activity1;
    @Override
    public boolean stopService(Intent name) {
        if(mHandler.hasMessages(1)){
            mHandler.removeMessages(1);
        }

        return super.stopService(name);
    }

    Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            i++;
            if (ping("pingService" + i)) {
                if (activity1!=null){
                    activity1.finish();
                }
                stopSelf();
            } else {
                mHandler.sendEmptyMessageDelayed(1, 6_000);
            }
        }
    };


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mHandler.sendEmptyMessageDelayed(1, 0);
    }

    public boolean ping(String code) {

        long time1 = System.currentTimeMillis();
        //百度IP地址
        String ip = "114.114.114.114";
        // ping 的地址，可以换成任何一种可靠的外网
        Process p = null;
        try {
            p = Runtime.getRuntime().exec("ping -c 2 -w 2 " + ip);
        } catch (IOException e) {
        }
        // ping网址2次
        int status = 0;
        try {
            status = p.waitFor();
        } catch (InterruptedException e) {

        }
        if (status == 0) {
            Log.i("ping", "baseActivity Success " + (System.currentTimeMillis() - time1));
            stopSelf();
            return true;
        } else {
            //当fail时ping很快返回结果
            Log.i("ping", "baseActivity fail " + (System.currentTimeMillis() - time1));
            return false;
        }
    }
}
