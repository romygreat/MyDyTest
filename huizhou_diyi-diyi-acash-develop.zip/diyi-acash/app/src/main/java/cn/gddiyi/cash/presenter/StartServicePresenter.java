package cn.gddiyi.cash.presenter;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import cn.gddiyi.cash.controler.DiyiInterface;
import cn.gddiyi.cash.service.DownLoadService;
import cn.gddiyi.cash.service.GetTokenService;
import cn.gddiyi.cash.service.PingService;
import cn.gddiyi.cash.service.WakeUpService;


public class StartServicePresenter implements DiyiInterface.StartServiceInterface {


    @Override
    public void startDownLoadService(Context context) {
        Intent intent=new Intent(context,DownLoadService.class);
        context.startService(intent);
    }

    @Override
    public void startGetTokenService(Context context) {
        Log.d("", "startGetTokenService: ");
        Intent intent=new Intent(context,GetTokenService.class);
        context.startService(intent);
    }

    @Override
    public void startPingService(Context context) {
        //
        Intent intent=new Intent(context,PingService.class);
        context.startService(intent);
    }

    @Override
    public void startWakeUpService(Context context) {
        Intent intent=new Intent(context,WakeUpService.class);
        context.startService(intent);
    }


}
