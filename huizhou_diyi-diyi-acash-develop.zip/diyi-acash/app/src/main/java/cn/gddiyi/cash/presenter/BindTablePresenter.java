package cn.gddiyi.cash.presenter;

import android.content.Context;

public class BindTablePresenter {
    Context mContext;

    public BindTablePresenter(Context mContext) {
        this.mContext = mContext;
    }
    public boolean bindSuccess(){
    //getBindTableResponse();
        return true;
    }
}
