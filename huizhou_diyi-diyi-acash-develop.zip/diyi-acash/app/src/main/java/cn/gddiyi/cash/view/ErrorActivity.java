package cn.gddiyi.cash.view;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import cn.gddiyi.cash.YidiApplication;
import cn.gddiyi.cash.constant.VSConstances;

public class ErrorActivity extends BaseActivity {
    EditText mainUrlEdit,serviceUrlEdit;
    Button confirm;
    String mainUrlString,serviceUrlString;
    static  boolean isChangeUrl=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(cn.gddiyi.cash.cashier.R.layout.error);
        initView();
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mainUrlEdit.getText().toString()!=null){
                    mainUrlString=mainUrlEdit.getText().toString();
                }
                if (serviceUrlEdit.getText().toString()!=null){
                    serviceUrlString=serviceUrlEdit.getText().toString();
                }
                VSConstances.MAIN_URL=mainUrlString;
                isChangeUrl=true;
                ErrorActivity.this.finish();

            }


        });

    }

    @Override
    public void currentActivity() {
        ((YidiApplication)getApplication()).setCurrentActivityPage(VSConstances.ERROR_ACTIVITY);
    }

    private void initView() {
        mainUrlEdit=findViewById(cn.gddiyi.cash.cashier.R.id.mainUrlEdit);
        serviceUrlEdit=findViewById(cn.gddiyi.cash.cashier.R.id.serviceUrlEdit);
        confirm=findViewById(cn.gddiyi.cash.cashier.R.id.confirm);
    }

}
