package cn.gddiyi.cash.controler;

import android.support.v4.content.FileProvider;

/**
 * 当android高版本时需要一个空的FileProvider，否则影响不能读写文件
 */
public class MyFileProvider extends FileProvider {
}
