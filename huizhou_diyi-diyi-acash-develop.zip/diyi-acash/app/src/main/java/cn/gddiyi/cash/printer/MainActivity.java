package cn.gddiyi.cash.printer;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeechService;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.printer.command.EscCommand;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Vector;
import java.util.concurrent.ArrayBlockingQueue;

import cn.gddiyi.cash.YidiApplication;
import cn.gddiyi.cash.cashier.R;
import cn.gddiyi.cash.constant.ConigInfo;
import cn.gddiyi.cash.constant.VSConstances;
import cn.gddiyi.cash.customview.MyWebView;
import cn.gddiyi.cash.jsinterface.JavaScriptinterface;
import cn.gddiyi.cash.presenter.CrossWalkPresenter;
import cn.gddiyi.cash.printer.vendor.jiabo.DeviceConnFactoryManager;
import cn.gddiyi.cash.printer.vendor.jiabo.PrinterCommand;
import cn.gddiyi.cash.printer.vendor.jiabo.PrinterPresenter;
import cn.gddiyi.cash.printer.vendor.jiabo.ThreadPool;
import cn.gddiyi.cash.printer.vendor.jiabo.Utils;
import cn.gddiyi.cash.printer.vendor.jiabo.ddo.PrintData;
import cn.gddiyi.cash.printer.vendor.jiabo.ddo.PrinterInfo;
import cn.gddiyi.cash.printer.vendor.jiabo.mydefinition.EthernetPort;
import cn.gddiyi.cash.printer.vendor.jiabo.mydefinition.EthernetPort.EtherPortMessageInterface;
import cn.gddiyi.cash.printer.vendor.jiabo.mydefinition.QueryBy4000Port;
import cn.gddiyi.cash.service.WakeUpService;
import cn.gddiyi.cash.text2speachlib.Text2Speech;
import cn.gddiyi.cash.utils.AndroidBug5497Workaround;
import cn.gddiyi.cash.view.SettingActivity;

import static android.net.ConnectivityManager.CONNECTIVITY_ACTION;
import static cn.gddiyi.cash.printer.vendor.jiabo.Constant.ACTION_SOCKET_EXPCETION;
import static cn.gddiyi.cash.printer.vendor.jiabo.Constant.ACTION_USB_PERMISSION;
import static cn.gddiyi.cash.printer.vendor.jiabo.Constant.CONN_STATE_DISCONN;
import static cn.gddiyi.cash.printer.vendor.jiabo.Constant.MESSAGE_UPDATE_PARAMETER;
import static cn.gddiyi.cash.view.CrossWalkActivity.ERR_INTERNET_DISCONNECTED;


public class MainActivity extends PrinterActivity implements View.OnTouchListener,
        EtherPortMessageInterface, DeviceConnFactoryManager.ReadListsener, QueryBy4000Port.CallBackState {

    private static final int HANDLE_QUERY_PRINTER_STATUS = 112;
    private static final int RE_CONNECT_PRINTER = 113;
    private static final int QUERY_PRINTER_INT = 114;
    private static final int HANDLE_QUERY_BY_4000_PORT = 115;

    public MyWebView mWebView;
    JavaScriptinterface javaScriptinterface;
    WebSettings settings;
    CrossWalkPresenter mCrossWalkPresenter;
    TextView tipsTv;
    LinearLayout linearLayout;

    boolean printerThreadStarted = false;

    public static final int HANDLE_RECONNECT_PRINTER = 10;
    public HashMap<String, ArrayBlockingQueue<Runnable>> failOrder = new HashMap<>(30);


    @Override
    protected void onResume() {
        super.onResume();
        onXWalkReady();
        currentActivity();
        boolean isfresh = ((YidiApplication) getApplication()).isFresh();
        doFreshPage(isfresh);
    }

    private void doFreshPage(boolean fresh) {
        if (fresh && (mWebView != null)) {
            mWebView.reload();
            ((YidiApplication) getApplication()).setFresh(false);
        }
    }

    private ThreadPool threadPool;
    String TAG = getClass().getSimpleName();
    private int HOUCHU = 0;
    private int id = 0;
    ArrayBlockingQueue<Runnable> printOrderList;
    //每台打印机维护一个阻塞队列

    /**
     * 所有打印机列表
     */
    ArrayList<PrinterInfo> printersList = new ArrayList<>(50);

    Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                //仅仅连接一台打印机的情况
                case CONN_STATE_DISCONN:
                    if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU] != null
                            || !DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU].getConnState(HOUCHU)) {
                        DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU].closePort(HOUCHU);
                        DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU] = null;
                        Utils.toast(MainActivity.this, getString(cn.gddiyi.cash.cashier.R.string.str_disconnect_success));
                    }
                    break;
                case MESSAGE_UPDATE_PARAMETER:
                    Log.d(TAG, "handleMessage:initPrinters ");
                    String strIp = msg.getData().getString("Ip");
                    String strPort = msg.getData().getString("Port");
                    /* 初始化打印机信息*/
                    PrinterInfo houChuPrinter = getPrinterFromList(strIp, strPort, "测试");
                    houChuPrinter.setId(0);
                    mPrinterPresenter.initPrinters(houChuPrinter, printersList);
                    break;
                case RE_CONNECT_PRINTER:
                    //需要的等待一分钟后方可重连
                    reConnectPrinterFlag = false;
                    break;
                case HANDLE_RECONNECT_PRINTER:
                    //当打印线程开启的时候运行
                    if (printerThreadStarted) {
                        if (!netWorkNormal) {
                            for (PrinterInfo printerInfo : printersList) {
                                mPrinterPresenter.initPrinters(printerInfo, printersList);
                            }
                        }
                    }
                    break;
                case HANDLE_QUERY_PRINTER_STATUS:
                    //如果处于重新连接状态延迟2分钟
                    if (!reConnectPrinterFlag) {
                        handleQueryPrinter();
                    } else {
                        mHandler.sendEmptyMessageDelayed(HANDLE_QUERY_PRINTER_STATUS, (VSConstances.TIME_UNIT_MIN + 10));
                    }
                    break;
                case HANDLE_QUERY_BY_4000_PORT:
                    canQueryBy4000Port = true;
                    break;
                default:
                    break;
            }
        }
    };

    private void handleQueryPrinter() {
        //一、先初始化数据
        for (PrinterInfo printerInfo : printersList) {
            if (printerInfo != null && printerInfo.getMyPrinterSta()) {
                printerInfo.setQueryStatus(false);
            }
        }

        //二、发送查询命令
        sendQueryAllPrintersCommand();
        mWebView.postDelayed(new Runnable() {
            @Override
            public void run() {
                for (PrinterInfo printerInfo : printersList) {
                    //注意与打印机失常时的处理
                    if (printerInfo.getMyPrinterSta()) {
                        Log.d(TAG, "run:printersList 查询状态结果= " + printerInfo.isQueryStatus());
                        if (!printerInfo.isQueryStatus()) {
                            printerInfo.setMyPrinterSta(false);
                        }
                    } else {
//                        tryConnectprinter1(printerInfo.getIp());
                    }
                }
            }
        }, 120);
        //一直检查是否连接
        mHandler.sendEmptyMessageDelayed(HANDLE_QUERY_PRINTER_STATUS, VSConstances.TIME_UNIT_MIN);
    }

    private void sendQueryAllPrintersCommand() {
        for (int i = 0; i < printersList.size(); i++) {
            PrinterInfo printerInfo = printersList.get(i);
            if (printerInfo.getMyPrinterSta()) {
                if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[i].getEthernetPortId().outputStream != null) {
                    PrinterInfo printerInfo1 = new PrinterInfo();
                    printerInfo1.setId(i);
                    printNow(QUERY_PRINTER_INT, new PrintData(), printerInfo1);
                }
            }
        }
    }

    private void sendQueryCommandByIp(String ip) {
        final int index = findPrinterIdByIp(ip);
        if (index != -1 && printOrderList != null) {
            PrinterInfo printerInfo = printersList.get(index);
            if (printerInfo.getMyPrinterSta()) {
                printerInfo.setQueryStatus(false);
                if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[index].getEthernetPortId().outputStream != null) {
//                    PrinterInfo printerInfo1=new PrinterInfo();
//                    printerInfo1.setIp(printerInfo.getIp());
//                    printerInfo1.setPort("9100");
                    printNow(QUERY_PRINTER_INT, new PrintData(), printerInfo);
                }
            }
        }
        mWebView.postDelayed(new Runnable() {
            @Override
            public void run() {
                boolean queryStatus = printersList.get(index).isQueryStatus();
                Log.d(TAG, "run:queryStatus= " + queryStatus);
                if (!queryStatus) {
                    printersList.get(index).setMyPrinterSta(false);
                    //立马连接，第二次尝试连接需要等待1分钟
                    reConnectPrinter(printersList.get(index));
                }
            }
        }, 180);
    }

    private void putQueryRunable(final int i) {
        final byte[] command = new byte[]{16, 4, 2};
        final Runnable queryRunable = new Runnable() {
            @Override
            public void run() {
                try {
                    DeviceConnFactoryManager.getDeviceConnFactoryManagers()[i].getEthernetPortId().outputStream.write(command);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        try {
            printOrderList.put(queryRunable);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Log.d(TAG, "putQueryRunable: ");
        //添加到失败的打印列表
    }


    @NonNull
    private PrinterInfo getPrinterFromList(String strIp, String strPort, String name) {
        PrinterInfo printerInfo = null;
        //查找是否存在打印机列表
        // TODO: 2019/12/18 修改可能导致索引出现故障 
//        int index = printersList.indexOf(printerInfo);
        int index = findPrinterIdByIp(strIp);
        if (index == -1) {
            //ID 根据打印机的列表数添加打印机
            printerInfo = new PrinterInfo();
            printerInfo.setId(printersList.size());
            printerInfo.setIp(strIp);
            printerInfo.setPort(strPort);
            printerInfo.setTitle(name);
            Log.d(TAG, "getPrinterFromList:size= " + printersList.size());
            printersList.add(printersList.size(), printerInfo);

        } else {
            printerInfo = printersList.get(index);
        }
        Log.d(TAG, "getPrinterFromList: " + index);
        return printerInfo;
    }

    /**
     * 查找打印机IP的索引
     *
     * @param ip
     * @return
     */
    public int findPrinterIdByIp(String ip) {
        int index = -1;
        for (PrinterInfo printerInfo : printersList) {
            Log.d(TAG, "findPrinterIdByIp: " + printerInfo.getIp());
            if (printerInfo.getIp() != null) {
                if (ip.trim().equals(printerInfo.getIp())) {
                    Log.d(TAG, "findPrinterIdByIp:wtf= " + printersList.indexOf(printerInfo));
                    index = printersList.indexOf(printerInfo);
                    Log.d(TAG, "findPrinterIdByIp: " + index);
                    break;
                }

            }
        }
        return index;
    }

    PrinterPresenter mPrinterPresenter = new PrinterPresenter(this);
    TextToSpeech textToSpeech;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.printer_activity);
        if (!isNetworkAvailable()) {
            startPingFailActivity("printerActivity");
            this.finish();
            return;
        }
        AndroidBug5497Workaround.assistActivity(this);
        initOnCreate();
        printOrderList = new ArrayBlockingQueue<>(60);
        //注册连接的信息
        EthernetPort.setEtherPortMessageInterface(this);
        DeviceConnFactoryManager.setReadListsener(this);
        QueryBy4000Port.setCallBackState(this);
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.PRINTER_ACTIVITY);
        if (!initPermission()) {
            onDestroy();
            this.finish();
        } else {
            initOnCreate();
            //启动语音服务
            textToSpeech = new TextToSpeech(MainActivity.this, new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int i) {
                    Log.d(TAG, "onInit: status=" + i);
                    if (TextToSpeech.SUCCESS == i) {
                        Log.d(TAG, "onInit: ");
                        textToSpeech.setEngineByPackageName("com.google.android.tts");
                        textToSpeech.setLanguage(Locale.CHINA);

                    }
                }
            });
            textToSpeech.setPitch(1.0f);
        }

    }

    private void registerMyReceiver() {
        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        filter.addAction(DeviceConnFactoryManager.ACTION_QUERY_PRINTER_STATE);
        filter.addAction(DeviceConnFactoryManager.ACTION_CONN_STATE);
        filter.addAction(DeviceConnFactoryManager.ACTION_PRINTER_STATUS);
        filter.addAction(DeviceConnFactoryManager.ACTION_READ_STATE_EXCEPTION);
        filter.addAction(ACTION_SOCKET_EXPCETION);
        filter.addAction(CONNECTIVITY_ACTION);
        receiver = getBroadcastReceiver();
        registerReceiver(receiver, filter);
    }

    public void btnWifiConn(View view) {
        //连接前做出连接判断
//        if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU] == null ||
////                !DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU].getConnState(HOUCHU)
////        ) {
////            Log.d(TAG, "btnWifiConn: if connect");
////        } else {
////            Log.d(TAG, "btnWifiConn: else alreadyConnect");
////            mHandler.obtainMessage(CONN_STATE_DISCONN).sendToTarget();
////        }
////
////        Message message = Message.obtain();
////        message.what = MESSAGE_UPDATE_PARAMETER;
////        Bundle bundle = new Bundle();
////        bundle.putString("Ip", Constant.WIFI_DEFAULT_IP);
////        bundle.putString("Port", Constant.WIFI_DEFAULT_PORT);
////        message.setData(bundle);
////        mHandler.sendMessage(message);

        if (WakeUpService.mSpeechSynthesisPresenter != null) {
            Log.d(TAG, "btnWifiConn: 语音");
            WakeUpService.mSpeechSynthesisPresenter.speak("您有新的订单003台桌，请及时查收");
        }
    }

    /**
     * 断开连接
     *
     * @param view
     */
    public void btnDisConn(View view) {
        if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU] == null
//                || !DeviceConnFactoryManager.getDeviceConnFactoryManagers()[id].getConnState()
        ) {
            Utils.toast(this, "请先连接打印机");
            return;
        } else if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU].getConnState(HOUCHU)) {
            Utils.toast(this, "状态未关闭");
        }

        mHandler.obtainMessage(CONN_STATE_DISCONN).sendToTarget();
    }

    public void printData(View view) {

    }

    public String tryConnectprinter(String ip) {
        PrinterInfo printerInfo = new PrinterInfo();
        ip = ip.substring(1, ip.length() - 1);
        printerInfo.setIp(ip);
        printerInfo.setPort("9100");
        int j = findPrinterIdByIp(ip);
        tryConnectprinter1(ip);
        return null;
    }

    public String tryConnectprinter1(String ip) {
        Log.d(TAG, "tryConnectprinter1: " + ip);
        PrinterInfo printerInfo = new PrinterInfo();
        printerInfo.setIp(ip);
        printerInfo.setPort("9100");
        mPrinterPresenter.initPrinters(printerInfo, printersList);
        return null;
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (receiver != null) {

            unregisterReceiver(receiver);
        }
        Log.e(TAG, "onDestroy()");
        DeviceConnFactoryManager.closeAllPort();
        if (threadPool != null) {
            threadPool.stopThreadPool();
            threadPool = null;
        }
    }

    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.PRINTER_ACTIVITY);
    }


    private BroadcastReceiver receiver = null;
    boolean netWorkNormal = true;

    @NonNull
    private BroadcastReceiver getBroadcastReceiver() {
        return new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                switch (action) {
                    case DeviceConnFactoryManager.ACTION_CONN_STATE:
                        int state = intent.getIntExtra(DeviceConnFactoryManager.STATE, -1);
                        int deviceId = intent.getIntExtra(DeviceConnFactoryManager.DEVICE_ID, -1);
                        switch (state) {
                            case DeviceConnFactoryManager.CONN_STATE_DISCONNECT:
                                if (HOUCHU == deviceId) {
                                    //关闭掉
                                    // printMytips("打印机已断开连接");
                                }
                                break;
                            case DeviceConnFactoryManager.CONN_STATE_CONNECTING:
                                break;
                            case DeviceConnFactoryManager.CONN_STATE_CONNECTED:

                                break;
                            case DeviceConnFactoryManager.CONN_STATE_FAILED:
//                                printMytips(getString(cn.gddiyi.cash.cashier.R.string.str_conn_fail));
                                break;
                            default:
                                break;
                        }
                        break;
                    case DeviceConnFactoryManager.ACTION_PRINTER_STATUS:
                        String status = intent.getStringExtra("status");
                        Log.d(TAG, "onReceive:status " + status);
                        //获取设备ID
                        deviceId = intent.getIntExtra(DeviceConnFactoryManager.DEVICE_ID, -1);
//                        showprinterToast(deviceId);
                        break;
                    case ACTION_SOCKET_EXPCETION:
                        deviceId = intent.getIntExtra(DeviceConnFactoryManager.DEVICE_ID, -1);
                        if (deviceId != -1) {
                            //关闭IO口
                            DeviceConnFactoryManager.getDeviceConnFactoryManagers()[deviceId].closePort(deviceId);
                        }
                        break;
                    case CONNECTIVITY_ACTION:
                        Log.d(TAG, "onReceive:netWorkNormal= " + netWorkNormal);
                        //第一种情况，平板处理网络问题
                        Log.d(TAG, "onReceive: wifi状态改变了");
                        if (isNetworkAvailable()) {
                            removeIfHasHandleMessage(HANDLE_RECONNECT_PRINTER);
                            mHandler.sendEmptyMessageDelayed(HANDLE_RECONNECT_PRINTER, 3000);
                            // TODO: 2019/12/7 测试如果出现异常，先屏蔽代码

                            netWorkNormal = true;
                        } else {
                            //关闭所有的打印机
                            Log.d(TAG, "onReceive: 网络不可用");
                            netWorkNormal = false;
                            if (!netWorkNormal) {
                                DeviceConnFactoryManager.closeAllPort();
                            }
                        }
                        break;
                    case DeviceConnFactoryManager.ACTION_READ_STATE_EXCEPTION:

                        break;
                    default:
                        break;
                }
            }
        };
    }

    private void removeIfHasHandleMessage(int what) {
        if (mHandler != null && mHandler.hasMessages(what)) {
            mHandler.removeMessages(what);
        }
    }

    private void showprinterToast(int deviceId) {
        String title = null;
        if (printersList.get(deviceId) != null) {
            title = printersList.get(deviceId).getTitle();
        }
        int currentAcivity = ((YidiApplication) getApplication()).getCurrentActivityPage();
        if (title != null && (VSConstances.PRINTER_ACTIVITY == currentAcivity)) {
//            printMytips(title + "打印机已连接");
        }

    }

    public boolean startSettingActivity() {
        startActivity(new Intent(this, SettingActivity.class));
        return true;
    }

    int i;

    Runnable printingRunnable = null;

    public void loopExit(View view) {
        Log.d(TAG, "loopExit: 开始进入循环");
    }

    private void startPrinterThread() {
        ThreadPool.getInstantiation().addTask(new Runnable() {
            @Override
            public void run() {
                try {
                    //开始循环打印
                    Log.d(TAG, "run:loopExit= " + printerThreadStarted);
                    while (printerThreadStarted) {
                        //阻塞队列
                        printingRunnable = printOrderList.take();
                        if (i > 1000) {
                            i = 0;
                        }
                        Log.d(TAG, "run:loopExit=take" + (i++));
                        printingRunnable.run();

                    }
                } catch (InterruptedException e) {
                    Log.d(TAG, "run: 中断异常");
                    e.printStackTrace();
                }
            }
        });
    }


    public void printNewOrder(View view) {

    }

    private byte[] esc = {0x10, 0x04, 0x02};

    public void queueIsFull(View view) {
        /* 打印机状态查询 */
        if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU] == null ||
                !DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU].getConnState(HOUCHU)) {
            Utils.toast(this, getString(cn.gddiyi.cash.cashier.R.string.str_cann_printer));
            return;
        }
        if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU] == null) {
            Log.d(TAG, "btnPrinterState: ===未连接");
        } else {
            Log.d(TAG, "btnPrinterState:getConnState " + DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU].getConnState(HOUCHU));
        }
        Log.d(TAG, "btnPrinterState: " + DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU]);
        DeviceConnFactoryManager.whichFlag = true;
        ThreadPool.getInstantiation().addTask(new Runnable() {
            @Override
            public void run() {
                Vector<Byte> data = new Vector<>(esc.length);
                if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[id].getCurrentPrinterCommand() == PrinterCommand.ESC) {
                    for (int i = 0; i < esc.length; i++) {
                        data.add(esc[i]);
                    }
                    DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU].sendDataImmediately(data, HOUCHU);
                }
            }
        });
    }

    boolean xwalkReady = false;

    @Override
    protected void onXWalkReady() {
        setWebSettings();
        windowSettingImpls.setWindowListener(this);
        //禁止长按事件
        mWebView.setLongClickable(false);

        mWebView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Log.d(TAG, "onLongClick: ");
                return true;
            }
        });
        mWebView.loadUrl(VSConstances.MAIN_URL);
        Log.d(TAG, "onXWalkReady:URL== " + mWebView.getUrl());
        showWebView();
        //加载缓存一段时间，比较暴力
        progressBar.postDelayed(new Runnable() {
            @Override
            public void run() {
                progressBar.setVisibility(View.INVISIBLE);
            }
        }, 1000);
        if (!xwalkReady) {
            //注册广播
            registerMyReceiver();
        }
        xwalkReady = true;


    }

    private void setWebSettings() {
        mCrossWalkPresenter = new CrossWalkPresenter(this);
        settings = mCrossWalkPresenter.setWebViewSettings(mWebView);
        settings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);

        //不同分辨率的显示状态不同
        mWebView.setInitialScale(100);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(false);

        javaScriptinterface = new JavaScriptinterface(this);
        mWebView.addJavascriptInterface(javaScriptinterface, "android");
        mWebView.setWebChromeClient(getWebChromeClient());
        mWebView.setWebViewClient(getWebViewClient());
        //网络出现问题
        mWebView.getSettings().setBlockNetworkImage(false);

        //调试
        WebView.setWebContentsDebuggingEnabled(true);
    }

    private boolean showWebView() {
        mWebView.setVisibility(View.VISIBLE);

        return false;
    }

    private WebViewClient getWebViewClient() {
        WebViewClient webViewClient = new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "onPageFinished:url= " + url);
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);
                Log.d(TAG, "onReceivedHttpError: getStatusCode=" + errorResponse.getStatusCode());
                Log.d(TAG, "onReceivedHttpError: getReasonPhrase=" + errorResponse.getReasonPhrase());
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
//                getHtmlContent(VSConstances.ERR_CONNECTION_ABORTED);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Log.d(TAG, "onReceivedError: getErrorCode==" + error.getErrorCode());
                    switch (error.getErrorCode()) {
                        //与unReachable相同
                        case ERR_INTERNET_DISCONNECTED:
                            break;
                        case VSConstances.ERR_CONNECTION_TIMED_OUT:
                            break;
                        //-6
                        case VSConstances.ERR_CONNECTION_ABORTED:
                            //net::ERR_CONNEadb CTION_REFUSED
                            //ERR_CONNECTION_ABORTED 网络出现未知错误

                            break;
                        default:
                            break;
                    }
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Log.d(TAG, "shouldOverrideUrlLoading: " + view.getUrl());
                return super.shouldOverrideUrlLoading(view, request);
            }
        };
        return webViewClient;
    }

    private WebChromeClient getWebChromeClient() {
        WebChromeClient webChromeClient = new WebChromeClient() {

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d(TAG, "onConsoleMessage: " + consoleMessage.message());
                return super.onConsoleMessage(consoleMessage);
            }
        };
        return webChromeClient;
    }

    void getHtmlContent(final int requestCode) {
        Log.d(TAG, "getHtmlContent: " + requestCode);
        String var = "javascript:window.android.getHtml(document.body.innerHTML)";
        Log.d(TAG, "getHtmlContent: ");
        mWebView.evaluateJavascript(var, new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                //获取结果
                Log.d(TAG, "onReceiveValue:getHtmlContent= " + value);
                if (value != null) {
                    if (value.contains("网页无法加载")) {
                        //出现了异常,requestCode
                        if (true) {
                            //进入其它网页，提示重新刷新？
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("是否重新启动")
                                    .setPositiveButton("是", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            restartAPP(MainActivity.this);
                                        }
                                    })
                                    .setNegativeButton("否", null)
                                    .show();
                        }
                    } else {
                    }

                } else {
                    //没有显示网页无法加载
                }
            }
        });
    }

    ProgressBar progressBar;

    private void initOnCreate() {
        mWebView = findViewById(cn.gddiyi.cash.cashier.R.id.xwalkWebView);
        mWebView.setOnTouchListener(this);
        tipsTv = findViewById(cn.gddiyi.cash.cashier.R.id.tips);
        tipsTv.setVisibility(View.INVISIBLE);
        progressBar = findViewById(cn.gddiyi.cash.cashier.R.id.progressBar);
        linearLayout = findViewById(cn.gddiyi.cash.cashier.R.id.linearLayout);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        Log.d(TAG, "onTouch: " + event.getAction());
        return false;
    }

    /**
     * 打印机自测
     *
     * @param ip
     * @param printerMessage
     * @return
     */
    public String canPrintTest(String ip, final String printerMessage) {
        Log.d(TAG, "canPrintTest: " + printerMessage);
        if (findPrinterIdByIp(ip) != -1) {
            HOUCHU = findPrinterIdByIp(ip);
            //创建一个自测信息的runnable，放入到打印队列中
            final Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    //打印自测信息
                    mPrinterPresenter.printerSelf(HOUCHU, printerMessage);
                }
            };

            if (printOtherData(printerMessage, runnable, ip)) {
                return "false";
            }
            Log.d(TAG, "print:canPrintTest= ");
        }
        return null;
    }

    private boolean printOtherData(String printerMessage, Runnable runnable, String ip) {
        //需要将HOUCHU数据修改为Index
        if (findPrinterIdByIp(ip) != -1) {
            HOUCHU = findPrinterIdByIp(ip);
            if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU] == null ||
                    !DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU].getConnState(HOUCHU)) {
                Utils.toast(MainActivity.this, getString(cn.gddiyi.cash.cashier.R.string.str_cann_printer));
                if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU] != null) {
                    Log.d(TAG, "printOtherData:Connstate= " + DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU].getConnState(HOUCHU));
                    DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU].closePort(HOUCHU);
                    DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU] = null;
                }
                ;
                mPrinterPresenter.initPrinters(printersList.get(HOUCHU), printersList);
                return true;
            } else {
                //正常流程走的打印自测
                Log.d(TAG, "printOtherData: 打印数据");
                int index = findPrinterIdByIp(ip);
                mPrinterPresenter.printerSelf(HOUCHU, printerMessage);
                if (index != -1 && printersList.size() > 0) {
                    printersList.get(index).setMyPrinterSta(true);

                }
            }

        }
        return false;
    }

    private void printOrderListPutRunnable(Runnable runnable) {
        try {
            printOrderList.put(runnable);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * 打印单数据
     * 接收函数
     *
     * @param printType  打印单类型
     * @param oringnalJson 原始数据
     * @return 打印成功与否
     */
    boolean reConnectPrinterFlag = false;

    public String printFromJs(final int printType, final String oringnalJson) {
        final String json = oringnalJson;
        Log.d(TAG, "print:printType= " + printType);
        Log.d(TAG, "print: " + oringnalJson);
        String TAG = "printMessage";
        PrinterInfo printerInfo = null;
        int serveCopies = 1;
        try {
            //将传过来的原始数据转化打印数据对像
            final PrintData printData = gson.fromJson(json, PrintData.class);
            mPrinterPresenter.printLog(printData);
            //在JavaScript类中处理了，最后将打印机信息存储在printData.getPrinter()[0]中
            if (printData.getPrinter()[0] != null) {
                printerInfo = printData.getPrinter()[0].getPrinter();
            } else {
                printMytips("没有接收到打印机相关的字段");
            }
            if (printData.getPrinter()[0] != null) {
                serveCopies = printerInfo.getCopies();
            }
            String serveIP = printerInfo.getIp();
            //获取打印机IP地址和标题
            String printerIp = printerInfo.getIp();
            Log.d(TAG, "printFromJs:myServe传过来的打印类型 " + printType);
            Log.d(TAG, "print: myServe传过来的IP地址=" + printerIp + "***printType=" + printType);
            String title = printerInfo.getTitle();
            //检查传过来的是否为打印机
            printerInfo = checkIpBeforePrint(TAG, printerInfo, printerIp, title);
            if (printerInfo == null) {
                //注意，由于打印机IP错误，不添加到打印列表中，直接返回
                printMytips("提示：" + mPrinterPresenter.processTitle(title));
                return "false";
            }
            //一、再一次执行IP索引
            int index = findPrinterIdByIp(serveIP);
            if (index >= 0) {
                printerInfo = printersList.get(index);
                Log.d(TAG, "print:IP索引= " + printerInfo.getIp() + "##index= " + index);
                Log.d(TAG, "print:getMyPrinterSta " + printerInfo.getMyPrinterSta());
                if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[index] == null ||
                        !DeviceConnFactoryManager.getDeviceConnFactoryManagers()[index].getConnState(index)) {
                    Log.d(TAG, "print1:打印机断开了连接 " + printerInfo.getId());
                    if (!reConnectPrinterFlag) {
                        mHandler.sendEmptyMessageDelayed(RE_CONNECT_PRINTER, VSConstances.TIME_UNIT_MIN);
                        reConnectPrinterFlag = true;
                        tryConnectprinter1(printerInfo.getIp());
                        send2QueueDelay3s(printType, printData, printerInfo);
                    }
                    return "false";
                } else {
                    for (int i = 1; i <= serveCopies; i++) {
                        Log.d(TAG, "print: 打印份数" + i);
                        printData.setPrintCount(i + "");
                        //打印机状态正常时打印
                        if (printerInfo.getMyPrinterSta()) {
                            //打印前查询打印机状态
                            send2QueryBy4000(printerInfo);
                            send2QueueAndQuery(printType, printData, printerInfo);
                        } else {
                            tryConnectprinter1(printerInfo.getIp());
                            send2QueueDelay3s(printType, printData, printerInfo);
                        }
                    }
                }
            } else {
                printMytips("该IP地址的打印机不存在");
            }
        } catch (JsonSyntaxException e) {
            e.printStackTrace();
            printMytips("接收的数据无法打印，请联系迪溢科技");
            return "false";
        }
        return "true";
    }

    private void send2QueueDelay3s(final int printType, final PrintData printData, final PrinterInfo printerInfo) {
        mWebView.postDelayed(new Runnable() {
            @Override
            public void run() {
                send2QueueAndQuery(printType, printData, printerInfo);
            }
        }, 10_000);
    }

    boolean queryByOneIp = true;

    private void send2QueueAndQuery(final int printType, final PrintData printData, final PrinterInfo printerInfo) {
//        sendQueryCommandByIp(printerInfo.getIp());
        mWebView.postDelayed(new Runnable() {
            @Override
            public void run() {
                add2PrinttingQueue(printType, printData, printerInfo, true);
                queryByOneIp = true;
            }
        }, 200);

    }

    private void reConnectPrinter(PrinterInfo printerInfo) {
        if (!reConnectPrinterFlag) {
            tryConnectprinter1(printerInfo.getIp());
            mHandler.sendEmptyMessageDelayed(RE_CONNECT_PRINTER, VSConstances.TIME_UNIT_MIN);
        }
    }


    @NonNull
    private PrinterInfo checkIpBeforePrint(String TAG, PrinterInfo printerInfo, String printerIp, String title) {
        if (!mPrinterPresenter.isIP(printerIp)) {
            printMytips("打印机IP地址设置未按指定格式");
            return null;
        }
        int index = findPrinterIdByIp(printerIp);
        //查找对应打印机IP地址是否在本地打印机列表中，不存在返回-1
        if (index != -1) {
            //本地打印机列表存在，直接打印数据
            Log.d(TAG, "print: 已经添加了打印机" + index);
            printerInfo = printersList.get(index);
            printerInfo.setTitle(title);
            HOUCHU = index;
            // TODO: 2019/12/3  可能产生bug?
            printerInfo.setId(index);
            Log.d(TAG, "checkIpBeforePrint: getMyPrinterSta" + printerInfo.getMyPrinterSta());
            return printerInfo;
        } else {
//            printerInfo = getPrinterFromList(printerInfo.getIp(), "9100", printerInfo.getTitle());
//            //尝试连接接口传过来的打印机
//            mPrinterPresenter.initPrinters(printerInfo, printersList);
            Log.d(TAG, "打印机列表中不存在该打印机");
            return null;
        }
//        return printerInfo;
    }

    public void add2PrinttingQueue(final int printType, final PrintData printData, final PrinterInfo printerInfo, boolean canPrint) {
        //添加到打印机队列之前，检查打印机状态
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                Log.d(TAG, "run:" + "printerId=" + printerInfo.getId() + "+printerIp= " + printerInfo.getIp());
                boolean printerStatus = printerInfo.getMyPrinterSta();
                Log.d(TAG, "run: printerStatus====" + printerStatus);
                if (printerStatus) {
                    printNow(printType, printData, printerInfo);
                } else {
                    if (printType != QUERY_PRINTER_INT) {
                        add2FailOrderList(printType, printData, printerInfo);
                    }
                    printMytips(mPrinterPresenter.processTitle(printerInfo.getTitle()));
                }

            }
        };
        printOrderListPutRunnable(runnable);
    }

    private void add2FailOrderList(final int printType, final PrintData printData, final PrinterInfo printerInfo) {
        Log.d(TAG, "add2FailOrderList: " + printType);
        if (printerInfo.getIp() != null) {
            ArrayBlockingQueue<Runnable> arrayBlockingQueue = failOrder.get(printerInfo.getIp());
            arrayBlockingQueue.add(new Runnable() {
                @Override
                public void run() {
                    Log.d(TAG, "run:add2FailOrderList ");
                    printNow(printType, printData, printerInfo);
                }
            });
        }
    }

    synchronized private void printNow(int printType, PrintData printData, final PrinterInfo printerInfo) {
        //获取打印机索引
        HOUCHU = printerInfo.getId();
        Log.d(TAG, "printNow: " + HOUCHU);
        EscCommand ret = null;
        if (printData != null) {
            Log.d(TAG, "printNow:printType打印类型= " + printType);
            switch (printType) {
                //1 预结单
                case ConigInfo.YUJIE_ORDER:
                    ret = mPrinterPresenter.printYuJieOrder(printData, HOUCHU, printType);
                    break;
                //2 结帐单
                case ConigInfo.JIEZHAANG_ORDER:
                    ret = mPrinterPresenter.printJieZhangOrder(printData, HOUCHU, printType);
                    break;
                //3 传菜单
                case ConigInfo.CHUANCAI_ORDER:
                    ret = mPrinterPresenter.printChuanCaiDan(printData, HOUCHU, printType);
                    break;
                //4 制作单
                case ConigInfo.ZHIZUO_ORDER:
                    ret = mPrinterPresenter.printZhiZuoOrder(printData, HOUCHU, printType);

                    break;
                //5 退菜单
                case ConigInfo.TUICAI_ORDER:
                    ret = mPrinterPresenter.printTuiChaiDan(printData, printType, HOUCHU);
                    break;
                //6 转台单
                case ConigInfo.ZHUANGTAI_ORDER:
                    ret = mPrinterPresenter.printZhuangTaiDan(printData, HOUCHU, printType);
                    break;
                //7 催菜单
                case ConigInfo.CUICAI_ORDER:
                    ret = mPrinterPresenter.printTuiChaiDan(printData, printType, HOUCHU);
                    break;
                case QUERY_PRINTER_INT:
                    putQueryRunable(printerInfo.getId());
                    break;
                default:
                    break;
            }
            Log.d(TAG, "printNow: ret=" + ret);
        } else {
            printMytips("打印数据不能为空");
        }
    }


    public static final Gson gson = new Gson();

    public static boolean mHideInputMethod = false;
    boolean canQueryBy4000Port = true;

    public void takeOne(View view) {
//        if (printersList != null && printersList.size() > 0) {
//            for (PrinterInfo printerInfo : printersList) {
//                final QueryBy4000Port queryBy4000Port = QueryBy4000Port.getInstance();
//                queryBy4000Port.queryPrinterStatus(printerInfo);
//            }
//        }

//        Log.d(TAG, "takeOne:ActivityName= " + SystemUtils.getRunningPackageName(this));


        Log.d(TAG, "takeOne: ");


//        textToSpeech.speak("您有新的订单A003，请及时查收",
//                TextToSpeech.QUEUE_FLUSH, null);
        Log.d(TAG, "takeOne: "+textToSpeech.getVoice().getName());
        Log.d(TAG, "takeOne: isNetworkConnectionRequired="+textToSpeech.getVoice().isNetworkConnectionRequired());
    }

    public String playVoice(String voiceContent) {
        textToSpeech.speak(voiceContent,
                TextToSpeech.QUEUE_FLUSH, null);
        return "";
    }

    public void hideInputMethod() {
        Log.d(TAG, "hideInputMethod: 修改");
        mHideInputMethod = true;
    }

    void printMytips(final String str) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void test(View view) {
        int index = findPrinterIdByIp("192.168.0.50");
        PrinterInfo printerInfo = printersList.get(index);
        Log.d(TAG, "test:引用结果= " + printerInfo.getIp() + "==status=" + printerInfo.getMyPrinterSta());
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop: 弹出退出提示框");
//        Intent intent = new Intent();
//        intent.setAction(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
//        intent.setData(Uri.parse("package:"+getPackageName()));
//        startActivity(intent);
//        Settings.canDrawOverlays(MainActivity.this);

    }


    /**
     * 连接成功信息
     *
     * @param ethernetPort
     * @param ip
     * @param printerId
     * @param connSuccessful
     * @return
     */
    @Override
    public int printterMessage(EthernetPort ethernetPort, String ip, int printerId, boolean connSuccessful) {
        Log.d(TAG, "printterMessage: Ip=" + ip);
        Log.d(TAG, "printterMessage: printerId=" + printerId);
        Log.d(TAG, "printterMessage: connSuccessful=" + connSuccessful);

        int index = findPrinterIdByIp(ip);
        if (index == -1) {
            return 0;
        }
        PrinterInfo printerInfo = printersList.get(index);

        if (!printerThreadStarted) {
            printerThreadStarted = true;
            // sendEmptyMessageDelayed(HANDLE_QUERY_PRINTER_STATUS, VSConstances.TIME_UNIT_MIN);
            startPrinterThread();
        }
        if (connSuccessful) {
            Log.d(TAG, "printterMessage:if ");
            printerInfo.setQueryStatus(true);
            if (printerInfo != null) {
                printerInfo.setMyPrinterSta(true);
                printMytips(printerInfo.getTitle() + "已连接");
                reAdd2PrinterQueue(ip);
            }
        } else {
            printerInfo.setMyPrinterSta(false);
            Log.d(TAG, "printterMessage:title= " + printerInfo.getTitle());
            String printerTitle = mPrinterPresenter.processTitle(printerInfo.getTitle());
            //不弹出提示
            //printMytips(printerTitle);
        }
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("status", printerInfo.getMyPrinterSta());
        jsonObject.addProperty("ip", printerInfo.getIp());
        Log.d(TAG, "printterMessage: " + jsonObject.toString());
        sendPrinterStatus2Js(jsonObject.toString());
        return 0;
    }

    @Override
    public int printerCheckIoException(EthernetPort ethernetPort, String ip, boolean status) {
        Log.d(TAG, "printerCheckIoException: status=" + status);
        Log.d(TAG, "printerCheckIoException: ip=" + ip);

        int index = findPrinterIdByIp(ip);
        if (!status) {
            if (index != -1 && printersList != null) {
                PrinterInfo printerInfo = printersList.get(index);
                //关闭端口
                if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[index] != null) {
                    DeviceConnFactoryManager.getDeviceConnFactoryManagers()[index].closePort(index);
                }
            }
        }

        return 0;
    }


    @Override
    public int socketTimeoutException(String ip, int id) {
        return 0;
    }

    private void reAdd2PrinterQueue(String ip) {
        ArrayBlockingQueue<Runnable> arrayBlockingQueue = failOrder.get(ip);
        Runnable runnable;
        int i = 0;
        while ((runnable = arrayBlockingQueue.poll()) != null) {
            Log.d(TAG, "reAdd2PrinterQueue: " + (++i));
            try {
                printOrderList.put(runnable);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * IpList未使用考虑去除掉
     */
    ArrayList<PrinterInfo> IpList = new ArrayList<>();
    int printerIndex = 0;

    public String getIpList(String ipList) {
        Log.d(TAG, "getIpListALL: " + ipList);
        printerIndex = 0;
        IpList.clear();
        try {
            JSONArray jsonArray = new JSONArray(ipList);
            int length = jsonArray.length();
            Log.d(TAG, "getIpList:length= " + length);

            for (int i = 0; i <= (length - 1); i++) {
                String ipInfo = jsonArray.getString(i);
                Log.d(TAG, "getIpList: " + ipInfo);
                JSONObject jsonObject = new JSONObject(ipInfo);
                String ip = (String) jsonObject.get("target");
                Log.d(TAG, "getIpList:target= " + ip);
                String title = (String) jsonObject.get("title");
                if (mPrinterPresenter.isIP(ip)) {
                    Log.d(TAG, "getIpList:Ip== " + ip);
                    PrinterInfo printerInfo = getPrinterFromList(ip, "9100", title);
                    printerInfo.setId(printerIndex);
                    Log.d(TAG, "getIpList: 当前的index=" + i);
                    printerInfo.setTitle(title);
                    IpList.add(printerInfo);
                    //缓存失败的队列
                    ArrayBlockingQueue<Runnable> failOrderList = new ArrayBlockingQueue<>(20);
                    failOrder.put(printerInfo.getIp(), failOrderList);
                    mPrinterPresenter.initPrinters(printerInfo, printersList);
                    printerIndex++;
                }
            }
        } catch (JSONException e) {
            Log.d(TAG, "getIpList: " + e.toString());
            e.printStackTrace();
        }
        return "";
    }

    String beforeSaveIpFromJS = "";

    public String beforeSaveIp(String json) {
        Log.d(TAG, "beforeSaveOneIp: " + json);
        try {
            JSONObject jsonObject = null;
            jsonObject = new JSONObject(json);
            beforeSaveIpFromJS = (String) jsonObject.get("target");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return "";
    }

    public String saveOneIp(String ServerPrintInfo) {
        Log.d(TAG, "saveOneIp: " + ServerPrintInfo);
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(ServerPrintInfo);
            String ip = (String) jsonObject.get("target");
            String title = (String) jsonObject.get("title");
//            int size = jsonObject.getInt("size");
            Log.d(TAG, "saveOneIp: " + ip);
            int index = findPrinterIdByIp(ip);
            if (index != -1) {
                PrinterInfo printInfo = printersList.get(index);
                printInfo.setTitle(title);
            } else {
                // TODO: 2019/12/20  
                int currentIndex = -1;
                if (mPrinterPresenter.isIP(ip)) {
                    if (!TextUtils.isEmpty(beforeSaveIpFromJS)) {
                        if (mPrinterPresenter.isIP(beforeSaveIpFromJS)) {
                            currentIndex = findPrinterIdByIp(beforeSaveIpFromJS);
                        }
                    }
                    Log.d(TAG, "getIpList:Ip== " + ip);
                    PrinterInfo printerInfo = getPrinterFromList(ip, "9100", title);
                    if (currentIndex != -1) {
                        //修改了打印机的IP,需要关闭掉打印机,否则出故障
                        closePrinter(currentIndex);
                        printerInfo.setId(currentIndex);

                    } else {
                        //添加打印机
                        if (printersList != null) {
                            PrinterInfo firAddPrinter = new PrinterInfo();
                            firAddPrinter.setIp(ip);
                            firAddPrinter.setTitle(title);
                            firAddPrinter.setPort("9100");
                            printersList.add(firAddPrinter);
                            int indexx = printersList.indexOf(firAddPrinter);
                            firAddPrinter.setId(indexx);
                            printerInfo = printersList.get(indexx);
                        }
                    }

                    printerInfo.setTitle(title);
//                  printerInfo.setSize(size);
                    IpList.add(printerInfo);
                    //缓存失败的队列
                    ArrayBlockingQueue<Runnable> failOrderList = new ArrayBlockingQueue<>(20);
                    failOrder.put(printerInfo.getIp(), failOrderList);
                    mPrinterPresenter.initPrinters(printerInfo, printersList);
                }
            }
        } catch (JSONException e) {

            e.printStackTrace();

        }
        //查询打印机状态
        return null;
    }

    private void closePrinter(int HOUCHU) {
        if (DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU] == null
                || !DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU].getConnState(HOUCHU)
        ) {
            return;
        } else {
            Log.d(TAG, "closePrinter: else");
            DeviceConnFactoryManager.getDeviceConnFactoryManagers()[HOUCHU].closePort(HOUCHU);
        }
        Log.d(TAG, "closePrinter: ");
    }

    @Override
    public int printerReadListsner(String printerIp, int printerId) {
        if (printersList != null && printersList.size() > printerId) {
            printMytips(mPrinterPresenter.processTitle(printersList.get(printerId).getTitle()));
        }

        return 0;
    }

    /**
     * JS 请求打印机状态信息
     *
     * @param json
     * @return
     */
    public String queryPrinterFromJs(String json) {
        //查询的打印机状态
        if (!TextUtils.isEmpty(json) && (!json.equals("1"))) {
            try {
                JSONObject jsonObject = null;
                jsonObject = new JSONObject(json);
                String ip = (String) jsonObject.get("target");
                final QueryBy4000Port queryBy4000Port = QueryBy4000Port.getInstance();
                PrinterInfo printerInfo = new PrinterInfo();
                printerInfo.setIp(ip);
                queryBy4000Port.queryPrinterStatus(printerInfo);
            } catch (Exception e) {
                printMytips("数据有误");
            }

            return "false";
        }
        if (printersList != null && printersList.size() > 0) {
            for (PrinterInfo printerInfo : printersList) {
                final QueryBy4000Port queryBy4000Port = QueryBy4000Port.getInstance();
                Log.d(TAG, "queryPrinterFromJs: " + printerInfo.getId() + "==ip=" + printerInfo.getIp());
                queryBy4000Port.queryPrinterStatus(printerInfo);
            }
        }

        return "";
    }

    public void send2QueryBy4000(PrinterInfo printerInfo) {
        final QueryBy4000Port queryBy4000Port = QueryBy4000Port.getInstance();
        Log.d(TAG, "打印前查询=: " + printerInfo.getId() + "==ip=" + printerInfo.getIp());
        queryBy4000Port.queryPrinterStatus(printerInfo);
    }

    /**
     * 返回打印机状态信息给JS
     *
     * @param printerInfo
     * @param status
     * @return
     */
    @Override
    public int currentState(PrinterInfo printerInfo, boolean status) {
        Log.d(TAG, "currentState: " + status);
        Log.d(TAG, "currentState: " + printerInfo.getIp());
        //可能影响打印机的状态
        String getIP = printerInfo.getIp();
        boolean myPrinterSta = getCurrent9100PortStatus(printerInfo, getIP);
        JsonObject jsonObject = new JsonObject();
        if (!myPrinterSta) {
            if (status) {
                Log.d(TAG, "currentState:Id= " + printerInfo.getId());
                printMytips(printerInfo.getTitle() + "脱机,请检查打印机");
                tryConnectprinter1(printerInfo.getIp());
            }
            jsonObject.addProperty("status", false);
        } else {
            jsonObject.addProperty("status", status);
            printerInfo.setMyPrinterSta(status);
        }

        jsonObject.addProperty("ip", printerInfo.getIp());
        //打印机本地的状态的修改
        final String json = jsonObject.toString();
        Log.d(TAG, "currentState: " + json);
        if (mWebView != null) {
            sendPrinterStatus2Js(json);
        }

        return 0;
    }

    private boolean getCurrent9100PortStatus(PrinterInfo printerInfo, String getIP) {
        boolean myPrinterSta = printerInfo.getMyPrinterSta();
        int indexIp = findPrinterIdByIp(getIP);
        if (printersList != null && printersList.size() > 0) {
            if (indexIp != -1) {
                PrinterInfo pr = printersList.get(indexIp);
                myPrinterSta = pr.getMyPrinterSta();
            }
        }
        Log.d(TAG, "currentState: " + myPrinterSta);
        return myPrinterSta;
    }

    private void sendPrinterStatus2Js(final String json) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mWebView.evaluateJavascript("javascript:printerStatus(" + json + ")", null);
            }
        });
    }

    @Override
    protected void onStart() {

        super.onStart();
    }


}
