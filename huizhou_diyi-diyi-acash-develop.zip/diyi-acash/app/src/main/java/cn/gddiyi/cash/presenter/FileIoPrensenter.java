package cn.gddiyi.cash.presenter;



import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import cn.gddiyi.cash.controler.MyThreadPool;

public class FileIoPrensenter {
   final String TAG=getClass().getSimpleName();
    public String ReadFile(final String path) {
        String laststr = null;
        final Future<String> result = MyThreadPool.getExeCutor().submit(new Callable<String>() {
            @Override
            public String call() {
                File file = new File(path);
                BufferedReader reader = null;
                String laststr = "";
                try {
                    reader = new BufferedReader(new FileReader(file));
                    String tempString ;
                    //一次读入一行，直到读入null为文件结束
                    while ((tempString = reader.readLine()) != null) {
                        //显示行号
                        laststr = tempString;
                    }
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e1) {
                        }
                    }
                }
                return laststr;
            }
        });
       //下面这段代码不能删除，否则报错，是属于获取结果返回
//        try {
//            Log.i(TAG, "ReadFile:result.get()= " + result.get());
//        } catch (ExecutionException e) {
//            e.printStackTrace();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
        try {
            laststr = result.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return laststr;
    }

    public void writeFile(final String filePath, final String sets) {
        MyThreadPool.getExeCutor().execute(new Runnable() {
            @Override
            public void run() {
                try {

                    FileWriter fw = new FileWriter(filePath);
                    PrintWriter out = new PrintWriter(fw);
                    out.write(sets);
                    out.println();
                    fw.close();
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

    }
}
