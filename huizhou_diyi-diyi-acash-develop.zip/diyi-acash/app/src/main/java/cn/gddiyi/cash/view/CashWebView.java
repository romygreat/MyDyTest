package cn.gddiyi.cash.view;


import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;


import cn.gddiyi.cash.YidiApplication;
import cn.gddiyi.cash.constant.VSConstances;
import cn.gddiyi.cash.customview.MyWebView;
import cn.gddiyi.cash.jsinterface.JavaScriptinterface;
import cn.gddiyi.cash.presenter.CrossWalkPresenter;

public class CashWebView extends BaseActivity  implements View.OnTouchListener{
    public MyWebView mWebView;
    final static String TAG = "CashWebView";
    JavaScriptinterface javaScriptinterface;
    WebSettings settings;
    CrossWalkPresenter mCrossWalkPresenter;
    TextView tipsTv;
    LinearLayout linearLayout;
    Button videoExitbt;
    Handler mWebViewHandler;

    @Override
    protected void onXWalkReady() {
         setWebSettings();
        windowSettingImpls.setWindowListener(this);
        mWebView.loadUrl("http://cash.dev.gddiyi.cn/");
        showWebView();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        super.onCreate(savedInstanceState);
            initOnCreate();
            mWebViewHandler =new Handler(getMainLooper()){
                @Override
                public void handleMessage(Message msg) {
                    linearLayout.setVisibility(View.INVISIBLE);
                }
            }
            ;
    }

    private void initOnCreate() {
            setContentView(cn.gddiyi.cash.cashier.R.layout.crosswalk);
            mWebView = findViewById(cn.gddiyi.cash.cashier.R.id.xwalkWebView);
            mWebView.setOnTouchListener(this);
            tipsTv =findViewById(cn.gddiyi.cash.cashier.R.id.tips);
            tipsTv.setVisibility(View.INVISIBLE);
            linearLayout=findViewById(cn.gddiyi.cash.cashier.R.id.linearLayout);
            linearLayout.setVisibility(View.VISIBLE);
            videoExitbt=findViewById(cn.gddiyi.cash.cashier.R.id.videoExit);
            videoExitbt.setBackgroundColor(Color.BLACK);
            videoExitbt.setTextColor(Color.WHITE);
            videoExitbt.setText("退出视频");
            videoExitbt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    restartAPP(CashWebView.this);
                }
            });
    }
    private void setWebSettings() {
        mCrossWalkPresenter=new CrossWalkPresenter(this);
        settings = mCrossWalkPresenter.setWebViewSettings(mWebView);

        javaScriptinterface = new JavaScriptinterface(this);
        mWebView.addJavascriptInterface(javaScriptinterface, "android");
        mWebView.setWebChromeClient(getWebChromeClient());
        mWebView.setWebViewClient(getWebViewClient());
        //网络出现问题
        mWebView.getSettings().setBlockNetworkImage(false);
        //调试
        WebView.setWebContentsDebuggingEnabled(true);
    }

    private WebViewClient getWebViewClient() {
        WebViewClient webViewClient=new WebViewClient(){
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(TAG, "onPageFinished:url= "+url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Log.d(TAG, "shouldOverrideUrlLoading: "+view.getUrl());
                return super.shouldOverrideUrlLoading(view, request);
            }
        };
        return webViewClient;
    }


    private WebChromeClient getWebChromeClient() {
        WebChromeClient webChromeClient = new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d(TAG, "onConsoleMessage: " + consoleMessage.message());
                return super.onConsoleMessage(consoleMessage);
            }
        };
        return webChromeClient;
    }

    private boolean showWebView() {
        mWebView.setVisibility(View.VISIBLE);
        return false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        onXWalkReady();
    }
    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.CROSSWALK_ACTIVITY);
    }


    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (MotionEvent.ACTION_DOWN==event.getAction()){
        linearLayout.setVisibility(View.VISIBLE);
        if (!mWebViewHandler.hasMessages(0))
        { mWebViewHandler.sendEmptyMessageDelayed(0,3000);}
        }
        return false;
    }


}

