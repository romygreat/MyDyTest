package cn.gddiyi.cash.view;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;



import cn.gddiyi.cash.YidiApplication;
import cn.gddiyi.cash.constant.VSConstances;



public class ConsoleErrorActivity extends BaseActivity {

    TextView tvInfo;
    int errorInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(cn.gddiyi.cash.cashier.R.layout.errormessage);
        Intent intent = getIntent();
        errorInfo = intent.getIntExtra(getString(cn.gddiyi.cash.cashier.R.string.errorInfo), 0);
        initView();
        messageTips();
        currentActivity();

    }

    private void messageTips() {
        String tips = "温馨提示，页面出现未知异常！";
        switch (errorInfo) {
            case VSConstances.ERR_CONNECTION_TIMED_OUT:
                tips = "提示：加载页面超时";
                break;
            case VSConstances.ONRECEIVALUE:
                tips = "无法加载网页";
                break;
            default:
                break;
        }
        tvInfo.setText(tips);
    }

    @Override
    public void currentActivity() {
        ((YidiApplication) getApplication()).setCurrentActivityPage(VSConstances.CONSOLEERROR_ACTIVITY);
    }

    private void initView() {
        tvInfo = findViewById(cn.gddiyi.cash.cashier.R.id.errorInfo);

    }

    public void fresh(View view) {
         restartAPP(this);
//        this.finish();
    }
}
