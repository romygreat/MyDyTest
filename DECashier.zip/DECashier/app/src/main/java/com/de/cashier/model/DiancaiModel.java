package com.de.cashier.model;

public class DiancaiModel {

    private String foodName;
    private float foodNum;
    private float foodPrice;

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public float getFoodNum() {
        return foodNum;
    }

    public void setFoodNum(float foodNum) {
        this.foodNum = foodNum;
    }

    public float getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(float foodPrice) {
        this.foodPrice = foodPrice;
    }
}
