package com.de.cashier.model;

import java.util.List;

public class FoodListModel {

    private String code;
    private String message;
    private boolean status;
    private FoodData data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public FoodData getData() {
        return data;
    }

    public void setData(FoodData data) {
        this.data = data;
    }

    public static class FoodData{
        private int total;
        private List<Food> list;

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public List<Food> getList() {
            return list;
        }

        public void setList(List<Food> list) {
            this.list = list;
        }

        public static class Food{
            private int id;
            private int sort;
            private int shop_id;
            private int cate_id;
            private String name;
            private String initial;
            private String code;
            private String describe;
            private String price;
            private String market_price;
            private String pic;
            private boolean is_sale;
            private boolean is_limit;
            private int limit_num;
            private boolean is_editable;
            private boolean is_side_dish;
            private boolean is_taste;
            private boolean is_procedure;
            private String remark;
            private String create_time;
            private String sales;
            private String unit;
            private String appraise;
            private String appr_num;
            private String delete_time;
            private String update_time;
            private boolean is_current;
            private String sign;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public int getSort() {
                return sort;
            }

            public void setSort(int sort) {
                this.sort = sort;
            }

            public int getShop_id() {
                return shop_id;
            }

            public void setShop_id(int shop_id) {
                this.shop_id = shop_id;
            }

            public int getCate_id() {
                return cate_id;
            }

            public void setCate_id(int cate_id) {
                this.cate_id = cate_id;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getInitial() {
                return initial;
            }

            public void setInitial(String initial) {
                this.initial = initial;
            }

            public String getCode() {
                return code;
            }

            public void setCode(String code) {
                this.code = code;
            }

            public String getDescribe() {
                return describe;
            }

            public void setDescribe(String describe) {
                this.describe = describe;
            }

            public String getPrice() {
                return price;
            }

            public void setPrice(String price) {
                this.price = price;
            }

            public String getMarket_price() {
                return market_price;
            }

            public void setMarket_price(String market_price) {
                this.market_price = market_price;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public boolean isIs_sale() {
                return is_sale;
            }

            public void setIs_sale(boolean is_sale) {
                this.is_sale = is_sale;
            }

            public boolean isIs_limit() {
                return is_limit;
            }

            public void setIs_limit(boolean is_limit) {
                this.is_limit = is_limit;
            }

            public int getLimit_num() {
                return limit_num;
            }

            public void setLimit_num(int limit_num) {
                this.limit_num = limit_num;
            }

            public boolean isIs_editable() {
                return is_editable;
            }

            public void setIs_editable(boolean is_editable) {
                this.is_editable = is_editable;
            }

            public boolean isIs_side_dish() {
                return is_side_dish;
            }

            public void setIs_side_dish(boolean is_side_dish) {
                this.is_side_dish = is_side_dish;
            }

            public boolean isIs_taste() {
                return is_taste;
            }

            public void setIs_taste(boolean is_taste) {
                this.is_taste = is_taste;
            }

            public boolean isIs_procedure() {
                return is_procedure;
            }

            public void setIs_procedure(boolean is_procedure) {
                this.is_procedure = is_procedure;
            }

            public String getRemark() {
                return remark;
            }

            public void setRemark(String remark) {
                this.remark = remark;
            }

            public String getCreate_time() {
                return create_time;
            }

            public void setCreate_time(String create_time) {
                this.create_time = create_time;
            }

            public String getSales() {
                return sales;
            }

            public void setSales(String sales) {
                this.sales = sales;
            }

            public String getUnit() {
                return unit;
            }

            public void setUnit(String unit) {
                this.unit = unit;
            }

            public String getAppraise() {
                return appraise;
            }

            public void setAppraise(String appraise) {
                this.appraise = appraise;
            }

            public String getAppr_num() {
                return appr_num;
            }

            public void setAppr_num(String appr_num) {
                this.appr_num = appr_num;
            }

            public String getDelete_time() {
                return delete_time;
            }

            public void setDelete_time(String delete_time) {
                this.delete_time = delete_time;
            }

            public String getUpdate_time() {
                return update_time;
            }

            public void setUpdate_time(String update_time) {
                this.update_time = update_time;
            }

            public boolean isIs_current() {
                return is_current;
            }

            public void setIs_current(boolean is_current) {
                this.is_current = is_current;
            }

            public String getSign() {
                return sign;
            }

            public void setSign(String sign) {
                this.sign = sign;
            }
        }
    }
}
