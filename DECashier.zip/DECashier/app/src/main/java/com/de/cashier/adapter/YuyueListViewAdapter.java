package com.de.cashier.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.de.cashier.R;
import com.de.cashier.fragment.GuqingFragment;
import com.de.cashier.fragment.YuyueFragment;
import com.de.cashier.layout.ConfirmDialog;
import com.de.cashier.layout.GuqingDialog;
import com.de.cashier.layout.YuyueEditDialog;
import com.de.cashier.model.GuqingListModel;
import com.de.cashier.model.TableModel;
import com.de.cashier.model.YuyueListModel;
import com.de.cashier.util.MapperUtils;
import com.de.cashier.util.OkHttpClientUtil;
import com.de.cashier.util.UrlUtil;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class YuyueListViewAdapter extends BaseAdapter {

    private YuyueListModel yuyueListModel;
    private LayoutInflater layoutInflater;
    private Context context;
    private int mCurrentItem = 0;
    private boolean isClick = false;
    private String token;
    private GuqingDialog.Builder guqingBuilder;
    private GuqingDialog guqingDialog;
    private ConfirmDialog.Builder confirmBuilder;
    private ConfirmDialog confirmDialog;
    private YuyueEditDialog.Builder yuyueEditBuilder;
    private YuyueEditDialog yuyueEditDialog;
    private TableModel tableModel;
    private String time;
    private int id;
    private String num;
    private int suotai;
    private String remark;
    private String name;
    private String tel;
    private int tableId;
    private String tableTitle;

    public YuyueListViewAdapter(Context context, YuyueListModel yuyueListModel, String token, TableModel tableModel){
        this.context = context;
        this.yuyueListModel = yuyueListModel;
        this.layoutInflater = LayoutInflater.from(context);
        this.token = token;
        this.tableModel = tableModel;
    }

    public final class MyView{
        public TextView time;
        public TextView name;
        public TextView num;
        public TextView tel;
        public TextView tableNo;
        public TextView remark;
        public TextView edit;
        public TextView delete;
    }

    @Override
    public int getCount() {
        return yuyueListModel.getList().size();
    }

    @Override
    public Object getItem(int position) {
        return yuyueListModel.getList().get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        MyView myView = null;
        if(convertView==null){
            myView=new MyView();
            //获得组件，实例化组件
            convertView=layoutInflater.inflate(R.layout.item_listview_yuyue, null);
            myView.name=(TextView)convertView.findViewById(R.id.item_yuyue_name);
            myView.time=(TextView)convertView.findViewById(R.id.item_yuyue_datetime);
            myView.num=(TextView)convertView.findViewById(R.id.item_yuyue_num);
            myView.tel=(TextView)convertView.findViewById(R.id.item_yuyue_tel);
            myView.remark=(TextView)convertView.findViewById(R.id.item_yuyue_remark);
            myView.tableNo=(TextView)convertView.findViewById(R.id.item_yuyue_tableno);
            myView.edit=(TextView)convertView.findViewById(R.id.item_yuyue_edit);
            myView.delete=(TextView)convertView.findViewById(R.id.item_yuyue_delete);

            convertView.setTag(myView);
        }else{
            myView=(MyView)convertView.getTag();
        }
        //绑定数据
        myView.time.setText(yuyueListModel.getList().get(position).getStart_time());
        myView.name.setText(yuyueListModel.getList().get(position).getRepast_name());
        myView.num.setText(yuyueListModel.getList().get(position).getRepast_num()+"");
        myView.tel.setText(yuyueListModel.getList().get(position).getRepast_phone());
        if(yuyueListModel.getList().get(position).getRemark().length() > 10) {
            myView.remark.setText(yuyueListModel.getList().get(position).getRemark().substring(0, 10) + "...");
        }else{
            myView.remark.setText(yuyueListModel.getList().get(position).getRemark());
        }
        myView.tableNo.setText(yuyueListModel.getList().get(position).getTable_title());

        myView.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yuyueEditBuilder = new YuyueEditDialog.Builder(context, yuyueListModel.getList().get(position), tableModel);
                yuyueEditBuilder.setPositiveButton("取消", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                yuyueEditBuilder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, int which) {
                        time = yuyueEditBuilder.getTime();
                        id = yuyueListModel.getList().get(position).getId();
                        num = yuyueEditBuilder.getNum();
                        suotai = yuyueEditBuilder.getIsSuotai();
                        remark = yuyueEditBuilder.getRemark();
                        name = yuyueEditBuilder.getName();
                        tel = yuyueEditBuilder.getTel();
                        tableId = yuyueEditBuilder.getTableid();
                        tableTitle = yuyueEditBuilder.getTableTitle();

                        edit(time + ":00", id, Integer.parseInt(num), suotai, remark, name, tel, tableId+"", position);
                    }
                });
                yuyueEditDialog = yuyueEditBuilder.create();
                yuyueEditDialog.show();
            }
        });

        myView.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmBuilder = new ConfirmDialog.Builder(context);
                confirmBuilder.setPositiveButton("取消", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                confirmBuilder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, int which) {
                        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
                        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
                        Map<String, Object> map = new HashMap<String, Object>();
                        map.put("id", yuyueListModel.getList().get(position).getId());
                        map.put("token", token);
                        map.put("machine", "shop");
                        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
                        final Request request = new Request.Builder()
                                .url(UrlUtil.SERVERIP + "/shop/ShopReserve/shopReserveDel")
                                .addHeader("Content-Type", "application/json")
                                .post(body)
                                .build();
                        okHttpClient.newCall(request).enqueue(new Callback() {
                            @Override
                            public void onFailure(Call call, IOException e) {

                            }

                            @Override
                            public void onResponse(Call call, Response response) throws IOException {

                                String result = response.body().string();
                                try {
                                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                                    if("1".equals(String.valueOf(map.get("code")))) {
                                        Message msg = Message.obtain();
                                        msg.what = 0;
                                        msg.obj = position;
                                        handler.sendMessage(msg);
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            }
                        });
                    }
                });
                confirmDialog = confirmBuilder.create();
                confirmDialog.show();


            }
        });

        return convertView;
    }

    public void setCurrentItem(int currentItem){
        this.mCurrentItem = currentItem;
    }

    public void setClick(boolean click){
        this.isClick = click;
    }

    private void edit(String time, final int id, int num, int suotai, String remark, String name, String tel, String tableId, final int position){
        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("start_time", time);
        if(id != -1) {
            map.put("id", id);
        }
        map.put("repast_num", num);
        map.put("is_open", suotai);
        map.put("remark", remark);
        map.put("repast_name", name);
        map.put("repast_phone", tel);
        if(!"-1".equals(tableId)) {
            map.put("table_id", tableId);
        }
        map.put("token", token);
        map.put("machine", "shop");
        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
        final Request request = new Request.Builder()
                .url(UrlUtil.SERVERIP + "/shop/ShopReserve/shopReserveSave")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String result = response.body().string();
                try {
                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                    if("1".equals(String.valueOf(map.get("code")))) {
//                        yuyueListModel = MapperUtils.json2pojo(result, YuyueListModel.class);
                        Message msg = Message.obtain();
                        msg.what = 1;
                        msg.obj = position;
                        handler.sendMessage(msg);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }
    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.what == 0) {
                int positon = (int) msg.obj;
                yuyueListModel.getList().remove(positon);
                notifyDataSetChanged();
                confirmDialog.dismiss();
                Toast.makeText(context, "操作成功！", Toast.LENGTH_LONG).show();
            }else if (msg.what == 1) {
                Message message = Message.obtain();
                msg.what = 0;
                YuyueFragment.handler2.sendMessage(message);
                yuyueEditDialog.dismiss();
                Toast.makeText(context, "操作成功！", Toast.LENGTH_LONG).show();
            }
            return false;
        }
    });

}

