package com.de.cashier.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.de.cashier.R;
import com.de.cashier.fragment.GuqingFragment;
import com.de.cashier.layout.ConfirmDialog;
import com.de.cashier.layout.GuqingDialog;
import com.de.cashier.model.GuqingListModel;
import com.de.cashier.util.MapperUtils;
import com.de.cashier.util.OkHttpClientUtil;
import com.de.cashier.util.UrlUtil;
import com.qmuiteam.qmui.widget.dialog.QMUIDialog;
import com.qmuiteam.qmui.widget.dialog.QMUIDialogAction;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class GuqingListViewAdapter extends BaseAdapter {

    private GuqingListModel guqingModel;
    private LayoutInflater layoutInflater;
    private Context context;
    private int mCurrentItem = 0;
    private boolean isClick = false;
    private String token;
    private GuqingDialog.Builder guqingBuilder;
    private GuqingDialog guqingDialog;
    private ConfirmDialog.Builder confirmBuilder;
    private ConfirmDialog confirmDialog;

    public GuqingListViewAdapter(Context context, GuqingListModel guqingModel, String token){
        this.context = context;
        this.guqingModel = guqingModel;
        this.layoutInflater = LayoutInflater.from(context);
        this.token = token;
    }

    public final class MyView{
        public TextView name;
        public TextView kucun;
        public TextView edit;
        public TextView delete;
    }

    @Override
    public int getCount() {
        return guqingModel.getData().getList().size();
    }

    @Override
    public Object getItem(int position) {
        return guqingModel.getData().getList().get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        MyView myView = null;
        if(convertView==null){
            myView=new MyView();
            //获得组件，实例化组件
            convertView=layoutInflater.inflate(R.layout.item_listview_guqing, null);
            myView.name=(TextView)convertView.findViewById(R.id.item_list_guqing_name);
            myView.kucun=(TextView)convertView.findViewById(R.id.item_list_guqing_kucun);
            myView.edit=(TextView)convertView.findViewById(R.id.item_list_guqing_edit);
            myView.delete=(TextView)convertView.findViewById(R.id.item_list_guqing_delete);

            convertView.setTag(myView);
        }else{
            myView=(MyView)convertView.getTag();
        }
        //绑定数据
        myView.name.setText(guqingModel.getData().getList().get(position).getName());
        if(guqingModel.getData().getList().get(position).getLimit_num() > 0){
            myView.kucun.setText(guqingModel.getData().getList().get(position).getLimit_num() + " 份");
        }else{
            myView.kucun.setText("已估清");
        }

        myView.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guqingBuilder = new GuqingDialog.Builder(context);
                guqingBuilder.setPositiveButton("确认估清", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, int which) {

                        String num = guqingBuilder.getNum();
                        guqing("edit", 1, Integer.parseInt(num), guqingModel.getData().getList().get(position).getId());

                    }
                });
                guqingDialog = guqingBuilder.create();
                guqingDialog.show();
            }
        });

        myView.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmBuilder = new ConfirmDialog.Builder(context);
                confirmBuilder.setPositiveButton("取消", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                confirmBuilder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, int which) {
                        guqing("del", 0, 0, guqingModel.getData().getList().get(position).getId());
                    }
                });
                confirmDialog = confirmBuilder.create();
                confirmDialog.show();


            }
        });

        return convertView;
    }

    public void setCurrentItem(int currentItem){
        this.mCurrentItem = currentItem;
    }

    public void setClick(boolean click){
        this.isClick = click;
    }

    private void guqing(final String type, int isLimit, int num, int id){
        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("operation", type);
        map.put("is_limit", isLimit);
        map.put("limit_num", num);
        map.put("id", id);
        map.put("token", token);
        map.put("machine", "shop");
        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
        final Request request = new Request.Builder()
                .url(UrlUtil.SERVERIP + "/product/product/operationProduct")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String result = response.body().string();
                try {
                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                    if("1".equals(String.valueOf(map.get("code")))) {
                        guqingModel = MapperUtils.json2pojo(result, GuqingListModel.class);
                        Message msg = Message.obtain();
                        msg.what = 0;
                        msg.obj = type;
                        handler.sendMessage(msg);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }
    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.what == 0) {
                notifyDataSetInvalidated();
                String type = (String) msg.obj;
                if("edit".equals(type)) {
                    guqingDialog.dismiss();
                }else if("del".equals(type)) {
                    confirmDialog.dismiss();
                }
                Toast.makeText(context, "操作成功！", Toast.LENGTH_LONG).show();
                Message message = Message.obtain();
                message.what = 4;
                message.obj = guqingModel.getData().getTotal();
                GuqingFragment.handler2.sendMessage(message);
            }
            return false;
        }
    });

}

