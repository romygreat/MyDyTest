package com.de.cashier.layout;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;

import com.de.cashier.R;
import com.de.cashier.model.TableModel;
import com.de.cashier.model.YuyueListModel;
import com.de.cashier.util.CustomDatePicker;
import com.de.cashier.util.DateFormatUtils;

import org.angmarch.views.NiceSpinner;

import java.util.ArrayList;
import java.util.List;

public class YuyueEditDialog extends Dialog {

    public YuyueEditDialog(Context context) {
        super(context);
    }

    public YuyueEditDialog(Context context, int theme) {
        super(context, theme);  
    }  
  
    public static class Builder {  
        private Context context;
        private String positiveButtonText;  
        private String negativeButtonText;
        private View contentView;
        private OnClickListener positiveButtonClickListener;
        private OnClickListener negativeButtonClickListener;
        private YuyueListModel.Yuyue yuyue;
        private EditText timeEditText;
        private EditText numEditText;
        private EditText nameEditText;
        private EditText telEditText;
        private EditText remarkEditText;
        private NiceSpinner tableSpinner;
        private Switch suotaiSwitch;
        private String time;
        private String num;
        private String name;
        private String tel;
        private String remark;
        private String tableTitle;
        private int tableId;
        private int isSuotai;
        private CustomDatePicker yuyueDatePicker;
        private TableModel tableModel;

        public Builder(Context context, YuyueListModel.Yuyue yuyue, TableModel tableModel) {
            this.context = context;
            this.yuyue = yuyue;
            this.tableModel = tableModel;
        }

        public String getTime(){
            return timeEditText.getText().toString();
        }
        public String getNum(){
            return numEditText.getText().toString();
        }
        public String getName(){
            return nameEditText.getText().toString();
        }
        public String getTel(){
            return telEditText.getText().toString();
        }
        public String getRemark(){
            return remarkEditText.getText().toString();
        }
        public String getTableTitle(){
            return tableTitle;
        }
        public int getTableid(){
            return tableId;
        }
        public int getIsSuotai(){
            return isSuotai;
        }

        /**
         * Set the positive button resource and it's listener 
         *  
         * @param positiveButtonText 
         * @return 
         */  
        public Builder setPositiveButton(int positiveButtonText,  
                OnClickListener listener) {
            this.positiveButtonText = (String) context  
                    .getText(positiveButtonText);  
            this.positiveButtonClickListener = listener;  
            return this;  
        }  
  
        public Builder setPositiveButton(String positiveButtonText,  
                OnClickListener listener) {
            this.positiveButtonText = positiveButtonText;  
            this.positiveButtonClickListener = listener;  
            return this;  
        }  
  
        public Builder setNegativeButton(int negativeButtonText,  
                OnClickListener listener) {
            this.negativeButtonText = (String) context  
                    .getText(negativeButtonText);  
            this.negativeButtonClickListener = listener;  
            return this;  
        }  
  
        public Builder setNegativeButton(String negativeButtonText,  
                OnClickListener listener) {
            this.negativeButtonText = negativeButtonText;  
            this.negativeButtonClickListener = listener;  
            return this;  
        }  
  
        public YuyueEditDialog create() {
        	LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);  
            // instantiate the dialog with the custom Theme  
            final YuyueEditDialog dialog = new YuyueEditDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.dialog_yuyue_edit, null);
            dialog.addContentView(layout, new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));  
            timeEditText = layout.findViewById(R.id.dialog_yuyue_time);
            numEditText = layout.findViewById(R.id.dialog_yuyue_people_num);
            nameEditText = layout.findViewById(R.id.dialog_yuyue_people_name);
            telEditText = layout.findViewById(R.id.dialog_yuyue_tel);
            remarkEditText = layout.findViewById(R.id.dialog_yuyue_remark);
            tableSpinner = layout.findViewById(R.id.dialog_yuyue_table_id);
            suotaiSwitch = layout.findViewById(R.id.dialog_yuyue_suotai_switch);

            initStartDatePicker();
            initSpinner();

            timeEditText.setText(yuyue.getStart_time().substring(0, yuyue.getStart_time().length() - 3));
            numEditText.setText(yuyue.getRepast_num()+"");
            nameEditText.setText(yuyue.getRepast_name());
            telEditText.setText(yuyue.getRepast_phone());
            remarkEditText.setText(yuyue.getRemark());
            if(yuyue.isIs_open()){
                suotaiSwitch.setChecked(true);
                isSuotai = 1;
            }else{
                suotaiSwitch.setChecked(false);
                isSuotai = 0;
            }
            tableId = yuyue.getTable_id();

            suotaiSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked){
                        isSuotai = 1;
                    }else{
                        isSuotai = 0;
                    }
                }
            });

            // set the confirm button  
            if (positiveButtonText != null) {  
                ((Button) layout.findViewById(R.id.dialog_yuyue_positiveButton)).setText(positiveButtonText);
                if (positiveButtonClickListener != null) {  
                    ((Button) layout.findViewById(R.id.dialog_yuyue_positiveButton)).setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {  
                            positiveButtonClickListener.onClick(dialog, DialogInterface.BUTTON_POSITIVE);  
                        }  
                    });  
                }  
            } else {  
                // if no confirm button just set the visibility to GONE  
                layout.findViewById(R.id.dialog_yuyue_positiveButton).setVisibility(View.GONE);
            }  
            // set the cancel button  
            if (negativeButtonText != null) {  
                ((Button) layout.findViewById(R.id.dialog_yuyue_negativeButton)).setText(negativeButtonText);
                if (negativeButtonClickListener != null) {  
                    ((Button) layout.findViewById(R.id.dialog_yuyue_negativeButton)).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {  
                    	negativeButtonClickListener.onClick(dialog, DialogInterface.BUTTON_NEGATIVE);  
                        }  
                    });  
                }  
            } else {  
                // if no confirm button just set the visibility to GONE  
                layout.findViewById(R.id.dialog_yuyue_negativeButton).setVisibility(View.GONE);
            }  
            // set the content message  
            if (contentView != null) {  
                // if no message set  
                // add the contentView to the dialog body  
                ((LinearLayout) layout.findViewById(R.id.content)).removeAllViews();  
                ((LinearLayout) layout.findViewById(R.id.content)).addView(contentView, new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));  
            }  
            dialog.setContentView(layout);  
            return dialog;  
        }

        private void initSpinner(){
            final List<String> tableData = new ArrayList<>();
            tableData.add("请输入预定桌号");
            for(TableModel.TableData.Tables table : tableModel.getData().getList()){
                tableData.add(table.getTitle());
            }

            tableSpinner.attachDataSource(tableData);
            tableSpinner.setBackgroundResource(R.drawable.edittext_shape);

            tableSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if(position != 0){
                        tableId = tableModel.getData().getList().get(position - 1).getId();
                        tableTitle = tableModel.getData().getList().get(position - 1).getTitle();
                    }else{
                        tableId = -1;
                        tableTitle = "";
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });

            if(!"".equals(yuyue.getTable_title())) {
                for (int i = 0; i < tableData.size(); i++) {
                    if (yuyue.getTable_title().equals(tableData.get(i))) {
                        tableSpinner.setSelectedIndex(i);
                    }
                }
            }
        }

        private void initStartDatePicker() {
            long beginTimestamp = System.currentTimeMillis();
            long endTimestamp = DateFormatUtils.str2Long("2030-12-31 23:59", true);

//            timeEditText.setText(DateFormatUtils.long2Str(beginTimestamp, true));
            timeEditText.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    yuyueDatePicker.show(timeEditText.getText().toString());
                }
            });

            // 通过时间戳初始化日期，毫秒级别
            yuyueDatePicker = new CustomDatePicker(context, new CustomDatePicker.Callback() {
                @Override
                public void onTimeSelected(long timestamp) {
                    timeEditText.setText(DateFormatUtils.long2Str(timestamp, true));
                }
            }, beginTimestamp, endTimestamp);
            // 不允许点击屏幕或物理返回键关闭
            yuyueDatePicker.setCancelable(false);
            // 不显示时和分
            yuyueDatePicker.setCanShowPreciseTime(true);
            // 不允许循环滚动
            yuyueDatePicker.setScrollLoop(false);
            // 不允许滚动动画
            yuyueDatePicker.setCanShowAnim(false);
        }
    }

}