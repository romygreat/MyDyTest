package com.de.cashier.activity;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.de.cashier.R;
import com.de.cashier.adapter.DiancaiListViewAdapter;
import com.de.cashier.application.CashierApplication;
import com.de.cashier.layout.AntoLineLayout;
import com.de.cashier.layout.ConfirmDialog;
import com.de.cashier.layout.FoodDetailDialog;
import com.de.cashier.model.DiancaiModel;
import com.de.cashier.model.FoodCategoryModel;
import com.de.cashier.model.FoodDetailModel;
import com.de.cashier.model.FoodListModel;
import com.de.cashier.model.LoginSuccessModel;
import com.de.cashier.util.MapperUtils;
import com.de.cashier.util.OkHttpClientUtil;
import com.de.cashier.util.UrlUtil;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class DiancaiActivity extends Activity {


    private QMUITipDialog dialog;

    private OkHttpClient okHttpClient;

    private CashierApplication mApplication;

    private LoginSuccessModel loginModel;

    private FoodCategoryModel foodCategoryModel;

    private FoodListModel foodListModel;

    @BindView(R.id.diancai_fenleilayout)
    public AntoLineLayout foodCategoryLayout;

    @BindView(R.id.diancai_foodlistlayout)
    public AntoLineLayout foodListLayout;

    @BindView(R.id.diancai_fenlei_page_left)
    public ImageButton fenleiPageLeft;

    @BindView(R.id.diancai_fenlei_page_right)
    public ImageButton fenleiPageRight;

    @BindView(R.id.diancai_food_pageup)
    public ImageButton foodPageUp;

    @BindView(R.id.diancai_food_pagedown)
    public ImageButton foodPageDown;

    @BindView(R.id.diancai_edit_eatnum)
    public ImageView editEatNumBtn;

    @BindView(R.id.diancai_eatnum)
    public TextView eatNumTV;

    @BindView(R.id.diancai_eattime)
    public TextView eatTimeTV;

    @BindView(R.id.diancai_table_title)
    public TextView tableTitleTV;

    @BindView(R.id.diancai_fuwuyuan)
    public TextView fuwuyuanTV;

    @BindView(R.id.diancai_all_price)
    public TextView allPriceTV;

    @BindView(R.id.diancai_all_num)
    public TextView allNumTV;

    @BindView(R.id.diancai_youhui_price)
    public TextView youhuiTV;

    @BindView(R.id.diancai_listview)
    public ListView mListView;

    private List<Button> buttonList = new ArrayList<>();

    private int foodCategoryTotalPage = 1;

    private int foodCategoryCurrentPage = 1;

    private int foodListTotalPage = 1;

    private int foodListCurrentPage = 1;

    private String eatNum;

    private String tableTitle;

    private boolean isOpen = false;

    private List<DiancaiModel> diancaiList = new ArrayList<>();

    private DiancaiListViewAdapter mAdapter;

    private float allPrice = 0;

    private FoodDetailModel foodDetailModel;

    private FoodDetailDialog.Builder foodDetailBuilder;
    private FoodDetailDialog foodDetailDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diancai);

        ButterKnife.bind(this);

        mApplication = (CashierApplication) CashierApplication.getInstance();

        loginModel = mApplication.getModel();

        eatNum = getIntent().getStringExtra("eatNum");
        tableTitle = getIntent().getStringExtra("tableTitle");
        isOpen = getIntent().getBooleanExtra("isOpen", false);

        eatNumTV.setText(eatNum);
        tableTitleTV.setText(tableTitle);
        if(isOpen){
            eatTimeTV.setText("开台");
        }
        fuwuyuanTV.setText("服务员：" + loginModel.getData().getRealname());

        mAdapter = new DiancaiListViewAdapter(this, diancaiList);
        mListView.setAdapter(mAdapter);

        initShopCate();
        initFoodList();

    }

    //菜品列表
    private void initFoodList(){
        getFoodList("", "");
    }

    private void getFoodList(String cate_id, String search){
        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
        Map<String, String> map = new HashMap<String, String>();
        map.put("cate_id", cate_id);
        map.put("search", search);
        map.put("token", loginModel.getData().getToken());
        map.put("machine", "shop");
        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
        final Request request = new Request.Builder()
                .url(UrlUtil.SERVERIP + "/product/Product/cateProduct")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String result = response.body().string();
                try {
                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                    if("1".equals(String.valueOf(map.get("code")))) {
                        foodListModel = MapperUtils.json2pojo(result, FoodListModel.class);
                        Message msg = Message.obtain();
                        msg.what = 1;
                        handler.sendMessage(msg);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    //菜品分类
    private void initShopCate(){
        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
        Map<String, String> map = new HashMap<String, String>();
        map.put("token", loginModel.getData().getToken());
        map.put("machine", "shop");
        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
        final Request request = new Request.Builder()
                .url(UrlUtil.SERVERIP + "/product/ProductCate/shopCate")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String result = response.body().string();
                try {
                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                    if("1".equals(String.valueOf(map.get("code")))) {
                        foodCategoryModel = MapperUtils.json2pojo(result, FoodCategoryModel.class);
                        Message msg = Message.obtain();
                        msg.what = 0;
                        handler.sendMessage(msg);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    @OnClick({R.id.diancai_fenlei_page_left, R.id.diancai_fenlei_page_right, R.id.diancai_food_pageup, R.id.diancai_food_pagedown})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.diancai_fenlei_page_left:
                if(foodCategoryCurrentPage > 1){
                    foodCategoryLayout.removeAllViews();
                    foodCategoryCurrentPage = foodCategoryCurrentPage - 1;
                    if(foodCategoryCurrentPage == 1){
                        fenleiPageLeft.setBackgroundResource(R.drawable.bg_black);
                    }else{
                        fenleiPageLeft.setBackgroundResource(R.drawable.bg_orange);
                    }
                    if(foodCategoryCurrentPage == foodCategoryTotalPage){
                        fenleiPageRight.setBackgroundResource(R.drawable.bg_black);
                    }else{
                        fenleiPageRight.setBackgroundResource(R.drawable.bg_orange);
                    }
                    switch (foodCategoryCurrentPage){
                        case 1:
                            LayoutInflater layoutInflater0 = getLayoutInflater();
                            View areaItem0 = layoutInflater0.inflate(R.layout.item_diancai_fenlei,null);
                            final Button button0 = areaItem0.findViewById(R.id.item_diancai_fenlei_btn);
                            button0.setText("全部");
                            buttonList.add(button0);
                            foodCategoryLayout.removeAllViews();
                            foodCategoryLayout.addView(areaItem0);
                            button0.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    for(Button b : buttonList){
                                        b.setBackgroundResource(R.drawable.bg_white);
                                        b.setTextColor(getResources().getColor(R.color.black));
                                    }
                                    button0.setBackgroundResource(R.drawable.bg_orange);
                                    button0.setTextColor(getResources().getColor(R.color.white));
                                    getFoodList("", "");
                                }
                            });
                            fenleiPageLeft.setBackgroundResource(R.drawable.bg_black);

                            for (int i = 0; i < 8; i++) {
                                LayoutInflater layoutInflater = getLayoutInflater();
                                View areaItem = layoutInflater.inflate(R.layout.item_diancai_fenlei, null);
                                final Button button = areaItem.findViewById(R.id.item_diancai_fenlei_btn);
                                button.setText(foodCategoryModel.getData().getList().get(i).getName());
                                button.setBackgroundResource(R.drawable.bg_white);
                                button.setTextColor(getResources().getColor(R.color.black));
                                buttonList.add(button);
                                foodCategoryLayout.addView(areaItem);
                                final int finalI = i;
                                button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        for (Button b : buttonList) {
                                            b.setBackgroundResource(R.drawable.bg_white);
                                            b.setTextColor(getResources().getColor(R.color.black));
                                        }
                                        button.setBackgroundResource(R.drawable.bg_orange);
                                        button.setTextColor(getResources().getColor(R.color.white));
                                        getFoodList(foodCategoryModel.getData().getList().get(finalI).getId()+"", "");
                                    }
                                });
                            }
                            break;
                        case 2:
                            for (int i = 8; i < 17; i++) {
                                LayoutInflater layoutInflater = getLayoutInflater();
                                View areaItem = layoutInflater.inflate(R.layout.item_diancai_fenlei, null);
                                final Button button = areaItem.findViewById(R.id.item_diancai_fenlei_btn);
                                button.setText(foodCategoryModel.getData().getList().get(i).getName());
                                button.setBackgroundResource(R.drawable.bg_white);
                                button.setTextColor(getResources().getColor(R.color.black));
                                buttonList.add(button);
                                foodCategoryLayout.addView(areaItem);
                                final int finalI = i;
                                button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        for (Button b : buttonList) {
                                            b.setBackgroundResource(R.drawable.bg_white);
                                            b.setTextColor(getResources().getColor(R.color.black));
                                        }
                                        button.setBackgroundResource(R.drawable.bg_orange);
                                        button.setTextColor(getResources().getColor(R.color.white));
                                        getFoodList(foodCategoryModel.getData().getList().get(finalI).getId()+"", "");
                                    }
                                });
                            }
                            break;
                        case 3:
                            for (int i = 17; i < 26; i++) {
                                LayoutInflater layoutInflater = getLayoutInflater();
                                View areaItem = layoutInflater.inflate(R.layout.item_diancai_fenlei, null);
                                final Button button = areaItem.findViewById(R.id.item_diancai_fenlei_btn);
                                button.setText(foodCategoryModel.getData().getList().get(i).getName());
                                button.setBackgroundResource(R.drawable.bg_white);
                                button.setTextColor(getResources().getColor(R.color.black));
                                buttonList.add(button);
                                foodCategoryLayout.addView(areaItem);
                                final int finalI = i;
                                button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        for (Button b : buttonList) {
                                            b.setBackgroundResource(R.drawable.bg_white);
                                            b.setTextColor(getResources().getColor(R.color.black));
                                        }
                                        button.setBackgroundResource(R.drawable.bg_orange);
                                        button.setTextColor(getResources().getColor(R.color.white));
                                        getFoodList(foodCategoryModel.getData().getList().get(finalI).getId()+"", "");
                                    }
                                });
                            }
                            break;
                    }
                }
                break;
            case R.id.diancai_fenlei_page_right:
                if(foodCategoryCurrentPage < foodCategoryTotalPage){
                    foodCategoryLayout.removeAllViews();
                    foodCategoryCurrentPage = foodCategoryCurrentPage + 1;
                    if(foodCategoryCurrentPage == 1){
                        fenleiPageLeft.setBackgroundResource(R.drawable.bg_black);
                    }else{
                        fenleiPageLeft.setBackgroundResource(R.drawable.bg_orange);
                    }
                    if(foodCategoryCurrentPage == foodCategoryCurrentPage){
                        fenleiPageRight.setBackgroundResource(R.drawable.bg_black);
                    }else{
                        fenleiPageRight.setBackgroundResource(R.drawable.bg_orange);
                    }
                    int endNum = 0;
                    switch (foodCategoryCurrentPage){
                        case 2:

                            if(foodCategoryTotalPage != 2){
                                endNum = 17;
                            }else{
                                endNum = foodCategoryModel.getData().getTotal();
                            }
                            for (int i = 8; i < endNum; i++) {
                                LayoutInflater layoutInflater = getLayoutInflater();
                                View areaItem = layoutInflater.inflate(R.layout.item_diancai_fenlei, null);
                                final Button button = areaItem.findViewById(R.id.item_diancai_fenlei_btn);
                                button.setText(foodCategoryModel.getData().getList().get(i).getName());
                                button.setBackgroundResource(R.drawable.bg_white);
                                button.setTextColor(getResources().getColor(R.color.black));
                                buttonList.add(button);
                                foodCategoryLayout.addView(areaItem);
                                final int finalI = i;
                                button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        for (Button b : buttonList) {
                                            b.setBackgroundResource(R.drawable.bg_white);
                                            b.setTextColor(getResources().getColor(R.color.black));
                                        }
                                        button.setBackgroundResource(R.drawable.bg_orange);
                                        button.setTextColor(getResources().getColor(R.color.white));
                                        getFoodList(foodCategoryModel.getData().getList().get(finalI).getId()+"", "");
                                    }
                                });
                            }
                            break;
                        case 3:
                            if(foodCategoryTotalPage != 3){
                                endNum = 26;
                            }else{
                                endNum = foodCategoryModel.getData().getTotal();
                            }
                            for (int i = 17; i < endNum; i++) {
                                LayoutInflater layoutInflater = getLayoutInflater();
                                View areaItem = layoutInflater.inflate(R.layout.item_diancai_fenlei, null);
                                final Button button = areaItem.findViewById(R.id.item_diancai_fenlei_btn);
                                button.setText(foodCategoryModel.getData().getList().get(i).getName());
                                button.setBackgroundResource(R.drawable.bg_white);
                                button.setTextColor(getResources().getColor(R.color.black));
                                buttonList.add(button);
                                foodCategoryLayout.addView(areaItem);
                                final int finalI = i;
                                button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        for (Button b : buttonList) {
                                            b.setBackgroundResource(R.drawable.bg_white);
                                            b.setTextColor(getResources().getColor(R.color.black));
                                        }
                                        button.setBackgroundResource(R.drawable.bg_orange);
                                        button.setTextColor(getResources().getColor(R.color.white));
                                        getFoodList(foodCategoryModel.getData().getList().get(finalI).getId()+"", "");
                                    }
                                });
                            }
                            break;

                    }
                }
                break;
            case R.id.diancai_food_pageup:
                if(foodListCurrentPage > 1){
                    foodListLayout.removeAllViews();
                    foodListCurrentPage = foodListCurrentPage - 1;
                    if(foodListCurrentPage == 1){
                        foodPageUp.setBackgroundResource(R.drawable.bg_gray);
                    }else{
                        foodPageUp.setBackgroundResource(R.drawable.bg_white);
                    }
                    if(foodListCurrentPage == foodListTotalPage){
                        foodPageDown.setBackgroundResource(R.drawable.bg_gray);
                    }else{
                        foodPageDown.setBackgroundResource(R.drawable.bg_white);
                    }
                    switch (foodListCurrentPage){
                        case 1:
                            initFoodView(0, 19);
                            break;
                        case 2:
                            initFoodView(19, 38);
                            break;
                        case 3:
                            initFoodView(38, 57);
                            break;
                        case 4:
                            initFoodView(57, 76);
                            break;
                        case 5:
                            initFoodView(76, 95);
                            break;
                        case 6:
                            initFoodView(95, 114);
                            break;
                        case 7:
                            initFoodView(114, 133);
                            break;
                    }
                }
                break;

            case R.id.diancai_food_pagedown:
                if(foodListCurrentPage < foodListTotalPage){
                    foodListLayout.removeAllViews();
                    foodListCurrentPage = foodListCurrentPage + 1;
                    if(foodListCurrentPage == 1){
                        foodPageUp.setBackgroundResource(R.drawable.bg_gray);
                    }else{
                        foodPageUp.setBackgroundResource(R.drawable.bg_white);
                    }
                    if(foodListCurrentPage == foodListTotalPage){
                        foodPageDown.setBackgroundResource(R.drawable.bg_gray);
                    }else{
                        foodPageDown.setBackgroundResource(R.drawable.bg_white);
                    }
                    int foodListEndNum = 0;
                    switch (foodListCurrentPage){
                        case 2:
                            if(foodListTotalPage != 2){
                                foodListEndNum = 38;
                            }else{
                                foodListEndNum = foodListModel.getData().getTotal();
                            }
                            initFoodView(19, foodListEndNum);

                            break;
                        case 3:
                            if(foodListTotalPage != 3){
                                foodListEndNum = 57;
                            }else{
                                foodListEndNum = foodListModel.getData().getTotal();
                            }
                            initFoodView(38, foodListEndNum);


                            break;
                        case 4:
                            if(foodListTotalPage != 4){
                                foodListEndNum = 76;
                            }else{
                                foodListEndNum = foodListModel.getData().getTotal();
                            }
                            initFoodView(57, foodListEndNum);


                            break;
                        case 5:
                            if(foodListTotalPage != 5){
                                foodListEndNum = 95;
                            }else{
                                foodListEndNum = foodListModel.getData().getTotal();
                            }
                            initFoodView(76, foodListEndNum);


                            break;
                        case 6:
                            if(foodListTotalPage != 6){
                                foodListEndNum = 114;
                            }else{
                                foodListEndNum = foodListModel.getData().getTotal();
                            }
                            initFoodView(95, foodListEndNum);


                            break;
                        case 7:
                            if(foodListTotalPage != 7){
                                foodListEndNum = 133;
                            }else{
                                foodListEndNum = foodListModel.getData().getTotal();
                            }
                            initFoodView(114, foodListEndNum);


                            break;
                        case 8:
                            if(foodListTotalPage != 8){
                                foodListEndNum = 152;
                            }else{
                                foodListEndNum = foodListModel.getData().getTotal();
                            }
                            initFoodView(133, foodListEndNum);


                            break;
                    }

                }
                break;
        }
    }

    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.what == 0) {
//                dialog.dismiss();
                LayoutInflater layoutInflater0 = getLayoutInflater();
                View areaItem0 = layoutInflater0.inflate(R.layout.item_diancai_fenlei,null);
                final Button button0 = areaItem0.findViewById(R.id.item_diancai_fenlei_btn);
                button0.setText("全部");
                buttonList.add(button0);
                foodCategoryLayout.removeAllViews();
                foodCategoryLayout.addView(areaItem0);
                button0.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        for(Button b : buttonList){
                            b.setBackgroundResource(R.drawable.bg_white);
                            b.setTextColor(getResources().getColor(R.color.black));
                        }
                        button0.setBackgroundResource(R.drawable.bg_orange);
                        button0.setTextColor(getResources().getColor(R.color.white));
                        getFoodList("", "");
                    }
                });
                fenleiPageLeft.setBackgroundResource(R.drawable.bg_black);
                if(foodCategoryModel.getData().getTotal() > 8){
                    if((foodCategoryModel.getData().getTotal()+1) % 9 != 0){
                        foodCategoryTotalPage = (foodCategoryModel.getData().getTotal()+1) / 9 + 1;
                    }else{
                        foodCategoryTotalPage = (foodCategoryModel.getData().getTotal()+1) / 9;
                    }
                    for (int i = 0; i < 8; i++) {
                        LayoutInflater layoutInflater = getLayoutInflater();
                        View areaItem = layoutInflater.inflate(R.layout.item_diancai_fenlei, null);
                        final Button button = areaItem.findViewById(R.id.item_diancai_fenlei_btn);
                        button.setText(foodCategoryModel.getData().getList().get(i).getName());
                        button.setBackgroundResource(R.drawable.bg_white);
                        button.setTextColor(getResources().getColor(R.color.black));
                        buttonList.add(button);
                        foodCategoryLayout.addView(areaItem);
                        final int finalI = i;
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                for (Button b : buttonList) {
                                    b.setBackgroundResource(R.drawable.bg_white);
                                    b.setTextColor(getResources().getColor(R.color.black));
                                }
                                button.setBackgroundResource(R.drawable.bg_orange);
                                button.setTextColor(getResources().getColor(R.color.white));
                                getFoodList(foodCategoryModel.getData().getList().get(finalI).getId()+"", "");
                            }
                        });
                    }
                }else {
                    fenleiPageRight.setBackgroundResource(R.drawable.bg_black);
                    for (int i = 0; i < foodCategoryModel.getData().getTotal(); i++) {
                        LayoutInflater layoutInflater = getLayoutInflater();
                        View areaItem = layoutInflater.inflate(R.layout.item_diancai_fenlei, null);
                        final Button button = areaItem.findViewById(R.id.item_diancai_fenlei_btn);
                        button.setText(foodCategoryModel.getData().getList().get(i).getName());
                        button.setBackgroundResource(R.drawable.bg_white);
                        button.setTextColor(getResources().getColor(R.color.black));
                        buttonList.add(button);
                        foodCategoryLayout.addView(areaItem);
                        final int finalI = i;
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                for (Button b : buttonList) {
                                    b.setBackgroundResource(R.drawable.bg_white);
                                    b.setTextColor(getResources().getColor(R.color.black));
                                }
                                button.setBackgroundResource(R.drawable.bg_orange);
                                button.setTextColor(getResources().getColor(R.color.white));
                                getFoodList(foodCategoryModel.getData().getList().get(finalI).getId()+"", "");
                            }
                        });
                    }
                }
            }else if(msg.what == 1){
//                dialog.dismiss();
                foodListLayout.removeAllViews();
                int pageNum = 0;
                if(foodListModel.getData().getTotal() > 19){
                    if((foodListModel.getData().getTotal()) % 19 != 0){
                        foodListTotalPage = (foodListModel.getData().getTotal()) / 19 + 1;
                    }else{
                        foodListTotalPage = (foodListModel.getData().getTotal()) / 19;
                    }
                    pageNum = 19;
                }else{
                    pageNum = foodListModel.getData().getTotal();
                }
                initFoodView(0, pageNum);

            }else if(msg.what == 2){
                foodDetailBuilder = new FoodDetailDialog.Builder(DiancaiActivity.this);
                foodDetailBuilder.setPositiveButton("取消", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                foodDetailBuilder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, int which) {

                    }
                });
                foodDetailDialog = foodDetailBuilder.create();
                foodDetailDialog.show();
            }
            return false;
        }
    });

    private void initFoodView(int startNum, int endNum){

        for (int i = startNum; i < endNum; i++) {
            if(foodListModel.getData().getList().get(i).isIs_sale()) {
                LayoutInflater layoutInflater = getLayoutInflater();
                View foodItem = layoutInflater.inflate(R.layout.item_diancai_caidan, null);
                LinearLayout foodLayout = foodItem.findViewById(R.id.item_daincai_caidan_layout);
                TextView name = foodItem.findViewById(R.id.item_diancai_food_name);
                name.setText(foodListModel.getData().getList().get(i).getName());
                TextView price = foodItem.findViewById(R.id.item_diancai_food_price);
                price.setText("￥" + foodListModel.getData().getList().get(i).getPrice());
                TextView status = foodItem.findViewById(R.id.item_diancai_food_status);
                ImageView shouqingImg = foodItem.findViewById(R.id.item_diancai_food_shouqing_img);
                if(foodListModel.getData().getList().get(i).isIs_limit()) {
                    if (foodListModel.getData().getList().get(i).getLimit_num() > 0) {
                        status.setText("剩" + foodListModel.getData().getList().get(i).getLimit_num() + foodListModel.getData().getList().get(i).getUnit());
                        shouqingImg.setVisibility(View.INVISIBLE);
                    }else{
                        status.setText("已售罄");
                        shouqingImg.setVisibility(View.VISIBLE);

                    }
                }

                TextView chengOrShi = foodItem.findViewById(R.id.item_diancai_food_chengorshi);

                if(foodListModel.getData().getList().get(i).isIs_editable()) {
                    chengOrShi.setText("称");
                    chengOrShi.setBackgroundResource(R.mipmap.icon_cheng);
                    chengOrShi.setVisibility(View.VISIBLE);
                }
                if(foodListModel.getData().getList().get(i).isIs_current()) {
                    chengOrShi.setText("时");
                    chengOrShi.setBackgroundResource(R.mipmap.icon_shi);
                    chengOrShi.setVisibility(View.VISIBLE);
                }

                foodListLayout.addView(foodItem);
                final int finalI = i;
                foodLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(foodListModel.getData().getList().get(finalI).isIs_limit() && foodListModel.getData().getList().get(finalI).getLimit_num() == 0){

                        }else {
                            if(foodListModel.getData().getList().get(finalI).isIs_procedure()){//是否开启做法
                                OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
                                MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
                                Map<String, Object> map = new HashMap<String, Object>();
                                map.put("token", loginModel.getData().getToken());
                                map.put("productid", foodListModel.getData().getList().get(finalI).getId());
                                RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
                                final Request request = new Request.Builder()
                                        .url(UrlUtil.SERVERIP + "/product/Product/cateProductDetail")
                                        .addHeader("Content-Type", "application/json")
                                        .post(body)
                                        .build();
                                okHttpClient.newCall(request).enqueue(new Callback() {
                                    @Override
                                    public void onFailure(Call call, IOException e) {

                                    }

                                    @Override
                                    public void onResponse(Call call, Response response) throws IOException {

                                        String result = response.body().string();
                                        try {
                                            Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                                            if("1".equals(String.valueOf(map.get("code")))) {
                                                foodDetailModel = MapperUtils.json2pojo(result, FoodDetailModel.class);
                                                Message msg = Message.obtain();
                                                msg.what = 2;
                                                handler.sendMessage(msg);
                                            }

                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }

                                    }
                                });
                            }else {
                                if (diancaiList.size() > 0) {
                                    boolean isNewFood = true;
                                    for (DiancaiModel m : diancaiList) {
                                        if (m.getFoodName().equals(foodListModel.getData().getList().get(finalI).getName())) {
                                            m.setFoodNum(m.getFoodNum() + 1);
                                            isNewFood = false;
                                        }
                                    }
                                    if (isNewFood) {
                                        DiancaiModel model = new DiancaiModel();
                                        model.setFoodName(foodListModel.getData().getList().get(finalI).getName());
                                        model.setFoodNum(Float.parseFloat("1"));
                                        model.setFoodPrice(Float.parseFloat(foodListModel.getData().getList().get(finalI).getPrice()));
                                        diancaiList.add(model);
                                    }
                                } else {
                                    DiancaiModel model = new DiancaiModel();
                                    model.setFoodName(foodListModel.getData().getList().get(finalI).getName());
                                    model.setFoodNum(Float.parseFloat("1"));
                                    model.setFoodPrice(Float.parseFloat(foodListModel.getData().getList().get(finalI).getPrice()));
                                    diancaiList.add(model);
                                }
                                mAdapter.notifyDataSetChanged();
                                allNumTV.setText("共" + diancaiList.size() + "项");
                                allPrice = allPrice + Float.parseFloat(foodListModel.getData().getList().get(finalI).getPrice());
                                allPriceTV.setText(allPrice + "");
                            }
                        }
                    }
                });
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        okHttpClient.dispatcher().cancelAll();
    }
}
