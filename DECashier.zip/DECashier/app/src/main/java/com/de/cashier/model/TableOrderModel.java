package com.de.cashier.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class TableOrderModel {

    private String code;
    private String message;
    private boolean status;
    private OrderData data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public OrderData getData() {
        return data;
    }

    public void setData(OrderData data) {
        this.data = data;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class OrderData{
        private String order_no;
        private String paid_price;
        private String delete_time;
        private String pin_out;
        private OrderRefund order_refund;
        private String discount_amount;
        private String pid;
        private String remark;
        private String change_status;
        private String real_price;
        private String discount_rate;
        private String pay_way;
        private String discount_reason;
        private String id;
        private boolean is_invoice;
        private String over_time;
        private String service_price;
        private String total_price;
        private String is_new;
        private String pay_time;
        private int pay_action;
        private String shop_id;
        private String tableware_fee;
        private String tableware_num;
        private String table_no;
        private String trade_no;
        private String change_price;
        private String close_reason;
        private String add_time;
        private OrderList order_list;
        private boolean append;
        private int status;

        public boolean isAppend() {
            return append;
        }

        public void setAppend(boolean append) {
            this.append = append;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getOrder_no() {
            return order_no;
        }

        public void setOrder_no(String order_no) {
            this.order_no = order_no;
        }

        public String getPaid_price() {
            return paid_price;
        }

        public void setPaid_price(String paid_price) {
            this.paid_price = paid_price;
        }

        public String getDelete_time() {
            return delete_time;
        }

        public void setDelete_time(String delete_time) {
            this.delete_time = delete_time;
        }

        public String getPin_out() {
            return pin_out;
        }

        public void setPin_out(String pin_out) {
            this.pin_out = pin_out;
        }

        public OrderRefund getOrder_refund() {
            return order_refund;
        }

        public void setOrder_refund(OrderRefund order_refund) {
            this.order_refund = order_refund;
        }

        public String getDiscount_amount() {
            return discount_amount;
        }

        public void setDiscount_amount(String discount_amount) {
            this.discount_amount = discount_amount;
        }

        public String getPid() {
            return pid;
        }

        public void setPid(String pid) {
            this.pid = pid;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public String getChange_status() {
            return change_status;
        }

        public void setChange_status(String change_status) {
            this.change_status = change_status;
        }

        public String getReal_price() {
            return real_price;
        }

        public void setReal_price(String real_price) {
            this.real_price = real_price;
        }

        public String getDiscount_rate() {
            return discount_rate;
        }

        public void setDiscount_rate(String discount_rate) {
            this.discount_rate = discount_rate;
        }

        public String getPay_way() {
            return pay_way;
        }

        public void setPay_way(String pay_way) {
            this.pay_way = pay_way;
        }

        public String getDiscount_reason() {
            return discount_reason;
        }

        public void setDiscount_reason(String discount_reason) {
            this.discount_reason = discount_reason;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public boolean isIs_invoice() {
            return is_invoice;
        }

        public void setIs_invoice(boolean is_invoice) {
            this.is_invoice = is_invoice;
        }

        public String getOver_time() {
            return over_time;
        }

        public void setOver_time(String over_time) {
            this.over_time = over_time;
        }

        public String getService_price() {
            return service_price;
        }

        public void setService_price(String service_price) {
            this.service_price = service_price;
        }

        public String getTotal_price() {
            return total_price;
        }

        public void setTotal_price(String total_price) {
            this.total_price = total_price;
        }

        public String getIs_new() {
            return is_new;
        }

        public void setIs_new(String is_new) {
            this.is_new = is_new;
        }

        public String getPay_time() {
            return pay_time;
        }

        public void setPay_time(String pay_time) {
            this.pay_time = pay_time;
        }

        public int getPay_action() {
            return pay_action;
        }

        public void setPay_action(int pay_action) {
            this.pay_action = pay_action;
        }

        public String getShop_id() {
            return shop_id;
        }

        public void setShop_id(String shop_id) {
            this.shop_id = shop_id;
        }

        public String getTableware_fee() {
            return tableware_fee;
        }

        public void setTableware_fee(String tableware_fee) {
            this.tableware_fee = tableware_fee;
        }

        public String getTableware_num() {
            return tableware_num;
        }

        public void setTableware_num(String tableware_num) {
            this.tableware_num = tableware_num;
        }

        public String getTable_no() {
            return table_no;
        }

        public void setTable_no(String table_no) {
            this.table_no = table_no;
        }

        public String getTrade_no() {
            return trade_no;
        }

        public void setTrade_no(String trade_no) {
            this.trade_no = trade_no;
        }

        public String getChange_price() {
            return change_price;
        }

        public void setChange_price(String change_price) {
            this.change_price = change_price;
        }

        public String getClose_reason() {
            return close_reason;
        }

        public void setClose_reason(String close_reason) {
            this.close_reason = close_reason;
        }

        public String getAdd_time() {
            return add_time;
        }

        public void setAdd_time(String add_time) {
            this.add_time = add_time;
        }

        public OrderList getOrder_list() {
            return order_list;
        }

        public void setOrder_list(OrderList order_list) {
            this.order_list = order_list;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class OrderList{
            private String total;
            private List<FoodList> list;

            public String getTotal() {
                return total;
            }

            public void setTotal(String total) {
                this.total = total;
            }

            public List<FoodList> getList() {
                return list;
            }

            public void setList(List<FoodList> list) {
                this.list = list;
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class FoodList{
                private String discount_amount;
                private String procedure_id;
                private String num;
                private String set_meal_id;
                private String group_spec_id;
                private String remark;
                private String pic;
                private String product_code;
                private int type;
                private int discount_rate;

                @JsonProperty("switch")
                private boolean switchss;
                private boolean is_pack;
                private String final_price;
                private String price;
                private String product_id;
                private String taste_id;
                private String discount_reason;
                private String[] contorno_ids;
                private String id;
                private String order;
                private String reduce_money;
                private String is_exists_edit;
                private String refund_status;
                private String cate_id;
                private boolean is_editable;
                private String unit_price;
                private boolean is_exists_current;
                private boolean preferential_way;
                private String shop_id;
                private String unit;
                private String name;
                private String close_reason;
                private boolean is_current;
                private String order_id;
                private String status;

                public String getDiscount_amount() {
                    return discount_amount;
                }

                public void setDiscount_amount(String discount_amount) {
                    this.discount_amount = discount_amount;
                }

                public String getProcedure_id() {
                    return procedure_id;
                }

                public void setProcedure_id(String procedure_id) {
                    this.procedure_id = procedure_id;
                }

                public String getNum() {
                    return num;
                }

                public void setNum(String num) {
                    this.num = num;
                }

                public String getSet_meal_id() {
                    return set_meal_id;
                }

                public void setSet_meal_id(String set_meal_id) {
                    this.set_meal_id = set_meal_id;
                }

                public String getGroup_spec_id() {
                    return group_spec_id;
                }

                public void setGroup_spec_id(String group_spec_id) {
                    this.group_spec_id = group_spec_id;
                }

                public String getRemark() {
                    return remark;
                }

                public void setRemark(String remark) {
                    this.remark = remark;
                }

                public String getPic() {
                    return pic;
                }

                public void setPic(String pic) {
                    this.pic = pic;
                }

                public String getProduct_code() {
                    return product_code;
                }

                public void setProduct_code(String product_code) {
                    this.product_code = product_code;
                }

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }

                public int getDiscount_rate() {
                    return discount_rate;
                }

                public void setDiscount_rate(int discount_rate) {
                    this.discount_rate = discount_rate;
                }

                public boolean isSwitchss() {
                    return switchss;
                }

                public void setSwitchss(boolean switchss) {
                    this.switchss = switchss;
                }

                public boolean isIs_pack() {
                    return is_pack;
                }

                public void setIs_pack(boolean is_pack) {
                    this.is_pack = is_pack;
                }

                public String getFinal_price() {
                    return final_price;
                }

                public void setFinal_price(String final_price) {
                    this.final_price = final_price;
                }

                public String getPrice() {
                    return price;
                }

                public void setPrice(String price) {
                    this.price = price;
                }

                public String getProduct_id() {
                    return product_id;
                }

                public void setProduct_id(String product_id) {
                    this.product_id = product_id;
                }

                public String getTaste_id() {
                    return taste_id;
                }

                public void setTaste_id(String taste_id) {
                    this.taste_id = taste_id;
                }

                public String getDiscount_reason() {
                    return discount_reason;
                }

                public void setDiscount_reason(String discount_reason) {
                    this.discount_reason = discount_reason;
                }

                public String[] getContorno_ids() {
                    return contorno_ids;
                }

                public void setContorno_ids(String[] contorno_ids) {
                    this.contorno_ids = contorno_ids;
                }

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }

                public String getOrder() {
                    return order;
                }

                public void setOrder(String order) {
                    this.order = order;
                }

                public String getReduce_money() {
                    return reduce_money;
                }

                public void setReduce_money(String reduce_money) {
                    this.reduce_money = reduce_money;
                }

                public String getIs_exists_edit() {
                    return is_exists_edit;
                }

                public void setIs_exists_edit(String is_exists_edit) {
                    this.is_exists_edit = is_exists_edit;
                }

                public String getRefund_status() {
                    return refund_status;
                }

                public void setRefund_status(String refund_status) {
                    this.refund_status = refund_status;
                }

                public String getCate_id() {
                    return cate_id;
                }

                public void setCate_id(String cate_id) {
                    this.cate_id = cate_id;
                }

                public boolean isIs_editable() {
                    return is_editable;
                }

                public void setIs_editable(boolean is_editable) {
                    this.is_editable = is_editable;
                }

                public String getUnit_price() {
                    return unit_price;
                }

                public void setUnit_price(String unit_price) {
                    this.unit_price = unit_price;
                }

                public boolean isIs_exists_current() {
                    return is_exists_current;
                }

                public void setIs_exists_current(boolean is_exists_current) {
                    this.is_exists_current = is_exists_current;
                }

                public boolean isPreferential_way() {
                    return preferential_way;
                }

                public void setPreferential_way(boolean preferential_way) {
                    this.preferential_way = preferential_way;
                }

                public String getShop_id() {
                    return shop_id;
                }

                public void setShop_id(String shop_id) {
                    this.shop_id = shop_id;
                }

                public String getUnit() {
                    return unit;
                }

                public void setUnit(String unit) {
                    this.unit = unit;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public String getClose_reason() {
                    return close_reason;
                }

                public void setClose_reason(String close_reason) {
                    this.close_reason = close_reason;
                }

                public boolean isIs_current() {
                    return is_current;
                }

                public void setIs_current(boolean is_current) {
                    this.is_current = is_current;
                }

                public String getOrder_id() {
                    return order_id;
                }

                public void setOrder_id(String order_id) {
                    this.order_id = order_id;
                }

                public String getStatus() {
                    return status;
                }

                public void setStatus(String status) {
                    this.status = status;
                }
            }
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class OrderRefund{
            private String total;
            private List<Refund> list;

            public String getTotal() {
                return total;
            }

            public void setTotal(String total) {
                this.total = total;
            }

            public List<Refund> getList() {
                return list;
            }

            public void setList(List<Refund> list) {
                this.list = list;
            }

            @JsonIgnoreProperties(ignoreUnknown = true)
            public static class Refund{
                private String procedure_id;
                private String num;
                private String set_meal_id;
                private String group_spec_id;
                private String pic;
                private String product_code;
                private String refund_price;
                private String refund_time;
                private String product_id;
                private String taste_id;
                private String name;
                private String refund_reason;
                private String[] contorno_ids;
                private String id;
                private String order_id;

                public String getProcedure_id() {
                    return procedure_id;
                }

                public void setProcedure_id(String procedure_id) {
                    this.procedure_id = procedure_id;
                }

                public String getNum() {
                    return num;
                }

                public void setNum(String num) {
                    this.num = num;
                }

                public String getSet_meal_id() {
                    return set_meal_id;
                }

                public void setSet_meal_id(String set_meal_id) {
                    this.set_meal_id = set_meal_id;
                }

                public String getGroup_spec_id() {
                    return group_spec_id;
                }

                public void setGroup_spec_id(String group_spec_id) {
                    this.group_spec_id = group_spec_id;
                }

                public String getPic() {
                    return pic;
                }

                public void setPic(String pic) {
                    this.pic = pic;
                }

                public String getProduct_code() {
                    return product_code;
                }

                public void setProduct_code(String product_code) {
                    this.product_code = product_code;
                }

                public String getRefund_price() {
                    return refund_price;
                }

                public void setRefund_price(String refund_price) {
                    this.refund_price = refund_price;
                }

                public String getRefund_time() {
                    return refund_time;
                }

                public void setRefund_time(String refund_time) {
                    this.refund_time = refund_time;
                }

                public String getProduct_id() {
                    return product_id;
                }

                public void setProduct_id(String product_id) {
                    this.product_id = product_id;
                }

                public String getTaste_id() {
                    return taste_id;
                }

                public void setTaste_id(String taste_id) {
                    this.taste_id = taste_id;
                }

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public String getRefund_reason() {
                    return refund_reason;
                }

                public void setRefund_reason(String refund_reason) {
                    this.refund_reason = refund_reason;
                }

                public String[] getContorno_ids() {
                    return contorno_ids;
                }

                public void setContorno_ids(String[] contorno_ids) {
                    this.contorno_ids = contorno_ids;
                }

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }

                public String getOrder_id() {
                    return order_id;
                }

                public void setOrder_id(String order_id) {
                    this.order_id = order_id;
                }
            }
        }

    }
}
