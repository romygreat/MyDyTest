package com.de.cashier.util;

public class UrlUtil {

//    public static String SERVERIP = "http://192.168.0.180:8888";
    public static String SERVERIP = "http://47.107.57.102:8082";
}
