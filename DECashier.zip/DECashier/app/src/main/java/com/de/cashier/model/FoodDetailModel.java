package com.de.cashier.model;

import java.util.List;

public class FoodDetailModel {

    private String code;
    private String message;
    private boolean status;
    private FoodDetailData data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public FoodDetailData getData() {
        return data;
    }

    public void setData(FoodDetailData data) {
        this.data = data;
    }

    public static class FoodDetailData{

        private List<Contorno> contorno;
        private List<Procedure> procedure;

        public List<Contorno> getContorno() {
            return contorno;
        }

        public void setContorno(List<Contorno> contorno) {
            this.contorno = contorno;
        }

        public List<Procedure> getProcedure() {
            return procedure;
        }

        public void setProcedure(List<Procedure> procedure) {
            this.procedure = procedure;
        }

        public static class Contorno{
            private int id;
            private int shop_id;
            private int dish_id;
            private float price;
            private String product_id;
            private String name;
            private int sort;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public int getShop_id() {
                return shop_id;
            }

            public void setShop_id(int shop_id) {
                this.shop_id = shop_id;
            }

            public int getDish_id() {
                return dish_id;
            }

            public void setDish_id(int dish_id) {
                this.dish_id = dish_id;
            }

            public float getPrice() {
                return price;
            }

            public void setPrice(float price) {
                this.price = price;
            }

            public String getProduct_id() {
                return product_id;
            }

            public void setProduct_id(String product_id) {
                this.product_id = product_id;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public int getSort() {
                return sort;
            }

            public void setSort(int sort) {
                this.sort = sort;
            }
        }

        public static class Procedure{
            private float proces_price;
            private int shop_id;
            private int procedure_id;
            private int product_id;
            private String name;
            private int id;
            private int sort;

            public float getProces_price() {
                return proces_price;
            }

            public void setProces_price(float proces_price) {
                this.proces_price = proces_price;
            }

            public int getShop_id() {
                return shop_id;
            }

            public void setShop_id(int shop_id) {
                this.shop_id = shop_id;
            }

            public int getProcedure_id() {
                return procedure_id;
            }

            public void setProcedure_id(int procedure_id) {
                this.procedure_id = procedure_id;
            }

            public int getProduct_id() {
                return product_id;
            }

            public void setProduct_id(int product_id) {
                this.product_id = product_id;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public int getSort() {
                return sort;
            }

            public void setSort(int sort) {
                this.sort = sort;
            }
        }
    }
}
