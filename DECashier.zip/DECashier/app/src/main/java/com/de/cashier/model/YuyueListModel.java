package com.de.cashier.model;

import java.util.List;

public class YuyueListModel {

    private List<Yuyue> list;
    private int pageNumber;
    private int pageSize;
    private int totalPage;
    private int totalRow;

    public List<Yuyue> getList() {
        return list;
    }

    public void setList(List<Yuyue> list) {
        this.list = list;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalRow() {
        return totalRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
    }

    public static class Yuyue{
        private int id;
        private int shop_id;
        private String repast_name;
        private int repast_num;
        private String repast_phone;
        private String start_time;
        private int table_id;
        private int status;
        private boolean is_open;
        private String remark;
        private String table_title;

        public String getTable_title() {
            return table_title;
        }

        public void setTable_title(String table_title) {
            this.table_title = table_title;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getShop_id() {
            return shop_id;
        }

        public void setShop_id(int shop_id) {
            this.shop_id = shop_id;
        }

        public String getRepast_name() {
            return repast_name;
        }

        public void setRepast_name(String repast_name) {
            this.repast_name = repast_name;
        }

        public int getRepast_num() {
            return repast_num;
        }

        public void setRepast_num(int repast_num) {
            this.repast_num = repast_num;
        }

        public String getRepast_phone() {
            return repast_phone;
        }

        public void setRepast_phone(String repast_phone) {
            this.repast_phone = repast_phone;
        }

        public String getStart_time() {
            return start_time;
        }

        public void setStart_time(String start_time) {
            this.start_time = start_time;
        }

        public int getTable_id() {
            return table_id;
        }

        public void setTable_id(int table_id) {
            this.table_id = table_id;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public boolean isIs_open() {
            return is_open;
        }

        public void setIs_open(boolean is_open) {
            this.is_open = is_open;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }
    }
}
