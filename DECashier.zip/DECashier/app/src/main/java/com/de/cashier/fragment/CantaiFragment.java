package com.de.cashier.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.de.cashier.R;
import com.de.cashier.activity.DiancaiActivity;
import com.de.cashier.application.CashierApplication;
import com.de.cashier.layout.AddTableDialog;
import com.de.cashier.layout.AntoLineLayout;
import com.de.cashier.layout.OpenTableDialog;
import com.de.cashier.layout.PayMenuDialog;
import com.de.cashier.listener.ClickListener;
import com.de.cashier.model.AreaModel;
import com.de.cashier.model.LoginSuccessModel;
import com.de.cashier.model.TableModel;
import com.de.cashier.model.TableOrderModel;
import com.de.cashier.util.MapperUtils;
import com.de.cashier.util.OkHttpClientUtil;
import com.de.cashier.util.UrlUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class CantaiFragment extends Fragment {

    @BindView(R.id.cantai_cantailayout)
    public AntoLineLayout cantaiLayout;

    @BindView(R.id.cantai_arealayout)
    public AntoLineLayout areaLayout;

    @BindView(R.id.cantai_shopname)
    public TextView shopNameTV;

    @BindView(R.id.cantai_shopid)
    public TextView shopIdTV;

    @BindView(R.id.cantai_caozuoyuan)
    public TextView caozuoyuanTV;

    @BindView(R.id.cantai_all_num)
    public TextView cantaiAllNumTV;

    @BindView(R.id.cantai_kongtai_num)
    public TextView cantaiKongtaiNumTV;

    @BindView(R.id.cantai_jiucan_num)
    public TextView cantaiJiucanNumTV;

    @BindView(R.id.cantai_dingzuo_num)
    public TextView cantaiDingzuoNumTV;

    @BindView(R.id.cantai_already_pay)
    public TextView alreadyPayTV;

    @BindView(R.id.cantai_not_pay)
    public TextView notPayTV;

    @BindView(R.id.cantai_already_pay_btn)
    public TextView alreadyPayBtn;

    @BindView(R.id.cantai_not_pay_btn)
    public TextView notPayBtn;

    @BindView(R.id.cantai_qingtai)
    public TextView qingtaiBtn;

    @BindView(R.id.cantai_more)
    public TextView moreBtn;

    @BindView(R.id.cantai_area_page_left)
    public ImageButton pageLeftBtn;

    @BindView(R.id.cantai_area_page_right)
    public ImageButton pageRightBtn;

    @BindView(R.id.cantai_table_pageup)
    public ImageButton pageUpBtn;

    @BindView(R.id.cantai_table_pagedown)
    public ImageButton pageDownBtn;

    @BindView(R.id.cantai_orderinfo_zhuohao)
    public TextView zhuohaoTV;

    @BindView(R.id.cantai_orderinfo_dingdanhao)
    public TextView dingdanhaohaoTV;

    @BindView(R.id.cantai_orderinfo_time)
    public TextView ordertimeTV;

    @BindView(R.id.cantai_orderinfo_status)
    public TextView statusTV;

    @BindView(R.id.cantai_orderinfo_usetime)
    public TextView usetimeTV;

    @BindView(R.id.cantai_orderinfo_daizhifu)
    public TextView daizhifuTV;

    @BindView(R.id.cantai_orderinfo_jiezhang_btn)
    public Button jiezhangBtn;

    @BindView(R.id.cantai_orderinfo_layout)
    public LinearLayout orderInfoLayout;

    @BindView(R.id.cantai_orderinfo_notorder_layout)
    public LinearLayout notOrderInfoLayout;

    @BindView(R.id.cantai_orderinfo_notorder_table_name)
    public TextView notOrderTableNameTV;

    private CashierApplication mApplication;

    private LoginSuccessModel loginModel;

    private TableModel tableModel;

    private TableOrderModel tableOrderModel;

    private AreaModel areaModel;

    private List<ImageView> tableCheckList = new ArrayList<>();

    private List<Button> buttonList = new ArrayList<>();

    private int page = 1;

    private long mLastTime=0;

    private long mCurTime=0;

    private int areasTotalPages = 0;

    private int areasCurrentPage = 1;

    private int tablesTotalPages = 0;

    private int tablesCurrentPage = 1;

    private PopupWindow mPopWindow;

    private String eatNum = "0";

    public CantaiFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view  = inflater.inflate(R.layout.fragment_cantai, container, false);

        ButterKnife.bind(this, view);

        mApplication = (CashierApplication) CashierApplication.getInstance();

        loginModel = mApplication.getModel();

        initData();

        return view;
    }

    private void initData(){
        shopNameTV.setText(loginModel.getData().getShop().getName());
        shopIdTV.setText("商户编号：" + loginModel.getData().getShop().getShop_id());
        caozuoyuanTV.setText("操作员：" + loginModel.getData().getRealname());

        initAreas();
        initAllTables();
    }

    private void initAreas(){
        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
        Map<String, String> map = new HashMap<String, String>();
        map.put("token", loginModel.getData().getToken());
        map.put("machine", "shop");
        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
        final Request request = new Request.Builder()
                .url(UrlUtil.SERVERIP + "/shop/ShopSubarea/listSubarea")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String result = response.body().string();
                try {
                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                    if("1".equals(String.valueOf(map.get("code")))) {
                        areaModel = MapperUtils.json2pojo(result, AreaModel.class);
                        Message msg = Message.obtain();
                        msg.what = 1;
                        handler.sendMessage(msg);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    private void initAllTables(){
        getTables("", "");
    }

    private void getTables(String areaId, String searchKey){
        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
        Map<String, String> map = new HashMap<String, String>();
        map.put("sign", "2");
        map.put("token", loginModel.getData().getToken());
        map.put("machine", "shop");
        map.put("subarea_id", areaId);
        map.put("search", searchKey);
        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
        final Request request = new Request.Builder()
                .url(UrlUtil.SERVERIP + "/shop/ShopTable/setShopTable")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String result = response.body().string();
                try {
                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                    if("1".equals(String.valueOf(map.get("code")))) {
                        tableModel = MapperUtils.json2pojo(result, TableModel.class);
                        mApplication.setTableModel(tableModel);
                        Message msg = Message.obtain();
                        msg.what = 0;
                        handler.sendMessage(msg);

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    private void initfristTableOrderInfo(){
        if("0".equals(tableModel.getData().getList().get(0).getStatus())) {
            Message msg = Message.obtain();
            msg.what = 3;
            msg.obj = tableModel.getData().getList().get(0).getTitle();
            handler.sendMessage(msg);
        }else {
            getTableOrderInfo(tableModel.getData().getList().get(0).getId(), tableModel.getData().getList().get(0).getTitle());
        }
    }

    private void getTableOrderInfo(int id, String table_no){
        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("id", id);
        map.put("table_no", table_no);
        map.put("token", loginModel.getData().getToken());
        map.put("machine", "shop");
        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
        final Request request = new Request.Builder()
                .url(UrlUtil.SERVERIP + "/order/order/setOrder")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String result = response.body().string();
                try {
                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                    if("1".equals(String.valueOf(map.get("code")))) {
                        tableOrderModel = MapperUtils.json2pojo(result, TableOrderModel.class);
                        Message msg = Message.obtain();
                        msg.what = 2;
                        handler.sendMessage(msg);

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    private void initTableView(int startNum, int endNum){
        for (int i = startNum; i < endNum; i++) {
            // 用以下方法将layout布局文件换成view
            LayoutInflater layoutInflater = getLayoutInflater();
            View cantaiItem = layoutInflater.inflate(R.layout.item_cantai,null);
            TextView name = cantaiItem.findViewById(R.id.item_cantai_name);
            TextView kongxian = cantaiItem.findViewById(R.id.item_cantai_kongxian);
            View bView = cantaiItem.findViewById(R.id.item_cantai_view);
            TextView price = cantaiItem.findViewById(R.id.item_cantai_jiage);
            TextView status = cantaiItem.findViewById(R.id.item_cantai_status);
            TextView peoplenum = cantaiItem.findViewById(R.id.item_cantai_peoplenum);
            name.setText(tableModel.getData().getList().get(i).getTitle());
            peoplenum.setText("0/" + tableModel.getData().getList().get(i).getPeople_num());
            final LinearLayout bgLayout = cantaiItem.findViewById(R.id.item_cantai_bglayout);
            final ImageView check = cantaiItem.findViewById(R.id.item_cantai_check);
            tableCheckList.add(check);
            switch (tableModel.getData().getList().get(i).getStatus()){
                case "0":

                    break;
                case "1":
                    bgLayout.setBackgroundResource(R.drawable.bg_orange);
                    name.setTextColor(getResources().getColor(R.color.white));
                    peoplenum.setTextColor(getResources().getColor(R.color.white));
                    kongxian.setVisibility(View.GONE);
                    bView.setVisibility(View.GONE);
                    price.setVisibility(View.VISIBLE);
                    status.setVisibility(View.VISIBLE);
                    price.setText("￥" + tableModel.getData().getList().get(i).getMoney());
                    peoplenum.setText(tableModel.getData().getList().get(i).getTableware_num() + "/" + tableModel.getData().getList().get(i).getPeople_num());
                    switch (tableModel.getData().getList().get(i).getOrder_status()){
                        case "0":
                            status.setText("未支付");
                            break;
                        case "1":
                            status.setText("已支付");
                            break;
                        case "2":
                            status.setText("已完成");
                            break;
                    }

                    break;
                case "2":
                    bgLayout.setBackgroundResource(R.drawable.bg_green);
                    name.setTextColor(getResources().getColor(R.color.white));
                    peoplenum.setTextColor(getResources().getColor(R.color.white));
                    kongxian.setText("预定");
                    kongxian.setTextColor(getResources().getColor(R.color.white));

                    peoplenum.setText(tableModel.getData().getList().get(i).getTableware_num() + "/" + tableModel.getData().getList().get(i).getPeople_num());

                    break;

            }

            final int finalI = i;
            bgLayout.setOnTouchListener(new ClickListener(new ClickListener.MyClickCallBack() {
                @Override
                public void oneClick() {
                    for(ImageView check : tableCheckList){
                        check.setVisibility(View.GONE);
                    }
                    check.setVisibility(View.VISIBLE);
                    if("0".equals(tableModel.getData().getList().get(finalI).getStatus())) {
                        Message msg = Message.obtain();
                        msg.what = 3;
                        msg.obj = tableModel.getData().getList().get(finalI).getTitle();
                        handler.sendMessage(msg);
                    }else {
                        getTableOrderInfo(tableModel.getData().getList().get(finalI).getId(), tableModel.getData().getList().get(finalI).getTitle());
                    }
                }

                @Override
                public void doubleClick() {
                    for(ImageView check : tableCheckList){
                        check.setVisibility(View.GONE);
                    }
                    check.setVisibility(View.VISIBLE);
                    if("0".equals(tableModel.getData().getList().get(finalI).getStatus())) {
                        final OpenTableDialog.Builder openTableBuilder = new OpenTableDialog.Builder(getActivity());
                        openTableBuilder.setPositiveButton("开台并点菜", new DialogInterface.OnClickListener() {
                            public void onClick(final DialogInterface dialog, int which) {

                                eatNum = openTableBuilder.getNum();
                                if("0".equals(eatNum)){
                                    Toast.makeText(getActivity(), "请输入用餐人数！", Toast.LENGTH_LONG).show();
                                    return;
                                }

                                OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
                                MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
                                Map<String, String> map = new HashMap<String, String>();
                                map.put("title", tableModel.getData().getList().get(finalI).getTitle());
                                map.put("token", loginModel.getData().getToken());
                                map.put("machine", "shop");
                                RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
                                final Request request = new Request.Builder()
                                        .url(UrlUtil.SERVERIP + "/shop/shopTable/openShopTable")
                                        .addHeader("Content-Type", "application/json")
                                        .post(body)
                                        .build();
                                okHttpClient.newCall(request).enqueue(new Callback() {
                                    @Override
                                    public void onFailure(Call call, IOException e) {

                                    }

                                    @Override
                                    public void onResponse(Call call, Response response) throws IOException {

                                        String result = response.body().string();
                                        try {
                                            Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                                            if("1".equals(String.valueOf(map.get("code")))) {
                                                Message msg = Message.obtain();
                                                msg.what = 4;
                                                msg.obj = tableModel.getData().getList().get(finalI).getTitle();
                                                handler.sendMessage(msg);

                                            }

                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }

                                    }
                                });


                            }
                        });
                        openTableBuilder.create().show();
                    }else{
                        Intent intent = new Intent();
                        intent.setClass(getActivity(), DiancaiActivity.class);
                        getActivity().startActivity(intent);
                    }
                }
            }));


            cantaiLayout.addView(cantaiItem);
        }

        LayoutInflater layoutInflater1 = getLayoutInflater();
        View addItem = layoutInflater1.inflate(R.layout.item_cantai_add,null);
        ImageButton addBtn = addItem.findViewById(R.id.item_cantai_addbtn);
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AddTableDialog.Builder addTableBuilder = new AddTableDialog.Builder(getActivity());
                addTableBuilder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, int which) {

                        //设置你的操作事项
                        String title = addTableBuilder.getTitle();
                        String num = addTableBuilder.getNum();

                        if("".equals(title)){
                            Toast.makeText(getActivity(), "请输入台桌名称！", Toast.LENGTH_LONG).show();
                            return;
                        }

                        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
                        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
                        Map<String, String> map = new HashMap<String, String>();
                        map.put("token", loginModel.getData().getToken());
                        map.put("machine", "shop");
                        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
                        final Request request = new Request.Builder()
                                .url(UrlUtil.SERVERIP + "/shop/ShopTable/saveShopTabl")
                                .addHeader("Content-Type", "application/json")
                                .post(body)
                                .build();
                        okHttpClient.newCall(request).enqueue(new Callback() {
                            @Override
                            public void onFailure(Call call, IOException e) {

                            }

                            @Override
                            public void onResponse(Call call, Response response) throws IOException {

                                String result = response.body().string();
                                try {
                                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                                    if("1".equals(String.valueOf(map.get("code")))) {
//                                        guqingListModel = MapperUtils.json2pojo(result, GuqingListModel.class);
//                                        Message msg = Message.obtain();
//                                        msg.what = 2;
//                                        handler.sendMessage(msg);
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            }
                        });


                    }
                });

                addTableBuilder.setNegativeButton("取消",
                        new android.content.DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });

                addTableBuilder.create().show();
            }
        });
        cantaiLayout.addView(addItem);
    }

    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.what == 0) {
                initfristTableOrderInfo();
                cantaiLayout.removeAllViews();
                tableCheckList.clear();
                cantaiAllNumTV.setText("(" + tableModel.getData().getStatus().getAll() + ")");
                cantaiKongtaiNumTV.setText("(" + tableModel.getData().getStatus().getLeisure() + ")");
                cantaiJiucanNumTV.setText("(" + tableModel.getData().getStatus().getMeals() + ")");
                cantaiDingzuoNumTV.setText("(" + tableModel.getData().getStatus().getSubscribe()+ ")");

                alreadyPayTV.setText((tableModel.getData().getOrder().getOrder_total() - tableModel.getData().getOrder().getOrder_unincome()) + "");
                notPayTV.setText(tableModel.getData().getOrder().getOrder_unincome() + "");

                int pageNum = 0;
                if(tableModel.getData().getTotal() > 26){
                    if((tableModel.getData().getTotal()) % 26 != 0){
                        tablesTotalPages = (tableModel.getData().getTotal()) / 26 + 1;
                    }else{
                        tablesTotalPages = (tableModel.getData().getTotal()) / 26;
                    }
                    pageNum = 26;
                }else{
                    pageNum = tableModel.getData().getTotal();
                }
                initTableView(0, pageNum);
                tableCheckList.get(0).setVisibility(View.VISIBLE);

            }else if(msg.what == 1){

                LayoutInflater layoutInflater0 = getLayoutInflater();
                View areaItem0 = layoutInflater0.inflate(R.layout.item_cantai_area,null);
                final Button button0 = areaItem0.findViewById(R.id.item_cantai_area_title);
                button0.setText("全部");
                buttonList.add(button0);
                areaLayout.removeAllViews();
                areaLayout.addView(areaItem0);
                button0.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        for(Button b : buttonList){
                            b.setBackgroundResource(R.drawable.bg_white);
                            b.setTextColor(getResources().getColor(R.color.black));
                        }
                        button0.setBackgroundResource(R.drawable.bg_orange);
                        button0.setTextColor(getResources().getColor(R.color.white));
                        getTables("", "");
                    }
                });
                pageLeftBtn.setBackgroundResource(R.drawable.bg_black);
                if(areaModel.getData().getTotal() > 6){
                    if((areaModel.getData().getTotal()+1) % 7 != 0){
                        areasTotalPages = (areaModel.getData().getTotal()+1) / 7 + 1;
                    }else{
                        areasTotalPages = (areaModel.getData().getTotal()+1) / 7;
                    }
                    for (int i = 0; i < 6; i++) {
                        LayoutInflater layoutInflater = getLayoutInflater();
                        View areaItem = layoutInflater.inflate(R.layout.item_cantai_area, null);
                        final Button button = areaItem.findViewById(R.id.item_cantai_area_title);
                        button.setText(areaModel.getData().getList().get(i).getTitle());
                        button.setBackgroundResource(R.drawable.bg_white);
                        button.setTextColor(getResources().getColor(R.color.black));
                        buttonList.add(button);
                        areaLayout.addView(areaItem);
                        final int finalI = i;
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                for (Button b : buttonList) {
                                    b.setBackgroundResource(R.drawable.bg_white);
                                    b.setTextColor(getResources().getColor(R.color.black));
                                }
                                button.setBackgroundResource(R.drawable.bg_orange);
                                button.setTextColor(getResources().getColor(R.color.white));
                                getTables(areaModel.getData().getList().get(finalI).getId(), "");
                            }
                        });
                    }
                }else {
                    pageRightBtn.setBackgroundResource(R.drawable.bg_gray);
                    for (int i = 0; i < areaModel.getData().getTotal(); i++) {
                        LayoutInflater layoutInflater = getLayoutInflater();
                        View areaItem = layoutInflater.inflate(R.layout.item_cantai_area, null);
                        final Button button = areaItem.findViewById(R.id.item_cantai_area_title);
                        button.setText(areaModel.getData().getList().get(i).getTitle());
                        button.setBackgroundResource(R.drawable.bg_white);
                        button.setTextColor(getResources().getColor(R.color.black));
                        buttonList.add(button);
                        areaLayout.addView(areaItem);
                        final int finalI = i;
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                for (Button b : buttonList) {
                                    b.setBackgroundResource(R.drawable.bg_white);
                                    b.setTextColor(getResources().getColor(R.color.black));
                                }
                                button.setBackgroundResource(R.drawable.bg_orange);
                                button.setTextColor(getResources().getColor(R.color.white));
                                getTables(areaModel.getData().getList().get(finalI).getId(), "");
                            }
                        });
                    }
                }
            }else if(msg.what == 2){
                orderInfoLayout.setVisibility(View.VISIBLE);
                notOrderInfoLayout.setVisibility(View.GONE);
                zhuohaoTV.setText("桌号：" + tableOrderModel.getData().getTable_no());
                dingdanhaohaoTV.setText("订单号：" + tableOrderModel.getData().getOrder_no());
                ordertimeTV.setText("下单时间：" + tableOrderModel.getData().getAdd_time());
                usetimeTV.setText("用餐时间：0");
                daizhifuTV.setText(tableOrderModel.getData().getPaid_price());
                switch (tableOrderModel.getData().getStatus()){
                    case 0:
                        statusTV.setText("订单状态：未支付");
                        break;
                    case 1:
                        statusTV.setText("订单状态：已付款");
                        break;
                    case 2:
                        statusTV.setText("订单状态：已完成");
                        break;
                    case 3:
                        statusTV.setText("订单状态：已取消");
                        break;
                    case 4:
                        statusTV.setText("订单状态：已关闭");
                        break;
                    case 5:
                        statusTV.setText("订单状态：挂账");
                        break;
                    case 6:
                        statusTV.setText("订单状态：合单");
                        break;
                }

            }else if(msg.what == 3){
                orderInfoLayout.setVisibility(View.GONE);
                notOrderInfoLayout.setVisibility(View.VISIBLE);
                notOrderTableNameTV.setText((String) msg.obj + "台桌");
            }else if(msg.what == 4){
                Intent intent = new Intent();
                intent.putExtra("eatNum", eatNum);
                intent.putExtra("tableTitle", (String) msg.obj);
                intent.putExtra("isOpen", true);
                intent.setClass(getActivity(), DiancaiActivity.class);
                getActivity().startActivity(intent);
            }
            return false;
        }
    });

    @OnClick({R.id.cantai_area_page_left, R.id.cantai_area_page_right, R.id.cantai_already_pay_btn, R.id.cantai_not_pay_btn, R.id.cantai_more, R.id.cantai_qingtai, R.id.cantai_orderinfo_jiezhang_btn, R.id.cantai_table_pagedown, R.id.cantai_table_pageup})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.cantai_area_page_left:

                if(areasCurrentPage > 1){
                    areaLayout.removeAllViews();
                    areasCurrentPage = areasCurrentPage - 1;
                    if(areasCurrentPage == 1){
                        pageLeftBtn.setBackgroundResource(R.drawable.bg_black);
                    }else{
                        pageLeftBtn.setBackgroundResource(R.drawable.bg_orange);
                    }
                    if(areasCurrentPage == areasTotalPages){
                        pageRightBtn.setBackgroundResource(R.drawable.bg_black);
                    }else{
                        pageRightBtn.setBackgroundResource(R.drawable.bg_orange);
                    }
                    switch (areasCurrentPage){
                        case 1:
                            LayoutInflater layoutInflater0 = getLayoutInflater();
                            View areaItem0 = layoutInflater0.inflate(R.layout.item_cantai_area,null);
                            final Button button0 = areaItem0.findViewById(R.id.item_cantai_area_title);
                            button0.setText("全部");
                            buttonList.add(button0);
                            areaLayout.removeAllViews();
                            areaLayout.addView(areaItem0);
                            button0.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    for(Button b : buttonList){
                                        b.setBackgroundResource(R.drawable.bg_white);
                                        b.setTextColor(getResources().getColor(R.color.black));
                                    }
                                    button0.setBackgroundResource(R.drawable.bg_orange);
                                    button0.setTextColor(getResources().getColor(R.color.white));
                                    getTables("", "");
                                }
                            });
                            for (int i = 0; i < 6; i++) {
                                LayoutInflater layoutInflater = getLayoutInflater();
                                View areaItem = layoutInflater.inflate(R.layout.item_cantai_area, null);
                                final Button button = areaItem.findViewById(R.id.item_cantai_area_title);
                                button.setText(areaModel.getData().getList().get(i).getTitle());
                                button.setBackgroundResource(R.drawable.bg_white);
                                button.setTextColor(getResources().getColor(R.color.black));
                                buttonList.add(button);
                                areaLayout.addView(areaItem);
                                final int finalI = i;
                                button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        for (Button b : buttonList) {
                                            b.setBackgroundResource(R.drawable.bg_white);
                                            b.setTextColor(getResources().getColor(R.color.black));
                                        }
                                        button.setBackgroundResource(R.drawable.bg_orange);
                                        button.setTextColor(getResources().getColor(R.color.white));
                                        getTables(areaModel.getData().getList().get(finalI).getId(), "");
                                    }
                                });
                            }
                            break;
                        case 2:
                            for (int i = 6; i < 13; i++) {
                                LayoutInflater layoutInflater = getLayoutInflater();
                                View areaItem = layoutInflater.inflate(R.layout.item_cantai_area, null);
                                final Button button = areaItem.findViewById(R.id.item_cantai_area_title);
                                button.setText(areaModel.getData().getList().get(i).getTitle());
                                button.setBackgroundResource(R.drawable.bg_white);
                                button.setTextColor(getResources().getColor(R.color.black));
                                buttonList.add(button);
                                areaLayout.addView(areaItem);
                                final int finalI = i;
                                button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        for (Button b : buttonList) {
                                            b.setBackgroundResource(R.drawable.bg_white);
                                            b.setTextColor(getResources().getColor(R.color.black));
                                        }
                                        button.setBackgroundResource(R.drawable.bg_orange);
                                        button.setTextColor(getResources().getColor(R.color.white));
                                        getTables(areaModel.getData().getList().get(finalI).getId(), "");
                                    }
                                });
                            }
                            break;
                        case 3:
                            for (int i = 13; i < 20; i++) {
                                LayoutInflater layoutInflater = getLayoutInflater();
                                View areaItem = layoutInflater.inflate(R.layout.item_cantai_area, null);
                                final Button button = areaItem.findViewById(R.id.item_cantai_area_title);
                                button.setText(areaModel.getData().getList().get(i).getTitle());
                                button.setBackgroundResource(R.drawable.bg_white);
                                button.setTextColor(getResources().getColor(R.color.black));
                                buttonList.add(button);
                                areaLayout.addView(areaItem);
                                final int finalI = i;
                                button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        for (Button b : buttonList) {
                                            b.setBackgroundResource(R.drawable.bg_white);
                                            b.setTextColor(getResources().getColor(R.color.black));
                                        }
                                        button.setBackgroundResource(R.drawable.bg_orange);
                                        button.setTextColor(getResources().getColor(R.color.white));
                                        getTables(areaModel.getData().getList().get(finalI).getId(), "");
                                    }
                                });
                            }
                            break;
                    }
                }

                break;
            case R.id.cantai_area_page_right:

                if(areasCurrentPage < areasTotalPages){
                    areaLayout.removeAllViews();
                    areasCurrentPage = areasCurrentPage + 1;
                    if(areasCurrentPage == 1){
                        pageLeftBtn.setBackgroundResource(R.drawable.bg_black);
                    }else{
                        pageLeftBtn.setBackgroundResource(R.drawable.bg_orange);
                    }
                    if(areasCurrentPage == areasTotalPages){
                        pageRightBtn.setBackgroundResource(R.drawable.bg_black);
                    }else{
                        pageRightBtn.setBackgroundResource(R.drawable.bg_orange);
                    }
                    int endNum = 0;
                    switch (areasCurrentPage){
                        case 2:

                            if(areasTotalPages != 2){
                                endNum = 13;
                            }else{
                                endNum = areaModel.getData().getTotal();
                            }
                            for (int i = 6; i < endNum; i++) {
                                LayoutInflater layoutInflater = getLayoutInflater();
                                View areaItem = layoutInflater.inflate(R.layout.item_cantai_area, null);
                                final Button button = areaItem.findViewById(R.id.item_cantai_area_title);
                                button.setText(areaModel.getData().getList().get(i).getTitle());
                                button.setBackgroundResource(R.drawable.bg_white);
                                button.setTextColor(getResources().getColor(R.color.black));
                                buttonList.add(button);
                                areaLayout.addView(areaItem);
                                final int finalI = i;
                                button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        for (Button b : buttonList) {
                                            b.setBackgroundResource(R.drawable.bg_white);
                                            b.setTextColor(getResources().getColor(R.color.black));
                                        }
                                        button.setBackgroundResource(R.drawable.bg_orange);
                                        button.setTextColor(getResources().getColor(R.color.white));
                                        getTables(areaModel.getData().getList().get(finalI).getId(), "");

                                    }
                                });
                            }
                            break;
                        case 3:
                            if(areasTotalPages != 3){
                                endNum = 20;
                            }else{
                                endNum = areaModel.getData().getTotal();
                            }
                            for (int i = 13; i < endNum; i++) {
                                LayoutInflater layoutInflater = getLayoutInflater();
                                View areaItem = layoutInflater.inflate(R.layout.item_cantai_area, null);
                                final Button button = areaItem.findViewById(R.id.item_cantai_area_title);
                                button.setText(areaModel.getData().getList().get(i).getTitle());
                                button.setBackgroundResource(R.drawable.bg_white);
                                button.setTextColor(getResources().getColor(R.color.black));
                                buttonList.add(button);
                                areaLayout.addView(areaItem);
                                final int finalI = i;
                                button.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        for (Button b : buttonList) {
                                            b.setBackgroundResource(R.drawable.bg_white);
                                            b.setTextColor(getResources().getColor(R.color.black));
                                        }
                                        button.setBackgroundResource(R.drawable.bg_orange);
                                        button.setTextColor(getResources().getColor(R.color.white));
                                        getTables(areaModel.getData().getList().get(finalI).getId(), "");

                                    }
                                });
                            }
                            break;
                    }
                }

                break;
            case R.id.cantai_already_pay_btn:
                cantaiLayout.removeAllViews();
                for (int i = 0; i < tableModel.getData().getTotal(); i++) {
                    if("1".equals(tableModel.getData().getList().get(i).getOrder_status())) {
                        // 用以下方法将layout布局文件换成view
                        LayoutInflater layoutInflater = getLayoutInflater();
                        View cantaiItem = layoutInflater.inflate(R.layout.item_cantai, null);
                        TextView name = cantaiItem.findViewById(R.id.item_cantai_name);
                        TextView kongxian = cantaiItem.findViewById(R.id.item_cantai_kongxian);
                        View bView = cantaiItem.findViewById(R.id.item_cantai_view);
                        TextView price = cantaiItem.findViewById(R.id.item_cantai_jiage);
                        TextView status = cantaiItem.findViewById(R.id.item_cantai_status);
                        TextView peoplenum = cantaiItem.findViewById(R.id.item_cantai_peoplenum);
                        name.setText(tableModel.getData().getList().get(i).getTitle());
                        peoplenum.setText("0/" + tableModel.getData().getList().get(i).getPeople_num());
                        final LinearLayout bgLayout = cantaiItem.findViewById(R.id.item_cantai_bglayout);
                        final ImageView check = cantaiItem.findViewById(R.id.item_cantai_check);
                        tableCheckList.add(check);
                        switch (tableModel.getData().getList().get(i).getStatus()) {
                            case "0":

                                break;
                            case "1":
                                bgLayout.setBackgroundResource(R.drawable.bg_orange);
                                name.setTextColor(getResources().getColor(R.color.white));
                                peoplenum.setTextColor(getResources().getColor(R.color.white));
                                kongxian.setVisibility(View.GONE);
                                bView.setVisibility(View.GONE);
                                price.setVisibility(View.VISIBLE);
                                status.setVisibility(View.VISIBLE);
                                price.setText("￥" + tableModel.getData().getList().get(i).getMoney());
                                peoplenum.setText(tableModel.getData().getList().get(i).getTableware_num() + "/" + tableModel.getData().getList().get(i).getPeople_num());
                                switch (tableModel.getData().getList().get(i).getOrder_status()) {
                                    case "0":
                                        status.setText("未支付");
                                        break;
                                    case "1":
                                        status.setText("已支付");
                                        break;
                                    case "2":
                                        status.setText("已完成");
                                        break;
                                }

                                break;
                            case "2":
                                bgLayout.setBackgroundResource(R.drawable.bg_green);
                                name.setTextColor(getResources().getColor(R.color.white));
                                peoplenum.setTextColor(getResources().getColor(R.color.white));
                                kongxian.setText("预定");
                                kongxian.setTextColor(getResources().getColor(R.color.white));

                                peoplenum.setText(tableModel.getData().getList().get(i).getTableware_num() + "/" + tableModel.getData().getList().get(i).getPeople_num());

                                break;

                        }

                        final int finalI = i;
                        bgLayout.setOnTouchListener(new ClickListener(new ClickListener.MyClickCallBack() {
                            @Override
                            public void oneClick() {
                                for (ImageView check : tableCheckList) {
                                    check.setVisibility(View.GONE);
                                }
                                check.setVisibility(View.VISIBLE);
                                if ("0".equals(tableModel.getData().getList().get(finalI).getStatus())) {
                                    Message msg = Message.obtain();
                                    msg.what = 3;
                                    msg.obj = tableModel.getData().getList().get(finalI).getTitle();
                                    handler.sendMessage(msg);
                                } else {
                                    getTableOrderInfo(tableModel.getData().getList().get(finalI).getId(), tableModel.getData().getList().get(finalI).getTitle());
                                }
                            }

                            @Override
                            public void doubleClick() {
                                for (ImageView check : tableCheckList) {
                                    check.setVisibility(View.GONE);
                                }
                                check.setVisibility(View.VISIBLE);
                                if ("0".equals(tableModel.getData().getList().get(finalI).getStatus())) {
                                    final OpenTableDialog.Builder openTableBuilder = new OpenTableDialog.Builder(getActivity());
                                    openTableBuilder.setPositiveButton("开台并点菜", new DialogInterface.OnClickListener() {
                                        public void onClick(final DialogInterface dialog, int which) {

                                            eatNum = openTableBuilder.getNum();
                                            if("0".equals(eatNum)){
                                                Toast.makeText(getActivity(), "请输入用餐人数！", Toast.LENGTH_LONG).show();
                                                return;
                                            }

                                            OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
                                            MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
                                            Map<String, String> map = new HashMap<String, String>();
                                            map.put("title", tableModel.getData().getList().get(finalI).getTitle());
                                            map.put("token", loginModel.getData().getToken());
                                            map.put("machine", "shop");
                                            RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
                                            final Request request = new Request.Builder()
                                                    .url(UrlUtil.SERVERIP + "/shop/shopTable/openShopTable")
                                                    .addHeader("Content-Type", "application/json")
                                                    .post(body)
                                                    .build();
                                            okHttpClient.newCall(request).enqueue(new Callback() {
                                                @Override
                                                public void onFailure(Call call, IOException e) {

                                                }

                                                @Override
                                                public void onResponse(Call call, Response response) throws IOException {

                                                    String result = response.body().string();
                                                    try {
                                                        Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                                                        if("1".equals(String.valueOf(map.get("code")))) {
                                                            Message msg = Message.obtain();
                                                            msg.what = 4;
                                                            msg.obj = tableModel.getData().getList().get(finalI).getTitle();
                                                            handler.sendMessage(msg);
                                                        }

                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                    }

                                                }
                                            });


                                        }
                                    });
                                    openTableBuilder.create().show();
                                }else{
                                    Intent intent = new Intent();
                                    intent.setClass(getActivity(), DiancaiActivity.class);
                                    getActivity().startActivity(intent);
                                }
                            }
                        }));

                        cantaiLayout.addView(cantaiItem);
                    }
                }
                break;

            case R.id.cantai_not_pay_btn:
                cantaiLayout.removeAllViews();
                for (int i = 0; i < tableModel.getData().getTotal(); i++) {
                    if("0".equals(tableModel.getData().getList().get(i).getOrder_status())) {
                        // 用以下方法将layout布局文件换成view
                        LayoutInflater layoutInflater = getLayoutInflater();
                        View cantaiItem = layoutInflater.inflate(R.layout.item_cantai, null);
                        TextView name = cantaiItem.findViewById(R.id.item_cantai_name);
                        TextView kongxian = cantaiItem.findViewById(R.id.item_cantai_kongxian);
                        View bView = cantaiItem.findViewById(R.id.item_cantai_view);
                        TextView price = cantaiItem.findViewById(R.id.item_cantai_jiage);
                        TextView status = cantaiItem.findViewById(R.id.item_cantai_status);
                        TextView peoplenum = cantaiItem.findViewById(R.id.item_cantai_peoplenum);
                        name.setText(tableModel.getData().getList().get(i).getTitle());
                        peoplenum.setText("0/" + tableModel.getData().getList().get(i).getPeople_num());
                        final LinearLayout bgLayout = cantaiItem.findViewById(R.id.item_cantai_bglayout);
                        final ImageView check = cantaiItem.findViewById(R.id.item_cantai_check);
                        tableCheckList.add(check);
                        switch (tableModel.getData().getList().get(i).getStatus()) {
                            case "0":

                                break;
                            case "1":
                                bgLayout.setBackgroundResource(R.drawable.bg_orange);
                                name.setTextColor(getResources().getColor(R.color.white));
                                peoplenum.setTextColor(getResources().getColor(R.color.white));
                                kongxian.setVisibility(View.GONE);
                                bView.setVisibility(View.GONE);
                                price.setVisibility(View.VISIBLE);
                                status.setVisibility(View.VISIBLE);
                                price.setText("￥" + tableModel.getData().getList().get(i).getMoney());
                                peoplenum.setText(tableModel.getData().getList().get(i).getTableware_num() + "/" + tableModel.getData().getList().get(i).getPeople_num());
                                switch (tableModel.getData().getList().get(i).getOrder_status()) {
                                    case "0":
                                        status.setText("未支付");
                                        break;
                                    case "1":
                                        status.setText("已支付");
                                        break;
                                    case "2":
                                        status.setText("已完成");
                                        break;
                                }

                                break;
                            case "2":
                                bgLayout.setBackgroundResource(R.drawable.bg_green);
                                name.setTextColor(getResources().getColor(R.color.white));
                                peoplenum.setTextColor(getResources().getColor(R.color.white));
                                kongxian.setText("预定");
                                kongxian.setTextColor(getResources().getColor(R.color.white));

                                peoplenum.setText(tableModel.getData().getList().get(i).getTableware_num() + "/" + tableModel.getData().getList().get(i).getPeople_num());

                                break;

                        }

                        final int finalI = i;
                        bgLayout.setOnTouchListener(new ClickListener(new ClickListener.MyClickCallBack() {
                            @Override
                            public void oneClick() {
                                for (ImageView check : tableCheckList) {
                                    check.setVisibility(View.GONE);
                                }
                                check.setVisibility(View.VISIBLE);
                                if ("0".equals(tableModel.getData().getList().get(finalI).getStatus())) {
                                    Message msg = Message.obtain();
                                    msg.what = 3;
                                    msg.obj = tableModel.getData().getList().get(finalI).getTitle();
                                    handler.sendMessage(msg);
                                } else {
                                    getTableOrderInfo(tableModel.getData().getList().get(finalI).getId(), tableModel.getData().getList().get(finalI).getTitle());
                                }
                            }

                            @Override
                            public void doubleClick() {
                                for (ImageView check : tableCheckList) {
                                    check.setVisibility(View.GONE);
                                }
                                check.setVisibility(View.VISIBLE);
                                if ("0".equals(tableModel.getData().getList().get(finalI).getStatus())) {
                                    final OpenTableDialog.Builder openTableBuilder = new OpenTableDialog.Builder(getActivity());
                                    openTableBuilder.setPositiveButton("开台并点菜", new DialogInterface.OnClickListener() {
                                        public void onClick(final DialogInterface dialog, int which) {

                                            //设置你的操作事项
//                                    String title = addTableBuilder.getTitle();
//                                    String num = addTableBuilder.getNum();

//                                    if("".equals(title)){
//                                        Toast.makeText(getActivity(), "请输入台桌名称！", Toast.LENGTH_LONG).show();
//                                        return;
//                                    }


                                        }
                                    });
                                    openTableBuilder.create().show();
                                }else{
                                    Intent intent = new Intent();
                                    intent.setClass(getActivity(), DiancaiActivity.class);
                                    getActivity().startActivity(intent);
                                }
                            }
                        }));

                        cantaiLayout.addView(cantaiItem);
                    }
                }
                break;

            case R.id.cantai_table_pageup:
                if(tablesCurrentPage > 1){
                    cantaiLayout.removeAllViews();
                    tableCheckList.clear();
                    tablesCurrentPage = tablesCurrentPage - 1;
                    if(tablesCurrentPage == 1){
                        pageUpBtn.setBackgroundResource(R.drawable.bg_gray);
                    }else{
                        pageUpBtn.setBackgroundResource(R.drawable.bg_white);
                    }
                    if(tablesCurrentPage == tablesTotalPages){
                        pageDownBtn.setBackgroundResource(R.drawable.bg_gray);
                    }else{
                        pageDownBtn.setBackgroundResource(R.drawable.bg_white);
                    }
                    switch (tablesCurrentPage){
                        case 1:
                            initTableView(0, 26);
                            break;
                        case 2:
                            initTableView(26, 52);
                            break;
                    }
                }
                break;
            case R.id.cantai_table_pagedown:
                if(tablesCurrentPage < tablesTotalPages){
                    cantaiLayout.removeAllViews();
                    tableCheckList.clear();
                    tablesCurrentPage = tablesCurrentPage + 1;
                    if(tablesCurrentPage == 1){
                        pageUpBtn.setBackgroundResource(R.drawable.bg_gray);
                    }else{
                        pageUpBtn.setBackgroundResource(R.drawable.bg_white);
                    }
                    if(tablesCurrentPage == tablesTotalPages){
                        pageDownBtn.setBackgroundResource(R.drawable.bg_gray);
                    }else{
                        pageDownBtn.setBackgroundResource(R.drawable.bg_white);
                    }
                    int endNum = 0;
                    switch (tablesCurrentPage){
                        case 2:
                            if(tablesTotalPages != 2){
                                endNum = 52;
                            }else{
                                endNum = tableModel.getData().getTotal();
                            }
                            initTableView(26, endNum);
                            break;
                        case 3:
                            if(tablesTotalPages != 3){
                                endNum = 78;
                            }else{
                                endNum = tableModel.getData().getTotal();
                            }
                            initTableView(52, endNum);

                            break;
                    }
                }
                break;
            case R.id.cantai_qingtai:
                showPopupWindow();
                break;
            case R.id.cantai_more:
                showPopupWindow();
                break;
            case R.id.cantai_orderinfo_jiezhang_btn:
                final PayMenuDialog.Builder openTableBuilder = new PayMenuDialog.Builder(getActivity());

                openTableBuilder.create().show();
                break;
        }
    }

    private void showPopupWindow() {
        View contentView = LayoutInflater.from(getActivity()).inflate(R.layout.window_cantai_more, null);
        mPopWindow = new PopupWindow(contentView);
        mPopWindow.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
        mPopWindow.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        mPopWindow.setFocusable(true);
        mPopWindow.setOutsideTouchable(true);

        TextView tv1 = (TextView)contentView.findViewById(R.id.pop_huantai_btn);
        TextView tv2 = (TextView)contentView.findViewById(R.id.pop_hedan_btn);

        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        mPopWindow.showAsDropDown(moreBtn,0, -140);

    }
}
