package com.de.cashier.fragment;


import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.Toast;

import com.de.cashier.R;
import com.de.cashier.adapter.YuyueListViewAdapter;
import com.de.cashier.application.CashierApplication;
import com.de.cashier.model.GuqingListModel;
import com.de.cashier.model.LoginSuccessModel;
import com.de.cashier.model.TableModel;
import com.de.cashier.model.YuyueListModel;
import com.de.cashier.util.CustomDatePicker;
import com.de.cashier.util.DateFormatUtils;
import com.de.cashier.util.MapperUtils;
import com.de.cashier.util.OkHttpClientUtil;
import com.de.cashier.util.UrlUtil;

import org.angmarch.views.NiceSpinner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class YuyueFragment extends Fragment {

    private CashierApplication mApplication;

    private static LoginSuccessModel loginModel;

    private static TableModel tableModel;

    private static YuyueListModel yuyueListModel;

    @BindView(R.id.yuyue_yuyue_time)
    public EditText yuyueEditText;

    @BindView(R.id.yuyue_people_num)
    public EditText numEditText;

    @BindView(R.id.yuyue_poeple_name)
    public EditText nameEditText;

    @BindView(R.id.yuyue_tel)
    public EditText telEditText;

    @BindView(R.id.yuyue_remark)
    public EditText remarkEditText;

    @BindView(R.id.yuyue_table_id)
    public NiceSpinner tableIdSpinner;

    @BindView(R.id.yuyue_suotai_switch)
    public Switch suotaiSwitch;

    @BindView(R.id.yuyue_submit_btn)
    public Button submitBtn;

    public static ListView mListView;

    private static YuyueListViewAdapter mAdapter;

    private int isSuotai = 1;

    private int tableId = -1;

    private CustomDatePicker yuyueDatePicker;

    private CustomDatePicker searchDatePicker;

    private static Context mContext;

    public YuyueFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view  = inflater.inflate(R.layout.fragment_yuyue, container, false);

        ButterKnife.bind(this, view);

        mListView = view.findViewById(R.id.yuyue_listview);

        mApplication = (CashierApplication) CashierApplication.getInstance();

        loginModel = mApplication.getModel();

        tableModel = mApplication.getTableModel();

        mContext = getActivity();

        suotaiSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    isSuotai = 1;
                }else{
                    isSuotai = 0;
                }
            }
        });

        final List<String> tableData = new ArrayList<>();
        tableData.add("请输入预定桌号");
        for(TableModel.TableData.Tables table : tableModel.getData().getList()){
            tableData.add(table.getTitle());
        }

        tableIdSpinner.attachDataSource(tableData);
        tableIdSpinner.setBackgroundResource(R.drawable.edittext_shape);

        tableIdSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position != 0){
                    tableId = tableModel.getData().getList().get(position - 1).getId();
                }else{
                    tableId = -1;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        initStartDatePicker();

        initYuyueList();

        return view;
    }

    private void initYuyueList(){
        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
        Map<String, String> map = new HashMap<String, String>();
        map.put("token", loginModel.getData().getToken());
        map.put("machine", "shop");
        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
        final Request request = new Request.Builder()
                .url(UrlUtil.SERVERIP + "/shop/ShopReserve/shopReserveList")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String result = response.body().string();
                try {
                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                    yuyueListModel = MapperUtils.json2pojo(result, YuyueListModel.class);
                    Message msg = Message.obtain();
                    msg.what = 1;
                    handler.sendMessage(msg);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    @OnClick({R.id.yuyue_submit_btn})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.yuyue_submit_btn:
                editOrDelete(yuyueEditText.getText().toString() + ":00", -1, Integer.parseInt(numEditText.getText().toString()), isSuotai, remarkEditText.getText().toString(), nameEditText.getText().toString(), telEditText.getText().toString(), tableId+"");
                break;
        }
    }

    private void editOrDelete(String time, int id, int num, int suotai, String remark, String name, String tel, String tableId){
        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("start_time", time);
        if(id != -1) {
            map.put("id", id);
        }
        map.put("repast_num", num);
        map.put("is_open", suotai);
        map.put("remark", remark);
        map.put("repast_name", name);
        map.put("repast_phone", tel);
        if(!"-1".equals(tableId)) {
            map.put("table_id", tableId);
        }
        map.put("token", loginModel.getData().getToken());
        map.put("machine", "shop");
        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
        final Request request = new Request.Builder()
                .url(UrlUtil.SERVERIP + "/shop/ShopReserve/shopReserveSave")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String result = response.body().string();
                try {
                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                    if("1".equals(String.valueOf(map.get("code")))) {
//                        yuyueListModel = MapperUtils.json2pojo(result, YuyueListModel.class);
                        Message msg = Message.obtain();
                        msg.what = 0;
                        handler.sendMessage(msg);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.what == 0) {
                Toast.makeText(getActivity(), "预约成功！", Toast.LENGTH_LONG).show();
                numEditText.setText("");
                nameEditText.setText("");
                telEditText.setText("");
                remarkEditText.setText("");
                suotaiSwitch.setChecked(true);
                initYuyueList();
            }else if (msg.what == 1) {
                mAdapter = new YuyueListViewAdapter(getActivity(), yuyueListModel, loginModel.getData().getToken(), tableModel);
                mListView.setAdapter(mAdapter);
            }
            return false;
        }
    });

    public static Handler handler2 = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.what == 0) {
                OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
                MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
                Map<String, String> map = new HashMap<String, String>();
                map.put("token", loginModel.getData().getToken());
                map.put("machine", "shop");
                RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
                final Request request = new Request.Builder()
                        .url(UrlUtil.SERVERIP + "/shop/ShopReserve/shopReserveList")
                        .addHeader("Content-Type", "application/json")
                        .post(body)
                        .build();
                okHttpClient.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {

                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {

                        String result = response.body().string();
                        try {
                            yuyueListModel = MapperUtils.json2pojo(result, YuyueListModel.class);
                            Message msg = Message.obtain();
                            msg.what = 1;
                            handler2.sendMessage(msg);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                });
            }else if (msg.what == 1) {

                mAdapter = new YuyueListViewAdapter(mContext, yuyueListModel, loginModel.getData().getToken(), tableModel);
                mListView.setAdapter(mAdapter);
            }
            return false;
        }
    });

    private void initStartDatePicker() {
        long beginTimestamp = System.currentTimeMillis();
        long endTimestamp = DateFormatUtils.str2Long("2030-12-31 23:59", true);

        yuyueEditText.setText(DateFormatUtils.long2Str(beginTimestamp, true));
        yuyueEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yuyueDatePicker.show(yuyueEditText.getText().toString());
            }
        });

        // 通过时间戳初始化日期，毫秒级别
        yuyueDatePicker = new CustomDatePicker(getActivity(), new CustomDatePicker.Callback() {
            @Override
            public void onTimeSelected(long timestamp) {
                yuyueEditText.setText(DateFormatUtils.long2Str(timestamp, true));
            }
        }, beginTimestamp, endTimestamp);
        // 不允许点击屏幕或物理返回键关闭
        yuyueDatePicker.setCancelable(false);
        // 不显示时和分
        yuyueDatePicker.setCanShowPreciseTime(true);
        // 不允许循环滚动
        yuyueDatePicker.setScrollLoop(false);
        // 不允许滚动动画
        yuyueDatePicker.setCanShowAnim(false);
    }

}
