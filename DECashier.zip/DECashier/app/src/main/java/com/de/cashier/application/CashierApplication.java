package com.de.cashier.application;

import android.app.Activity;
import android.app.Application;
import android.content.Context;

import com.de.cashier.model.LoginSuccessModel;
import com.de.cashier.model.TableModel;

import java.util.ArrayList;
import java.util.List;

public class CashierApplication extends Application {

    private static CashierApplication instance;

    private static List<Activity> lists = new ArrayList<>();

    private LoginSuccessModel model;

    private TableModel tableModel;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    public static Context getInstance() {
        return instance;
    }

    public static void addActivity(Activity activity) {
        lists.add(activity);
    }

    public static void clearActivity() {
        if (lists != null) {
            for (Activity activity : lists) {
                activity.finish();
            }

            lists.clear();
        }
    }

    public LoginSuccessModel getModel() {
        return model;
    }

    public void setModel(LoginSuccessModel model) {
        this.model = model;
    }

    public TableModel getTableModel() {
        return tableModel;
    }

    public void setTableModel(TableModel tableModel) {
        this.tableModel = tableModel;
    }
}
