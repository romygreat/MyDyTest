package com.de.cashier.model;

import java.util.List;

public class GuqingListModel {

    private String code;
    private String message;
    private boolean status;
    private GuqingListData data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public GuqingListData getData() {
        return data;
    }

    public void setData(GuqingListData data) {
        this.data = data;
    }

    public static class GuqingListData{
        private String total;
        private List<Guqing> list;

        public String getTotal() {
            return total;
        }

        public void setTotal(String total) {
            this.total = total;
        }

        public List<Guqing> getList() {
            return list;
        }

        public void setList(List<Guqing> list) {
            this.list = list;
        }

        public static class Guqing{
            private int id;
            private String name;
            private int limit_num;
            private int is_limit;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public int getLimit_num() {
                return limit_num;
            }

            public void setLimit_num(int limit_num) {
                this.limit_num = limit_num;
            }

            public int getIs_limit() {
                return is_limit;
            }

            public void setIs_limit(int is_limit) {
                this.is_limit = is_limit;
            }
        }
    }
}
