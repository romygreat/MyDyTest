package com.de.cashier.model;

import java.util.List;

public class DingdanListModel {

    private List<Order> list;
    private int pageNumber;
    private int pageSize;
    private int totalPage;
    private int totalRow;

    public List<Order> getList() {
        return list;
    }

    public void setList(List<Order> list) {
        this.list = list;
    }

    public int getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber) {
        this.pageNumber = pageNumber;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalRow() {
        return totalRow;
    }

    public void setTotalRow(int totalRow) {
        this.totalRow = totalRow;
    }

    public static class Order{
        private int id;
        private int shop_id;
        private int pid;
        private String order_no;
        private String trade_no;
        private String add_time;
        private String pay_time;
        private int status;
        private int close_reason;
        private String total_price;
        private String paid_price;
        private int pay_action;
        private int pay_way;
        private String delete_time;
        private boolean change_status;
        private String table_no;
        private boolean is_invoice;
        private String over_time;
        private String service_price;
        private String tableware_num;
        private String tableware_fee;
        private String remark;
        private boolean is_new;
        private String real_price;
        private String change_price;
        private String discount_amount;
        private String discount_reason;
        private boolean append;
        private String discount_rate;
        private String pin_out;
        private String list;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getShop_id() {
            return shop_id;
        }

        public void setShop_id(int shop_id) {
            this.shop_id = shop_id;
        }

        public int getPid() {
            return pid;
        }

        public void setPid(int pid) {
            this.pid = pid;
        }

        public String getOrder_no() {
            return order_no;
        }

        public void setOrder_no(String order_no) {
            this.order_no = order_no;
        }

        public String getTrade_no() {
            return trade_no;
        }

        public void setTrade_no(String trade_no) {
            this.trade_no = trade_no;
        }

        public String getAdd_time() {
            return add_time;
        }

        public void setAdd_time(String add_time) {
            this.add_time = add_time;
        }

        public String getPay_time() {
            return pay_time;
        }

        public void setPay_time(String pay_time) {
            this.pay_time = pay_time;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public int getClose_reason() {
            return close_reason;
        }

        public void setClose_reason(int close_reason) {
            this.close_reason = close_reason;
        }

        public String getTotal_price() {
            return total_price;
        }

        public void setTotal_price(String total_price) {
            this.total_price = total_price;
        }

        public String getPaid_price() {
            return paid_price;
        }

        public void setPaid_price(String paid_price) {
            this.paid_price = paid_price;
        }

        public int getPay_action() {
            return pay_action;
        }

        public void setPay_action(int pay_action) {
            this.pay_action = pay_action;
        }

        public int getPay_way() {
            return pay_way;
        }

        public void setPay_way(int pay_way) {
            this.pay_way = pay_way;
        }

        public String getDelete_time() {
            return delete_time;
        }

        public void setDelete_time(String delete_time) {
            this.delete_time = delete_time;
        }

        public boolean isChange_status() {
            return change_status;
        }

        public void setChange_status(boolean change_status) {
            this.change_status = change_status;
        }

        public String getTable_no() {
            return table_no;
        }

        public void setTable_no(String table_no) {
            this.table_no = table_no;
        }

        public boolean isIs_invoice() {
            return is_invoice;
        }

        public void setIs_invoice(boolean is_invoice) {
            this.is_invoice = is_invoice;
        }

        public String getOver_time() {
            return over_time;
        }

        public void setOver_time(String over_time) {
            this.over_time = over_time;
        }

        public String getService_price() {
            return service_price;
        }

        public void setService_price(String service_price) {
            this.service_price = service_price;
        }

        public String getTableware_num() {
            return tableware_num;
        }

        public void setTableware_num(String tableware_num) {
            this.tableware_num = tableware_num;
        }

        public String getTableware_fee() {
            return tableware_fee;
        }

        public void setTableware_fee(String tableware_fee) {
            this.tableware_fee = tableware_fee;
        }

        public String getRemark() {
            return remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }

        public boolean isIs_new() {
            return is_new;
        }

        public void setIs_new(boolean is_new) {
            this.is_new = is_new;
        }

        public String getReal_price() {
            return real_price;
        }

        public void setReal_price(String real_price) {
            this.real_price = real_price;
        }

        public String getChange_price() {
            return change_price;
        }

        public void setChange_price(String change_price) {
            this.change_price = change_price;
        }

        public String getDiscount_amount() {
            return discount_amount;
        }

        public void setDiscount_amount(String discount_amount) {
            this.discount_amount = discount_amount;
        }

        public String getDiscount_reason() {
            return discount_reason;
        }

        public void setDiscount_reason(String discount_reason) {
            this.discount_reason = discount_reason;
        }

        public boolean isAppend() {
            return append;
        }

        public void setAppend(boolean append) {
            this.append = append;
        }

        public String getDiscount_rate() {
            return discount_rate;
        }

        public void setDiscount_rate(String discount_rate) {
            this.discount_rate = discount_rate;
        }

        public String getPin_out() {
            return pin_out;
        }

        public void setPin_out(String pin_out) {
            this.pin_out = pin_out;
        }

        public String getList() {
            return list;
        }

        public void setList(String list) {
            this.list = list;
        }
    }
}
