package com.de.cashier.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.de.cashier.R;
import com.de.cashier.fragment.YuyueFragment;
import com.de.cashier.layout.ConfirmDialog;
import com.de.cashier.layout.GuqingDialog;
import com.de.cashier.layout.YuyueEditDialog;
import com.de.cashier.model.DingdanListModel;
import com.de.cashier.model.TableModel;
import com.de.cashier.model.YuyueListModel;
import com.de.cashier.util.MapperUtils;
import com.de.cashier.util.OkHttpClientUtil;
import com.de.cashier.util.UrlUtil;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class DingdanListViewAdapter extends BaseAdapter {

    private DingdanListModel dingdanListModel;
    private LayoutInflater layoutInflater;
    private Context context;
    private int mCurrentItem = 0;
    private boolean isClick = false;
    private String token;

    public DingdanListViewAdapter(Context context, DingdanListModel dingdanListModel, String token){
        this.context = context;
        this.dingdanListModel = dingdanListModel;
        this.layoutInflater = LayoutInflater.from(context);
        this.token = token;
    }

    public final class MyView{
        public TextView time;
        public TextView orderno;
        public TextView num;
        public TextView status;
        public TextView tableNo;
        public TextView paytype;
        public TextView payclass;
        public TextView money;
        public Button editBtn;
    }

    @Override
    public int getCount() {
        return dingdanListModel.getList().size();
    }

    @Override
    public Object getItem(int position) {
        return dingdanListModel.getList().get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        MyView myView = null;
        if(convertView==null){
            myView=new MyView();
            //获得组件，实例化组件
            convertView=layoutInflater.inflate(R.layout.item_listview_dingdan, null);
            myView.orderno=(TextView)convertView.findViewById(R.id.item_dingdan_orderno);
            myView.time=(TextView)convertView.findViewById(R.id.item_dingdan_ordertime);
            myView.num=(TextView)convertView.findViewById(R.id.item_dingdan_peoplenum);
            myView.paytype=(TextView)convertView.findViewById(R.id.item_dingdan_paytype);
            myView.payclass=(TextView)convertView.findViewById(R.id.item_dingdan_payclass);
            myView.tableNo=(TextView)convertView.findViewById(R.id.item_dingdan_tableno);
            myView.money=(TextView)convertView.findViewById(R.id.item_dingdan_money);
            myView.status=(TextView)convertView.findViewById(R.id.item_dingdan_orderstatus);
            myView.editBtn=(Button) convertView.findViewById(R.id.item_dingdan_editbtn);

            convertView.setTag(myView);
        }else{
            myView=(MyView)convertView.getTag();
        }
        //绑定数据
        myView.orderno.setText(dingdanListModel.getList().get(position).getOrder_no());
        myView.time.setText(dingdanListModel.getList().get(position).getAdd_time());
        myView.num.setText(dingdanListModel.getList().get(position).getTableware_num());
        myView.money.setText("￥" + dingdanListModel.getList().get(position).getReal_price());
        myView.tableNo.setText(dingdanListModel.getList().get(position).getTable_no());
//        myView.name.setText(yuyueListModel.getList().get(position).getRepast_name());
//        myView.num.setText(yuyueListModel.getList().get(position).getRepast_num()+"");
//        myView.tel.setText(yuyueListModel.getList().get(position).getRepast_phone());
//        if(yuyueListModel.getList().get(position).getRemark().length() > 10) {
//            myView.remark.setText(yuyueListModel.getList().get(position).getRemark().substring(0, 10) + "...");
//        }else{
//            myView.remark.setText(yuyueListModel.getList().get(position).getRemark());
//        }
//        myView.tableNo.setText(yuyueListModel.getList().get(position).getTable_title());
//
//        myView.edit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                yuyueEditBuilder = new YuyueEditDialog.Builder(context, yuyueListModel.getList().get(position), tableModel);
//                yuyueEditBuilder.setPositiveButton("取消", new DialogInterface.OnClickListener() {
//                    public void onClick(final DialogInterface dialog, int which) {
//                        dialog.dismiss();
//                    }
//                });
//                yuyueEditBuilder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
//                    public void onClick(final DialogInterface dialog, int which) {
//                        time = yuyueEditBuilder.getTime();
//                        id = yuyueListModel.getList().get(position).getId();
//                        num = yuyueEditBuilder.getNum();
//                        suotai = yuyueEditBuilder.getIsSuotai();
//                        remark = yuyueEditBuilder.getRemark();
//                        name = yuyueEditBuilder.getName();
//                        tel = yuyueEditBuilder.getTel();
//                        tableId = yuyueEditBuilder.getTableid();
//                        tableTitle = yuyueEditBuilder.getTableTitle();
//
//                        edit(time + ":00", id, Integer.parseInt(num), suotai, remark, name, tel, tableId+"", position);
//                    }
//                });
//                yuyueEditDialog = yuyueEditBuilder.create();
//                yuyueEditDialog.show();
//            }
//        });
//
//        myView.delete.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                confirmBuilder = new ConfirmDialog.Builder(context);
//                confirmBuilder.setPositiveButton("取消", new DialogInterface.OnClickListener() {
//                    public void onClick(final DialogInterface dialog, int which) {
//                        dialog.dismiss();
//                    }
//                });
//                confirmBuilder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
//                    public void onClick(final DialogInterface dialog, int which) {
//                        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
//                        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
//                        Map<String, Object> map = new HashMap<String, Object>();
//                        map.put("id", yuyueListModel.getList().get(position).getId());
//                        map.put("token", token);
//                        map.put("machine", "shop");
//                        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
//                        final Request request = new Request.Builder()
//                                .url(UrlUtil.SERVERIP + "/shop/ShopReserve/shopReserveDel")
//                                .addHeader("Content-Type", "application/json")
//                                .post(body)
//                                .build();
//                        okHttpClient.newCall(request).enqueue(new Callback() {
//                            @Override
//                            public void onFailure(Call call, IOException e) {
//
//                            }
//
//                            @Override
//                            public void onResponse(Call call, Response response) throws IOException {
//
//                                String result = response.body().string();
//                                try {
//                                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
//                                    if("1".equals(String.valueOf(map.get("code")))) {
//                                        Message msg = Message.obtain();
//                                        msg.what = 0;
//                                        msg.obj = position;
//                                        handler.sendMessage(msg);
//                                    }
//
//                                } catch (Exception e) {
//                                    e.printStackTrace();
//                                }
//
//                            }
//                        });
//                    }
//                });
//                confirmDialog = confirmBuilder.create();
//                confirmDialog.show();
//
//
//            }
//        });

        return convertView;
    }

    public void setCurrentItem(int currentItem){
        this.mCurrentItem = currentItem;
    }

    public void setClick(boolean click){
        this.isClick = click;
    }

    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.what == 0) {
            }else if (msg.what == 1) {
            }
            return false;
        }
    });

}

