package com.de.cashier.model;

import java.io.Serializable;
import java.util.List;

public class LoginSuccessModel implements Serializable {

    private String code;
    private String message;
    private boolean status;
    private Data data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public class Data implements Serializable{
        private Shop shop;
        private String last_login_time;
        private boolean is_super;
        private String affiliation_id;
        private String realname;
        private String token;
        private String uid;
        private String role_id;
        private String user;
        private String account;
        private String terminal_id;
        private String token_validity;
        private boolean status;

        public Shop getShop() {
            return shop;
        }

        public void setShop(Shop shop) {
            this.shop = shop;
        }

        public String getLast_login_time() {
            return last_login_time;
        }

        public void setLast_login_time(String last_login_time) {
            this.last_login_time = last_login_time;
        }

        public boolean isIs_super() {
            return is_super;
        }

        public void setIs_super(boolean is_super) {
            this.is_super = is_super;
        }

        public String getAffiliation_id() {
            return affiliation_id;
        }

        public void setAffiliation_id(String affiliation_id) {
            this.affiliation_id = affiliation_id;
        }

        public String getRealname() {
            return realname;
        }

        public void setRealname(String realname) {
            this.realname = realname;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public String getUid() {
            return uid;
        }

        public void setUid(String uid) {
            this.uid = uid;
        }

        public String getRole_id() {
            return role_id;
        }

        public void setRole_id(String role_id) {
            this.role_id = role_id;
        }

        public String getUser() {
            return user;
        }

        public void setUser(String user) {
            this.user = user;
        }

        public String getAccount() {
            return account;
        }

        public void setAccount(String account) {
            this.account = account;
        }

        public String getTerminal_id() {
            return terminal_id;
        }

        public void setTerminal_id(String terminal_id) {
            this.terminal_id = terminal_id;
        }

        public String getToken_validity() {
            return token_validity;
        }

        public void setToken_validity(String token_validity) {
            this.token_validity = token_validity;
        }

        public boolean isStatus() {
            return status;
        }

        public void setStatus(boolean status) {
            this.status = status;
        }

        public class Shop implements Serializable{
            private boolean is_e_print;
            private String address;
            private String salt;
            private String service_price;
            private boolean is_voice;
            private String charge_price;
            private String ticket_tail;
            private boolean is_service;
            private String[] pay_action;
            private String shop_id;
            private String tableware_fee;
            private String phone;
            private boolean is_direct_printer;
            private boolean is_tableware;
            private String is_reserve;
            private String name;
            private String id;
            private boolean is_invoice;
            private String ticket_head;
            private boolean is_print;
            private String pwd;
            private String charge_time;
            private String product_bind;

            public boolean isIs_e_print() {
                return is_e_print;
            }

            public void setIs_e_print(boolean is_e_print) {
                this.is_e_print = is_e_print;
            }

            public String getAddress() {
                return address;
            }

            public void setAddress(String address) {
                this.address = address;
            }

            public String getSalt() {
                return salt;
            }

            public void setSalt(String salt) {
                this.salt = salt;
            }

            public String getService_price() {
                return service_price;
            }

            public void setService_price(String service_price) {
                this.service_price = service_price;
            }

            public boolean isIs_voice() {
                return is_voice;
            }

            public void setIs_voice(boolean is_voice) {
                this.is_voice = is_voice;
            }

            public String getCharge_price() {
                return charge_price;
            }

            public void setCharge_price(String charge_price) {
                this.charge_price = charge_price;
            }

            public String getTicket_tail() {
                return ticket_tail;
            }

            public void setTicket_tail(String ticket_tail) {
                this.ticket_tail = ticket_tail;
            }

            public boolean isIs_service() {
                return is_service;
            }

            public void setIs_service(boolean is_service) {
                this.is_service = is_service;
            }

            public String[] getPay_action() {
                return pay_action;
            }

            public void setPay_action(String[] pay_action) {
                this.pay_action = pay_action;
            }

            public String getShop_id() {
                return shop_id;
            }

            public void setShop_id(String shop_id) {
                this.shop_id = shop_id;
            }

            public String getTableware_fee() {
                return tableware_fee;
            }

            public void setTableware_fee(String tableware_fee) {
                this.tableware_fee = tableware_fee;
            }

            public String getPhone() {
                return phone;
            }

            public void setPhone(String phone) {
                this.phone = phone;
            }

            public boolean isIs_direct_printer() {
                return is_direct_printer;
            }

            public void setIs_direct_printer(boolean is_direct_printer) {
                this.is_direct_printer = is_direct_printer;
            }

            public boolean isIs_tableware() {
                return is_tableware;
            }

            public void setIs_tableware(boolean is_tableware) {
                this.is_tableware = is_tableware;
            }

            public String getIs_reserve() {
                return is_reserve;
            }

            public void setIs_reserve(String is_reserve) {
                this.is_reserve = is_reserve;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public boolean isIs_invoice() {
                return is_invoice;
            }

            public void setIs_invoice(boolean is_invoice) {
                this.is_invoice = is_invoice;
            }

            public String getTicket_head() {
                return ticket_head;
            }

            public void setTicket_head(String ticket_head) {
                this.ticket_head = ticket_head;
            }

            public boolean isIs_print() {
                return is_print;
            }

            public void setIs_print(boolean is_print) {
                this.is_print = is_print;
            }

            public String getPwd() {
                return pwd;
            }

            public void setPwd(String pwd) {
                this.pwd = pwd;
            }

            public String getCharge_time() {
                return charge_time;
            }

            public void setCharge_time(String charge_time) {
                this.charge_time = charge_time;
            }

            public String getProduct_bind() {
                return product_bind;
            }

            public void setProduct_bind(String product_bind) {
                this.product_bind = product_bind;
            }
        }
    }


}
