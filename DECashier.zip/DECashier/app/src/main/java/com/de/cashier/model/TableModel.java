package com.de.cashier.model;

import java.util.List;

public class TableModel {

    private String code;
    private String message;
    private boolean status;
    private TableData data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public TableData getData() {
        return data;
    }

    public void setData(TableData data) {
        this.data = data;
    }

    public static class TableData{
        private int total;
        private List<Tables> list;
        private Status status;
        private Order order;

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public List<Tables> getList() {
            return list;
        }

        public void setList(List<Tables> list) {
            this.list = list;
        }

        public Status getStatus() {
            return status;
        }

        public void setStatus(Status status) {
            this.status = status;
        }

        public Order getOrder() {
            return order;
        }

        public void setOrder(Order order) {
            this.order = order;
        }

        public class Order{
            private String order_unincome_money;
            private int order_total;
            private int order_unincome;

            public String getOrder_unincome_money() {
                return order_unincome_money;
            }

            public void setOrder_unincome_money(String order_unincome_money) {
                this.order_unincome_money = order_unincome_money;
            }

            public int getOrder_total() {
                return order_total;
            }

            public void setOrder_total(int order_total) {
                this.order_total = order_total;
            }

            public int getOrder_unincome() {
                return order_unincome;
            }

            public void setOrder_unincome(int order_unincome) {
                this.order_unincome = order_unincome;
            }
        }

        public class Status{
            private String all;
            private String subscribe;
            private String leisure;
            private String meals;

            public String getAll() {
                return all;
            }

            public void setAll(String all) {
                this.all = all;
            }

            public String getSubscribe() {
                return subscribe;
            }

            public void setSubscribe(String subscribe) {
                this.subscribe = subscribe;
            }

            public String getLeisure() {
                return leisure;
            }

            public void setLeisure(String leisure) {
                this.leisure = leisure;
            }

            public String getMeals() {
                return meals;
            }

            public void setMeals(String meals) {
                this.meals = meals;
            }
        }

        public static class Tables{
            private int id;
            private String title;
            private String people_num;
            private String status;
            private String money;
            private String order_status;
            private String order_id;
            private String tableware_num;
            private int subarea_id;

            public int getSubarea_id() {
                return subarea_id;
            }

            public void setSubarea_id(int subarea_id) {
                this.subarea_id = subarea_id;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getPeople_num() {
                return people_num;
            }

            public void setPeople_num(String people_num) {
                this.people_num = people_num;
            }

            public String getStatus() {
                return status;
            }

            public void setStatus(String status) {
                this.status = status;
            }

            public String getMoney() {
                return money;
            }

            public void setMoney(String money) {
                this.money = money;
            }

            public String getOrder_status() {
                return order_status;
            }

            public void setOrder_status(String order_status) {
                this.order_status = order_status;
            }

            public String getOrder_id() {
                return order_id;
            }

            public void setOrder_id(String order_id) {
                this.order_id = order_id;
            }

            public String getTableware_num() {
                return tableware_num;
            }

            public void setTableware_num(String tableware_num) {
                this.tableware_num = tableware_num;
            }
        }
    }
}
