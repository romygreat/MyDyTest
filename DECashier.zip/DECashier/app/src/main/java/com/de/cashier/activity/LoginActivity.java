package com.de.cashier.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.de.cashier.R;
import com.de.cashier.application.CashierApplication;
import com.de.cashier.model.LoginSuccessModel;
import com.de.cashier.util.MapperUtils;
import com.de.cashier.util.OkHttpClientUtil;
import com.de.cashier.util.UrlUtil;
import com.qmuiteam.qmui.widget.dialog.QMUIDialog;
import com.qmuiteam.qmui.widget.dialog.QMUITipDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class LoginActivity extends Activity {

    @BindView(R.id.login_username)
    public EditText usernameET;

    @BindView(R.id.login_password)
    public EditText passwordET;

    @BindView(R.id.login_button_0)
    public Button button0;

    @BindView(R.id.login_button_1)
    public Button button1;

    @BindView(R.id.login_button_2)
    public Button button2;

    @BindView(R.id.login_button_3)
    public Button button3;

    @BindView(R.id.login_button_4)
    public Button button4;

    @BindView(R.id.login_button_5)
    public Button button5;

    @BindView(R.id.login_button_6)
    public Button button6;

    @BindView(R.id.login_button_7)
    public Button button7;

    @BindView(R.id.login_button_8)
    public Button button8;

    @BindView(R.id.login_button_9)
    public Button button9;

    @BindView(R.id.login_button_back)
    public Button buttonBack;

    @BindView(R.id.login_button_go)
    public Button buttonGo;

    @BindView(R.id.login_errormsg)
    public TextView errormsgTV;

    private boolean usernameEtFocus = false;

    private boolean passwordEtFocus = false;

    private QMUITipDialog dialog;

    private OkHttpClient okHttpClient;

    private CashierApplication mApplication;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        ButterKnife.bind(this);

        mApplication = (CashierApplication) CashierApplication.getInstance();

        usernameET.setOnFocusChangeListener(new android.view.View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {

                if (hasFocus) {
                    // 获得焦点
                    usernameEtFocus = true;
                } else {
                    // 失去焦点
                    usernameEtFocus = false;
                }
            }
        });

        passwordET.setOnFocusChangeListener(new android.view.View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {

                if (hasFocus) {
                    // 获得焦点
                    passwordEtFocus = true;
                } else {
                    // 失去焦点
                    passwordEtFocus = false;
                }
            }
        });
    }

    @OnClick({R.id.login_button_0, R.id.login_button_1, R.id.login_button_2, R.id.login_button_3, R.id.login_button_4, R.id.login_button_5, R.id.login_button_6, R.id.login_button_7, R.id.login_button_8, R.id.login_button_9, R.id.login_button_back, R.id.login_button_go})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.login_button_0:
                if(usernameEtFocus){
                    int index = usernameET.getSelectionStart();
                    Editable editable = usernameET.getText();
                    editable.insert(index, "0");
                }
                if(passwordEtFocus){
                    int index = passwordET.getSelectionStart();
                    Editable editable = passwordET.getText();
                    editable.insert(index, "0");
                }
                break;
            case R.id.login_button_1:
                if(usernameEtFocus){
                    int index = usernameET.getSelectionStart();
                    Editable editable = usernameET.getText();
                    editable.insert(index, "1");
                }
                if(passwordEtFocus){
                    int index = passwordET.getSelectionStart();
                    Editable editable = passwordET.getText();
                    editable.insert(index, "1");
                }
                break;
            case R.id.login_button_2:
                if(usernameEtFocus){
                    int index = usernameET.getSelectionStart();
                    Editable editable = usernameET.getText();
                    editable.insert(index, "2");
                }
                if(passwordEtFocus){
                    int index = passwordET.getSelectionStart();
                    Editable editable = passwordET.getText();
                    editable.insert(index, "2");
                }
                break;
            case R.id.login_button_3:
                if(usernameEtFocus){
                    int index = usernameET.getSelectionStart();
                    Editable editable = usernameET.getText();
                    editable.insert(index, "3");
                }
                if(passwordEtFocus){
                    int index = passwordET.getSelectionStart();
                    Editable editable = passwordET.getText();
                    editable.insert(index, "3");
                }
                break;
            case R.id.login_button_4:
                if(usernameEtFocus){
                    int index = usernameET.getSelectionStart();
                    Editable editable = usernameET.getText();
                    editable.insert(index, "4");
                }
                if(passwordEtFocus){
                    int index = passwordET.getSelectionStart();
                    Editable editable = passwordET.getText();
                    editable.insert(index, "4");
                }
                break;
            case R.id.login_button_5:
                if(usernameEtFocus){
                    int index = usernameET.getSelectionStart();
                    Editable editable = usernameET.getText();
                    editable.insert(index, "5");
                }
                if(passwordEtFocus){
                    int index = passwordET.getSelectionStart();
                    Editable editable = passwordET.getText();
                    editable.insert(index, "5");
                }
                break;
            case R.id.login_button_6:
                if(usernameEtFocus){
                    int index = usernameET.getSelectionStart();
                    Editable editable = usernameET.getText();
                    editable.insert(index, "6");
                }
                if(passwordEtFocus){
                    int index = passwordET.getSelectionStart();
                    Editable editable = passwordET.getText();
                    editable.insert(index, "6");
                }
                break;
            case R.id.login_button_7:
                if(usernameEtFocus){
                    int index = usernameET.getSelectionStart();
                    Editable editable = usernameET.getText();
                    editable.insert(index, "7");
                }
                if(passwordEtFocus){
                    int index = passwordET.getSelectionStart();
                    Editable editable = passwordET.getText();
                    editable.insert(index, "7");
                }
                break;
            case R.id.login_button_8:
                if(usernameEtFocus){
                    int index = usernameET.getSelectionStart();
                    Editable editable = usernameET.getText();
                    editable.insert(index, "8");
                }
                if(passwordEtFocus){
                    int index = passwordET.getSelectionStart();
                    Editable editable = passwordET.getText();
                    editable.insert(index, "8");
                }
                break;
            case R.id.login_button_9:
                if(usernameEtFocus){
                    int index = usernameET.getSelectionStart();
                    Editable editable = usernameET.getText();
                    editable.insert(index, "9");
                }
                if(passwordEtFocus){
                    int index = passwordET.getSelectionStart();
                    Editable editable = passwordET.getText();
                    editable.insert(index, "9");
                }
                break;
            case R.id.login_button_back:
                if(usernameEtFocus){
                    int index = usernameET.getSelectionStart();
                    if(index > 0) {
                        Editable editable = usernameET.getText();
                        editable.delete(index - 1, index);
                    }
                }
                if(passwordEtFocus){
                    int index = passwordET.getSelectionStart();
                    if(index > 0) {
                        Editable editable = passwordET.getText();
                        editable.delete(index - 1, index);
                    }
                }
                break;
            case R.id.login_button_go:
//                if("".equals(usernameET.getText().toString().toString())){
//                    errormsgTV.setVisibility(View.VISIBLE);
//                    errormsgTV.setText("请输入账号");
//                    return;
//                }
//                if("".equals(passwordET.getText().toString().toString())){
//                    errormsgTV.setVisibility(View.VISIBLE);
//                    errormsgTV.setText("请输入密码");
//                    return;
//                }
                dialog = new QMUITipDialog.Builder(LoginActivity.this)
                        .setIconType(QMUITipDialog.Builder.ICON_TYPE_LOADING)
                        .setTipWord("正在登陆，请稍后...")
                        .create();
                dialog.setCanceledOnTouchOutside(false);
                dialog.setCancelable(false);
                dialog.show();
                okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
                MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
                Map<String, String> map = new HashMap<String, String>();
                map.put("account", "18028498089");
                map.put("pwd", "123456");
                map.put("terminal_domain", "shop.gddiyi.com");
                map.put("token", "");
                map.put("machine", "");
                RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
                final Request request = new Request.Builder()
                        .url(UrlUtil.SERVERIP + "/account/Login/userLogin")
                        .addHeader("Content-Type", "application/json")
                        .post(body)
                        .build();
                okHttpClient.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        Message msg = Message.obtain();
                        msg.what = 1;
                        handler.sendMessage(msg);
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {

                        String result = response.body().string();
                        try {
                            Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                            if("10011".equals(String.valueOf(map.get("code")))){
                                LoginSuccessModel model = MapperUtils.json2pojo(result, LoginSuccessModel.class);
                                mApplication.setModel(model);
                                Intent intent = new Intent();
                                intent.putExtra("model", model);
                                intent.setClass(LoginActivity.this, MainActivity.class);
                                startActivity(intent);
                                Message msg = Message.obtain();
                                msg.what = 2;
                                handler.sendMessage(msg);
                            }else{
                                Message msg = Message.obtain();
                                msg.what = 0;
                                handler.sendMessage(msg);
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                });
                break;
        }
    }

    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.what == 0) {
                dialog.dismiss();
                errormsgTV.setVisibility(View.VISIBLE);
                errormsgTV.setText("用户名或密码错误");
            }else if(msg.what == 1){
                dialog.dismiss();
            }else if(msg.what == 2){
                dialog.dismiss();
            }
            return false;
        }
    });

    @Override
    protected void onDestroy() {
        super.onDestroy();
        okHttpClient.dispatcher().cancelAll();
    }
}
