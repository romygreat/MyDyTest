package com.de.cashier.layout;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.de.cashier.R;

import org.angmarch.views.NiceSpinner;

public class PayMenuDialog extends Dialog {

    public PayMenuDialog(Context context) {
        super(context);
    }

    public PayMenuDialog(Context context, int theme) {
        super(context, theme);  
    }

    public static class Builder {  
        private Context context;
        private View contentView;
        private Button jiezhangBtn;
        private LinearLayout cashLayout;
        private LinearLayout guazhangLayout;
        private LinearLayout cashBtn;
        private LinearLayout scanBtn;
        private LinearLayout guazhangBtn;
        private NiceSpinner areaSpinner;
        private ImageView cashBtnImage;
        private ImageView scanBtnImage;
        private ImageView guazhangBtnImage;
        private TextView cashBtnName;
        private TextView scanBtnName;
        private TextView guazhangBtnName;


        public Builder(Context context) {  
            this.context = context;  
        } 
        
        public Builder setContentView(View v) {
            this.contentView = v;  
            return this;  
        }

        public PayMenuDialog create() {
        	LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);  
            // instantiate the dialog with the custom Theme  
            final PayMenuDialog dialog = new PayMenuDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.dialog_pay_menu, null);
            dialog.addContentView(layout, new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));  
            cashLayout = (LinearLayout) layout.findViewById(R.id.dialog_pay_cash_layout);
            guazhangLayout = (LinearLayout) layout.findViewById(R.id.dialog_pay_guazhang_layout);
            jiezhangBtn = (Button) layout.findViewById(R.id.dialog_pay_menu_jiezhang);
            cashBtn = (LinearLayout) layout.findViewById(R.id.dialog_pay_menu_cash_layout_btn);
            scanBtn = (LinearLayout) layout.findViewById(R.id.dialog_pay_menu_scan_layout_btn);
            guazhangBtn = (LinearLayout) layout.findViewById(R.id.dialog_pay_menu_guazhang_layout_btn);
            cashBtnImage = (ImageView) layout.findViewById(R.id.dialog_pay_menu_cashbtn_image);
            scanBtnImage = (ImageView) layout.findViewById(R.id.dialog_pay_menu_scanbtn_image);
            guazhangBtnImage = (ImageView) layout.findViewById(R.id.dialog_pay_menu_guazhangbtn_image);
            cashBtnName = (TextView) layout.findViewById(R.id.dialog_pay_menu_cashbtn_name);
            scanBtnName = (TextView) layout.findViewById(R.id.dialog_pay_menu_scanbtn_name);
            guazhangBtnName = (TextView) layout.findViewById(R.id.dialog_pay_menu_guazhangbtn_name);

            cashBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cashBtn.setBackgroundResource(R.drawable.button_bg_orange);
                    cashBtnImage.setImageResource(R.mipmap.btn_icon_cash_select);
                    cashBtnName.setTextColor(context.getColor(R.color.white));
                    guazhangBtn.setBackgroundResource(R.drawable.button_bg_gray);
                    guazhangBtnImage.setImageResource(R.mipmap.btn_icon_guazhang_normal);
                    guazhangBtnName.setTextColor(context.getColor(R.color.black));

                    cashLayout.setVisibility(View.VISIBLE);
                    guazhangLayout.setVisibility(View.GONE);
                }
            });
            scanBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final OpenTableDialog.Builder openTableBuilder = new OpenTableDialog.Builder(context);
                    openTableBuilder.create().show();
                }
            });
            guazhangBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cashBtn.setBackgroundResource(R.drawable.button_bg_gray);
                    cashBtnImage.setImageResource(R.mipmap.btn_icon_cash_normal);
                    cashBtnName.setTextColor(context.getColor(R.color.black));
                    guazhangBtn.setBackgroundResource(R.drawable.button_bg_orange);
                    guazhangBtnImage.setImageResource(R.mipmap.btn_icon_guazhang_select);
                    guazhangBtnName.setTextColor(context.getColor(R.color.white));

                    cashLayout.setVisibility(View.GONE);
                    guazhangLayout.setVisibility(View.VISIBLE);
                }
            });

            jiezhangBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(context, "jiezhang", Toast.LENGTH_LONG).show();
                }
            });


            // set the content message  
            if (contentView != null) {  
                // if no message set  
                // add the contentView to the dialog body  
                ((LinearLayout) layout.findViewById(R.id.content)).removeAllViews();  
                ((LinearLayout) layout.findViewById(R.id.content)).addView(contentView, new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));  
            }  
            dialog.setContentView(layout);  
            return dialog;  
        }  
    }  
}