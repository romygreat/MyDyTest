package com.de.cashier.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.de.cashier.R;
import com.de.cashier.fragment.BaobiaoFragment;
import com.de.cashier.fragment.CantaiFragment;
import com.de.cashier.fragment.DayinFragment;
import com.de.cashier.fragment.DingdanFragment;
import com.de.cashier.fragment.GuqingFragment;
import com.de.cashier.fragment.YuyueFragment;
import com.de.cashier.fragment.XinxiFragment;

import butterknife.BindView;

public class MainActivity extends FragmentActivity {

    public RadioGroup radioGroup;

    @BindView(R.id.main_menu_cantai)
    public RadioButton cantai;

    @BindView(R.id.main_menu_digndan)
    public RadioButton dingdan;

    @BindView(R.id.main_menu_guqing)
    public RadioButton guqing;

    @BindView(R.id.main_menu_xinxi)
    public RadioButton xinxi;

    @BindView(R.id.main_menu_mendian)
    public RadioButton mendian;

    @BindView(R.id.main_menu_baobiao)
    public RadioButton baobiao;

    @BindView(R.id.main_menu_dayin)
    public RadioButton dayin;

    @BindView(R.id.main_menu_tuichu)
    public RadioButton tuichu;

    //  fragment标记
    public static final String fragmentCantaiTag = "cantai";
    public static final String fragmentDingdanTag = "dingdan";
    public static final String fragmentGuqingTag = "guqing";
    public static final String fragmentXinxiTag = "xinxi";
    public static final String fragmentMendianTag = "mendian";
    public static final String fragmentBaobiaoTag = "baobiao";
    public static final String fragmentDayinTag = "dayin";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initOnclick();
    }

    public void initView() {
        firstShow();
    }

    public void initOnclick() {
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        // 单选框的点击事件，判断哪一个选中
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

                //用对应的标记在内存中找对应的Fragment对象
                Fragment cantaiFragment =  fragmentManager.findFragmentByTag(fragmentCantaiTag);
                Fragment dingdanFragment =  fragmentManager.findFragmentByTag(fragmentDingdanTag);
                Fragment guqingFragment =  fragmentManager.findFragmentByTag(fragmentGuqingTag);
                Fragment xinxiFragment =  fragmentManager.findFragmentByTag(fragmentXinxiTag);
                Fragment mendianFragment =  fragmentManager.findFragmentByTag(fragmentMendianTag);
                Fragment baobiaoFragment =  fragmentManager.findFragmentByTag(fragmentBaobiaoTag);
                Fragment dayinFragment =  fragmentManager.findFragmentByTag(fragmentDayinTag);

                if (cantaiFragment != null) {
                    fragmentTransaction.hide(cantaiFragment);
                }
                if (dingdanFragment != null) {
                    fragmentTransaction.hide(dingdanFragment);
                }
                if (guqingFragment != null) {
                    fragmentTransaction.hide(guqingFragment);
                }
                if (xinxiFragment != null) {
                    fragmentTransaction.hide(xinxiFragment);
                }
                if (mendianFragment != null) {
                    fragmentTransaction.hide(mendianFragment);
                }
                if (baobiaoFragment != null) {
                    fragmentTransaction.hide(baobiaoFragment);
                }
                if (dayinFragment != null) {
                    fragmentTransaction.hide(dayinFragment);
                }

                switch (checkedId) {
                    case R.id.main_menu_cantai:
                        if (cantaiFragment == null) {
                            cantaiFragment = new CantaiFragment();
                            fragmentTransaction.add(R.id.activity_main_framlayout, cantaiFragment, fragmentCantaiTag);

                        } else {
                            fragmentTransaction.show(cantaiFragment);

                        }
                        fragmentTransaction.commit();
                        break;
                    case R.id.main_menu_digndan:
                        if (dingdanFragment == null) {
                            dingdanFragment = new DingdanFragment();
                            fragmentTransaction.add(R.id.activity_main_framlayout, dingdanFragment, fragmentDingdanTag);

                        } else {
                            fragmentTransaction.show(dingdanFragment);

                        }
                        fragmentTransaction.commit();
                        break;
                    case R.id.main_menu_guqing:
                        if (guqingFragment == null) {
                            guqingFragment = new GuqingFragment();
                            fragmentTransaction.add(R.id.activity_main_framlayout, guqingFragment, fragmentGuqingTag);

                        } else {
                            fragmentTransaction.show(guqingFragment);

                        }
                        fragmentTransaction.commit();
                        break;
                    case R.id.main_menu_xinxi:
                        if (xinxiFragment == null) {
                            xinxiFragment = new XinxiFragment();
                            fragmentTransaction.add(R.id.activity_main_framlayout, xinxiFragment, fragmentXinxiTag);

                        } else {
                            fragmentTransaction.show(xinxiFragment);
                        }
                        fragmentTransaction.commit();
                        break;
                    case R.id.main_menu_mendian:
                        if (mendianFragment == null) {
                            mendianFragment = new YuyueFragment();
                            fragmentTransaction.add(R.id.activity_main_framlayout, mendianFragment, fragmentMendianTag);

                        } else {
                            fragmentTransaction.show(mendianFragment);
                        }
                        fragmentTransaction.commit();
                        break;
                    case R.id.main_menu_baobiao:
                        if (baobiaoFragment == null) {
                            baobiaoFragment = new BaobiaoFragment();
                            fragmentTransaction.add(R.id.activity_main_framlayout, baobiaoFragment, fragmentBaobiaoTag);

                        } else {
                            fragmentTransaction.show(baobiaoFragment);
                        }
                        fragmentTransaction.commit();
                        break;
                    case R.id.main_menu_dayin:
                        if (dayinFragment == null) {
                            dayinFragment = new DayinFragment();
                            fragmentTransaction.add(R.id.activity_main_framlayout, dayinFragment, fragmentDayinTag);

                        } else {
                            fragmentTransaction.show(dayinFragment);
                        }
                        fragmentTransaction.commit();
                        break;
                    case R.id.main_menu_tuichu:
                        Toast.makeText(MainActivity.this, "tuichu", Toast.LENGTH_LONG).show();
                        break;
                }

            }
        });

    }

    /**
     * 初始化时显示的fragment
     */
    private void firstShow(){
        //实例化fragment对象
        CantaiFragment blankFragment1 = new CantaiFragment();
        //获取fragment管理器,并显示fragment,传入一个记号
        getSupportFragmentManager().beginTransaction().add(R.id.activity_main_framlayout, blankFragment1, fragmentCantaiTag).commit();
    }

}

