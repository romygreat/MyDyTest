package com.de.cashier.layout;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.de.cashier.R;

import org.angmarch.views.NiceSpinner;

public class GuqingDialog extends Dialog {

    public GuqingDialog(Context context) {
        super(context);
    }

    public GuqingDialog(Context context, int theme) {
        super(context, theme);  
    }

    public static class Builder {  
        private Context context;
        private String positiveButtonText;  
        private View contentView;
        private OnClickListener positiveButtonClickListener;
        private TextView numTextView;
        private TextView numBtn1;
        private TextView numBtn2;
        private TextView numBtn3;
        private TextView numBtn4;
        private TextView numBtn5;
        private TextView numBtn6;
        private TextView numBtn7;
        private TextView numBtn8;
        private TextView numBtn9;
        private TextView numBtn0;
        private ImageButton deleteBtn;
        private TextView clearBtn;
        private boolean isInit = true;

        public Builder(Context context) {  
            this.context = context;  
        } 
        
        public Builder setContentView(View v) {
            this.contentView = v;  
            return this;  
        }

        public String getNum(){
            return numTextView.getText().toString();
        }

        /**
         * Set the positive button resource and it's listener 
         *  
         * @param positiveButtonText 
         * @return 
         */  
        public Builder setPositiveButton(int positiveButtonText,  
                OnClickListener listener) {
            this.positiveButtonText = (String) context  
                    .getText(positiveButtonText);  
            this.positiveButtonClickListener = listener;  
            return this;  
        }  
  
        public Builder setPositiveButton(String positiveButtonText,  
                OnClickListener listener) {
            this.positiveButtonText = positiveButtonText;  
            this.positiveButtonClickListener = listener;  
            return this;  
        }  
  
        public GuqingDialog create() {
        	LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);  
            // instantiate the dialog with the custom Theme  
            final GuqingDialog dialog = new GuqingDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.dialog_guqing_num, null);
            dialog.addContentView(layout, new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));  
            numTextView = (TextView) layout.findViewById(R.id.dialog_guqing_num_tv);
            numBtn0 = (TextView) layout.findViewById(R.id.dialog_guqing_num_btn_0);
            numBtn1 = (TextView) layout.findViewById(R.id.dialog_guqing_num_btn_1);
            numBtn2 = (TextView) layout.findViewById(R.id.dialog_guqing_num_btn_2);
            numBtn3 = (TextView) layout.findViewById(R.id.dialog_guqing_num_btn_3);
            numBtn4 = (TextView) layout.findViewById(R.id.dialog_guqing_num_btn_4);
            numBtn5 = (TextView) layout.findViewById(R.id.dialog_guqing_num_btn_5);
            numBtn6 = (TextView) layout.findViewById(R.id.dialog_guqing_num_btn_6);
            numBtn7 = (TextView) layout.findViewById(R.id.dialog_guqing_num_btn_7);
            numBtn8 = (TextView) layout.findViewById(R.id.dialog_guqing_num_btn_8);
            numBtn9 = (TextView) layout.findViewById(R.id.dialog_guqing_num_btn_9);
            deleteBtn = (ImageButton) layout.findViewById(R.id.dialog_guqing_num_btn_delete);
            clearBtn = (TextView) layout.findViewById(R.id.dialog_guqing_num_btn_clear);

            numBtn0.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isInit){
                        numTextView.setText("0");
                        isInit = false;
                    }else{
                        String oldNum = numTextView.getText().toString();
                        int oldNumInt = Integer.parseInt(oldNum);
                        if(oldNumInt != 0) {
                            numTextView.setText(oldNum + "0");
                        }
                    }
                }
            });
            numBtn1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isInit){
                        numTextView.setText("1");
                        isInit = false;
                    }else{
                        String oldNum = numTextView.getText().toString();
                        int oldNumInt = Integer.parseInt(oldNum);
                        if(oldNumInt != 0) {
                            numTextView.setText(oldNum + "1");
                        }else{
                            numTextView.setText("1");
                        }
                    }
                }
            });
            numBtn2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isInit){
                        numTextView.setText("2");
                        isInit = false;
                    }else{
                        String oldNum = numTextView.getText().toString();
                        int oldNumInt = Integer.parseInt(oldNum);
                        if(oldNumInt != 0) {
                            numTextView.setText(oldNum + "2");
                        }else{
                            numTextView.setText("2");
                        }
                    }
                }
            });
            numBtn3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isInit){
                        numTextView.setText("3");
                        isInit = false;
                    }else{
                        String oldNum = numTextView.getText().toString();
                        int oldNumInt = Integer.parseInt(oldNum);
                        if(oldNumInt != 0) {
                            numTextView.setText(oldNum + "3");
                        }else{
                            numTextView.setText("3");
                        }
                    }
                }
            });
            numBtn4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isInit){
                        numTextView.setText("4");
                        isInit = false;
                    }else{
                        String oldNum = numTextView.getText().toString();
                        int oldNumInt = Integer.parseInt(oldNum);
                        if(oldNumInt != 0) {
                            numTextView.setText(oldNum + "4");
                        }else{
                            numTextView.setText("4");
                        }
                    }
                }
            });
            numBtn5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isInit){
                        numTextView.setText("5");
                        isInit = false;
                    }else{
                        String oldNum = numTextView.getText().toString();
                        int oldNumInt = Integer.parseInt(oldNum);
                        if(oldNumInt != 0) {
                            numTextView.setText(oldNum + "5");
                        }else{
                            numTextView.setText("5");
                        }
                    }
                }
            });
            numBtn6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isInit){
                        numTextView.setText("6");
                        isInit = false;
                    }else{
                        String oldNum = numTextView.getText().toString();
                        int oldNumInt = Integer.parseInt(oldNum);
                        if(oldNumInt != 0) {
                            numTextView.setText(oldNum + "6");
                        }else{
                            numTextView.setText("6");
                        }
                    }
                }
            });
            numBtn7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isInit){
                        numTextView.setText("7");
                        isInit = false;
                    }else{
                        String oldNum = numTextView.getText().toString();
                        int oldNumInt = Integer.parseInt(oldNum);
                        if(oldNumInt != 0) {
                            numTextView.setText(oldNum + "7");
                        }else{
                            numTextView.setText("7");
                        }
                    }
                }
            });
            numBtn8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isInit){
                        numTextView.setText("8");
                        isInit = false;
                    }else{
                        String oldNum = numTextView.getText().toString();
                        int oldNumInt = Integer.parseInt(oldNum);
                        if(oldNumInt != 0) {
                            numTextView.setText(oldNum + "8");
                        }else{
                            numTextView.setText("8");
                        }
                    }
                }
            });
            numBtn9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isInit){
                        numTextView.setText("9");
                        isInit = false;
                    }else{
                        String oldNum = numTextView.getText().toString();
                        int oldNumInt = Integer.parseInt(oldNum);
                        if(oldNumInt != 0) {
                            numTextView.setText(oldNum + "9");
                        }else{
                            numTextView.setText("9");
                        }
                    }
                }
            });
            deleteBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String oldnum = numTextView.getText().toString();
                    if(oldnum.length() > 1){
                        numTextView.setText(oldnum.substring(0, oldnum.length() - 1));
                    }else{
                        isInit = true;
                        numTextView.setText("0");
                    }
                }
            });
            clearBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    isInit = true;
                    numTextView.setText("1");
                }
            });

            // set the confirm button  
            if (positiveButtonText != null) {  
                ((Button) layout.findViewById(R.id.dialog_guqing_positiveButton)).setText(positiveButtonText);
                if (positiveButtonClickListener != null) {  
                    ((Button) layout.findViewById(R.id.dialog_guqing_positiveButton)).setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {  
                            positiveButtonClickListener.onClick(dialog, DialogInterface.BUTTON_POSITIVE);  
                        }  
                    });  
                }  
            } else {  
                // if no confirm button just set the visibility to GONE  
                layout.findViewById(R.id.dialog_guqing_positiveButton).setVisibility(View.GONE);
            }  

            // set the content message  
            if (contentView != null) {  
                // if no message set  
                // add the contentView to the dialog body  
                ((LinearLayout) layout.findViewById(R.id.content)).removeAllViews();  
                ((LinearLayout) layout.findViewById(R.id.content)).addView(contentView, new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));  
            }  
            dialog.setContentView(layout);  
            return dialog;  
        }  
    }  
}