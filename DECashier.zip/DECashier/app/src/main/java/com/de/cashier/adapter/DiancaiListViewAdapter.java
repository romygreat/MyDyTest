package com.de.cashier.adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.de.cashier.R;
import com.de.cashier.fragment.GuqingFragment;
import com.de.cashier.layout.ConfirmDialog;
import com.de.cashier.layout.GuqingDialog;
import com.de.cashier.model.DiancaiModel;
import com.de.cashier.model.GuqingListModel;
import com.de.cashier.util.MapperUtils;
import com.de.cashier.util.OkHttpClientUtil;
import com.de.cashier.util.UrlUtil;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class DiancaiListViewAdapter extends BaseAdapter {

    private List<DiancaiModel> diancaiModelList;
    private LayoutInflater layoutInflater;
    private Context context;
    private int mCurrentItem = 0;
    private boolean isClick = false;
    private GuqingDialog.Builder guqingBuilder;
    private GuqingDialog guqingDialog;
    private ConfirmDialog.Builder confirmBuilder;
    private ConfirmDialog confirmDialog;

    public DiancaiListViewAdapter(Context context, List<DiancaiModel> diancaiModelList){
        this.context = context;
        this.diancaiModelList = diancaiModelList;
        this.layoutInflater = LayoutInflater.from(context);
    }

    public final class MyView{
        public TextView name;
        public TextView num;
        public TextView price;
    }

    @Override
    public int getCount() {
        return diancaiModelList.size();
    }

    @Override
    public Object getItem(int position) {
        return diancaiModelList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        MyView myView = null;
        if(convertView==null){
            myView=new MyView();
            //获得组件，实例化组件
            convertView=layoutInflater.inflate(R.layout.item_listview_diancai, null);
            myView.name=(TextView)convertView.findViewById(R.id.item_list_diancai_foodname);
            myView.num=(TextView)convertView.findViewById(R.id.item_list_diancai_foodnum);
            myView.price=(TextView)convertView.findViewById(R.id.item_list_diancai_foodprice);

            convertView.setTag(myView);
        }else{
            myView=(MyView)convertView.getTag();
        }
        //绑定数据
        myView.name.setText(diancaiModelList.get(position).getFoodName());
        myView.num.setText(diancaiModelList.get(position).getFoodNum() + "份");
        myView.price.setText(diancaiModelList.get(position).getFoodPrice()+"");

        return convertView;
    }

    public void setCurrentItem(int currentItem){
        this.mCurrentItem = currentItem;
    }

    public void setClick(boolean click){
        this.isClick = click;
    }



}

