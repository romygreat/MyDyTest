package com.de.cashier.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.de.cashier.R;
import com.de.cashier.adapter.DingdanListViewAdapter;
import com.de.cashier.application.CashierApplication;
import com.de.cashier.model.DingdanListModel;
import com.de.cashier.model.LoginSuccessModel;
import com.de.cashier.model.TableModel;
import com.de.cashier.model.YuyueListModel;
import com.de.cashier.util.MapperUtils;
import com.de.cashier.util.OkHttpClientUtil;
import com.de.cashier.util.UrlUtil;

import org.angmarch.views.NiceSpinner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class DingdanFragment extends Fragment {

    @BindView(R.id.dingdan_paytype_spinner)
    public NiceSpinner payTypeSpinner;

    @BindView(R.id.dingdan_tableid_spinner)
    public NiceSpinner tableIdSpinner;

    @BindView(R.id.dingdan_orderstatus_spinner)
    public NiceSpinner orderStatusSpinner;

    @BindView(R.id.dingdan_listview)
    public ListView mListView;

    private DingdanListViewAdapter mAdapter;

    private CashierApplication mApplication;

    private LoginSuccessModel loginModel;

    private TableModel tableModel;

    private DingdanListModel dingdanListModel;

    public DingdanFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view  = inflater.inflate(R.layout.fragment_dingdan, container, false);

        ButterKnife.bind(this, view);

        mApplication = (CashierApplication) CashierApplication.getInstance();

        loginModel = mApplication.getModel();

        tableModel = mApplication.getTableModel();

        final List<String> payTypeData = new LinkedList<>(Arrays.asList("支付方式", "线上支付", "餐后支付"));
        payTypeSpinner.attachDataSource(payTypeData);
        payTypeSpinner.setBackgroundResource(R.drawable.edittext_shape);

        final List<String> tableData = new ArrayList<>();
        tableData.add("请选择桌台");
        for(TableModel.TableData.Tables table : tableModel.getData().getList()){
            tableData.add(table.getTitle());
        }
        tableIdSpinner.attachDataSource(tableData);
        tableIdSpinner.setBackgroundResource(R.drawable.edittext_shape);

        final List<String> orderStatusData = new LinkedList<>(Arrays.asList("订单状态", "未支付", "已付款", "已完成", "已挂账", "已撤单", "失败"));
        orderStatusSpinner.attachDataSource(orderStatusData);
        orderStatusSpinner.setBackgroundResource(R.drawable.edittext_shape);

        payTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String item = (String) parent.getItemAtPosition(position);
//                Toast.makeText(getActivity(), dataset.get(position), Toast.LENGTH_LONG).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        initOrderList();

        return view;
    }

    private void initOrderList(){
        OkHttpClient okHttpClient = OkHttpClientUtil.getInstance().getOkHttpClient();
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");//数据类型为json格式
        Map<String, String> map = new HashMap<String, String>();
        map.put("token", loginModel.getData().getToken());
        map.put("machine", "shop");
        RequestBody body = RequestBody.Companion.create(MapperUtils.mapToJson(map), JSON);
        final Request request = new Request.Builder()
                .url(UrlUtil.SERVERIP + "/order/order/indexOrder")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String result = response.body().string();
                try {
                    Map<String, Object> map = MapperUtils.json2mapDeeply(result);
                    dingdanListModel = MapperUtils.json2pojo(result, DingdanListModel.class);
                    Message msg = Message.obtain();
                    msg.what = 0;
                    handler.sendMessage(msg);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if (msg.what == 0) {
                mAdapter = new DingdanListViewAdapter(getActivity(), dingdanListModel, loginModel.getData().getToken());
                mListView.setAdapter(mAdapter);
            }
            return false;
        }
    });
}
