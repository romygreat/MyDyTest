package com.de.cashier.layout;
  
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import android.app.Dialog;
import android.content.Context;  
import android.content.DialogInterface;  
import android.view.LayoutInflater;  
import android.view.View;  
import android.view.ViewGroup.LayoutParams;  
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;  
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.de.cashier.R;

import org.angmarch.views.NiceSpinner;

public class AddTableDialog extends Dialog {
  
    public AddTableDialog(Context context) {
        super(context);  
    }  
  
    public AddTableDialog(Context context, int theme) {
        super(context, theme);  
    }  
  
    public static class Builder {  
        private Context context;
        private String positiveButtonText;  
        private String negativeButtonText;  
        private View contentView;  
        private OnClickListener positiveButtonClickListener;
        private OnClickListener negativeButtonClickListener;
        private EditText titleEditText;
        private TextView numTextView;
        private Button minusBtn;
        private Button plusBtn;
        private NiceSpinner areaSpinner;
        private String title;
        private String num;
        private String area;

        public Builder(Context context) {  
            this.context = context;  
        } 
        
        public Builder setContentView(View v) {
            this.contentView = v;  
            return this;  
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getNum() {
            return num;
        }

        public void setNum(String num) {
            this.num = num;
        }

        public String getArea() {
            return area;
        }

        public void setArea(String area) {
            this.area = area;
        }

        /**
         * Set the positive button resource and it's listener 
         *  
         * @param positiveButtonText 
         * @return 
         */  
        public Builder setPositiveButton(int positiveButtonText,  
                OnClickListener listener) {
            this.positiveButtonText = (String) context  
                    .getText(positiveButtonText);  
            this.positiveButtonClickListener = listener;  
            return this;  
        }  
  
        public Builder setPositiveButton(String positiveButtonText,  
                OnClickListener listener) {
            this.positiveButtonText = positiveButtonText;  
            this.positiveButtonClickListener = listener;  
            return this;  
        }  
  
        public Builder setNegativeButton(int negativeButtonText,  
                OnClickListener listener) {
            this.negativeButtonText = (String) context  
                    .getText(negativeButtonText);  
            this.negativeButtonClickListener = listener;  
            return this;  
        }  
  
        public Builder setNegativeButton(String negativeButtonText,  
                OnClickListener listener) {
            this.negativeButtonText = negativeButtonText;  
            this.negativeButtonClickListener = listener;  
            return this;  
        }  
  
        public AddTableDialog create() {
        	LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);  
            // instantiate the dialog with the custom Theme  
            final AddTableDialog dialog = new AddTableDialog(context, R.style.Dialog);
            View layout = inflater.inflate(R.layout.dialog_table_add, null);
            dialog.addContentView(layout, new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT));  
            titleEditText = (EditText) layout.findViewById(R.id.dialog_table_add_title);
            numTextView = (TextView) layout.findViewById(R.id.dialog_table_add_num);
            minusBtn = (Button) layout.findViewById(R.id.dialog_table_add_num_minus);
            plusBtn = (Button) layout.findViewById(R.id.dialog_table_add_num_plus);
            areaSpinner = (NiceSpinner) layout.findViewById(R.id.dialog_table_add_area);
            final List<String> dataset = new LinkedList<>(Arrays.asList("One", "Two", "Three", "Four", "Five"));
            areaSpinner.attachDataSource(dataset);
            areaSpinner.setBackgroundResource(R.drawable.edittext_shape);

            minusBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String num = numTextView.getText().toString();
                    int intNum = Integer.parseInt(num);
                    if(intNum > 1) {
                        numTextView.setText((intNum-1)+"");
                    }
                }
            });
            plusBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String num = numTextView.getText().toString();
                    int intNum = Integer.parseInt(num);
                    numTextView.setText((intNum+1)+"");

                }
            });

            // set the confirm button  
            if (positiveButtonText != null) {  
                ((Button) layout.findViewById(R.id.dialog_table_add_positiveButton)).setText(positiveButtonText);
                if (positiveButtonClickListener != null) {  
                    ((Button) layout.findViewById(R.id.dialog_table_add_positiveButton)).setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {  
                            positiveButtonClickListener.onClick(dialog, DialogInterface.BUTTON_POSITIVE);  
                        }  
                    });  
                }  
            } else {  
                // if no confirm button just set the visibility to GONE  
                layout.findViewById(R.id.dialog_table_add_positiveButton).setVisibility(View.GONE);
            }  
            // set the cancel button  
            if (negativeButtonText != null) {  
                ((Button) layout.findViewById(R.id.dialog_table_add_negativeButton)).setText(negativeButtonText);
                if (negativeButtonClickListener != null) {  
                    ((Button) layout.findViewById(R.id.dialog_table_add_negativeButton)).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {  
                    	negativeButtonClickListener.onClick(dialog, DialogInterface.BUTTON_NEGATIVE);  
                        }  
                    });  
                }  
            } else {  
                // if no confirm button just set the visibility to GONE  
                layout.findViewById(R.id.dialog_table_add_negativeButton).setVisibility(View.GONE);
            }  
            // set the content message  
            if (contentView != null) {  
                // if no message set  
                // add the contentView to the dialog body  
                ((LinearLayout) layout.findViewById(R.id.content)).removeAllViews();  
                ((LinearLayout) layout.findViewById(R.id.content)).addView(contentView, new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT));  
            }  
            dialog.setContentView(layout);  
            return dialog;  
        }  
    }  
}