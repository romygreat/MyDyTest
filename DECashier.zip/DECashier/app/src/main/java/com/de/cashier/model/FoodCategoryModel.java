package com.de.cashier.model;

import java.util.List;

public class FoodCategoryModel {

    private String code;
    private String message;
    private boolean status;
    private FoodCategory data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public FoodCategory getData() {
        return data;
    }

    public void setData(FoodCategory data) {
        this.data = data;
    }

    public static class FoodCategory{
        private int total;
        private List<Category> list;

        public int getTotal() {
            return total;
        }

        public void setTotal(int total) {
            this.total = total;
        }

        public List<Category> getList() {
            return list;
        }

        public void setList(List<Category> list) {
            this.list = list;
        }

        public static class Category{
            private int id;
            private int pid;
            private int shop_id;
            private String name;
            private String path;
            private int sort;
            private String addtime;
            private int printer_id;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public int getPid() {
                return pid;
            }

            public void setPid(int pid) {
                this.pid = pid;
            }

            public int getShop_id() {
                return shop_id;
            }

            public void setShop_id(int shop_id) {
                this.shop_id = shop_id;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getPath() {
                return path;
            }

            public void setPath(String path) {
                this.path = path;
            }

            public int getSort() {
                return sort;
            }

            public void setSort(int sort) {
                this.sort = sort;
            }

            public String getAddtime() {
                return addtime;
            }

            public void setAddtime(String addtime) {
                this.addtime = addtime;
            }

            public int getPrinter_id() {
                return printer_id;
            }

            public void setPrinter_id(int printer_id) {
                this.printer_id = printer_id;
            }
        }
    }

}
