/*
 * @Author: 叶锦荣
 * @Date: 2019-10-21 13:50:24
 * @LastEditTime: 2019-12-11 11:23:04
 */
const path = require('path')
function resolve(dir) {
  return path.join(__dirname, dir)
}
module.exports = {
  lintOnSave: true,
  chainWebpack: (config) => {
    config.resolve.alias
      .set('@', resolve('src'))
      .set('_c', resolve('src/components'))
  }, 
  devServer: {
    // proxy: 'http://www.dy.cc'
    proxy: 'http://service.dev.gddiyi.cn/'
  }
}  