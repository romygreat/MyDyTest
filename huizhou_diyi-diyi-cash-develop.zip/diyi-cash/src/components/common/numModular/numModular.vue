<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-25 10:03:12
 * @LastEditTime: 2019-12-01 09:37:59
 -->
<template>
  <div class="numModular">
    <dl @click="setNumber(item,index)" v-for="(item, index) in list" :key="index">
      <dd>
        {{item}}
        <img v-if="index === 11" :src="cleartuicai" />
      </dd>
    </dl>
  </div>
</template>
<script>
import cleartuicai from '@/assets/img/cleartuicai.png'
export default {
  data() {
    return {
      cleartuicai,
      list: [1, 2, 3, 4, 5, 6, 7, 8, 9, '.', 0, '']
    }
  },
  methods: {
    setNumber(item, index) {
      if (item === '') this.$emit('setReturnNum', -1)
      else this.$emit('setReturnNum', item)
    }
  }
}
</script>
<style lang="less" scoped>
@import url('./numModular.less');
</style>