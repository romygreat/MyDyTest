/*
 * @Author: 叶锦荣
 * @Date: 2019-10-25 10:03:25
 * @LastEditTime: 2019-10-25 10:04:03
 */
import numModular from './numModular.vue'
export default numModular