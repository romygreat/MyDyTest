<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-30 08:46:51
 * @LastEditTime : 2019-12-28 11:56:34
 -->
<template>
  <div v-show="leftShow" class="left">
    <ul>
      <li
        :style="useNav == idx ? useColor : ''"
        @click="getRouter(item,idx)"
        v-for="(item,idx) in nav"
        :key="idx"
      >
        <img :src="item.meta.icon" alt />
        <p>{{item.meta.title}}</p>
      </li>
    </ul>
  </div>
</template>

<script> 
import logos from '@/assets/img/logos.png'
import { closeShopTable } from '@/api/home'
export default {
  data() {
    return {
      logos,
      nav: [],
      useNav: 0,
      useColor: {
        background: '#FE7622'
      },
      leftShow: true,
      current: 'home',
      tips_num: 0,
      AccountInfo: {
        shop: {
          name: ''
        },
        realname: '',
        login_time: ''
      }
    }
  },
  methods: {
    setNav(list) {
      /**
       * 踢出多余的页面
       * @param {String} icon 图标用于区分
       * @param {Aarry} list  路由表
       */
      list.forEach(el => {
        if (el.meta.icon) this.nav.push(el)
      })
    },
    getRouter(item, index) {
      /**
       * 根据路由表进入对应的路由
       * @param {object} item 当前点击的路由
       * @param {Number} index 当前路由索引
       * @param {String} current  当前路由
       */
      if (item.name == 'signOut') {
        // this.logOut()
        this.$emit('signOut', true)
      } else {
        if (this.current == item.name) return
        // 返回提示
        if (item.name !== 'signOut' && this.current == 'menu' && this.userOder.status != 1) {
          let justList = this.cartList
          let text = '当前有未下单的商品，确认离开吗？'
          let off = false
          if (!this.userOder.order_no && justList.length == 0) {
            off = true
            text = '当前尚未进行点餐，确认离开吗？'
          }
          justList.forEach(el => {
            if (el.switch === false) {
              off = true
            }
          })
          if (off) {
            this.$confirm(text, '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning ',
              customClass: 'calction'
            })
              .then(() => {
                const data = {
                  title: JSON.parse(sessionStorage.getItem('tables_noInfo')),
                  pwd: '123456'
                }
                closeShopTable(data).then(res => {
                  this.useNav = index
                  this.$router.push({ name: item.name })
                  this.$store.commit('setCartList', [])
                })
              })
              .catch(() => {
                return
              })
            return
          }
        }
        this.useNav = index
        sessionStorage.setItem('useNav',JSON.stringify(index))
        this.$router.push({ name: item.name })
        this.$store.commit('setCartList', [])
      }
    }
  },
  computed: {
    cartList() {
      return this.$store.state.cartList
    },
    userOder() {
      return this.$store.state.useOrder
    }
  },
  watch: {
    $route(to) {
      this.current = to.name

      if (to.name === 'login') this.leftShow = false
      else this.leftShow = true
    },
    adminInfos: {
      handler(n, o) {},
      deep: true
    }
  },
  created() {
    if(sessionStorage.getItem('useNav')) this.useNav = JSON.parse(sessionStorage.getItem('useNav'))
    this.setNav(this.$router.options.routes)
    if (this.$router.history.current.name === 'login') this.leftShow = false
    else this.leftShow = true
    
  },
  mounted() {}
}
</script>


<style lang='less' scoped >
@import url('./leftNav.less');
</style>
<style lang="less">
.backOrder {
  position: absolute;
  left: 50%;
  top: 10vh;
  transform: translateX(-50%);
  .el-button--primary {
    background: #eb6100;
    border-color: #eb6100;
  }
  .el-button--primary:hover {
    background: #eb6100 !important;
    border-color: #eb6100 !important;
  }
}
.info {
  left: 80px !important;
  background: #171922 !important;
  .content {
    margin-left: 16px;
    span {
      display: block;
      color: #ffffff;
      font-size: 14px;
      margin-bottom: 16px;
      img {
        width: 32px;
        height: 32px;
        margin-right: 12px;
        position: relative;
        top: 8px;
      }
    }
    span:first-child {
      font-size: 16px !important;
      font-weight: 600;
    }
  }
}
</style>