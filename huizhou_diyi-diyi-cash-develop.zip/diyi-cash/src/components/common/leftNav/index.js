import leftNav from './leftNav.vue'
export default leftNav