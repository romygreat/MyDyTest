<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-30 08:46:51
 * @LastEditTime: 2019-12-01 18:32:59
 -->
<template>
  <el-dialog
    custom-class="temporaryBox"
    title="设置临时菜"
    :visible.sync="temporaryShow"
    width="30%"
    :before-close="handleClose"
  >
    <div class="temporaryInfo">
      <div class="name">
        <span>菜品名称：</span>
        <el-input :maxlength="40" v-model="name" placeholder="请输入临时菜名称" />
      </div>
      <div class="price">
        <span>菜品价格：</span>
        <el-input-number :controls="false" v-model="price" :min="0" label />
      </div>
      <div class="num">
        <span>份数：</span>
        <img class="rudis" @click="calcTemporary('-')" :src="rudisTuicai" alt />
        <el-input-number :controls="false" v-model="num" placeholder="请输入临时菜数量" />
        <img class="add" @click="calcTemporary('+')" :src="addtuicai" alt />
      </div>
      <div class="unit">
        <span>单位：</span>
        <div class="unitbox">
          <dl
            @click="unitIndex = index"
            :class="unitIndex === index ? 'use' : ''"
            v-for="(item, index) in list"
            :key="index"
          >
            <dt>{{item.name}}</dt>
            <img v-if="unitIndex === index" :src="gou2" alt />
          </dl>
        </div>
      </div>
      <div class="buttomfoor">
        <div @click="handleClose">取消</div>
        <div @click="setTemporary">确认</div>
      </div>
    </div>
  </el-dialog>
</template>
<script>
import rudisTuicai from '@/assets/img/rudisTuicai.png'
import addtuicai from '@/assets/img/addtuicai.jpg'
import { productUnitList } from '@/api/menu'
import gou2 from '@/assets/img/gou2.png'
export default {
  props: ['show'],
  data() {
    return {
      gou2,
      temporaryShow: false,
      name: '',
      num: 1,
      price: 0,
      rudisTuicai,
      addtuicai,
      list: [],
      unitIndex: 0
    }
  },
  methods: {
    handleClose() {
      this.$emit('toTemporary', false)
    },
    setUnitList() {
      productUnitList({}).then(res => {
        this.list = res.data.data.list
      })
    },
    setTemporary() {
      if (this.name === '' || this.num === '' || this.price === '') {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '参数不得为空，请按规则填写'
        })
        return
      }
      if (isNaN(this.num) && isNaN(this.price)) {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '价格或者份数必须是数字'
        })
        return
      }
      // 向父元素传递对象
      this.$emit('toTemporary', {
        name: this.name,
        num: this.num,
        price: this.price * 100,
        unit: this.list[this.unitIndex].name,
        temporary: 1,
        is_limit: 1,
        cate_id: -2
      })
    },
    /**
     * @description 增减临时菜的数量
     */
    calcTemporary(type) {
      if (type === '+') this.num++
      else {
        if (this.num === 0) return
        else this.num--
      }
    }
  },
  mounted() {
    this.temporaryShow = this.show
    this.setUnitList()
  }
}
</script>
<style lang='less' scoped>
@import url('./writeTemporary.less');
</style>
<style lang='less' >
.temporaryBox {
  width: 584px !important;
  border-radius: 3px;
  padding: 22px 46px;
  .el-dialog__body {
    padding: 30px 0 0 !important;
  }
  .el-dialog__header {
    text-align: center;
    padding: 0;
    .el-dialog__title {
      font-size: 20px;
      font-weight: bold;
      color: rgba(23, 25, 34, 1);
    }
    .el-dialog__headerbtn {
      display: none;
    }
  }
  .temporaryInfo {
    .el-input {
      width: 388px;
      float: left;
      display: block;
    }
    .price {
      input {
        text-align: left;
      }
    }
    .num {
      .el-input {
        width: 66px !important;
        margin-left: 25px;
      }
    }
  }
}
</style>