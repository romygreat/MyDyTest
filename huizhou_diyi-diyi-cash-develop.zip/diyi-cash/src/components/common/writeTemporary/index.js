import writeTemporary from './writeTemporary.vue'
export default writeTemporary