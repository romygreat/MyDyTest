import packSwitch from './packSwitch.vue'
export default packSwitch