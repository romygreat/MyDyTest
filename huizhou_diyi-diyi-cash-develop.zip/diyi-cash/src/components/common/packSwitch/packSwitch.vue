<template>
  <div class="packSwitch">
    <h3>单品打包</h3>
    <el-switch
      @change="wtring"
      v-model="valueInfo"
      active-color="#EB6100"
      inactive-color="#EBEEF5"
    />
  </div>
</template>
<script>
export default {
  props: ['pack'],
  data() {
    return {
      valueInfo: false
    }
  },
  methods: {
    wtring(res) {
      this.$emit('setPack', res)
    }
  },
  mounted() {
    this.valueInfo = this.pack
  },
  watch: {
    pack: {
      handler(n, o) {
        this.valueInfo = n
      }
    }
  }
}
</script>
<style lang='less' scoped>
@import url('./packSwitch.less');
</style>
<style lang="less">
.packSwitch {
  .el-switch {
    position: absolute;
    right: 25px;
    top: 50%;
    transform: translateY(-50%);
  }
}
</style>
