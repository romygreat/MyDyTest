import numberKey from './numberKey.vue'
export default numberKey