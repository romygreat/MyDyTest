<template>
    <div class="numberKey" >
        <div  class="number" >
            <dl @click="setNumberKey(item)"  v-for="(item, index) in list" :key="index" >
                <dt>{{item}}</dt>
            </dl>
        </div>
        <div class="buttom" >
            <div @click="setNumberKey('clear')"  class="clearNumber" >
                <img :src="cleartuicai" alt="">
            </div>
            <div @click="isconfirm()" class="checkOut" >
                结账
            </div>
        </div>
    </div>
</template>
<script>
import cleartuicai from '@/assets/img/cleartuicai.png'
export default {
    props:['money'],
    data(){
        return{
            cleartuicai,
            list:[1,2,3,4,5,6,7,8,9,'.',0,'00']
        }
    },
    methods:{
        setNumberKey(value){
            /**
             *  向父元素传递增减一位操作 
             *  @param {String || Number } value 值 
             *  if value === 'clear' 为 减少一位
             */
             this.$emit('setNumberKey',value)
        },
        isconfirm(){
            /**
             * 确认操作
             */
            this.$emit('isconfirm',true)
        }
    }
}
</script>
<style lang="less"  scoped>
@import url('./numberKey.less');
</style>