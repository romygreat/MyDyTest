<template>
  <div class="keyboard" id="keyboard" ref="keyboard">
    <!-- 按键 -->
    <div class="keys">
      <ul>
        <li
          :class="{'active' : inputVal === item[index]}"
          v-for="(item,index) in keyboardItem"
          :key="index"
          @click="getInputValue(item[index])"
        >{{item[index]}}</li>
      </ul>
    </div>
  </div>
</template>
<script>
import { setTimeout } from 'timers'
import { watch } from 'fs'
export default {
  props: {
    inputItem: String
  },
  data() {
    return {
      keyboardItem: [
        { 0: '1' },
        { 1: '2' },
        { 2: '3' },
        { 3: '4' },
        { 4: '5' },
        { 5: '6' },
        { 6: '7' },
        { 7: '8' },
        { 8: '9' },
        { 9: '0' },
        { 10: 'Q' },
        { 11: 'W' },
        { 12: 'E' },
        { 13: 'R' },
        { 14: 'T' },
        { 15: 'Y' },
        { 16: 'U' },
        { 17: 'I' },
        { 18: 'O' },
        { 19: 'P' },
        { 20: 'A' },
        { 21: 'S' },
        { 22: 'D' },
        { 23: 'F' },
        { 24: 'G' },
        { 25: 'H' },
        { 26: 'J' },
        { 27: 'K' },
        { 28: 'L' },
        { 29: '*' },
        { 30: 'Z' },
        { 31: 'X' },
        { 32: 'C' },
        { 33: 'V' },
        { 34: 'B' },
        { 35: 'N' },
        { 36: 'M' },
        { 37: '退格' },
        { 38: '清除' },
        { 39: '确认' }
      ],
      inputValue: '',
      inputVal: ''
    }
  },
  methods: {
    getInputValue(value) {
      this.inputVal = value
      setTimeout(() => {
        this.inputVal = ''
      }, 200)
      switch (value) {
        case '清除':
          this.inputValue = ''
          break
        case '退格':
          this.inputValue = this.inputValue.substr(
            0,
            this.inputValue.length - 1
          )
          break
        case '确认':
          this.$store.commit('setKeyShow', false)
          break
        default:
          this.inputValue += value
          break
      }
      this.$emit('sendInput', {
        value: this.inputValue
      })
    },
    /**
     * 在搜索那里清空了输输入框，把键盘的文本去掉
     */
    clearString(e) {
      this.inputValue = ''
    }
  },
  created() {
    this.inputValue = this.inputItem
  },
  watch: {
    inputItem: {
      handler(n, o) {
        this.inputValue = n
      }
    }
  }
}
</script>
<style lang='less' scoped>
@import './keyboard.less';
.active {
  color:#fff !important;
  background: #F5F5F5 !important;
}
</style>