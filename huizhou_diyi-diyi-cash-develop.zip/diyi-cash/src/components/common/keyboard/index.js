import keyboard from './keyboard.vue'
export default keyboard