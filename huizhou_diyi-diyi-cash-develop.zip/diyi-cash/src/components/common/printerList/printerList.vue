<!--
 * @Author: 叶锦荣
 * @Date: 2019-11-20 09:00:29
 * @LastEditTime : 2019-12-24 16:55:37
 -->
<template>
  <div class="printerList">
      <h3 v-if="!isAdd" class="headerH3">我的打印机</h3>
     <section   v-if="!isAdd" >
        <dl class="add" @click="addPrinter('add')">
          <hgroup>
            <h1>+</h1>
            <h2>添加打印机</h2>
          </hgroup>
        </dl>  
        <dl @click="addPrinter('edit',item)" v-for="(item,idx) in list" :key="idx">
          <dt>
            <hgroup>
              <img :src="printerImg2" alt="" />
              <title>{{item.title}}</title>
            </hgroup>
            <p>{{statusList[item.type]}} / {{item.size}} mm </p>
          </dt>
          <dd>点击修改</dd>
          <span v-if="item.type !== 3" :class="[item.isstatus === false ? 'poff' : 'pon','status']" >{{item.isstatus === false ? '已断开' : '已连接'}}</span>
        </dl>
     </section>
     <div class='openinfo'  v-else >
      <div class="open" >
        <h3>
          打印机设置 
          <span @click="theSheet(openObj.target,openObj)" >打印测试单</span>
        </h3>
        <div>
          <dl class="openDl" >
            <dt>打印机名称：</dt>
            <el-input :maxlength='40' v-model="openObj.title"  placeholder="例如:后厨打印机" />
          </dl>
          <dl class="openDl" >
            <dt>{{openObj.type == 3 ? '打印机SN' : 'IP地址'}}：</dt>
            <el-input :maxlength='40' v-model="openObj.target"  placeholder="请输入打印机IP地址" />
          </dl>
          <dl class="openDl" >
            <dt>接口类型：</dt>
            <figure>
              <div 
                @click='setType(item)'
                :class=" openObj.type == item.type ? 'use' : '' 
                " v-for="(item, index) in this.printerType" :key="index" >{{item.name}}</div>
            </figure>
          </dl>
          <dl class='openDl'> 
            <dt>品牌</dt>
            <el-select v-model="openObj.manu_id" filterable placeholder="请选择打印机品牌">
              <el-option
                v-for="item in printerMenuListInfo.list"
                :key="item.id"
                :label="item.name"
                :value="item.id">
              </el-option>
            </el-select>
          </dl>
          <dl class='openDl'> 
            <dt>打印纸宽度</dt>
            <figure>
              <div 
                @click="setSize(item)"
                :class="openObj.size == item ? 'use' : '' "
                v-for="(item, index) in this.sizeList" :key="index" >{{item}}mm</div>
            </figure>
          </dl>
          <dl v-if="false" class='openDl' >
            <dt>打印样式</dt>
            <figure>
              <div 
                @click="setStyle(item)"
                :class="openObj.style == item.type ? 'use' : '' "
                v-for="(item, index) in this.printerStyle" :key="index" >{{item.name}}</div>
            </figure>
          </dl>
          <dl class='openDl numberKey' >
            <dt>打印份数</dt>
            <img @click="calcCopies('-')" class='jianimg' :src='jian' />
            <el-input  min='1' max='99'   v-model='openObj.copies' placeholder="请输入打印份数" />
            <img @click="calcCopies('+')" class='jia' :src='jia' />
          </dl>
          <dl v-show="openObj.type == 3" class="openDl" >
            <dt>云打印机Key</dt>
             <el-input  v-model='openObj.key' placeholder="请输入云打印机key" />
          </dl>
          <dl v-if="false" class='openDl' >
            <dt>蜂鸣提示音</dt>
            <figure>
              <el-switch
                v-model="isVoidInfo"
                active-color="#EC6E24" 
                inactive-color="#EBEEF5">
              </el-switch>
            </figure>
          </dl>
          <dl  class="openDl" >
            <dt v-if="openObjStubArr && openObjStubArr.length < 6" >打印类型</dt>
            <el-select v-model="openObjStubArr" multiple placeholder="请选择">
              <el-option
                v-for="item in printerStubList"
                :key="item.type"
                :label="item.name"
                :value="item.type">
              </el-option>
            </el-select>
          </dl>
          <dl v-if="false" class='openDl'> 
            <dt>打印机用途</dt>
            <el-input :maxlength='40'  v-model='openObj.remark'  placeholder="请输入内容" />
          </dl>
          <aside class="menuinfo">
              <h3>菜品分类</h3>
              <el-tree ref="treeList"  node-key="id"  :default-checked-keys="treeUse"  :data='menuList' show-checkbox />
          </aside>
        </div>
      </div>
     </div>
     <div class='buttom' v-if="isAdd" >  
        <div class='delet' @click="toPrinterDelete()" v-if="openObj.id" >删除打印机</div>
        <div class='retun' @click='callCack()' >取消</div>
        <div class='onciclk' @click="arginPrinter(openObj)"  v-if="openObj.id" >重新连接打印机</div>
        <div  style="margin-left:10px" class='onciclk' @click="onClick()" >保存</div>
     </div>
      <el-dialog
        title="清空信息提醒"
        custom-class="del-dialog"
        center
        :visible.sync="deletShow"
        width="20%"
      >
        <p>此操作将删除当前打印机，清空后不可恢复！</p>
        <p>确认是否清空?</p>
        <span slot="footer" class="dialog-footer">
          <el-button @click="deletShow = false">取 消</el-button>
          <el-button type="primary" @click="toPrinterDelete(true)">确认删除</el-button>
        </span>
      </el-dialog>
  </div>
</template>
<script>
import jia from '@/assets/img/jia.png'
import jian from '@/assets/img/jian.png'
import { printerList,printerManuList,printerSave,printerDelete } from '@/api/printer'
import printerImg from '@/assets/img/printerImg.png' 
import printerImg2 from '@/assets/img/printerImg2.png' 
import { getStautsText } from "@/libs/util"
import {shopCate} from '@/api/menu'
import { join } from 'path'
export default {
  props:['obj'],
  data() {
    return {
      printerImg2,
      resparam: { 
        sn: '',
        key: '',
        manu_id: ''
      },
      list:[],
      openObj:{
        type:'',
        style:'',
        size:'',
        copies:1,
        stubArr:[],
        key:''
      },
      total: 0,
      userIndex: 0,
      printerImg,
      statusList:{},
      isAdd:false,
      printerType:[],
      printerStyle:[],
      sizeList:[
        58,80
      ],
      jia,
      jian,
      isVoidInfo:false,
      menuList:[{id:-1,label:'全部',children:[]}],
      treeUse:[-1],
      printerMenuRes:{
        machine:'',
        name:''
      },
      printerMenuListInfo:[],
      printerStubList:[],
      deletShow:false,
      openObjStubArr:[]
    }
  },
  methods: {
    /**
     * @description 获取打印机厂商
     */
    async setPrinterMueb(){
      let res = (await printerManuList(this.printerMenuRes)).data
      this.printerMenuListInfo = res.data
    },
    /** 
     * @description 获取打印机列表
     */
    async setPrinterList() {
      let res = (await printerList(this.resparam)).data
      this.total = res.data.total
      res.data.list.forEach((el,index) => {
         this.$set(res.data.list[index],'isstatus',false)
      })
      this.list = res.data.list
    },
    /** 
     * @description 操作打印机
     */
    addPrinter(type,item) {
      if (type === 'add'){
        this.initialization('add') 
        this.isAdd = true
        this.$set(this.treeUse,0,-1)
      } else {
       this.openObj = item
       this.treeUse = item.product_cate_ids.split(',')
       this.openObjStubArr = this.openObj.types.split(',')
       if(this.openObjStubArr.indexOf('7') != -1){ 
         let key = this.openObjStubArr.indexOf('7')
         this.openObjStubArr.splice(key,1)
      }
      if(window.android) {
        window.android.beforeSaveOneIp(JSON.stringify(this.openObj))
      }
       this.isAdd = true
      }
    },
    /** 
     * @description  初始化数据
     */
     initialization(type){
       this.openObj = {
         type:'',
         size:'',
         style:''
       }
       this.openObj.copies = 1
       this.isVoidInfo =  this.openObj.is_voice === 1 ? true : false
       let data =  getStautsText('printer')
       //数组化类型
       if(type) {
         this.openObj.type = this.printerType[0].type
         this.openObj.size = this.sizeList[0]
         this.openObj.style = this.printerStyle[0].type
         this.openObjStubArr = []
        //  this.$refs.treeList.getCheckedNodes() = []
       } else {
        for (let key in this.statusList) {
          this.printerType.push({name:this.statusList[key],type:key})
        }
        //  数组化样式
        let styleObj = getStautsText('printer.style')
        for (let key in styleObj) {
          this.printerStyle.push({name:styleObj[key],type:key})
        }
        // 可打印类型数组化
        let stubObj = getStautsText('printer.stub')
        for (let key in stubObj) {
          if(key != 7) this.printerStubList.push({name:stubObj[key],type:key})
        }
       }
       if(!this.obj) {
         this.openObj.type = this.printerType[0].type
         this.openObj.size = this.sizeList[0]
         this.openObj.style = this.printerStyle[0].type
       }
     },
     /**
      *  @description 选择接口
      **/
     setType(item) {
        this.$set(this.openObj,'type',item.type)
     },
     /** 
      * @description 选择样式 
      */
     setStyle(item) {
        this.$set(this.openObj,'style',item.type)
     },
     /**
      * @description 选择纸张宽度
      */
     setSize(item) {
       this.$set(this.openObj,'size',item)
     },
    /** 
     * @description 获取菜单分类
     */
    async setShopCate(){
       const data = {
         page : 1 ,
         rows:50,
         printer:''
       }
       let res = await shopCate(data)
       let arr = res.data.data.list
       arr.forEach(el => {
         if(el.shop_id === -2){ el.id = el.shop_id}
         el.label = el.name
       })
       this.$set(this.menuList[0],'children',arr)
    },
    /** @description 回退 */
    callCack(){
      this.isAdd = false
    },
    /** 
     * @description 确认
     */
    async onClick(){
      let arr = []
      this.$refs.treeList.getCheckedNodes().forEach(el => {
        if(el.id && el.id !== -1) arr.push(el.id)
      })
      this.openObj.product_cate_ids = arr.join(',')
      this.openObj.types = this.openObjStubArr.join(',')
      this.openObj.is_voice = this.isVoidInfo ? 1 : 0
      let res = await printerSave(this.openObj)
      if(this.openObj.type != 3) {
        delete this.openObj.key
      }
      if(res.data.code == 1) {
         this.$notify({
          title: '成功',
          message: this.openObj.id ? '打印机修改成功' : '打印机添加成功',
          type: 'success'
        })
        await this.setPrinterList()
        if(window.android) {
          window.android.saveIp(JSON.stringify(this.openObj))
          this.monitorPrinter()
        }
        this.isAdd = false
      } else {
        this.$notify({
          title: '警告',
          message: this.openObj.id ? '打印机修改失败' : '打印机添加失败',
          type: 'warning'
        })
      }
    },
    /**
     * @description 加减纸张数量
     */
    calcCopies(type) {
      if(type === '+') this.openObj.copies++
      else {
        if(this.openObj.copies == 1) return
        else this.openObj.copies--
      }
    },
    /** 
     * @description 删除打印机
     */
    toPrinterDelete(type){
      if(!type) {
        this.deletShow = true
        return
      }
      printerDelete({id:this.openObj.id}).then(res => {
         if(res.data.code === 1) {
          this.$message({
            message: '删除成功',
            type: 'success'
          })
          this.callCack()
         } else {
             this.$message.error(`${res.data.message}`);
         }
      })
    },
    /**  
     * @description 重新连接打印机
    */
   arginPrinter(data) {
     if(window.android) window.android.connectPrinter(JSON.stringify(data.target))
   },
   /** 
    * @descriptiom 测试打印单
   */
    theSheet(id,data){
      if(window.android) window.android.canPrintTest(id,JSON.stringify(data))
    },
    /**
     * @description 监听打印机状态
     */
    monitorPrinter(){
      if(window.android) {
        window.android.queryprinterStatus('1')
      }
    },
    /**
     *  @description 写入打印机状态
     */
    setMonitorPrinter(res){
      this.list.forEach((el,idx) => {
        if(res.ip == el.target) {
          this.$set(this.list[idx],'isstatus',res.status)
          // alert(JSON.stringify(this.list[idx].title))
        }
      })
    }
  },
  mounted() {
    this.setPrinterMueb()
    this.setShopCate()
    this.initialization()
  },
  async created(){
    this.statusList = getStautsText('printer.type')
    await this.setPrinterList()
    window.printerStatus = this.setMonitorPrinter
    this.monitorPrinter()
  } 
}
</script>
<style lang='less' scoped>
@import url('./printerList.less');
</style>
<style lang="less">
@import url('./printerListMedia.less');
@import url('../../../assets/less/subscribe/dialog.less');
  .openDl {
    .el-input__inner {
      border-top: 1px solid transparent !important;
      border-left : 1px solid transparent !important;
      border-right: 1px solid transparent !important;
      border-radius: 0 !important;
        text-align: right !important;
    }
    .el-select{
      width:100%;
    }
    .el-select__tags{
      > span {
        text-align: right;
          width: 100%;
          display: block;
      }
    }
  }
  .numberKey {
    .el-input__inner {
      padding-right:50px;
      padding-left:450px;
      text-align:center !important;
    }
  }
  .printerList{
     .el-checkbox__input.is-checked .el-checkbox__inner, .el-checkbox__input.is-indeterminate .el-checkbox__inner{
       background-color: #fe7622 !important;
       border-color: #fe7622 !important;
     }
  }

</style>