import printerList from './printerList.vue'
export default printerList