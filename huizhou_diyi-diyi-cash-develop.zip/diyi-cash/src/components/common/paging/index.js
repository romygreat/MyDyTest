import paging from './paging.vue'
export default paging