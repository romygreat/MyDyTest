<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-30 08:46:51
 * @LastEditTime: 2019-11-01 14:35:00
 -->
<template>
  <div class="pageBox">
    <div
      :style="[whparamObj,ismodulUse ? modulUseObj : '']"
      @click="clickButtom(nextOff,'next')"
      :class="[nextOff ? 'no' : 'off','next']"
    >
      <img :src="nextOff ? lower : upperStop" alt />
    </div>
    <div
      :style="[whparamObj,ismodulUse ? modulUseObj : '']"
      @click="clickButtom(upperOff,'upper')"
      :class="[upperOff ? 'no' : 'off','upper']"
    >
      <img :src="upperOff ? lower : upperStop" alt />
    </div>
  </div>
</template>
<script>
import lower from '@/assets/img/lower.png'
import upperStop from '@/assets/img/upperStop.png'
export default {
  props: ['total', 'page', 'rows', 'whparpam', 'modulUse'],
  data() {
    return {
      lower,
      upperStop,
      totalPage: 0,
      pagePage: 0,
      rowsPage: 0,
      nextOff: false,
      upperOff: true,
      whparamObj: {
        height: ''
      },
      modulUseObj: {
        height: '36px',
        width: '49%',
        float: 'left',
        marginRight: '1%'
      },
      ismodulUse: false
    }
  },
  methods: {
    clickButtom(switchInfo, type) {
      if (switchInfo === true) this.$emit('setPage', type)
    },
    againCalss() {
      // 当页码为1的时候
      if (this.pagePage == 1) {
        this.nextOff = false
        //而且当总数大于页码 * 条数
        if (this.totalPage > this.rowsPage * this.pagePage) this.upperOff = true
        else this.upperOff = false
      }
      // 当页码非1得时候
      else {
        this.nextOff = true
        if (
          this.totalPage > this.rowsPage * this.pagePage &&
          Math.ceil(this.rowsPage * this.pagePage) > 1
        )
          this.upperOff = true
        else this.upperOff = false
      }
    }
  },
  watch: {
    page: {
      handler(n, o) {
        /**
         * 根据总数分页条数，算出能否上下一页
         * @param {Number} totalPage 当前数组总数1
         * @param {Number} rowsPage 当前数组每页条数
         * @param {Number} pagePage 当前数组页码
         * 判定条件为：
         *  1. 总数 > 页码 * 条数  即为可以下一页
         *  2. 总数 < 页码 * 条数  即为可以上一页
         *  3. 上述判断都需要考虑页码是否等于 1
         * **/
        this.pagePage = n
        this.againCalss()
      },
      deep: true
    },
    total: {
      handler(n) {
        this.totalPage = n
        this.pagePage = 1
        this.againCalss()
      },
      deep: true
    }
  },
  mounted() {
    this.totalPage = this.total
    this.pagePage = this.page
    this.rowsPage = this.rows
    if (this.whparpam) this.whparamObj.height = `50px`
    if (this.modulUse == true) this.ismodulUse = true
  }
}
</script>
<style lang='less' scoped>
@import url('./paging.less');
</style>
