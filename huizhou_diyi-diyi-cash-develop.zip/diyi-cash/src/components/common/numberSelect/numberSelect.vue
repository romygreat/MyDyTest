<!--
 * @Author: 叶锦荣
 * @Date: 2019-11-01 08:46:05
 * @LastEditTime: 2019-12-10 16:39:52
 -->
<template>
  <el-dialog
    :title="logTitle"
    :visible.sync="logshow"
    width="429"
    custom-class="numberSelect"
    :before-close="handleClose"
    append-to-body
  >
    <section>
      <header>
        <h3>{{logTitle}}</h3>
        <p>
          <span>{{logNumber}}</span>
          {{logUnit}}
        </p>
      </header>
      <div class="numberBox clear">
        <dl>
          <dd @click="setNumber(item)" v-for="(item, index) in list" :key="index">{{item}}</dd>
        </dl>
        <div class="numberBoxButtom">
          <div @click="clearNumber()">
            <img :src="cleartuicai" alt />
          </div>
          <div @click="clearnum()">清空</div>
        </div>
      </div>
      <div @click="goTables" class="footerButtom">{{logText}}</div>
    </section>
  </el-dialog>
</template>
<script>
import cleartuicai from '@/assets/img/cleartuicai.png'
export default {
  props: ['title', 'show', 'unit', 'buttomText'],
  data() {
    return {
      cleartuicai,
      logshow: false,
      logTitle: '',
      logNumber: '1',
      logText: '开台并点菜',
      logUnit: '',
      list: [1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, ''],
      oneOff: true
    }
  },
  methods: {
    clearnum() {
      this.oneOff = true
      if (this.logUnit == '折') this.logNumber = 10
      else this.logNumber = 1
    },
    handleClose() {
      this.logNumber = 0
      this.$emit('clearEdlog', false)
    },
    setNumber(value) {
      /**
       *  写入组件数字
       *  @param {String} logNumber 写入的数字
       *  @param {Number} value 传进来的参数
       * **/
      if (value == '.') {
        if (String(this.logNumber).indexOf('.') == -1)
          this.logNumber = `${this.logNumber}${String(value)}`
        return
      }
      if (this.logNumber == '0') {
        this.logNumber = String(value)
        return
      }
      if (this.oneOff == true) {
        this.logNumber = `${String(value)}`
        this.oneOff = false
        return
      }
      if(this.logTitle === '选择人数' && this.logNumber > 10  ) {
        return
      }
      let oldNumber = ''
      oldNumber = JSON.parse(JSON.stringify(this.logNumber))
      this.logNumber = `${this.logNumber}${String(value)}`
      // 折率不允许大于10
      console.log(this.logNumber,'num')
      if(this.logTitle === '自定义折扣') {
        if( Number(this.logNumber) > 10 ) {
          // this.logNumber = `${oldNumber}`
          this.logNumber = `${value}`
        }
      }
    },
    clearNumber(type) {
      /**
       * 回退组件数字
       * @param {Boolean} true 存在即为清空
       * @param {Number} logNumber.length 字符串长度  >2 即可运行
       * **/
      if (type == true) {
        this.logNumber = '0'
        return
      }
      if (this.logNumber.length == 1) {
        this.logNumber = '0'
        return
      }
      this.logNumber = this.logNumber.substring(0, this.logNumber.length - 1)
    },
    goTables() {
      /**
       * 把选好的数字传递给引入的父组件
       *  注意！ 要转化为Number类型
       * @param {String => Number} logNumber 传递父组件的数字
       */
      this.$emit('setEdlog', Number(this.logNumber))
    }
  },
  mounted() {
    this.logTitle = this.title
    this.logshow = this.show
    this.logUnit = this.unit
    if (this.logUnit == '折') {
      this.logText = this.buttomText
      this.logNumber = 10
      this.$set(this.list, 9, '.')
      this.oneOff = true
    }
    if (this.buttomText) {
      this.logText = this.buttomText
    }
  }
}
</script>
<style lang="less" >
@import url('./numberSelect.less');
</style>