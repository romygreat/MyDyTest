import numberSelect from './numberSelect.vue'
export default numberSelect