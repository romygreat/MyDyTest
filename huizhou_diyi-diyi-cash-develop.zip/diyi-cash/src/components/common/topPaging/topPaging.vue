<!--  
  使用：
  Param
  {String}  top 控制样式位置
  {String}  right 控制样式位置
  {Number}  total 总数
  {Number}  page  当前页数
  {Number}  row   分页条数
  {function}  setTopPage  点击切换的按钮
 -->
<template>
  <div class="menu-paging" :style="whparamObj" v-if="isShow">
    <div 
    @click="clickButtom(nextOff,'next')"
    :class="nextOff?'paing-btn':'stop-click paing-btn'"
    >
      <i class="el-icon-arrow-left"></i>
    </div>
    <div 
    @click="clickButtom(upperOff,'upper')"
    :class="upperOff?'paing-btn':'stop-click paing-btn'"
    >
      <i class="el-icon-arrow-right"></i>
    </div>
  </div>
</template>
<script>
export default {
  props: ['top', 'right', 'total', 'page', 'row'],
  data() {
    return {
      totalPage: 0,
      pagePage: 0,
      rowsPage: 0,
      nextOff: false,
      upperOff: true,
      whparamObj: {
        top: '',
        right: ''
      },
      ismodulUse: false,
      isShow:true
    }
  },
  methods: {
    clickButtom(switchInfo, type) {
      if (switchInfo === true) this.$emit('setTopPage', type)
    },
    showButton(){
      
      if (this.page>1) {
        this.isShow=true
      }
      if (this.page==1 && this.total < this.page * this.row) {
        this.isShow=false
      }
      
    }
  },
  watch: {
    page: {
      handler(n, o) {
        /**
         * 根据总数分页条数，算出能否上下一页
         * @param {Number} totalPage 当前数组总数1
         * @param {Number} rowsPage 当前数组每页条数
         * @param {Number} pagePage 当前数组页码
         * 判定条件为：
         *  1. 总数 > 页码 * 条数  即为可以下一页
         *  2. 总数 < 页码 * 条数  即为可以上一页
         *  3. 上述判断都需要考虑页码是否等于 1
         * **/
        this.pagePage = n
        // 当页码为1的时候
        if (this.pagePage == 1) {
          this.nextOff = false
          //而且当总数大于页码 * 条数
          if (this.totalPage > this.rowsPage * this.pagePage)
            this.upperOff = true
          else this.upperOff = false
        }
        // 当页码非1得时候
        else {
          this.nextOff = true
          if (
            this.totalPage > this.rowsPage * this.pagePage &&
            Math.ceil(this.rowsPage * this.pagePage) > 1
          )
            this.upperOff = true
          else this.upperOff = false
        }
      },
      deep: true
    },
    total: {
      handler(n) {
        this.totalPage = n
      },
      deep: true
    }
  },
  mounted() {
    this.totalPage = this.total
    this.pagePage = this.page
    this.rowsPage = this.row
    this.whparamObj.top = this.top + 'px'
    this.whparamObj.right = this.right + 'px'
    this.showButton()
  }
}
</script>
<style lang="less" scoped>
@import url('./topPaging.less');
</style>
<style>
.stop-click{
  cursor: not-allowed !important;
  background: #b6b6b6 !important;
}
</style>