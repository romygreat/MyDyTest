<template>
    <section class="column-tabs">
      <header>
        <h3>报表统计</h3>
      </header>
      <div class="column-list">
        <ul class="column-ul">
          <li @click="getDetails('report')">
            <img :src="report" alt />
            <span :class="useIndex==2?'active':''">营业报表</span>
          </li>
          <li @click="getDetails('ranking')">
            <img :src="ranking" alt />
            <span :class="useIndex==1?'active':''">商品销售排行</span>
          </li>
          
        </ul>
      </div>
    </section>
</template>
<script>
import ranking from '@/assets/img/ranking.png'
import report from '@/assets/img/report.png'

export default {
  data() {
    return {
      ranking,
      report,
      useIndex: 1,
      detailsData: {
        "index":1,
        title:'商品销售排行'
      }
    }
  },
  methods: {
    getDetails(type) {
      if (type == 'ranking') {
        this.detailsData.title = '商品销售排行'
        this.detailsData.index = 1
        this.useIndex = 1
      } else if (type == 'report') {
        this.useIndex = 2
        this.detailsData.index = 2
        this.detailsData.title = '营业报表'
      }
      this.$emit('sendIndex',this.detailsData);
    }
  },
  mounted() {
    this.getDetails('report')
  }
}
</script>
<style lang="less" scoped>
@import url('./columnTabs.less');
@import url('./columnTabsMedia.less');
</style>