<template>
  <div>
    <div class="details-list">
      <div class="list-tabs">
        <div class="title">
          <h5>商品消费单数排名</h5>
        </div>

        <div class="menu">
          <!-- @click="getData(item.index)" -->
          <ul>
            <li
              v-for="item in menu"
              :key="item.index"
              @click="getData(item.index)"
              :class="useIndex==item.index?'active':''"
            >
              <span>{{item.title}}</span>
            </li>
          </ul>
          <div class="add-btn" @click="showCheckTime = true">
            <img :src="jia" alt />
          </div>
        </div>
      </div>
      <div class="list">
        <el-table
          class="list-table"
          :data="list"
          header-row-class-name="table-header"
          style="width: 100%"
          header-cell-class-name="header-cell"
          cell-class-name="list-cell"
        >
          <el-table-column show-overflow-tooltip label="销量排行" prop="rank" width="180"></el-table-column>
          <el-table-column show-overflow-tooltip label="商品名称" prop="name" width="180"></el-table-column>
          <el-table-column show-overflow-tooltip label="商品类别" >
            <template slot-scope="scope">
              <span>{{ shopCateList[scope.row.cate_id] }}</span>
            </template>
          </el-table-column>
          <el-table-column show-overflow-tooltip label="销售数量">
            <template slot-scope="scope">
              <span style="margin-left: 10px">{{ parseInt(scope.row.sales) }}</span>
            </template>
          </el-table-column>
          <el-table-column show-overflow-tooltip label="商品原价(元)" prop="unit_price"></el-table-column>
        </el-table>
        <el-pagination
          background
          layout="prev, pager, next"
          :page-size="Number(rankData.row)"
          @prev-click="humit"
          @next-click="humit"
          @current-change="humit"
          :pager-count="5"
          :total="Number(total)"
          class="table-paing"
        ></el-pagination>
      </div>
    </div>
    <div class="tips">
      <span>【注】所有菜品或类别，均已商品原价统计为标准，不计算优惠信息，与实际收入可能会有差别</span>
    </div>
    <!-- <div class="print-btn">
      <span>打印</span>
    </div>-->
    <el-dialog title="请选择统计时间段" :visible.sync="showCheckTime" width="32%">
      <el-date-picker style="width:160px" id="start" v-model="tableData.start" type="date" placeholder="开始日期" @focus="showTime()"></el-date-picker>
      <span style="margin:0 12px;">至</span>
      <el-date-picker style="width:160px" id="end" v-model="tableData.end" type="date" placeholder="结束日期"  @focus="showTime()"></el-date-picker>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showCheckTime = false">取 消</el-button>
        <el-button type="primary" @click="searchByTime()">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import jia from '@/assets/img/jia.png'
import { rankList } from '@/api/statistics'
import { transformRMB } from '@/libs/util'
import {  shopCate } from '@/api/menu'

export default {
  data() {
    return {
      jia,
      showCheckTime: false,
      menu: [
        { title: '今天', index: 1 },
        { title: '昨天', index: 2 },
        { title: '本周', index: 3 },
        { title: '本月', index: 4 },
        { title: '近7天', index: 5 }
      ],
      useIndex: 1,
      tableData: {start:'',end:''},
      rankData: {
        page: 1,
        row: 8,
        sign: ''
      },
      list: [],
      total: 0,
      resShopCate: {
        // rows: 8,
        // page: 1,
        sort: {
          sort: 'asc'
        }
      },
      shopCateList:{},
    }
  },
  methods: {
    getData(index) {
      this.useIndex = index
      this.rankData.sign = index
      this.getRankList()
    },
    getRankList() {
      /**
       * 请求列表
       * rankData 请求参数
       */
      rankList(this.rankData).then(res => {
        if (res.data.code == 1) {
          this.total = res.data.data.total
          this.list = res.data.data.list
          this.showCheckTime = false
        }
        for (let i = 0; i < this.list.length; i++) {
          this.list[i].unit_price = this.transformMondy(this.list[i].unit_price)
        }
        this.tableData = {start:'',end:''}
      })
    },
    transformMondy(value) {
      /**
       * 金额换算
       */
      return transformRMB(value)
    },
    humit(v) {
      /**
       * 分页
       * rankData.page 页码
       */
      this.rankData.page = v
      this.getRankList()
    },
    showTime() {
      /**
       * 显示时间选择窗口
       * 不调用键盘
       */
      let Timepicker = document.getElementById('start')
      document.getElementById('end').setAttribute('readOnly', true)
      Timepicker.setAttribute('readOnly', true)
    },
    searchByTime() {
      /**
       * 时间段搜索
       * rankData.sign当前时间段 -->2019-1-11 - 2019-1-16
       */
      let end = this.tableData.start
      if (new Date(this.tableData.start).getTime()>new Date(this.tableData.end).getTime()) {
        this.tableData.start = this.tableData.end
        this.tableData.end = end
      }
      this.rankData.sign = this.dealTime(this.tableData.start, this.tableData.end)
      this.getRankList()
      this.useIndex = -1
    },
    dealTime(start, end) {
      /**
       *  时间处理
       * time1 开始时间-->2019-1-01
       * time2 结束时间-->2019-1-06
       * returnTime 返回时间 -->2019-1-01 - 2019-1-06
       */
      const time1 = new Date(start)
      const time2 = new Date(end)
      let returnTime =
        time1.getFullYear() +
        '-' +
        (time1.getMonth() + 1) +
        '-' +
        time1.getDate() +
        ' - ' +
        time2.getFullYear() +
        '-' +
        (time2.getMonth() + 1) +
        '-' +
        time2.getDate()
      return returnTime
    },
    async shopCateTitle() {
      await shopCate(this.resShopCate).then(res => {
        
        res.data.data.list.forEach(item => {
          this.shopCateList[item.id] = item.name
        })
      })
    },
  },
  mounted() {
    this.shopCateTitle()
    this.getRankList()
  }
}
</script>
<style lang="less" scoped>
@import url('./rankList.less');
</style>
<style lang="less">
.list-table {
  .table-header {
    color: rgba(70, 76, 91, 1) !important;
    font-size: 14px !important;
  }
  .header-cell {
    font-size: 14px;
    color: #5a606e;
    font-weight: bold;
    text-align: center;
    border-bottom: 2px solid rgba(220, 223, 230, 1) !important;
  }
  .list-cell {
    font-size: 14px;
    color: #5b606e;
    text-align: center;
  }
}
.table-paing {
  .el-pagination{
    margin-bottom: 16px !important;
  }
  button,.el-pager li{
    width: 40px;
    height: 40px;
    line-height: 40px;
    font-size: 16px;
  }
  .el-pager li:not(.disabled).active {
    background-color: #fe7622 !important;
    color: #fff !important;
  }
  .el-pager li:not(.disabled,.active):hover {
    color: #fff !important;
  }
  .el-pager li:hover {
    color: #fe7622 !important;
  }
}
</style>