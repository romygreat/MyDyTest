<template>
  <div>
    <section class="statistics-details">
      <header>
        <h3>{{statisticsIndex.title}}</h3>
      </header>
      <div class="details">
        <RankList v-if="statisticsIndex.index==1"></RankList>
        <BusinessList v-if="statisticsIndex.index==2"></BusinessList>
      </div>
    </section>
  </div>
</template>
<script>
import store from '../../../store'
import RankList from './rankList'
import BusinessList from './businessList'
export default {
  props:["statisticsIndex"],
  components: {
    RankList,
    BusinessList
  },
  data() {
    return {}
  },
  watch: {
    details: {
      handler(n, o) {
      },
      deep: true
    }
  },
  computed: {
  }
}
</script>
<style lang="less" scoped>
@import url('./statisticsDetails.less');
@import url('./statisticsDetailsMedia.less');
</style>
