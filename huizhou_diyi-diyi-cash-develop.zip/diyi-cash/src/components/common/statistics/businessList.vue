<template>
  <div>
    <div class="details-list">
      <div class="list-tabs">
        <div class="title">
          <h5>营业报表</h5>
        </div>
        <div class="menu">
          <ul>
            <li
              v-for="item in menu"
              :key="item.index"
              @click="getData(item.index)"
              :class="useIndex==item.index?'active':''"
            >
              <span>{{item.title}}</span>
            </li>
          </ul>
          <div class="add-btn" @click="showCheckTime = true">
            <img :src="jia" alt />
          </div>
        </div>
      </div>
      <div class="details">
        <div class="paid-price">
          <div class="left">
            <span>￥{{businessData.paid_up?transformMondy(Number(businessData.paid_up.paid_up)):0}}</span>
            <h3>营业实收(元)</h3>
          </div>
          <div class="right">
            <ul class="detalis">
              <li v-for="(item,index) in payStatus" :key="index">{{item}}(元)</li>
            </ul>
            <ul class="detalis">
              <li v-for="(item,index) in businessData.paid_up.list" :key="index">
                <span>￥{{item.paid_price?transformMondy(item.paid_price):0}}</span>
                <h3>单数：{{item.count?item.count:0}}</h3>
              </li>
            </ul>
          </div>
        </div>
        <div class="discount">
          <div class="left">
            <span>￥{{businessData.preferential?transformMondy(businessData.preferential.discounts):0}}</span>
            <h3>优免金额(元)</h3>
          </div>
          <div class="right">
            <ul class="detalis">
              <li>免单：￥ {{businessData.preferential&&businessData.preferential.gratis?transformMondy(businessData.preferential.gratis):0}}</li>
              <li>整单折扣：￥{{businessData.preferential&&businessData.preferential.discount_rate?transformMondy(businessData.preferential.discount_rate):0}}</li>
              <li>抹零：￥{{businessData.preferential&&businessData.preferential.pin_out?transformMondy(businessData.preferential.pin_out):0}}</li>
            </ul>
          </div>
        </div>
        <div class="total-price">
          <div class="total-price-detalis">
            <span>￥{{businessData.receivable_account?transformMondy(Number(businessData.receivable_account.receivable)):0}}</span>
            <h3>应收金额(元)</h3>
          </div>
          <div class="total-price-detalis">
            <div>
              <span>{{businessData.receivable_account?businessData.receivable_account.list_all.count:0}}</span>
              <h3>账单数（笔）</h3>
            </div>
            <div>
              <span>￥{{businessData.receivable_account?transformMondy(Number(businessData.receivable_account.list_all.amount)):0}}</span>
              <h3>单均消费(元)</h3>
            </div>
          </div>
          <div class="total-price-detalis">
            <div>
              <span>{{businessData.receivable_account?businessData.receivable_account.per_capita.count:0}}</span>
              <h3>消费人数(人)</h3>
            </div>
            <div>
              <span>￥{{businessData.receivable_account?transformMondy(Number(businessData.receivable_account.per_capita.amount)):0}}</span>
              <h3>人均消费(元)</h3>
            </div>
          </div>
        </div>
        <div class="abnormal">
          <ul>
            <li>异常监控</li>
            <li>免单（{{abnormalData.gratis.total}}）：￥{{transformMondy(abnormalData.gratis.amount)}}</li>
            <li>退菜（{{abnormalData.refund.total}}）：￥{{transformMondy(abnormalData.refund.amount)}}</li>
          </ul>
        </div>
      </div>
    </div>
    <el-dialog title="请选择统计时间段" :visible.sync="showCheckTime" width="32%">
      <el-date-picker
        style="width:160px"
        id="start"
        v-model="tableData.start"
        type="date"
        placeholder="开始日期"
        @focus="showTime()"
      ></el-date-picker>
      <span style="margin:0 12px;">至</span>
      <el-date-picker
        style="width:160px"
        id="end"
        v-model="tableData.end"
        type="date"
        placeholder="结束日期"
        @focus="showTime()"
      ></el-date-picker>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showCheckTime = false">取 消</el-button>
        <el-button type="primary" @click="searchByTime()">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import jia from '@/assets/img/jia.png'
import { businessReport, abnormal } from '@/api/statistics'
import { transformRMB, getStautsText } from '@/libs/util'

export default {
  data() {
    return {
      jia,
      showCheckTime: false,
      menu: [
        { title: '今天', index: 1 },
        { title: '昨天', index: 2 },
        { title: '本周', index: 3 },
        { title: '本月', index: 4 },
        { title: '近7天', index: 5 }
      ],
      useIndex: 1,
      tableData: {
        start: '',
        end: ''
      },
      businessReportData: {
        sign: 1
      },
      businessData: {
        paid_up:{
          list:[]
        }
      },
      abnormalData: {
        gratis: { total: 0, amount: 0 },
        refund: { total: 0, amount: 0 },
        freebie: { total: 0, amount: 0 }
      },
      payStatus: {},
      payStatusList: []
    }
  },
  methods: {
    getData(index) {
      /**
       * 导航栏天数请求
       */
      this.useIndex = index
      this.businessReportData.sign = index
      this.getBusinessReport()
    },
    async getBusinessReport() {
      /**
       * 请求列表
       */
      await abnormal(this.businessReportData).then(res => {
        this.abnormalData = res.data.data
      })
      businessReport(this.businessReportData).then(res => {
        if (res.data.code == 1) {
          this.businessData = res.data.data

          this.showCheckTime = false
        }

        if (this.businessData.preferential != undefined) {
          let preferentialAmount = 0
          if (this.businessData.preferential.list != []) {
            this.businessData.preferential.discount_rate =
              this.businessData.preferential.list[0].discount_rate == null
                ? 0
                : this.businessData.preferential.list[0].discount_rate
            this.businessData.preferential.gratis =
              this.businessData.preferential.list[0].gratis == null
                ? 0
                : this.businessData.preferential.list[0].gratis
            this.businessData.preferential.pin_out =
              this.businessData.preferential.list[0].pin_out == null
                ? 0
                : this.businessData.preferential.list[0].pin_out

            for (
              let i = 0;
              i < this.businessData.preferential.list.length;
              i++
            ) {
              preferentialAmount += Number(
                this.businessData.preferential.list[i].discount_amount
              )
            }
          }

          this.businessData.preferential.preferentialAmount = preferentialAmount
        }
        let newList = []

        if (this.businessData.paid_up != undefined) {
          for (let i = 0; i < Object.keys(this.payStatus).length; i++) {
            if (this.businessData.paid_up.list[i]!=undefined) {
              
              newList[Number(this.businessData.paid_up.list[i].pay_way)-1] = this.businessData.paid_up.list[i]
            }
          }
          for (let j = 0; j < Object.keys(this.payStatus).length; j++) {
              if (newList[j]==undefined) {
                newList[j]={}
              }              
            }
            this.businessData.paid_up.list = newList
        }
      })
    },
    transformMondy(value) {
      /**
       * 金额转换
       */
      return transformRMB(value)
    },
    showTime() {
      /**
       * 显示时间选择窗口
       * 不调用键盘
       */
      let Timepicker = document.getElementById('start')
      document.getElementById('end').setAttribute('readOnly', true)
      Timepicker.setAttribute('readOnly', true)
    },
    searchByTime() {
      /**
       * 时间段搜索
       */

      let end = this.tableData.start
      if (
        new Date(this.tableData.start).getTime() >
        new Date(this.tableData.end).getTime()
      ) {
        this.tableData.start = this.tableData.end
        this.tableData.end = end
      }

      this.businessReportData.sign = this.dealTime(
        this.tableData.start,
        this.tableData.end
      )
      this.getBusinessReport()
      this.useIndex = -1
    },
    dealTime(start, end) {
      /**
       *  时间处理
       */
      const time1 = new Date(start)
      const time2 = new Date(end)
      let returnTime =
        time1.getFullYear() +
        '-' +
        (time1.getMonth() + 1) +
        '-' +
        time1.getDate() +
        ' - ' +
        time2.getFullYear() +
        '-' +
        (time2.getMonth() + 1) +
        '-' +
        time2.getDate()
      return returnTime
    }
  },
  mounted() {},
  created() {
    this.getBusinessReport()
    this.payStatus = getStautsText('order.pay_way')
  }
}
</script>
<style lang="less" scoped>
@import url('./businessList.less');
</style>