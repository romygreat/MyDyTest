<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-30 08:46:51
 * @LastEditTime: 2019-12-16 18:04:53
 -->
<template>
  <el-dialog
    title="结账页"
    :visible.sync="logshow"
    width="30%"
    id="checkoutLog"
    custom-class="checkoutLog"
    :before-close="handleClose"
  >
    <div class="header">
      <h3>
        <span>实收：￥</span>
        {{transformMoney(list.statistics.paid_price)}}
      </h3>
      <p>已付： ￥{{setMoney}}</p>
      <img @click="handleClose" :src="close" alt srcset />
    </div>
    <div class="main clear">
      <div class="clearZero clear">
        <p>抹零：</p>
        <el-switch v-model="clearZero" active-color="#EC6E24" inactive-color="#EBEEF5"></el-switch>
        <el-input  v-if="clearZero" v-model="clearZeroValue" placeholder="请输入抹零数" />
      </div>
    </div>
    <div class="mode clear">
      <dl
        @click="useIndex = index;"
        :class="useIndex === index ? 'use' : ''"
        v-for="(item, index) in mode"
        :key="index"
      >
        <dt>
          <img :src="useIndex === index ? item.fimg : item.img" alt srcset />
        </dt>
        <dd>{{item.name}}</dd>
      </dl>
    </div>
    <div v-if="useIndex==0 || useIndex==1">
      <div class="palyMondy">
        <p>现金</p>
        <h3>￥</h3>
        <el-input   @focus="noEadalog"  min="0.01" :controls="false" v-model="setMoney" placeholder="请输入实收金额" />
        <h1>
          找零：
          <span>￥ {{calcRulrer(setMoney, TwopointsInfo(transformMoney(list.statistics.paid_price)),(clearZero == true ? clearZeroValue : 0)) }}</span>
        </h1>
      </div>
      <numberkey v-on:isconfirm="isconfirm($event)" v-on:setNumberKey="setNumberKey($event)" />
    </div>
    <div v-if="useIndex==2" class="credit">
      <div class="left">
        <el-form label-position="left" label-width="80px" class="credit-form">
          <el-form-item label="挂账金额">
            <el-input v-model="clearZeroKeys" :disabled="true"></el-input>
          </el-form-item>
          <el-form-item label="挂账类型">
            <el-radio v-model="creditData.type" label="1" style="margin-right:16px !important;">公司</el-radio>
            <el-radio v-model="creditData.type" label="2">个人</el-radio>
          </el-form-item>
          <el-form-item label="挂账主体" v-if="creditData.type==1">
            <el-select v-model="creditData.accounts_id" placeholder="请选择挂账主体" popper-class="select-center">
              <el-option
                v-for="(item,index) in creditCompany"
                :key="index"
                :label="item.arrearage_company"
                :value="item.id"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="挂账人" v-if="creditData.type==2">
            <el-select v-model="creditData.accounts_id" placeholder="请选择挂账人">
              <el-option
                v-for="(item,index) in creditCompany"
                :key="index"
                :label="item.arrearage_company"
                :value="item.id"
              ></el-option>
            </el-select>

          </el-form-item>
          <el-form-item label='挂账姓名' >
            <el-input v-model="creditData.accounts_name"></el-input>
          </el-form-item>
          <el-form-item label="挂账电话">
            <el-input v-model="creditData.accounts_phone"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div class="right credit-btn">
        <el-button @click="CreditSave()">挂账</el-button>
      </div>
    </div>
     <audio id="issuccpay" style="height: 40px; display:block !important; width:40px; " :src="succpay"></audio>
    <sweepCode
      v-on:codeCallack="codeCallack($event)"
      :order="list"
      :pin_out='clearZero ? clearZeroValue : 0'
      :show="useIndex==1"
      v-if="useIndex==1"
    />
    <!-- 支付成功 -->
    <el-dialog
      width="30%"
      title
      :before-close="clearSuccOrder"
      :visible.sync="succOrderShow"
      custom-class="succElgo"
      append-to-body
    >
      <div class="succElgoBox">
        <img :src="succorder" alt srcset />
        <p>￥{{TwopointsInfo(setMoney)}}</p>
        <h3>{{succText}}</h3>
      </div>
    </el-dialog>
  </el-dialog>
</template>
<script>
import Calc from 'number-precision'
import { transformRMB, Twopoints } from '@/libs/util'
import close from '@/assets/img/close.png'
import xianjin from '@/assets/img/xianjin.png'
import xianjinF from '@/assets/img/xianjin-f.png'
import saoma from '@/assets/img/saoma.png'
import saomaF from '@/assets/img/saoma-f.png'
import yinlian from '@/assets/img/yinlian.png'
import yinlianF from '@/assets/img/yinlian-f.png'
import huiyuanka from '@/assets/img/huiyuanka.png'
import succorder from '@/assets/img/succorder.png'
import huiyuankaF from '@/assets/img/huiyuanka-f.png'
import guazhang from '@/assets/img/guazhang.png'
import guazhangF from '@/assets/img/guazhang-f.png'
import numberkey from '_c/common/numberKey'
import { closeOrder, oAList, oASave } from '@/api/menu'
import sweepCode from '_c/common/sweepCode'
import { replacementOrder } from '@/api/printer'
import succpay from '@/assets/audio/succpay.mp3';
export default {
  props: ['show', 'data'],
  components: { numberkey, sweepCode },
  data() {
    return {
      succpay,
      list: {},
      succorder,
      succOrderShow: false,
      succText: '支付成功',
      logshow: false,
      callbackRes: {
        show: false,
        type: 0
      },
      setMoney: 0,
      close,
      clearZero: false,
      clearZeroValue: 0,
      mode: [
        { name: '现金', img: xianjin, title: 'cash', fimg: xianjinF },
        { name: '扫码', img: saoma, title: 'sweepCode', fimg: saomaF },
        // { name: '银联', img: yinlian, title: 'yinlian', fimg: yinlianF },
        // {
        //   name: '会员卡',
        //   img: huiyuanka,
        //   title: 'membershipCard',
        //   fimg: huiyuankaF
        // },
        {
          name: '挂账',
          img: guazhang,
          title: 'settleAccounts',
          fimg: guazhangF
        }
      ],
      timers: '',
      useIndex: 0,
      creditData: {
        type:"1"
      },
      creditCompany: [],
      closeDiog: false,
      oAListParam:{type:'1'}
    }
  },
  methods: {
    async handleClose() {      
      this.$emit('checkoutLogCallBack', this.callbackRes)
    },
    transformMoney(value) {
      return transformRMB(value)
    },
    isconfirm(res) {
      /**
       * 开始结账
       */
      if (res !== true) return
      const data = {
        id: this.list.id,
        trade_no: this.list.trade_no,
        change_price: parseInt(Calc.minus(
          Calc.times(this.setMoney, 100),
          Calc.minus(
            this.list.statistics.paid_price,
            this.clearZero == true ? Calc.times(this.clearZeroValue, 100) : 0
          )
        )),
        real_price: Calc.times(this.setMoney, 100),
        table_no: this.list.table_no,
        paid_price: this.list.statistics.paid_price,
        discount_amount: 0,
        discount_reason: '',
        pin_out:
          Number(this.clearZero == true ? Calc.times(this.clearZeroValue, 100) : 0)
      }
      if (data.change_price < 0) {
        this.$notify.error({
          title: '错误',
          message: '当前付款金额小于实收金额，请核实后再付款'
        })
        return
      }
      closeOrder(data).then(res => {
        if (res.data.code == 1) {
          //支付成功
          document.getElementById('issuccpay').play()
          this.succText = '支付成功'
          this.succOrderShow = true
          this.callbackRes.type = 1
          this.timers = setTimeout(() => {
            this.handleClose()
          }, 1000)
        } else {
          this.$notify.error({
            title: '错误',
            message: res.data.message
          })
        }
      })
    },
    setNumberKey(res) {
      /**
       * 增减￥
       * @param {String ||  Number} res
       * 注意： '.' 与  'clear' 回腿
       */
      let number = JSON.parse(JSON.stringify(this.setMoney))
      number = `${number}`
      //判断类型
      if (res === 'clear') {
        // 如果回退的时候发现这个数值只有一位则置为0
        if (number.length == 1) {
          this.setMoney = 0
          return
        }
        // 回退一位
        number = number.substring(0, number.length - 1)
        this.setMoney = JSON.parse(JSON.stringify(number))
        return
      }
      // 判断是否小数点
      if (res === '.') {
        //先查看是否本身有小数点
        if (number.indexOf('.') === -1) {
          number = `${number}${res}`
          this.setMoney = JSON.parse(JSON.stringify(number))
          return
        } else {
          return
        }
      }
      number = `${number}${res}`
      if (number.indexOf('.') > -1) {
        let numLength = number.substring(number.indexOf('.')).length-1
        if (numLength>2) {
          number = number.substring(0,number.length-1)
        }
        this.setMoney = number

      } else {
        this.setMoney = Number(JSON.parse(JSON.stringify(number)))
      }
    },
    clearSuccOrder() {
      clearTimeout(this.timers)

      this.handleClose()
    },
    TwopointsInfo(value) {
      return Twopoints(value)
    },
    calcRulrer(v1, v2, v3) {
      return Calc.plus(Calc.minus(v1, v2), v3)
    },
    /**
     * 挂账公司列表
     */
    oAListList() {
      oAList(this.oAListParam).then(res => {
        this.creditCompany = res.data.data.list
      })
    },
    CreditSave() {
      this.creditData.order_id = this.list.id
      this.creditData.title = this.list.table_no
      console.log(this.creditData,'::::')
      oASave(this.creditData).then(res => {
        if (res.data.code == 1) {
          this.logshow = false
          this.callbackRes.type = 1
          this.$emit('checkoutLogCallBack', this.callbackRes)
          this.$notify.success({
            title: '成功',
            message: '此订单已挂起，请及时处理'
          })
        } else {
          this.$notify({
            title: '抱歉',
            message: '挂账失败,请联系管理员',
            type: 'warning'
          })
          return
        }
      })
    },
    async codeCallack(res) {
      if (res.key === false) {
        this.useIndex = 0
      }
      if (res.key === true) {
        document.getElementById('issuccpay').play()
        this.succText = '支付成功'
        this.succOrderShow = true
        this.setMoney = Calc.divide(res.paid_price,100)
        this.callbackRes.type = 1
        this.timers = setTimeout(() => {
          this.handleClose()
        }, 1000)
      }
    },
    noEadalog(){
      if (window.android) window.android.sendMessage(2)
    }
  },
  created() {
    this.list = this.data
    if (this.list.statistics == undefined) {
      this.list.statistics = this.list
    }
    this.creditData.accounts_money = this.transformMoney(
      this.list.statistics.paid_price
    )
    this.logshow = this.show
    this.oAListList()
  },
  mounted(){
    console.log(this.data,12345)
     if (window.android) window.android.sendMessage(2)
  },
  watch:{
    "creditData.type":{
      handler(n,o){        
        this.oAListParam.type=='1'?this.oAListParam.type='2':this.oAListParam.type='1'
        this.oAListList()
        if (n!=o) {
      this.creditData.accounts_id = ''
        }
      }
    }
  },
  computed:{
    clearZeroKeys(){
      if(this.clearZero) return Calc.minus(this.creditData.accounts_money,this.clearZeroValue)
      else return this.creditData.accounts_money
    }
  },
}
</script>
<style lang="less" scoped >
@import url('./checkoutLog.less');
</style>
<style lang="less">
@import url('./checkoutLogMedia.less');
.checkoutLog {
  display: flex;
  justify-content: center;
  align-items: center;
}

// 老样子，针对UI空间无法作用于封闭内嵌
@media screen and (max-width: 1280px) {
  .checkoutLog {
    margin-top: 10vh !important;
  }
}
.checkoutLog {
  border-radius: 3px;
  width: 572px !important;
  .el-dialog__header {
    display: none;
  }
  .el-dialog__body {
    padding: 0;
  }
  .el-switch {
    display: block !important;
    float: left;
    transform: translateY(-2px);
  }
  .clearZero {
    .el-input {
      margin-left: 10px;
      width: 72px;
      height: 33px;
      transform: translateY(-8px);
      input {
        height: 33px;
      }
    }
  }
  .palyMondy {
    .el-input-number,
    .el-input {
      width: 100%;
      height: 100%;
      text-align: left;
      input {
        width: 100%;
        height: 100%;
      }
    }
    .el-input__inner {
      padding-left: 110px;
      font-size: 24px;
      color: #464c5b;
      font-weight: bold;
      line-height: 70px;
      padding-top: 2px;
      text-align: left;
      border: 2px solid #ec6e24;
      padding-left: 120px !important;
    }
    .el-input_suffix {
      width: 26px !important;
      height: 26px !important;
    }
  }
}
.succElgo {
  width: 298px !important;
  height: 304px !important;
  .el-dialog__headerbtn .el-dialog__close {
    font-size: 20px;
  }
}
.credit-form {
  .el-form-item {
    margin-bottom: 22px !important;
    .el-form-item__label {
      color: rgba(70, 76, 91, 1) !important;
      font-size: 16px !important;
    }
    .el-select {
      width: 100%;
    }
  }
}
.credit-btn {
  .el-button,
  .el-button:hover,
  .el-button:active,
  .el-button:focus {
    width: 100%;
    height: 100%;
    box-sizing: border-box;
    padding: 0 !important;
    margin-bottom: 18px !important;
    background: #fe7622 !important;
    font-size: 22px;
    color: #fff;
    font-weight: bold;
  }
}
.select-center{
  text-align: center !important;
}
</style>
