<!--
 * @Author: 叶锦荣
 * @Date: 2019-11-05 10:08:21
 * @LastEditTime: 2019-12-16 10:40:08
 -->
<template>
  <el-dialog
    title="提示"
    :visible.sync="codeShow"
    width="30%"
    custom-class="sweepCode"
    append-to-body
    :before-close="handleClose"
  >
    <div @click="setkeyFrous" class="sweepCodeBox">
      <hgroup>
        <h3>请选择扫码方式</h3>
        <p>实收：￥ {{transformMoney(order.statistics.paid_price,pin_out)}}</p>
        <i @click.stop="handleClose" class="el-icon-close closeSweep"></i>
      </hgroup>
      <div class="funtionListMain">
        <dl
          @click="setFocus(index)"
          :class="functionListIndex === index ? 'use' : '' "
          v-for="(item, index) in functionList"
          :key="index"
        >
          <dt>{{item.title}}</dt>
        </dl>
      </div>
      <!-- 扫码枪 -->
      <div class="codeGun" v-show="functionListIndex === 0">
        <img :src="codeGun" alt srcset />
        <p>使用扫码枪</p>
        <p>扫描顾客的条形码或者二维码</p>
        <el-input
          id="user"
          @change="toValue"
          v-focus
          :autofocus="true"
          v-model="codeValue"
          placeholder="请输入内容"
        />
      </div>
      <!-- 二维码 -->
      <div class="codeImg" v-if="functionListIndex === 1">
        <h3>
          请在
          <span>{{times}}</span>秒内完成扫码
        </h3>
        <img :src="succOrderImg" alt />
      </div>
      <!-- img -->
      <div class="codeFooterImg">
        <img v-for="(item, index) in footerImg" :key="index" :src="item.url" alt />
      </div>
    </div>
  </el-dialog>
</template>
<script>
import Calc from 'number-precision'
import codeGun from '@/assets/img/codeGun.png'
import yinhang from '@/assets/img/foorer (1).png'
import weixin from '@/assets/img/foorer (2).png'
import zhifubao from '@/assets/img/foorer (3).png'
import codekeyimg from '@/assets/img/codekeyimg.png'
import { transformRMB } from '@/libs/util'
import {
  createPayUrl,
  getOrderStatus,
  scannedPay,
  closeScannedOrder,
  scannedPayResultQuery
} from '@/api/menu'
import { async } from 'q'
export default {
  props: ['order', 'show','pin_out'],
  data() {
    return {
      codekeyimg,
      codeGun,
      codeShow: false,
      orderInfo: {},
      functionList: [
        { title: '扫码枪', type: 'codeGun' },
        { title: '二维码', type: 'codeImg' }
      ],
      functionListIndex: 0,
      codeValue: '',
      footerImg: [{ url: yinhang }, { url: weixin }, { url: zhifubao }],
      times: 900,
      timesinfo: '',
      orderStareTime: '',
      succOrderImg: '',
      aginSweep: '',
      wait_time: 0
    }
  },
  methods: {
    handleClose() {
      clearInterval(this.orderStareTime)
      clearInterval(this.timesinfo)
      this.$emit('codeCallack',{key:false})
    },
    /** @description 切换索引 */
    async setFocus(index) {
      this.functionListIndex = index
      if (index === 0) {
        if (window.android) window.android.sendMessage(2)
        clearInterval(this.orderStareTime)
        clearInterval(this.timesinfo)
        this.setkeyFrous()
      }
      if (index === 1) {
        const data = {
          id:this.order.id,
          remark1: '',
          remark2: '',
          paid_price: this.order.statistics.paid_price,
          pin_out: Calc.times( Number(this.pin_out),100)
        }
        let res = await createPayUrl(data)
        this.succOrderImg = res.data.data.qr_code
        this.getOrderStatusQ()
        this.times = res.data.data.validity
        this.timesinfo = setInterval(() => {
          if( this.times === 0 || this.times < 0) {
            this.handleClose()
            this.$notify({
              title: '失败',
              message: '超出了扫码时间限制，请重新操作',
              type: 'warning'
            })
              clearInterval(this.timesinfo)
          } 
          else this.times--
        }, 1000)
      }
    },
    /**
     * @description 监听订单支付情况
     */
    getOrderStatusQ() {
      const data = {
        id: this.order.id
      }
      var orderInfo = setInterval(() => {
        getOrderStatus(data).then(res => {
          if (res.data.data == 0) {
            clearInterval(orderInfo)
            clearInterval(this.timesinfo)
            this.$emit('codeCallack', {key:true,paid_price: this.order.statistics.paid_price})
          }
          this.orderStareTime = orderInfo
        })
      }, 1000)
    },
    /** @description 主动获取索引 */
    setkeyFrous() {
      if (this.functionListIndex === 0) document.getElementById('user').focus()
    },
    /** @description 扫码盒赋值成功后 */
    async toValue() {
      this.order.trade_no = String(this.order.trade_no).substring(
        this.order.trade_no.length - 15,
        this.order.trade_no.length
      )
      const data = {
        qrcode: this.codeValue,
        id: this.order.id,
        paid_price: this.order.statistics.paid_price,
        pin_out: Calc.times( Number(this.pin_out),100)
        //    paid_price:1
      }
      let codeRes = (await scannedPay(data)).data
      /**
       *  @param result  Y - 成功  N - 失败  U - 不确认  Q - 待查询 [需要使用主动查询]
       */
      //先判断接口是否正常
      if (codeRes.code !== 1) {
        this.$notify.error({
          title: '出错',
          message: codeRes.msg
        })
        this.codeValue = ''
        //   alert(JSON.stringify(codeRes) )
        return
      }
      // 支付失败
      if (codeRes.data.result === 'N') {
        this.$notify({
          title: '失败',
          message: codeRes.data.errmsg,
          type: 'warning'
        })
        this.codeValue = ''
        return
      }
      // 支付成功
      if (codeRes.data.result === 'Y') {
        this.codeValue = ''
        this.$emit('codeCallack',{key:true,paid_price: this.order.statistics.paid_price})
      }
      // 待查询 [需要使用主动查询]
      if (codeRes.data.result === 'Q' || codeRes.data.result === 'U') {
        this.wait_time = 15
        const agin = {
          qrcode: this.codeValue,
          trade_no: this.order.trade_no,
          qry_time: 0,
          qrcode_type: codeRes.data.qrcode_type,
          pin_out: Calc.times( Number(this.pin_out),100)
        }
        // 开始主动轮询主动查询
        this.aginSweep = setInterval(async () => {
          // 如果超过了轮询时间，请求关闭查询接口，并且关闭主动查询
          if (this.wait_time === 0) {
            const waitdata = {
              qrcode_type: codeRes.data.qrcode_type,
              trade_no: this.order.trade_no
            }
            let waitinfo = await closeScannedOrder(waitdata)
            this.codeValue = ''
            clearInterval(this.aginSweep)
            return
          }
          // 开启主动查询
          agin.qry_time++
          scannedPayResultQuery(agin).then(res => {

            // 当主动查询有结果，成功 或者 失败
            if (res.data.result === 'Y') {
              this.codeValue = ''
              this.$emit('codeCallack', {key:true,paid_price: this.order.statistics.paid_price})
              clearInterval(this.aginSweep)
            }
            if (res.data.result === 'N') {
              this.$notify({
                title: '失败',
                message: codeRes.data.errmsg,
                type: 'warning'
              })
              this.codeValue = ''
              clearInterval(this.aginSweep)
            }
            // 同步减少请求时长
            this.wait_time--
          })
        }, 2000)
      }
    },
    transformMoney(value,value2) {
      if(value2){ 
        value2 = Calc.times(value2,100)
        value = Calc.minus(value,value2)
      }
      return transformRMB(value)
    }
  },
  mounted() {
    this.codeShow = this.show
    if (window.android) window.android.sendMessage(2)
  },
  directives: {
    /** @description 切换主动获得焦点 */
    focus: {
      inserted(el) {
        el.querySelector('input').focus()
      }
    }
  }
}
</script>
<style lang="less">
@import url('./sweepCode.less');
</style>