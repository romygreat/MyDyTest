/*
 * @Author: 叶锦荣
 * @Date: 2019-11-05 10:08:46
 * @LastEditTime: 2019-11-05 10:49:22
 */
import sweepCode from './sweepCode.vue'
export default sweepCode