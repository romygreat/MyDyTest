<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-30 15:05:37
 * @LastEditTime: 2019-11-13 11:56:10
 -->
<template>
  <div class="require">
    <i @click.stop="swiperFalse" class="el-icon-close closeSweep"></i>
    <section>
      <h3>要求</h3>
      <p v-if="requirList.contornoArr">
        配菜
        <span>+ {{requirList.contorno.contorno_price / 100 }} 元</span>
      </p>
      <div v-if="requirList.contornoArr">
        <dl
          @click="againGarnish(item,index)"
          :class="contornoIndex.indexOf(index) !== -1 ? 'use' : ''"
          v-for="(item, index) in requirList.contornoArr"
          :key="index"
        >
          <dt>{{item.name}}</dt>
          <img v-if="contornoIndex.indexOf(index) !== -1" :src="gou2" alt />
        </dl>
      </div>
      <p class="mt50" v-if="requirList.procedureArr">
        做法
        <span>+ {{requirList.procedure.proces_price / 100}} 元</span>
      </p>
      <div v-if="requirList.procedureArr">
        <dl
          @click="againProcedure(item,index)"
          :class="requirList.procedure.id === item.id ? 'use' : ''"
          v-for="(item, index) in requirList.procedureArr"
          :key="index"
        >
          <dt>{{item.name}}</dt>
          <img v-if="requirList.procedure.id == item.id" :src="gou2" alt />
        </dl>
      </div>
      <p class="mt50" v-if="requirList.tasteArr">口味</p>
      <div v-if="requirList.tasteArr">
        <dl
          @click="againTaste(item,index)"
          :class="requirList.taste.id == item.id ? 'use' : ''"
          v-for="(item, index) in requirList.tasteArr"
          :key="index"
        >
          <dt>{{item.name}}</dt>
          <img v-if="requirList.taste.id == item.id" :src="gou2" alt />
        </dl>
      </div>
    </section>
    <div @click="okDiscount()" class="commitButtom">确认</div>
  </div>
</template>
<script>
import Calc from 'number-precision'
import { transformRMB, Twopoints } from '@/libs/util'
import gou2 from '@/assets/img/gou2.png'
export default {
  props: ['list'],
  data() {
    return {
      gou2,
      requirList: {},
      reprice: 0,
      contornoIndex: []
    }
  },
  methods: {
    /**
     * @description 重新选择配菜
     */
    againGarnish(item, index) {
      // 选择集合对象数组化
      console.log(this.requirList.contorno, '未下单')
      let caryyName = []
      if (this.requirList.switch)
        caryyName = this.requirList.contorno.contorno_name.split('-')
      else caryyName = this.requirList.contorno.contorno_name.split(',')
      if (caryyName[0] == '' || caryyName[0] == 0) caryyName = []
      // id 数组化
      let carryID = this.requirList.contorno_ids.split(',')
      if (carryID[0] == '' || caryyName[0] == 0) carryID = []

      console.log(caryyName, 7452, carryID)
      // 查看是否有选中
      /** @type name */
      console.log(caryyName, item.name, caryyName.indexOf(item.name))
      if (caryyName.indexOf(item.name) !== -1) {
        this.contornoIndex.splice(caryyName.indexOf(item.name), 1)
        caryyName.splice(caryyName.indexOf(item.name), 1)
        this.reprice = Calc.minus(
          Number(this.requirList.contorno.contorno_price),
          Number(item.price)
        )
      } else {
        this.contornoIndex.push(index)
        caryyName.push(item.name)
        this.requirList.contorno.contorno_price = Calc.plus(
          Number(item.price),
          Number(this.requirList.contorno.contorno_price)
        )
        this.reprice = this.requirList.contorno.contorno_price
      }
      /** @type ID */
      console.log(carryID, carryID.indexOf(String(item.id)), item.id)
      if (carryID.indexOf(String(item.id)) !== -1) {
        carryID.splice(carryID.indexOf(String(item.id)), 1)
      } else {
        carryID.push(String(item.id))
      }
      console.log(carryID, '??din')
      //赋值
      let obj = {}
      caryyName.forEach((item, idx) => {
        obj[idx] = item
      })
      console.log(this.requirList.contorno,'domfpfpfpff')
      if(this.requirList.contorno) {
        this.$set(this.requirList, 'contorno', obj)
        this.$set(this.requirList, 'contorno_ids', carryID.join(','))
        this.$set(this.requirList.contorno, 'id', this.requirList.contorno_ids)
        this.$set(
          this.requirList.contorno,
          'contorno_price',
          Number(this.reprice)
        )
        console.log(this.requirList.contorno,'妈嗨')
      } else {
        this.requirList.contorno = {}
        this.requirList.contorno =  obj
        this.requirList.contorno_ids = carryID.join(',')
        this.requirList.contorno.id = this.requirList.contorno_ids
        this.requirList.contorno.contorno_price =  Number(this.reprice) 
                console.log('ddddd',  this.requirList.contorno) 
      }
      if (this.requirList.switch)
        this.$set(
          this.requirList.contorno,
          'contorno_name',
          caryyName.join('-')
        )
      else {
        this.requirList.contorno.contorno_name =  caryyName.join(',')
        this.$set(
          this.requirList.contorno,
          'contorno_name',
          caryyName.join(',')
        )
      }
      console.log(this.requirList,'ifnofinfo')
    },
    /**
     * @description 重新选择口味
     */
    againTaste(item, index) {
      console.log(item,'口味')
      this.$set(this.requirList, 'taste', item)
    },
    /**
     * @description 重新选择做法
     */
    againProcedure(item, index) {
      this.$set(this.requirList, 'procedure', item)
    },
    okDiscount() {
      console
      if (this.requirList.contorno.contorno_name == '') delete this.requirList.contorno
      this.$emit('toRequire', this.requirList)
    },
    /** @description 查看配菜对应的索引 */
    setGarnishIndex() {
      String(this.requirList.contorno_ids).split(',').forEach((el, index) => {
        this.requirList.contornoArr.forEach((jl, idx) => {
          if (jl.id == el) {
            console.log(index,':')
            this.contornoIndex.push(idx)
          }
        })
      })
      console.log(this.contornoIndex, 111)
    },
    swiperFalse() {
      this.$emit('swiperFalse', false)
    }
  },
  watch: {
    requirList: {
      handler(n, o) {
        console.log(n, 2221)
      },
      deep: true
    }
  },
  mounted() {
    this.requirList = JSON.parse(JSON.stringify(this.list))
    console.log(this.requirList, 123321)
    if (!this.requirList.contorno) {
      this.requirList.contorno = {}
      this.requirList.contorno.contorno_id = ''
      this.requirList.contorno.contorno_name = ''
      this.requirList.contorno.contorno_price = 0
      this.requirList.contorno.id = ''
    }
    if (!this.requirList.contorno_ids) this.requirList.contorno_ids = ''
    console.log(this.requirList.contorno)
    this.setGarnishIndex()
  }
}
</script>
<style lang="less" scoped >
@import url('./modularShop.less');
</style>