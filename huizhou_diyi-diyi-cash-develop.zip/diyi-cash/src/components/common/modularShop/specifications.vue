<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-23 15:32:
 * @LastEditTime: 2019-11-25 09:30:06
 -->
<template>
  <div class="specifications">
    <i @click.stop="swiperFalse" class="el-icon-close closeSweep"></i>
    <h3>{{useList.name}}</h3>
    <hgroup>
      <span>已选：{{useList.group.group_title}}</span>
      <p>￥ {{transformMondy(useList.group.group_price)}}</p>
    </hgroup>
    <div>
      <dl v-for="(item, index) in useList.spec" :key="index">
        <dt>{{item.name}}</dt>
        <dd
          @click="setSpec(item,index,idx)"
          :class="keyinfo[index] == idx ? 'use' : '' "
          v-for="(el, idx) in item.spec_val"
          :key="idx"
        >
          {{el.spec_val}}
          <img :src="gou2" />
        </dd>
      </dl>
    </div>
    <div @click="okDiscount()" class="commitButtom">确认</div>
  </div>
</template>
<script>
import { transformRMB } from '@/libs/util'
import gou2 from '@/assets/img/gou2.png'
export default {
  props: ['list'],
  data() {
    return {
      useList: {},
      gou2,
      indexList: {},
      keyinfo: {},
      toSpec: {}
    }
  },
  methods: {
    /**
     * @description: 查找当前商品规格索引
     * @param {Aarry} useList.spec 商品拥有的规格集合
     * @param {String} useList.group.spec_val_ids 商品所选ID组合
     * @return:
     */
    indexes() {
      let spec = this.useList.spec
      let key = String(this.useList.group.spec_val_ids).split(',')
      key.forEach((el, idx) => {
        spec.forEach((jl, index) => {
          jl.spec_val.forEach((zl, zdx) => {
            if (el == zl.id) {
              this.indexList[index] = zdx
            }
          })
        })
      })
      this.keyinfo = JSON.parse(JSON.stringify(this.indexList))
    },
    /**
     * @description: 选择规格名，组合规格组合
     * @param {Object} useList.groupArr 选择后的组合
     */
    setSpec(item, index, idx) {
      //先赋值过去
      this.$set(this.indexList, index, idx)
      // 在循环内把值提取规格名组合
      let infotext = ''
      let off = false
      for (let i in this.indexList) {
        // 第一次
        if (off === false) {
          infotext = `${this.useList.spec[i].spec_val[this.indexList[i]].spec_val}`
          off = true
        } else {
          infotext = `${infotext}-${this.useList.spec[i].spec_val[this.indexList[i]].spec_val}`
        }
      }
      //TODO 这里用了$set 还是没解决渲染问题，日后再看一下，  keyinfo是解决现在这个问题的参数
      this.keyinfo = JSON.parse(JSON.stringify(this.indexList))
      // 更新所选规格名组合
      this.useList.group.group_title = infotext
      
      // 从组合里面抽出当前所选
      let obj = {}
      this.useList.groupArr.forEach((element, idx) => {
        if (element.group_title == infotext) {
          obj = element
        }
      })
      this.useList.group.group_price = obj.group_price
      this.toSpec = obj
    },
    transformMondy(value) {
      return transformRMB(value)
    },
    okDiscount() {
      this.$emit('specPrmis', this.toSpec)
    },
    swiperFalse() {
      this.$emit('swiperFalse', false)
    }
  },
  created() {
    this.useList = JSON.parse(JSON.stringify(this.list))
    this.indexes()
  }
}
</script>
<style lang="less" scoped>
@import url('./modularShop.less');
</style>