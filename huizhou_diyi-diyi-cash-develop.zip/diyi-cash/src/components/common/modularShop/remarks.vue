<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-30 08:46:51
 * @LastEditTime: 2019-11-13 14:50:27
 -->
<template>
  <div class="remarks">
    <i @click.stop="swiperFalse" class="el-icon-close closeSweep"></i>
    <section>
      <h3>备注-{{openlist.name}}</h3>
      <PackSwithc :pack="openlist_isPack" v-on:setPack="setPack($event)" />
      <div class="tab">
        <dl
          @click="setTab(idx)"
          :class="tabIndex === idx ? 'use' : ''"
          v-for="(item,idx) in tabList"
          :key="idx"
        >
          <dt>{{item.title}}</dt>
        </dl>
      </div>
      <div class="reasonList">
        <dl
          @click="setReason(item,idx)"
          :class="useindexCallback(item) ? 'use' : ''"
          v-for="(item,idx) in reasonListAll.list"
          :key="idx"
        >
          <dt>{{item.reason}}</dt>
          <img v-if="useindexCallback(item)" :src="gou2" alt />
        </dl>
        <dl style="border:none;">
          <paging
          class="paing-btn"
            v-if="reasonListAll.total > 5"
            v-on:setPage="setPage($event)"
            :modulUse="true"
            :total="reasonListAll.total"
            :page="remarksReq.page"
            :rows="remarksReq.rows"
          />
        </dl>
      </div>
      <el-input
       :maxlength='60'
        v-if="tabList[tabIndex].type === 'AllforOne'"
        type="textarea"
        :rows="2"
        :placeholder="placeholder"
        v-model="remarksInfo"
      />
      <el-input
        :maxlength='60'
        v-if="tabList[tabIndex].type === 'OneforAll'"
        type="textarea"
        :rows="2"
        :placeholder="placeholder"
        v-model="remarksInfoOrder"
      />
    </section>
    <div @click="okDiscount()" class="commitButtom">确认</div>
  </div>
</template>
<script>
import paging from '_c/common/paging'
import { reasonList } from '@/api/menu'
import PackSwithc from '_c/common/packSwitch'
import gou2 from '@/assets/img/gou2.png'
export default {
  props: ['list', 'order'],
  components: { PackSwithc, paging },
  data() {
    return {
      gou2,
      openlist: {},
      remarks: false,
      tabList: [
        { title: '单品备注', type: 'AllforOne' },
        { title: '整单备注', type: 'OneforAll' }
      ],
      tabIndex: 0,
      tabAarry: [],
      remarksInfo: '',
      placeholder: '请输入或选择备注内容，不要超过10个字',
      remarksReq: {
        page: 1,
        rows: 5,
        type: 3
      },
      reasonListAll: {
        list: [],
        total: 0
      },
      reasonIndex: 0,
      reasonAarry: [],
      openlist_isPack: false,
      remarksInfoOrder: ''
    }
  },
  methods: {
    /**
     *  @description 获取备注库的备注
     */
    async setReasonList(type) {
      let res = await reasonList(this.remarksReq)
      this.reasonListAll.list = res.data.data.list
      this.reasonListAll.total = res.data.data.total
    },
    /**
     * @description 写入备注
     */
    setReason(item, idx) {
      if (this.tabList[this.tabIndex].type === 'AllforOne') {
        if (this.tabAarry.indexOf(item.reason) !== -1) {
          this.tabAarry.splice(this.tabAarry.indexOf(item.reason), 1)
          this.remarksInfo = this.tabAarry.join(',')
          return
        }
        this.tabAarry.push(item.reason)
        this.remarksInfo = this.tabAarry.join(',')
      }
      if (this.tabList[this.tabIndex].type === 'OneforAll') {
        if(this.reasonAarry.indexOf(item.reason) !== -1) {
          this.reasonAarry.splice(this.reasonAarry.indexOf(item.reason),1)
          this.remarksInfoOrder = this.reasonAarry.join(',')
          return
        }
        this.reasonAarry.push(item.reason)
        this.remarksInfoOrder = this.reasonAarry.join(',')
      }
    },
    /**
     * @description 确认
     */
    okDiscount() {
      this.openlist_isPack
        ? (this.openlist.is_pack = 1)
        : (this.openlist.is_pack = 0)
      for (let key of this.remarksInfo) {
        if (key === '，') key = ','
      }
      if (this.tabList[this.tabIndex].type === 'AllforOne') {
        if (this.openlist.is_pack == 1 && this.remarksInfo.split(',').indexOf('打包 ') == -1) {
          this.remarksInfo = `打包 ${this.remarksInfo}`
        } 
         if (this.openlist.is_pack != 1 && this.remarksInfo.split(',').indexOf('打包 ') != -1 ){
          let arr = JSON.parse(JSON.stringify(this.remarksInfo.split(',')))
          arr.splice(arr.indexOf('打包 '),1)
          let infoKey = arr.join(',')
          this.remarksInfo = infoKey
        }
        this.$emit('toRemarks', {
          ...this.openlist,
          remarks: this.remarksInfo,
          remarksType: 0,
          openlist_isPack: this.openlist.is_pack
        })
      } else
        this.$emit('toRemarks', {
          remarksType: 1,
          remarks: this.remarksInfoOrder,
          openlist_isPack: this.openlist.is_pack
        })
    },
    /**
     *  @description 由分页组件 paging 传递过来的参数，指挥上下翻页
     *  @param {String} res 标识  next ： 上一页  upper ： 下一页
     */
    setPage(res) {
      if (res === 'next') this.remarksReq.page--
      else this.remarksReq.page++
      this.setReasonList(true)
    },
    setPack(res) {
      this.openlist_isPack = res
      // this.openlist.is_pack = res == true ? 1 : 0
      //  this.remarksInfo = `[打包] ${this.remarksInfo}`
    },
    /** @descriptio 切换Tab页面 */
    setTab(idx) {
      if (idx === 0 && this.list.refund_price) {
        this.$notify({
          title: '错误',
          message: '当前商品是退菜商品，暂不支持该操作',
          type: 'warning'
        })
        return
      }
      this.tabIndex = idx
    },
    swiperFalse() {
      this.$emit('swiperFalse', false)
    },
    useindexCallback(item) {
      if (this.tabIndex === 0 && this.tabAarry.indexOf(item.reason) !== -1)
        return true
      else false
      if (this.tabIndex === 1 && this.reasonAarry.indexOf(item.reason) !== -1)
        return true
      else false
    }
  },
  mounted() {
    if (this.list.refund_price) {
      this.tabIndex = 1
    } else {
      this.openlist = JSON.parse(JSON.stringify(this.list))
      if (this.openlist.remark && this.openlist.remark != '')
        this.remarksInfo = this.openlist.remark
      if (this.openlist.remark) this.tabAarry = this.openlist.remark.split(',')
      this.openlist_isPack = this.openlist.is_pack == 1 ? true : false
    }
    this.remarksInfoOrder = this.order.remark
    if (this.order.remark) this.reasonAarry = this.order.remark.split(',')
  },
  created() {
    this.setReasonList()
  }
}
</script>
<style lang='less' scoped>
@import url('./modularShop.less');
</style>
<style lang="less" >
.remarks {
  .el-textarea {
    width: 242px !important;
    height: 78px !important;
    display: block;
    margin: 18px auto 14px auto;
    textarea {
      width: 100% !important;
      height: 100% !important;
    }
  }
}
</style>