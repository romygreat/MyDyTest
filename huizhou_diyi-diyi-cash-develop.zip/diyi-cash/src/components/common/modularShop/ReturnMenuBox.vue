<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-24 18:38:15
 * @LastEditTime: 2019-12-11 16:04:07
 -->
<template>
  <div class="returnMenu">
    <i @click.stop="swiperFalse" class="el-icon-close closeSweep"></i>
    <section>
      <h3>退菜-{{openRes.name}}</h3>
      <div>
        <p>退菜数量：</p>
        <div class="returnInfo">
          <img @click="algorithm('-')" :src="rudisTuicai" />
          <el-input-number @blur="handleChange" :controls="false" v-model="returnNumber" :min="0" />
          <img @click="algorithm('+')" :src="addtuicai" />
        </div>
      </div>
      <numModular v-on:setReturnNum="setReturnNum($event)" />
      <section class="reson">
        <h3>退菜原因:</h3>
        <el-input
          :maxlength="30"
          type="textarea"
          :rows="2"
          :placeholder="placeholder"
          v-model="reason"
        />
        <dl
          @click="setReson(item,index)"
          :class="useindex === index ? 'use' : ''"
          v-for="(item, index) in reasonList.list"
          :key="index"
        >
          <dd>
            {{item.reason}}
            <img v-if="useindex === index" :src="gou2" />
          </dd>
        </dl>
        <div class="kongbai"></div>
        <div class="pagebox">
          <paging
            v-on:setPage="setPage($event)"
            :modulUse="true"
            :total="reasonList.total"
            :page="returnReq.page"
            :rows="returnReq.rows"
          />
        </div>
      </section>
      <div @click="okDiscount()" class="commitButtom">确认</div>
    </section>
  </div>
</template>
<script>
import rudisTuicai from '@/assets/img/rudisTuicai.png'
import addtuicai from '@/assets/img/addtuicai.jpg'
import { reasonList } from '@/api/menu'
import numModular from '_c/common/numModular'
import gou2 from '@/assets/img/gou2.png'
import paging from '_c/common/paging'
export default {
  components: { numModular, paging },
  props: ['list'],
  data() {
    return {
      gou2,
      openRes: {},
      rudisTuicai,
      addtuicai,
      returnNumber: 1,
      returnReq: {
        page: 1,
        rows: 5,
        type: 2
      },
      reasonList: {},
      reason: '',
      placeholder: '请选择或者输入退菜原因',
      useindex: 0,
      xiaoshuSwitch: false,
      setOff:false
    }
  },
  methods: {
    /**
     * @description 获取退菜原因列表
     * @param {Boole} type  type === true 为第一次获取列表中的第一个
     * @param {Object} reasonList 原因对象，内有列表List, 总叔total
     */
    setReasonList(type) {
      reasonList(this.returnReq).then(res => {
        this.reasonList = res.data.data
        if (type == true) this.reason = this.reasonList.list[0].reason
      })
    },
    /**
     * @description 正常点击赋值
     * @param {String} reason 原因
     * @param {Number} useindex 索引
     */

    setReson(item, index) {
      this.reason = item.reason
      this.useindex = index
    },
    /**
     *  @description 由分页组件 paging 传递过来的参数，指挥上下翻页
     *  @param {String} res 标识  next ： 上一页  upper ： 下一页
     */
    setPage(res) {
      if (res === 'next') this.returnReq.page--
      else this.returnReq.page++
      this.setReasonList(true)
    },
    /**
     *  @description 增减退菜数量
     *  @param {String} type 类别，区分是“ + ” 还是 “ - ”
     */
    algorithm(type) {
      // 先判断当前算法
      if (type === '+') {
        // 假如退菜数量大于点菜数量
        if (this.returnNumber + 1 > this.openRes.num) {
          this.$notify({
            title: '错误',
            message: '退菜数量无法超过实际点菜数量',
            type: 'warning'
          })
          return
        }
        this.returnNumber++
      }
      if (type === '-') {
        if (this.returnNumber == 1) return
        else this.returnNumber--
      }
    },
    /**
     * @description 接受组件的退菜数量
     * @param {Number} res 写入的数量
     */
    setReturnNum(res) {
      if(res === -1){
        this.setOff = false
        if(this.openRes.num < 1)  this.returnNumber = 0
        else this.returnNumber = 1
        this.xiaoshuSwitch = false
       return
      }
      // 如果是小数点
      if(res === '.') {
        if(this.openRes.is_editable != 1) {
          this.$notify({
            title: '错误',
            message: '该商品不是称重商品，无法使用小数点',
            type: 'warning'
          })
          return
        }
        this.xiaoshuSwitch = true
        this.setOff = true
        return
      }
      // 如果上一步使用了小数点
      if(this.xiaoshuSwitch) {
        this.xiaoshuSwitch = false
        this.returnNumber =  Number(`${this.returnNumber}.${res}`)
        this.setOff = true
        return
      }
      // 是否第一次赋值
      if(!this.setOff) {
        this.returnNumber = res
        if(this.openRes.num <  this.returnNumber) {
          this.$notify({
            title: '错误',
            message: '退菜数量无法超过实际点菜数量',
            type: 'warning'
          })
          if(this.openRes.num < 1)  this.returnNumber = 0
          else this.returnNumber = 1
          return
        }
        return
      } 
      this.returnNumber =  Number(`${this.returnNumber}${res}`)
        if(this.openRes.num <  this.returnNumber) {
          this.$notify({
            title: '错误',
            message: '退菜数量无法超过实际点菜数量',
            type: 'warning'
          })
          if(this.openRes.num < 1)  this.returnNumber = 0
          else this.returnNumber = 1
        }
    },
    handleChange() {
      if (this.returnNumber + 1 > this.openRes.num) {
        this.$notify({
          title: '错误',
          message: '退菜数量无法超过实际点菜数量',
          type: 'warning'
        })
        this.returnNumber = 1
        // this.returnNumber = Number(JSON.parse(JSON.stringify(this.openRes.num)))
      }
      this.setOff = false
    },
    okDiscount() {
      if( this.returnNumber ===0 ||  this.returnNumber === '0') {
        this.$notify({
          title: '错误',
          message: '退菜数量无法为零',
          type: 'warning'
        })
        return
      }
      let data = {
        num: this.returnNumber,
        refund_reason: this.reason
      }
      this.$emit('toReturnMenu', data)
    },
    swiperFalse() {
      this.$emit('swiperFalse', false)
    }
  },
  mounted() {
    this.openRes = this.list
    this.setReasonList(true)
  }
}
</script>
<style lang="less" scoped>
@import url('./modularShop.less');
</style>
<style lang="less">
.returnInfo {
  .el-input-number {
    width: 72px !important;
    height: 32px !important;
    margin: 0 10px !important;
  }
  .el-input {
    width: 72px !important;
    height: 32px !important;
    input {
      width: 100% !important;
      height: 100% !important;
    }
  }
}
.reson {
  .el-textarea {
    width: 100% !important;
    height: 56px !important;
    display: block;
    margin: 18px auto 14px auto;
    textarea {
      width: 100% !important;
      height: 100% !important;
    }
  }
}
</style>
