<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-25 18:37:45
 * @LastEditTime: 2019-12-01 11:40:09
 -->
<template>
  <div class="discount clear">
    <h3>{{tabInfo[useIndex].name}}</h3>
    <dl>
      <dd
        :class="useIndex === idx ? 'use' : ''"
        @click="setIndex(idx)"
        v-for="(item,idx) in tabInfo"
        :key="idx"
      >{{item.name}}</dd>
    </dl>
    <!-- 整单打择 -->
    <section class="single" v-if="useIndex == 1">
      <hgroup v-if="false">
        <div style="display:block;width:100%">应收金额：{{ unitPrice( order.statistics.paid_price,100)}}</div>
        <div style="display:block;width:100%;text-align:left">
          优惠价：
          <span>￥ {{TwopointsValue(paidRate)}}</span>
        </div>
      </hgroup>
      <div class="function">
        <div :class="clearALL ? 'use' : ''" @click="setEdlog(10);clearALL = true">移除优惠</div>
        <div
          :class="(Orderdiscount_rate !=10 || (order.discount_rate && order.discount_rate != 10 )) && !clearALL ? 'use' : ''"
          @click="logData.show = true"
        >{{Orderdiscount_rate != 10 || (order.discount_rate && order.discount_rate != 10) ? `${ Orderdiscount_rate != 10 ? Orderdiscount_rate : order.discount_rate}折` : '自定义折扣'}}</div>
      </div>
    </section>
    <!-- 单品优惠 -->
    <section class="single" v-if="useIndex == 0">
      <hgroup>
        <div>单价：{{opendata.switch ? TwopointsValue(unitPrice(opendata.price,opendata.num)) : TwopointsValue(opendata.paramePrice ? opendata.paramePrice : 0)}}</div>
        <div>份数：{{opendata.num}}</div>
        <div>
          优惠价：
          <span>￥ {{concessionalRate}}</span>
        </div>
      </hgroup>
      <div class="function">
        <div
          :class="funtionIndex ===  idx ? 'use' : ''"
          @click="selectFuntion(item,idx)"
          v-for="(item,idx) in funtionList"
          :key="idx"
        >{{(discount_rate !== 0 || (opendata.discount_rate && opendata.discount_rate != 10)) && idx === 2 ? `${discount_rate !== 0 ? discount_rate : opendata.discount_rate}折` : item.name}}</div>
      </div>
    </section>
    <!-- 打折原因 -->
    <section class="reason">
      <h3>打折原因：</h3>
      <el-input
        :maxlength="40"
        type="textarea"
        :rows="2"
        :placeholder="placeholder"
        v-model="reason"
      />
      <dl
        :class="reasonIndex === idx ? 'use' : ''"
        @click="setReason(item,idx)"
        v-for="(item,idx) in reasonList.list"
        :key="idx"
      >
        <dd>
          {{item.reason}}
          <img :src="gou2" />
        </dd>
      </dl>
      <div class="kongbai"></div>
      <div class="pagebox">
        <paging
          v-if="reasonList.total > 5"
          v-on:setPage="setPage($event)"
          :modulUse="true"
          :total="reasonList.total"
          :page="disscountReq.page"
          :rows="disscountReq.rows"
        />
      </div>
      <div @click="okDiscount()" class="commitButtom">确认</div>
    </section>
    <numberSelect
      v-if="logData.show"
      v-on:setEdlog="setEdlog($event)"
      v-on:clearEdlog="clearEdlog($event)"
      :title="logData.title"
      :show="logData.show"
      :unit="logData.unit"
      :buttomText="logData.buttomText"
    />
    <i @click.stop="swiperFalse" class="el-icon-close closeSweep"></i>
  </div>
</template>
<script>
import { Twopoints } from '@/libs/util'
import Calc from 'number-precision'
import { reasonList } from '@/api/menu'
import numberSelect from '_c/common/numberSelect'
import paging from '_c/common/paging'
import gou2 from '@/assets/img/gou2.png'
export default {
  props: ['list', 'order'],
  components: { numberSelect, paging },
  data() {
    return {
      gou2,
      tabInfo: [{ name: '单品优惠' }, { name: '整单打折' }],
      useIndex: 0,
      opendata: {},
      concessionalRate: 0,
      funtionList: [
        { name: '移除优惠', type: 'clear' },
        { name: '赠送', type: 'give' },
        { name: '自定义折扣', type: 'custom' }
      ],
      funtionIndex: '',
      reason: '',
      reasonIndex: 0,
      reasonList: {},
      disscountReq: {
        page: 1,
        rows: 5,
        type: 1
      },
      placeholder: '请输入或者选择菜品打折原因，不得超过20个字',
      useFunction: {},
      logData: {
        title: '自定义折扣',
        unit: '折',
        show: false,
        buttomText: '确认'
      },
      discount_rate: 0,
      Orderdiscount_rate: 10,
      paidRate: 0,
      discountSwitch: false,
      clearALL: false
    }
  },
  methods: {
    /**
     * @description 计算出单价
     **/
    unitPrice(price, num) {
      return Calc.divide(price, num)
    },
    /**
     * @description 算出真实数据
     */
    TwopointsValue(value) {
      return Twopoints(Calc.divide(value, 100))
    },
    /**
     * @description 获取原因列表
     */
    getResonList(type) {
      reasonList(this.disscountReq).then(res => {
        this.reasonList = res.data.data
        if (type == true) this.reason = this.reasonList.list[0].reason
      })
    },
    /**
     *  @description 功能分发
     *  @param {String} type 功能类型
     *  @param {String} custom 自定义折率
     *  @param {String} give 赠菜
     *  @param {String} clear 移除优惠
     */
    selectFuntion(item, index) {
      if (item.type === 'custom') this.logData.show = true
      // 赠送
      if (item.type === 'give') {
        this.setEdlog(0)
      }
      // 移除优惠
      if (item.type === 'clear') {
        this.setEdlog(10)
      }
      this.funtionIndex = index
    },
    /**
     * @description 写入优惠
     */
    setEdlog(res) {
      this.logData.show = false
      if (this.useIndex === 0) {
        let unitPrice = 0
        this.discount_rate = res
        // 先区分下单后还是下单前
        if (this.opendata.switch) {
          // 先算出真实单价
          unitPrice = this.unitPrice(this.opendata.price, this.opendata.num)
        } else {
          // 没下单有真实单价参数
          unitPrice = JSON.parse(JSON.stringify(this.opendata.paramePrice))
        }
        // 开始打折
        unitPrice = Calc.times(unitPrice, Calc.divide(res, 10))
        // 赋予这个商品的小计
        this.concessionalRate = this.TwopointsValue(
          Calc.times(this.opendata.num, unitPrice)
        )
      }
      if (this.useIndex === 1) {
        this.Orderdiscount_rate = res
        if (res == 10) {
          res = 11
        } else {
          this.clearALL = false
        }
        // 算出优惠金额  实收 * 折率
        this.paidRate = Twopoints(
          Calc.times(
            Number(this.order.statistics.paid_price),
            Calc.divide(res, 10)
          )
        )
      }
    },
    clearEdlog(res) {
      this.logData.show = res
    },
    setPage(res) {
      /**
       * 由分页组件 paging 传递过来的参数，指挥上下翻页
       *  @param {String} res 标识  next ： 上一页  upper ： 下一页
       */
      if (res === 'next') this.disscountReq.page--
      else this.disscountReq.page++
      this.getResonList(true)
    },
    setReason(item, idx) {
      this.reasonIndex = idx
      this.reason = item.reason
    },
    okDiscount() {
      /**
       * 回传给父组件参数,下面是回传信息
       * @param {String} discount_rate 折率
       * @param {String} discount_reason 优惠原因
       * @param {String} is_discount 对线上优惠罚值
       */
      if (this.useIndex === 0) {
        let obj = {
          discountPrice: parseInt(Calc.times(this.concessionalRate, 100)),
          discount_reason: this.reasonList.list[this.reasonIndex].reason,
          is_discount: 1,
          discount_rate: this.discount_rate,
          typeKey: 1
        }
        this.$emit('setDiscount', obj)
      } else {
        let allObj = {
          discountPrice: this.TwopointsValue(this.paidRate),
          typeKey: 0,
          discount_rate: this.Orderdiscount_rate
        }
        this.$emit('setDiscount', allObj)
      }
    },
    setIndex(index) {
      if (index === 1 && this.opendata.refund_price) {
        this.$notify({
          title: '错误',
          message: '当前商品是退菜商品，暂不支持该操作',
          type: 'warning'
        })
        return
      }
      // this.discount_rate = 0
      this.useIndex = index
    },
    swiperFalse() {
      this.$emit('swiperFalse', false)
    }
  },
  mounted() {
    this.opendata = JSON.parse(JSON.stringify(this.list))
    this.paidRate = Calc.minus(
      Number(this.order.statistics.total_price),
      Calc.minus(
        Number(this.order.statistics.total_price),
        Number(this.order.statistics.paid_price)
      )
    )
    this.getResonList(true)
    if (!this.opendata.refund_price) {
      // 如果之前有优惠需要先算出来
      if (this.opendata.discount_rate) {
        this.concessionalRate = this.TwopointsValue(
          Calc.minus(this.opendata.price, this.opendata.discount_amount)
        )
      }
      //判断索引
      if (this.opendata.discount_rate === '0') this.funtionIndex = 1
      else if (this.opendata.discount_rate && this.opendata.discount_rate != 10)
        this.funtionIndex = 2
    } else {
      this.useIndex = 1
    }
    console.log(this.order.discount_rate, this.order.discount_rate != 10)
    if (this.order.discount_rate && this.order.discount_rate != 10)
      this.discountSwitch = true
    console.log(this.discountSwitch, 'kaiguan')
  }
}
</script>
<style lang='less' scoped>
@import url('./modularShop.less');
</style>
<style lang='less'>
.reason {
  .el-textarea {
    width: 242px !important;
    height: 78px !important;
    display: block;
    margin: 18px auto 14px auto;
    textarea {
      width: 100% !important;
      height: 100% !important;
    }
  }
}
</style>
