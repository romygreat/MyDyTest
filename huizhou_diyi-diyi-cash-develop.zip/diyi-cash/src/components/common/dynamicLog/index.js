/*
 * @Author: 叶锦荣
 * @Date: 2019-10-25 18:00:17
 * @LastEditTime: 2019-10-25 18:24:20
 */
import dynamicLog from './dynamicLog.vue'
export default dynamicLog