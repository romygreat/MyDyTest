<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-25 17:59:57
 * @LastEditTime: 2019-11-30 12:03:50
 -->
<template>
  <el-dialog
    title="提示"
    :visible.sync="show"
    width="30%"
    custom-class="dynamicLog"
    :before-close="handleClose"
  >
    <hgroup class="header">
      <h3>{{list.name}}</h3>
      <div>
        <div class="price">
          <span>单价：{{TwopointsValue()}}</span>
        </div>
        <div v-if="list.is_editable != 1" class="num">
          <span>份数：</span>
          <el-input-number :min="0.01" :controls="false" v-model="list.num" label="请输入份数">
          </el-input-number>
        </div>
      </div>
    </hgroup>
    <section class="main">
      <div class="title">{{menuType}}</div>
    </section>
    <div class="open">
      <div v-if="list.is_current == 1">
        <el-input
          type="number"
          min="0.01"
          :controls="false"
          v-model="resInfo.timePrcie"
          @input="finalInput(1)"
          label="请输入商品当前时价"
        >
        <template slot="prepend">菜品价格：</template>
        </el-input>
      </div>
      <div v-if="list.is_editable == 1">
        <el-input type="number" @input="finalInput(2)" :controls="false" v-model="resInfo.weight" label="请输入商品的重量" >
          <template slot="prepend">重 量：</template>
        </el-input>
      </div>
      <!-- 时价总价 -->
      <div class="price" v-if="showTotalPrice==1">
        <span style="width:40px">总 价:</span>
        <span style="color:#FE7622;">￥ {{getTotalPriceForTimePrice(resInfo.timePrcie,list.num)}}</span>
      </div>
      <!-- 时价称重 -->
      <div class="price" v-if="showTotalPrice==2">
        <span style="width:40px">总 价:</span>
        <span style="color:#FE7622;">￥ {{getTotalPriceForTimeAndWeightPrice(resInfo)}}</span>
      </div>
    </div>

    <div class="footer">
      <div @click="handleClose">取消</div>
      <div @click="setDynamic">确认</div>
    </div>
  </el-dialog>
</template>
<script>
import Calc from 'number-precision'
import { transformRMB, Twopoints } from '@/libs/util'
export default {
  props: ['dynamicShow', 'openList'],
  data() {
    return {
      show: false,
      list: {},
      resInfo: {
        type: 0,
        timePrcie: 0,
        weight: 0
      },
      menuType: '',
      showTotalPrice: 0
    }
  },
  methods: {
    handleClose() {
      this.$emit('toDynamic', this.resInfo)
    },
    TwopointsValue() {
      this.list.price = Number(this.list.price)
      return Twopoints(
        Calc.divide(Calc.divide(this.list.price, this.openList.num), 100)
      )
    },
    setDynamic() {
      // 拦截没有填的，身为0的价格
      if (
        (this.resInfo.timePrcie == 0 && this.list.is_current == 1) ||
        (this.resInfo.weight == 0 && this.list.is_editable == 1)
      ) {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '参数填写错误，请核对参数'
        })
        return
      }
      this.resInfo.type = 1
      this.resInfo.timePrcie = Calc.times(this.resInfo.timePrcie, 100)
      this.$emit('toDynamic', this.resInfo)
    },
    getTotalPriceForTimeAndWeightPrice(resInfo) {
      // this.resInfo.timePrcie = this.resInfo.timePrcie.replaceAll('^(0+)', '')
      return Twopoints(Calc.times(resInfo.weight, resInfo.timePrcie))
    },
    getTotalPriceForTimePrice(price, num) {
      return Twopoints(Calc.times(price, num))
    },
    finalInput(type) {
      const regex = /^[0]+/
      if (type == 1) {
        if (this.resInfo.timePrcie < 1) {
          this.resInfo.timePrcie = this.resInfo.timePrcie.replace(regex, '0')
        } else {
          this.resInfo.timePrcie = this.resInfo.timePrcie.replace(regex, '')
        }
      }
      if (type==2) {
        if (this.resInfo.weight < 1) {
          this.resInfo.weight = this.resInfo.weight.replace(regex, '0')
        } else {
          this.resInfo.weight = this.resInfo.weight.replace(regex, '')
        }
      }
    }
  },
  mounted() {
    this.show = this.dynamicShow
    this.list = JSON.parse(JSON.stringify(this.openList))
    // 判断菜品类型
    if (this.list.is_editable == 1 && this.list.is_current == 1) {
      this.menuType = '时价称重菜'
      this.showTotalPrice = 2
    }

    if (this.list.is_editable == 1 && this.list.is_current != 1) {
      this.menuType = '称重菜'
      this.showTotalPrice = 0
    }

    if (this.list.is_editable != 1 && this.list.is_current == 1) {
      this.menuType = '时价菜'
      this.showTotalPrice = 1
    }
  }
}
</script>
<style lang="less" scoped>
@import url('./dynamicLog.less');
</style>
<style lang="less" >
.dynamicLog {
  width: 584px !important;
  height: 509px !important;
  position: relative;
  .el-dialog__header {
    display: none;
  }
  .el-dialog__body {
    padding: 22px 46px 28px 46px;
  }
  .num {
    .el-input-number {
      width: 90px;
      height: 30px;
      .el-input {
        height: 100%;
        input {
          height: 100%;
        }
      }
    }
  }
  .open {
    .el-input-number {
      width: 422px;
      text-align: left;
    }
    .el-input__inner {
      text-align: left;
    }
  }
}

input[type='number'] {
  -moz-appearance: textfield;
}
input[type='number']::-webkit-inner-spin-button,
input[type='number']::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
.el-input-group__prepend{
  width: 66px !important;
  background-color: #fff !important;
  border: none !important;
}
</style>