<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-22 08:45:27
 * @LastEditTime : 2019-12-27 11:56:44
 -->
<template>
  <div class="menulist">
    <!-- 菜品分类 -->
    <header>
      <ul>
        <li
          v-for="(item, index) in shopCate.list"
          :key="index"
          @click="setSubareaId(item.id)"
          :class="rescateProduct.cate_id==item.id?'use':''"
        >
          {{item.name}}
          <span v-if="item.selectNumber !== 0 && !isdefectProduct">{{item.selectNumber}}</span>
        </li>
      </ul>
      <topPaging
        class="menu-paing-btn"
        top="56"
        right="3"
        :row="resShopCate.rows"
        :page="resShopCate.page"
        :total="shopCate.total"
        v-on:setTopPage="setTopPage($event)"
      />
    </header>
    <!-- 菜品列表 -->
    <section class="list">
      <dl @click="temporaryShow = true">
        <dt>临时菜</dt>
        <dd>￥ 0.00</dd>
      </dl>
      <dl @click="addmenu(item,index)" v-for="(item, index) in arrCate.list" :key="index">
        <span class="tips1" v-if="item.is_editable==1">称</span>
        <span class="tips2" v-if="item.is_current==1">时</span>
        <dt>{{item.name}}</dt>
        <dd>￥{{transformMoney(item.price)}}</dd>
        <p class="product-code" v-if="item.code!=0">{{item.code}}</p>
        <p v-if="item.is_limit == 0">在售</p>
        <p v-if="item.is_limit === 1 && item.limit_num !== 0">剩 {{item.limit_num}} {{item.unit}}</p>
        <p v-if="item.is_limit === 1 && item.limit_num == 0">已售罄</p>
        <img v-if="item.is_limit === 1 && item.limit_num == 0" :src="yishouqing" alt srcset />
        <div v-if="item.selectNumber !== 0&& !isdefectProduct" class="shopNumber">{{item.selectNumber}}</div>
      </dl>
      <figure>
        <Paging
          v-on:setPage="setPage($event)"
          :rows="rescateProduct.rows"
          :total="arrCate.total"
          :page="rescateProduct.page"
          :whparpam="50"
        />
      </figure>
      <transition name="keyboard">
        <keyboard
          class="menu-keyboard"
          @sendInput="getInput"
          v-if="isKeyboardShow"
          :inputItem="rescateProduct.search"
        />
      </transition>
    </section>
    <!-- 按钮 -->
    <footer class="menulistFooter clear">
      <div :class="isdefectProduct ? 'isDefect' : ''" id="menu-input">
        <el-input
          :maxlength="40"
          placeholder="输入菜品名称首字母或菜品编码查询"
          @focus="getSystem()"
          :readonly="isReadonly"
          clearable
          v-model="rescateProduct.search"
        >
          <template slot="prepend">
            <img :src="search" />
          </template>
          <template slot="append">
            <img :src="key" />
          </template>
        </el-input>
      </div>
      <el-popover
        v-if="!isdefectProduct"
        placement="top"
        popper-class="print-btn"
        width="90"
        trigger="click"
      >
        <el-button
          :class="!useOrder.id ? 'nouse' : ''"
          :disabled="!useOrder.id ? true : false"
          @click="agrinToPtinter(1)"
        >预结单</el-button>
        <el-button
          :class="!useOrder.id ? 'nouse' : ''"
          :disabled="!useOrder.id ? true : false"
          @click="agrinToPtinter(3)"
        >传菜单</el-button>
        <el-button
          :class="useOrder.order_refund ? 'nouse' : ''"
          :disabled="!useOrder.order_refund ? true : false"
          @click="agrinToPtinter(5)"
        >退菜单</el-button>
        <el-button
          :class="!useOrder.id ? 'nouse' : ''"
          @click="agrinToPtinter(7)"
          :disabled="!useOrder.id ? true : false"
        >制作单</el-button>
        <el-button slot="reference" class="print-button">
          <img :src="print" />
          <p>打印明细</p>
        </el-button>
      </el-popover>

      <el-button v-if="!isdefectProduct" @click="toRevokeShow()" class="print-button">
        <img :src="revoke" />
        <p>撤 单</p>
      </el-button>
    </footer>
    <el-dialog title="撤单提醒" custom-class="del-dialog" center :visible.sync="revokeShow" width="20%">
      <p>
        此操作将撤销当前订单，
        <span style="color:#FE7622;font-weight: bold;">并需手动将该点餐平板进行清台操作！</span>
      </p>
      <p>确认是否撤单?</p>
      <!-- <el-radio-group v-model="radio">
        <el-radio :label="3">备选项</el-radio>
        <el-radio :label="6">备选项</el-radio>
        <el-radio :label="9">备选项</el-radio>
      </!--> -->
      <span slot="footer" class="dialog-footer">
        <el-button @click="revokeShow = false">取 消</el-button>
        <el-button type="primary" @click="toRevoke()">撤 单</el-button>
      </span>
    </el-dialog>
    <!-- 带参数的商品选择 -->
    <el-dialog
      title="选择参数"
      :visible.sync="layerShow"
      custom-class="layerDiaLog"
      id="layerDiaLog"
      width="30%"
      :before-close="layerClear"
    >
      <hgroup class="layerHeader">
        <h3>{{layerData.name}}</h3>
        <div>
          <p v-if="layerData.spec || layerData.contorno || layerData.taste || layerData.procedure">
            已选：
            <span v-if="layerData.spec">{{ Object.values(this.isSelcectSpectitle).join(',')}}</span>
            <span v-if="layerData.procedure">{{procedure.name}}</span>
            <span v-if="layerData.contorno && sideList.name.length">{{sideList.name.join(',')}}</span>
            <span v-if="layerData.taste">{{taste.name}}</span>
          </p>
        </div>
        <span>￥{{transformMoney((Number(sideList.price == '' ? 0 : sideList.price) + Number(procedure.proces_price == '' ? 0 : procedure.proces_price ) + Number(layerAllPrice)))}}</span>
      </hgroup>
      <dl class="productSpec-spec" v-for="(item,index) in layerData.spec" :key="index">
        <dt>{{item.name}}</dt>
        <dd :key="indexj" v-for="(itemj,indexj) in layerData.spec[index].spec_val">
          <div
            :class="UseProductSpec[index] == indexj ? 'productSpecSpecUse' : ''"
            @click="selectSpec(item,index,itemj,indexj)"
          >
            {{itemj.spec_val}}
            <img :src="gouhao2" />
          </div>
        </dd>
      </dl>
      <dl v-if="layerData.contorno" class="productSpec-side_dish">
        <dt>加配菜</dt>
        <div>
          <dd
            :class="sideList.use.indexOf(index) > -1 ? 'use' : ''"
            @click="selectSide(item,index)"
            v-for="(item,index) in layerData.contorno"
            :key="index"
          >
            {{item.name}}
            <img :src="gouhao2" />
          </dd>
        </div>
      </dl>
      <dl v-if="layerData.taste" class="productSpec-side_dish">
        <dt>口味</dt>
        <div>
          <dd
            :class="taste.userIdx == index ? 'use' : ''"
            @click="setTaste(item,index)"
            v-for="(item,index) in layerData.taste"
            :key="index"
          >
            {{item.name}}
            <img :src="gouhao2" />
          </dd>
        </div>
      </dl>
      <dl v-if="layerData.procedure" class="productSpec-side_dish">
        <dt>做法</dt>
        <div>
          <dd
            :class="procedure.userIdx == index ? 'use' : ''"
            @click="setProcedure(item,index)"
            v-for="(item,index) in layerData.procedure"
            :key="index"
          >
            {{item.name}}
            <img :src="gouhao2" />
          </dd>
        </div>
      </dl>
      <div class="layerData-footer">
        <div @click="layerClear()">取消</div>
        <div @click="addLayerShop()">确认</div>
      </div>
    </el-dialog>
    <writeTemporary
      v-on:toTemporary="toTemporary($event)"
      v-if="temporaryShow"
      :show="temporaryShow"
    />
  </div>
</template>
<script>
import { replacementOrder, printerList } from '@/api/printer'
import { getStautsText } from '@/libs/util'
import { cateProduct, shopCate, revokeOrder } from '@/api/menu'
import { printingOrder } from '@/api/order'
import Paging from '_c/common/paging'
import { transformRMB } from '@/libs/util'
import Calc from 'number-precision'
import keyboard from '_c/common/keyboard'
import gouhao2 from '@/assets/img/gou2.png'
import search from '@/assets/img/search@2x.png'
import key from '@/assets/img/key.png'
import print from '@/assets/img/print.png'
import revoke from '@/assets/img/revoke.png'
import topPaging from '_c/common/topPaging'
import writeTemporary from '_c/common/writeTemporary'
import yishouqing from '@/assets/img/yishouqing.png'
import { log } from 'util'
import { stringify } from 'querystring'
export default {
  props: ['defectProduct'],
  components: { Paging, keyboard, topPaging, writeTemporary },
  data() {
    return {
      yishouqing,
      gouhao2,
      search,
      key,
      print,
      revoke,
      isdefectProduct: false,
      list: [],
      order: {
        id: '',
        remark: '',
        statistics: {
          paid_price: 0
        },
        order_no: ''
      },
      resShopCate: {
        rows: 8,
        page: 1,
        sort: {
          sort: 'asc'
        }
      },
      rescateProduct: {
        cate_id: '',
        page: 1,
        rows: 23,
        search: '',
        sort: {
          sort: 'desc'
        }
      },
      shopCate: {
        list: [],
        total: 0
      },
      arrCate: {
        list: [],
        total: 0
      },
      keyShow: false,
      layerData: {},
      layerShow: false,
      // 配菜
      sideList: {
        use: [],
        price: 0,
        name: [],
        indexj: [],
        dish_id: []
      },
      // 做法
      procedure: {
        id: '',
        proces_price: '',
        name: '',
        userIdx: '',
        procedure_id: ''
      },
      // 口味
      taste: {
        userIdx: '',
        name: '',
        remark_id: '',
        id: ''
      },
      // 规格
      UseProductSpec: {},
      isSelcectSpectitle: {},
      acitiveProductSpec: {},
      layerAllPrice: 0,
      snackMenu: [],
      temporaryShow: false,
      printBtn: ['前台', '后厨'],
      revokeShow: false,
      isReadonly: false,
      showPage: true,
      isKeyLimit: 0,
      DiscountPriceOrder: 0
    }
  },
  methods: {
    async shopCateTitle() {
      await shopCate(this.resShopCate).then(res => {
        /**
         *  获取菜单分类列表
         *  @param {Aarry} list 分类列表
         *  @param {Number} total 总数
         *  @param {Object} shopCate 存放位置
         */
        let headerd = { id: '', name: '全部' }
        this.shopCate.list = [headerd, ...res.data.data.list]
        this.shopCate.list.forEach((el, idx) => {
          this.$set(this.shopCate.list[idx], 'selectNumber', 0)
        })
        this.shopCate.total = res.data.data.total
        console.log(this.shopCate.total);
        
      })
    },
    async cateProductList(type) {
      /**
       * 获取菜单菜品分类
       * @param {String} type 传进来的参数，用于刷新菜单列表
       * @param {Aarry} list 商品列表
       * @param {Number} total 总数
       * @param {Object} arrCate 存放位置
       */
      if (type) {
        this.rescateProduct.page = 1
      }
      await cateProduct(this.rescateProduct).then(res => {
        this.arrCate = res.data.data
        this.arrCate.list.forEach((el, idx) => {
          this.$set(this.arrCate.list[idx], 'selectNumber', 0)
        })
        this.matchingCart()
        if (
          this.rescateProduct.rows * this.rescateProduct.page >
          this.shopCate.total
        ) {
          if (this.rescateProduct.page > 1) {
            this.showPaing = true
          } else {
            this.showPaing = false
          }
        } else {
          this.showPaing = true
        }
      })
    },
    setPage(res) {
      /**
       * 由分页组件 paging 传递过来的参数，指挥上下翻页
       *  @param {String} res 标识  next ： 上一页  upper ： 下一页
       */
      if (res === 'next') this.rescateProduct.page--
      else this.rescateProduct.page++
      this.cateProductList()
      this.matchingCart()
    },
    sendInput(res) {
      /**
       * 获取键盘组件回调
       */
      this.rescateProduct.search = res.value
    },
    addmenu(item, index) {
      // 估清组件回弹
      if (this.$router.currentRoute.name === 'defectProduct') {
        this.$emit('setDefect', item)
        return
      }
      /**
       * 商品添加
       * @param {Object} item  商品
       * @param {Number} index 商品索引
       */

      //  初始化
      let cart = {}
      // 防止线上支付操作菜品
      // if (this.useOrder.status == 1) {
      //   this.$notify({
      //     title: '错误',
      //     message: '当前订单为线上支付，暂不能操作该订单',
      //     type: 'warning'
      //   })
      //   return
      // }
      // 确认是否为沽清商品 || 且判断沽清值是否为零
      if (item.is_limit === 1 && item.limit_num == 0) {
        this.$notify({
          title: '抱歉',
          message: '该商品已经售磬，无法添加进购物车',
          type: 'warning'
        })
        return
      }
      // 区分商品类别，做法 ：口味 ： 规格 : 配菜
      if (item.group || item.contorno || item.procedure || item.taste) {
        item.cplimit_num = JSON.parse(JSON.stringify(item.limit_num))
        item.isCheck = []
        this.layerData = JSON.parse(JSON.stringify(item))
        //  有规格的时候
        if (item.group) {
          this.selectSpec(item, '', '', '', true)
        } else {
          this.layerAllPrice = item.price
        }
        // 有口味的时候
        if (item.taste) this.setTaste('', '', true)
        // 有做法的时候
        if (item.procedure) this.setProcedure('', '', true)
        this.layerShow = true
      } else {
        // 查找购物车是否已经有这个商品
        let idx = -1
        for (let i in this.list) {
          if (
            this.list[i].switch == false &&
            this.list[i].product_id == item.id
          ) {
            idx = i
          }
        }
        // 临时菜默认不存在
        if (item.temporary == 1) {
          idx = -1
        }
        // 没有这个商品，即添加到购物车
        if (idx === -1) {
          cart = {
            cate_id: item.cate_id,
            shop_id: item.shop_id,
            name: item.name,
            market_price: item.market_price,
            num: 1,
            product_code: item.code,
            product_id: item.id,
            reduce_money: 0,
            switch: false,
            is_limit: item.is_limit,
            unit_price: item.price,
            paramePrice: item.price,
            cplimit_num: item.limit_num,
            unit: item.unit,
            limit_num: item.limit_num,
            istype: [],
            is_pack: false,
            type: '',
            pic: item.pic,
            is_editable: item.is_editable == 1 ? item.is_editable : 0,
            is_current: item.is_current == 1 ? item.is_current : 0,
            is_exists_edit: 0,
            is_exists_current: 0,
            append:0
          }
          if (item.isSnack) {
            cart.isSnack = item.isSnack
          }
          if (item.temporary == 1) {
            cart.temporary = 1
            cart.num = item.num
            this.order.id ?  item.append = 1 :  item.append = 0
          }
          cart.price = Calc.times(item.price, cart.num)
          if(this.order.id) {
            cart.append = 1
          }
          this.list.push(cart)
          this.$store.commit('setTheWorld', true)
        } else {
          // 如果沽清，且数量大于沽清数量，则拦截
          if (
            this.list[idx].is_limit == 1 &&
            this.list[idx].num >= item.limit_num
          ) {
            this.$notify({
              title: '抱歉',
              message: '该商品已经售罄，暂时无法添加',
              type: 'warning'
            })
            return
          }
          //购物车有这个商品 num + 1
          let newsNum = Number(this.list[idx].num) + 1
          // 商品单价更新
          let newsPrice = Calc.times(
            Number(this.list[idx].paramePrice),
            newsNum
          )
          // 如果有优惠
          if (this.list[idx].discount_amount) {
            let newsDisprice = this.list[idx].discount_amount
            let nesDis = Calc.times(
              Calc.divide(newsDisprice, newsNum - 1),
              newsNum
            )
            this.$set(this.list[idx], 'discount_amount', nesDis)
          }
          // 同步数量 ， 同步商品小计
          this.$set(this.list[idx], 'num', newsNum)
          this.$set(this.list[idx], 'price', newsPrice)
        }
        this.$store.commit('setCartList', this.list)
        this.matchingCart()
      }
    },
    selectSide(item, index) {
      /**
       *  选择配菜，拼接配菜
       *  @param {Object} sideList 配菜对象
       *  @param {Array} sideList.use 选择索引
       *  @param {String} sideList.price 所选配菜总价
       *  @param {Array} sidelist.indexj ID
       *  @param {Array} sideList.dish_id 配菜ID
       *  @param {Array} sidelist.name 配菜名称集合
       */
      if (this.sideList.use.indexOf(index) === -1) {
        this.sideList.use.push(index)
        this.sideList.price = Calc.plus(this.sideList.price, item.price)
        this.sideList.name.push(item.name)
        this.sideList.indexj.push(item.id)
        this.sideList.dish_id.push(item.dish_id)
      } else {
        let idx = this.sideList.use.indexOf(index)
        this.sideList.price = Calc.minus(this.sideList.price, item.price)
        this.sideList.name.splice(idx, 1)
        this.sideList.indexj.splice(idx, 1)
        this.sideList.dish_id.splice(idx, 1)
        this.sideList.use.splice(idx, 1)
      }
    },
    setProcedure(item, index, type) {
      /**
       *  选举做法 && 拼接做法
       *  @param {Object} procedure 做法对象
       *  @param {String} procedure.id 选择id
       *  @param {String}procedure.userIdx 所选做法索引
       *  @param {String} procedure.proces_price 所选做法总价
       *  @param {String} procedure.procedure_id ID
       */
      if (type) {
        this.layerData.procedure.forEach((el, idx) => {
          if (idx == 0) {
            this.$set(this.procedure, 'name', el.name)
            this.$set(this.procedure, 'userIdx', 0)
            this.$set(this.procedure, 'procedure_id', el.procedure_id)
            this.$set(this.procedure, 'proces_price', el.proces_price)
            this.$set(this.procedure, 'id', el.id)
          }
        })
      } else {
        this.$set(this.procedure, 'userIdx', index)
        this.$set(this.procedure, 'name', item.name)
        this.$set(this.procedure, 'procedure_id', item.procedure_id)
        this.$set(this.procedure, 'proces_price', item.proces_price)
        this.$set(this.procedure, 'id', item.id)
      }
    },
    setTaste(item, index, type) {
      /**
       * 口味选择
       *  @param taste 口味对象
       *  @param taste.remark_id 所选口味ID
       *  @param taste.userIdx 所选口味索引
       *  @param taste.id id
       *  @param taste.name 所选口味名称
       */
      if (type) {
        this.layerData.taste.forEach((el, idx) => {
          if (idx == 0) {
            this.$set(this.taste, 'remark_id', el.remark_id)
            this.$set(this.taste, 'name', el.name)
            this.$set(this.taste, 'userIdx', 0)
            this.$set(this.taste, 'id', el.id)
          }
        })
      } else {
        this.$set(this.taste, 'name', item.name)
        this.$set(this.taste, 'userIdx', index)
        this.$set(this.taste, 'remark_id', item.remark_id)
        this.$set(this.taste, 'id', item.id)
      }
    },
    selectSpec(item, index, itemj, indexj, type) {
      /**
       *  规格选择
       *  @param layerData 影响商品价格选择数据
       *  @param acitiveProductSpec 从组合筛选出来的方法
       *  @param UseProductSpec  选择标记
       *  @param isSelcectSpectitle 筛选条件
       *
       */
      if (type) {
        this.layerData.spec.forEach((el, idx) => {
          this.$set(this.UseProductSpec, idx, 0)
          this.$set(this.isSelcectSpectitle, idx, el.spec_val[0].spec_val)
        })
      } else {
        this.$set(this.UseProductSpec, index, indexj)
        this.$set(this.isSelcectSpectitle, index, itemj.spec_val)
      }
      let arrinxex = this.layerData.group.filter(element => {
        return (
          element.group_title ==
          Object.values(this.isSelcectSpectitle).join('-')
        )
      })
      //  方便赋值，筛选数组变对象
      arrinxex.forEach(el => {
        this.acitiveProductSpec = el
      })
      this.acitiveProductSpec.indexjarr = this.UseProductSpec
      this.layerAllPrice = this.acitiveProductSpec.group_price
    },
    transformMoney(value) {
      return transformRMB(Number(value))
    },
    layerClear() {
      /**
       * 重置layer商品弹出框参数
       */
      this.layerData = {}
      this.layerShow = false
      this.acitiveProductSpec = {}
      this.isSelcectSpectitle = {}
      this.$set(this.sideList, 'use', [])
      this.$set(this.sideList, 'price', 0)
      this.$set(this.sideList, 'name', [])
      this.$set(this.sideList, 'indexj', [])
      this.$set(this.sideList, 'dish_id', [])
      this.$set(this.taste, 'userIdx', '')
      this.$set(this.taste, 'test', '')
      this.$set(this.taste, 'remark_id', '')
      this.$set(this.taste, 'id', '')
      this.$set(this.procedure, 'id', '')
      this.$set(this.procedure, 'proces_price', '')
      this.$set(this.procedure, 'test', '')
      this.$set(this.procedure, 'userIdx', '')
      this.$set(this.procedure, 'procedure_id', '')
    },
    addLayerShop() {
      /**
       *  layer进入购物车
       */
      let cart = {
        append:0,
        cate_id: this.layerData.cate_id,
        is_pack: false,
        shop_id: this.layerData.id,
        name: this.layerData.name,
        market_price: this.layerData.market_price,
        num: 1,
        product_code: this.layerData.code,
        product_id: this.layerData.id,
        reduce_money: 0,
        switch: false,
        contornoArr: this.layerData.contorno,
        procedureArr: this.layerData.procedure,
        tasteArr: this.layerData.taste,
        is_limit: this.layerData.is_limit,
        unit_price: this.layerData.price,
        cplimit_num: this.layerData.limit_num,
        unit: this.layerData.unit,
        limit_num: this.layerData.limit_num,
        istype: [],
        type: '',
        price: 0,
        pic: this.layerData.pic,
        is_editable:
          this.layerData.is_editable == 1 ? this.layerData.is_editable : 0,
        is_current:
          this.layerData.is_current == 1 ? this.layerData.is_current : 0,
        is_exists_edit: 0,
        is_exists_current: 0
      }
      // 创建密钥(验证组合)
      let isCheck = []
      cart.price = 0
      if (this.layerData.group) {
        cart.group = JSON.parse(JSON.stringify(this.acitiveProductSpec))
        if (cart.group) {
          cart.price = Calc.plus(cart.price, Number(cart.group.group_price))
        } else {
          cart.price = Calc.plus(cart.price, Number(this.acitiveProductSpec))
        }
        isCheck.push(this.acitiveProductSpec.id)
        cart.spec = this.layerData.spec
        cart.groupArr = this.layerData.group
      } else {
        cart.price = Calc.plus(cart.price, Number(this.layerData.price))
      }
      if (this.layerData.procedure) {
        cart.procedure = JSON.parse(JSON.stringify(this.procedure))
        cart.price = Calc.plus(cart.price, Number(this.procedure.proces_price))
        isCheck.push(this.procedure.procedure_id)
      }
      if (this.sideList.indexj.length) {
        cart.price = Calc.plus(cart.price, Number(this.sideList.price))
        cart.contorno = {
          contorno_id: '',
          contorno_name: '',
          contorno_price: '',
          id: ''
        }
        cart.contorno.id = JSON.parse(
          JSON.stringify(this.sideList.indexj.join(','))
        )
        cart.contorno.contorno_id = JSON.parse(
          JSON.stringify(this.sideList.indexj.join(','))
        )
        cart.contorno.contorno_name = JSON.parse(
          JSON.stringify(this.sideList.name.join(','))
        )
        cart.contorno.contorno_price = JSON.parse(
          JSON.stringify(this.sideList.price)
        )
        isCheck.push(this.sideList.dish_id.join(','))
        cart.contorno_ids = cart.contorno.id
      }
      if (this.layerData.taste) {
        cart.taste = JSON.parse(JSON.stringify(this.taste))
        isCheck.push(this.taste.remark_id)
      }
      // 计算小计
      cart.paramePrice = JSON.parse(JSON.stringify(cart.price))
      cart.price = Calc.times(Number(cart.price), Number(cart.num))
      // this.layerAllPrice = JSON.parse(JSON.stringify(cart.price))
      cart.isCheck = isCheck
      // 既有ID，开始匹配密钥
      let idx = ''
      //  isKeyLimit 【沽清总数，针对规格配菜多ID情况】
      this.isKeyLimit = 0
      let isKeyLimitOff = false
      this.list.forEach((el, idxs) => {
        if (el.product_id === cart.product_id) {
          this.isKeyLimit = Calc.plus(this.isKeyLimit, el.num)
          // 如果是沽清商品，则开始计算沽清
          if (el.is_limit === 1) {
            if (this.isKeyLimit >= this.layerData.limit_num) {
              isKeyLimitOff = true
            }
          }
          if (
            (el.switch == false || el.switch == undefined) &&
            el.isCheck &&
            el.isCheck.join('-') == cart.isCheck.join('-')
          ) {
            idx = idxs
          }
        }
      })
      // 捕获到沽清拦截
      if (isKeyLimitOff) {
        this.$notify({
          title: '抱歉',
          message: '该商品已经售罄，暂时无法添加',
          type: 'warning'
        })
        return
      }
      // 获得密钥索引
      if (idx === '') {
          if(this.order.id) {
            cart.append = 1
          }
        this.list.push(cart)
        this.$store.commit('setTheWorld', true)
      } else {
        let self = this.list[idx]
        let newNum = Calc.plus(Number(self.num), 1)
        this.$set(self, 'num', newNum)
        this.$set(self, 'price', Calc.times(Number(self.paramePrice), newNum))
        if (self.discount_amount) {
          let nesDis = Calc.times(
            Calc.divide(self.discount_amount, newNum - 1),
            newNum
          )
          this.$set(self, 'discount_amount', nesDis)
        }
      }
      this.$store.commit('setCartList', this.list)
      this.layerShow = false
      this.layerClear()
      this.matchingCart()
    },
    getInput(item) {
      this.rescateProduct.search = item.value
    },
    /**
     * @description 撤单
     */
    toRevokeShow() {
      // 防止线上支付操作菜品
      if (this.useOrder.status == 1) {
        this.$notify({
          title: '错误',
          message: '当前订单为线上支付，暂不能操作该订单',
          type: 'warning'
        })
        return
      }
      this.revokeShow = true
    },
    toRevoke() {
      if (this.useOrder.status == 1) {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '该订单已经支付,无法撤单'
        })
        return
      }
      if (!this.useOrder.order_no) {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '当前没有下单,无法撤单'
        })
        return
      }
      revokeOrder({ id: this.useOrder.id }).then(res => {
        if (res.data.code === 1) {
          this.$notify({
            type: 'success',
            title: '成功',
            message: `已经成功撤单`
          })
          this.$router.push({ name: 'home' })
        } else {
          this.$notify({
            type: 'warning',
            title: '错误',
            message: '撤单失败,请联系管理元'
          })
        }
      })
    },
    /**
     * @description 获得小吃
     */
    setSnackMenu() {
      this.snackMenu = JSON.parse(
        sessionStorage.getItem('adminInfo')
      ).shop.product_bind
      for (let i = 0; i < this.snackMenu.length; i++) {
        this.snackMenu[i].isSnack = true
      }
      // 如果存在小吃项目
      if (
        this.snackMenu.length &&
        (this.useOrder.order_no == '' || !this.useOrder.order_no)
      ) {
        this.snackMenu.forEach((item, idx) => {
          if (this.$router.currentRoute.name != 'defectProduct')
            this.addmenu(item, idx)
        })
      }
    },
    /**
     * @description  写入临时菜
     */
    toTemporary(res) {
      if (res == false) this.temporaryShow = false
      else {
        this.addmenu(res)
        this.temporaryShow = false
      }
    },
    async setTopPage(res) {
      if (res === 'next') this.resShopCate.page--
      else this.resShopCate.page++
      this.shopCateTitle()
      // 切换菜单的时候刷新回全部的菜单列表
      await this.setSubareaId(this.shopCate.list[0].id)
      this.matchingCart()
    },
    setSubareaId(v) {
      if (v || v != '') {
        this.rescateProduct.cate_id = v
        this.rescateProduct.page = 1
      } else {
        this.rescateProduct = {
          cate_id: '',
          page: 1,
          rows: 23,
          search: ''
        }
      }
      this.cateProductList()
    },
    getSystem() {
      let version = navigator.userAgent.toLocaleLowerCase()
      let isWin = version.indexOf('windows') > -1 ? true : false
      if (isWin) {
        this.isReadonly = false
      } else {
        this.isReadonly = true
      }
    },
    /**
     * @desciption 主动打印
     */
    async agrinToPtinter(key) {
      // 如果是退菜单
      if (key == 5 && !this.useOrder.order_refund) {
        this.$notify.error({
          title: '出错',
          message: '当前没有退菜，暂不能打印出退菜单'
        })
        return
      }

      const data = {
        type: key,
        id: this.order.id
      }
      if (window.android) {
        let sulf = await replacementOrder(data)
        if (sulf.data.code == 1) {
          let numberPrcie = 0
          sulf.data.data.order_list.forEach(jl => {
            numberPrcie = Calc.plus(jl.discount_amount, numberPrcie)
          })
          sulf.data.data.discount_amountInfo = Calc.plus(
            numberPrcie,
            sulf.data.data.discount_amount
          )
          // sulf.data.data.printer.forEach((el, idx) => {
          window.android.printOneOrder(0, JSON.stringify(sulf.data.data))
          // })
          this.$notify({
            type: 'success',
            title: '成功',
            message: `已经成功打印，请稍等`
          })
        } else {
          this.$notify.error({
            title: '出错',
            message: sulf.data.message
          })
        }
      }
    },
    /**
     * @desciption 匹配数量
     */
    matchingCart() {
      let arr = []
      if (this.useOrder.id) {
        arr = [...this.list, ...this.useOrder.order_list.list]
      } else {
        if (this.list.length) {
          arr = JSON.parse(JSON.stringify(this.list))
        }
      }
      // 先行计算当前商品匹配
      this.arrCate.list.forEach((el, index) => {
        this.$set(this.arrCate.list[index], 'selectNumber', 0)
      })
      arr.forEach((jl, idx) => {
        this.arrCate.list.forEach((el, index) => {
          if (jl.product_id === el.id) {
            el.selectNumber = Number(el.selectNumber)
            jl.num = Number(jl.num)
            this.$set(
              this.arrCate.list[index],
              'selectNumber',
              el.selectNumber + jl.num
            )
          }
        })
      })
      // 计算菜品分类
      this.shopCate.list.forEach((el, idx) => {
        this.$set(this.shopCate.list[idx], 'selectNumber', 0)
      })
      arr.forEach(jl => {
        this.shopCate.list.forEach((el, idx) => {
          if (el.id === jl.cate_id) {
            jl.num = Number(jl.num)
            let calcNumber = el.selectNumber + jl.num
            this.$set(this.shopCate.list[idx], 'selectNumber', calcNumber)
          }
        })
      })
    }
  },
  computed: {
    isKeyboardShow() {
      return this.$store.state.keyshow
    },
    useOrder() {
      /**
       * 当前订单
       * @param {Object}
       */
      return this.$store.state.useOrder
    },
    cartList() {
      return this.$store.state.cartList
    }
  },
  watch: {
    useOrder: {
      handler(n, o) {
        let off = false
        if (n.order_list) {
          this.order.id = n.id
          n.order_list.list.forEach(el => {
            if (el.switch === false) off = true
          })
          this.cateProductList()
        } else {
          this.order.id = ''
        }
        if (!off) {
          this.list = []
        }
      }
    },
    cartList: {
      handler(n, o) {
        if (n.length == 0) this.list = []
        else {
          this.list = n
        }
        this.matchingCart()
      }
    },
    'rescateProduct.search': {
      handler(n, o) {
        if (n != o) {
          this.rescateProduct.page = 1
          this.cateProductList()
        }
      }
    },
    defectProduct: {
      handler(n, o) {
        if (n === true) {
          this.cateProductList()
        }
      }
    }
  },
  async created() {
    this.setSnackMenu()
    await this.shopCateTitle()
    await this.cateProductList()
  },
  mounted() {
    if (this.$route.name === 'defectProduct') {
      this.isdefectProduct = true
    }
  }
}
</script>
<style lang="less" scoped >
@import url('../../assets/less/menu/list.less');
@import url('../../assets/less/menu/listMedia.less');
</style>
<style lang='less' >
/** 
*  针对UI控件无法对内嵌Scoped进行响应
*/
.menulistFooter {
  .isDefect {
    .el-input {
      width: 766px;
    }
  }
  .el-input {
    display: block;
    float: left;
    height: 52px;
    width: 456px;
    display: flex;
  }
  .el-input__suffix span i {
    font-size: 24px !important;
    line-height: 40px;
  }
  .el-input-group__append {
    padding: 0 !important;
    padding-right: 16px !important;
  }
  .el-input-group__prepend {
    padding: 0 !important;
    padding-left: 16px !important;
  }
  .el-input-group__prepend,
  .el-input-group__append {
    width: 32px !important;
    border: none !important;
    height: 52px;
    display: flex;
    align-items: center;
    background-color: #fff !important;
    outline: none !important;
    img {
      width: 22px;
      height: 22px;
      margin: auto 0;
      padding: 0;
    }
  }
  input {
    height: 100%;
    border: none !important;
  }
  .el-button {
    display: block;
    float: left;
    margin-left: 10px;
    width: 145px;
    height: 52px;
  }
  .print-button {
    span {
      display: block;
      text-align: left;
    }
    img {
      float: left;
      width: 26px;
      height: 26px;
      margin: 13px 16px;
    }
    p {
      font-size: 16px;
      color: #3e4049;
      font-weight: bold;
      line-height: 53px;
    }
  }
  .el-button:hover {
    color: #fe7622;
  }
}
#layerDiaLog {
  display: flex;
  justify-content: center;
  align-items: center;
}
.layerDiaLog {
  margin: 0 !important;
  width: 518px !important;
  height: auto;
  max-height: 100%;
  max-width: 100%;
  overflow: hidden;
  border-radius: 6px;
  .el-dialog__header {
    .el-dialog__title {
      font-size: 16px;
      font-weight: 700;
      display: block;
    }
  }
  .el-dialog__body {
    padding: 0 20px 100px 20px;
    border-radius: 6px;
  }
}
.menu-paing-btn {
  width: 144px;
  height: 50px;
  .paing-btn {
    width: 67px !important;
    height: 50px !important;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 20px;
    font-weight: bold;
  }
}
.print-btn {
  width: 120px !important;
  // height: 100px !important;
  min-width: 90px !important;
  display: flex;
  flex-flow: column;
}
.print-btn button {
  width: 100%;
  height: 50px;
  margin-bottom: 5px !important;
  color: #333;
  margin-left: 0 !important;
  font-size: 16px !important;
  border: none;
}
.print-btn button:not(.is-disabled):hover,
.print-btn button:not(.is-disabled):active,
.print-btn button:not(.is-disabled):focus {
  color: #fe7622 !important;
  border: none;
  background-color: #fff !important;
}

.print-btn button:not(:first-child) {
  margin-top: 6px;
}
</style>