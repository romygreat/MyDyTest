<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-22 08:45:27
 * @LastEditTime : 2019-12-30 12:14:46
 -->
<template>
  <div class="cart">
    <!-- 购物车头部信息 -->
    <section class="shopCart">
      <header>
        <div class="table">
          <h3>餐台号</h3>
          <span>{{useTable_no}}</span>
        </div>
        <div class="shop-info">
          <div class="people-num">
            <span>
              <p style="font-weight: bold;">{{tables_numInfo}}</p>人,店内/堂食
            </span>
            <img @click="numberSelectPros.show = true" :src="editIcon" alt />
          </div>
          <span>服务员：{{adminInfo.realname}}</span>
          <span>状态：{{ useTime!=""?'用餐'+useTime.hours+'小时'+useTime.minutes+'分':'开台'}}</span>
        </div>
      </header>
      <!-- 购物车列表 -->
      <section class="list">
        <!-- 列表头 -->
        <hgroup class="clear">
          <h3 v-for="(item,idx) in listHeader" :key="idx">{{item.name}}</h3>
        </hgroup>
        <!-- 列表 -->
        <div ref="listbox" class="listbox">
          <dl
            :class="uselistIdx == idx ? 'use' : ''"
            @click="setOperation(item,idx)"
            v-for="(item,idx) in list"
            :key="idx"
          >
            <dt class="clear">
              <p :class="item.refund_price || item.refund_price === 0  ? 'name del-name' : 'name'">
                <img v-if="item.switch" class="groupimg" :src="shopgou" alt />
                <span v-else class="groupimg">
                  <span></span>
                </span>
                <span class="isAppend"  v-if="item.append == 1"  >[加]</span>
                {{item.name}}
                <span
                  :class="['shopStatus',item.type == 1 ? 'deng' : 'ji']"
                  v-if="item.type && (item.type == 1 || item.type == 2)"
                >{{item.type == 1 ? '等' : '急'}}</span>
              </p>
              <p class="num">
                {{item.num}}{{item.unit !== '' ? item.unit : '份' }}
                <b
                  @click="setOperation(item,idx,true)"
                  class="editable"
                  :style="item.is_exists_edit == 1 || item.is_exists_current == 1 ? 'background:#1bbc9b' : ''"
                  v-if="item.is_editable == 1 || item.is_current == 1"
                >{{item.is_exists_edit == 1 || item.is_exists_current == 1 ? '√' : '?'}}</b>
              </p>
              <p
                v-if="!item.refund_price && item.refund_price !== 0"
                class="price"
              >￥{{transformMondy(item.price,item.discount_amount)}}</p>
              <p v-else class="price">￥{{transformRMBKey(item.refund_price)}}</p>
            </dt>
            <dd>
              <h4 v-if="item.discount_amount && item.discount_amount != 0">
                -{{item.discount_rate != 100 && item.discount_rate != 0 ? `[${item.discount_rate}折]` : '[赠]' }} {{item.discount_reason}}
                <span>-￥{{transformMondy(item.price-item.price*item.discount_rate/10)}}</span>
              </h4>
              <h4 v-if="item.refund_price || item.refund_price === 0">-[退] {{item.refund_reason}}</h4>
              <h4 v-if="item.group" class="product-label">
                -[规格]：
                <b v-if="item.group">{{item.group.group_title}}</b>
              </h4>
              <h4 v-if="item.remark && item.remark != ''">- [备注] {{item.remark}}</h4>
              <h4 v-if="item.contorno">-[配菜] {{item.contorno.contorno_name}}</h4>
              <h4 v-if="item.procedure">-[做法] {{item.procedure.name}}</h4>
              <h4 v-if="item.taste">-[口味] {{item.taste.name}}</h4>
              <h4 v-if="item.urge">-[已催]</h4>
            </dd>
          </dl>
          <!-- 杂项费 -->
          <dl v-if="(order.id && order.service_price !== 0) || (!order.id && codePaw.is_service == 1)">
            <dt>
              <p style="width:50%;float:left">服务费</p>
              <p style="width:25%;float:left">1项</p>
              <p
                v-if="!order.id"
                class="price"
                style="width:25%;float:left"
              >￥{{transformMondy(codePaw.service_price*service_nums)}}</p>
              <p v-else  class="price"  style="width:25%;float:left">
                ￥{{transformMondy(order.service_price)}}
              </p>
            </dt>
          </dl>
          <dl  v-if="(order.id && order.tableware_fee !== 0) || (!order.id && codePaw.is_tableware == 1)"  >
            <dt>
              <p style="width:50%;float:left">餐具费</p>
              <p style="width:25%;float:left">{{tables_numInfo}} 位</p>
              <p
                v-if="!order.id"
                class="price"
                style="width:25%;float:left"
              >￥{{transformMondy(codePaw.tableware_fee * tables_numInfo)}}</p>
              <p v-else class="price" style="width:25%;float:left" >
                ￥{{transformMondy(order.tableware_fee * tables_numInfo)}}
              </p>
            </dt>
          </dl>

          <dl v-if=" alldiscount_rate!=10" class="discount-dl">
            <dt>
              <div class="discount-order">
                <img :src="discountIcon" alt />
                <span>整单打折 {{alldiscount_rate}}折</span>
                <span>-￥{{DiscountPriceOrder}}</span>
              </div>
            </dt>
          </dl>
        </div>
        <!-- 当没有任何商品的时候 -->
        <div
          v-if="list.length === 0 && codePaw.is_service != 1 && codePaw.is_tableware != 1"
          class="nullproductbox"
        >
          <img :src="nullproduct" alt />
          <p>你还没有添加商品</p>
        </div>
        <!-- 信息栏 -->
        <div class="cartfooter-other">
          <div class="product-num">
            <span   >共{{Math.floor(listHeader[0].total)}}项</span>
          </div>
          <div @click="setCartLsitInfo(true)" class="clearListButtom">
            <span>清空</span>
            <img :src="clearListButtom" alt />
          </div>
        </div>
        <!-- 按钮以及价格 -->
        <div id="elbox" class="cartfooter elbox">
          <div class="cartfooter-num clear">
            <h2 class="cartfooter-reamk">
              已优惠
              <span class="discount-price">￥{{DiscountPrice}}</span>
            </h2>
            <h2>
              实收
              <span>￥{{transformMondy(order.statistics.paid_price)}}</span>
            </h2>
          </div>
          <aside
            v-if="!order.order_no"
            :class="isClick?'not-click cartfooter-bottom':'cartfooter-bottom'"
          >
            <div @click="commitOrder(1,true)">下单并结账</div>
            <div @click="commitOrder(1,false)">下 单</div>
          </aside>
          <aside v-else class="cartfooter-bottom">
            <div @click="commitOrder(2,false)">加 菜</div>
            <div @click="checkout()">结 账</div>
          </aside>
        </div>
      </section>
    </section>
    <!-- 功能拦 -->
    <section :style="Buckle ? openCalss : ''" class="function">
      <div>
        <!-- 前三个功能 -->
        <dl>
          <dt
            @click="openOperation(item,index)"
            :class="functionIndex === item.setType ? 'use' : ''"
            v-for="(item, index) in functionListH"
            :key="index"
          >{{item.name}}</dt>
        </dl>
        <!-- 加减面板 -->
        <div>
          <img @click="calculation('+')" :src="jiapng" alt />
          <p>{{list.length ? list[uselistIdx].num : 0}}</p>
          <img @click="calculation('-')" :src="jianpng" alt />
        </div>
        <!-- 后植入功能 -->
        <dl class="footerFunction">
          <dt
            @click="openOperation(item,index)"
            :class="functionIndex === item.setType &&  Buckle == true ? 'use' : ''"
            v-for="(item, index) in functionListF"
            :key="index"
          >{{item.name}}</dt>
        </dl>
      </div>
      <transition name="funtionCtranison">
        <section v-if="Buckle" class="functionComponents">
          <Discount
            v-on:setDiscount="setDiscount($event)"
            v-on:swiperFalse="swiperFalse($event)"
            :list="list[uselistIdx]"
            :order="order"
            v-if="functionIndex === 'discount'"
          />
          <Specifications
            v-if="functionIndex === 'specifications'"
            :list="list[uselistIdx]"
            v-on:specPrmis="specPrmis($event)"
            v-on:swiperFalse="swiperFalse($event)"
          />
          <ReturnMenuList
            v-if="functionIndex ==='returnMenu'"
            :list="list[uselistIdx]"
            v-on:toReturnMenu="toReturnMenu($event)"
            v-on:swiperFalse="swiperFalse($event)"
          />
          <Remarks
            v-if="functionIndex ==='remarks'"
            :list="list[uselistIdx]"
            :order="order"
            v-on:toRemarks="toRemarks($event)"
            v-on:swiperFalse="swiperFalse($event)"
          />
          <Require
            v-if="functionIndex ==='requirement'"
            :list="list[uselistIdx]"
            v-on:toRequire="toRequire($event)"
            v-on:swiperFalse="swiperFalse($event)"
          />
        </section>
      </transition>
    </section>
    <div @click="Buckle = false" class="morcl" v-if="Buckle"></div>
    <CheckoutLog
      v-on:checkoutLogCallBack="checkoutLogCallBack($event)"
      v-if="checkoutShow"
      :show="checkoutShow"
      :data="useOrder"
    />
    <dynamicLog
      v-on:toDynamic="toDynamic($event)"
      v-if="dynamicShow"
      :dynamicShow="dynamicShow"
      :openList="list[uselistIdx]"
    />
    <numberSelect
      v-on:clearEdlog="clearEdlog($event)"
      v-on:setEdlog="setEdlog($event)"
      v-if="numberSelectPros.show"
      :unit="numberSelectPros.unit"
      :title="numberSelectPros.title"
      :show="numberSelectPros.show"
      :buttomText="numberSelectPros.logtext"
    />
  </div>
</template>
<script>
import {
  getPayButtom,
  toOrder,
  setOrder,
  modify,
  urgeOrderGoods,
  modifyOrderGoods,
  rdSavet,
  modifyBaseInfo,
  modifyBaseInfoProduct,
  modifyNum,
  beforeSettlemen
} from '@/api/menu'
import { replacementOrder } from '@/api/printer'
import shopgou from '@/assets/img/shopgou.png'
import discountIcon from '@/assets/img/discount.png'
import jiapng from '@/assets/img/jia.png'
import jianpng from '@/assets/img/jian.png'
import clearListButtom from '@/assets/img/clear.png'
import editIcon from '@/assets/img/edit.png'
import {
  getStautsText,
  transformRMB,
  Twopoints,
  setSessionStorage
} from '@/libs/util'
import nullproduct from '@/assets/img/nullproduct.png'
import Calc from 'number-precision'
import { dyencrypt } from '@/libs/md5'
import CheckoutLog from '_c/common/checkoutLog'
import Discount from '_c/common/modularShop/discount'
import Specifications from '_c/common/modularShop/specifications'
import ReturnMenuList from '_c/common/modularShop/ReturnMenuBox'
import dynamicLog from '_c/common/dynamicLog'
import Remarks from '_c/common/modularShop/remarks'
import Require from '_c/common/modularShop/require'
import numberSelect from '_c/common/numberSelect'
import { ChangeTime } from '@/libs/changeTime'
import { setTimeout } from 'timers'

export default {
  components: {
    ReturnMenuList,
    CheckoutLog,
    Discount,
    Specifications,
    dynamicLog,
    Remarks,
    Require,
    numberSelect
  },
  data() {
    return {
      tables_numInfo: 1,
      numberSelectPros: {
        title: '选择人数',
        show: false,
        unit: '人',
        logtext: '确认'
      },
      clearListButtom,
      jiapng,
      jianpng,
      shopgou,
      nullproduct,
      editIcon,
      discountIcon,
      codePaw: {},
      useTime: '',
      listHeader: [
        { name: '品名', total: 0 },
        { name: '数量', total: 0 },
        { name: '小计', total: 0 }
      ],
      uselistIdx: 0,
      list: [],
      retutnList: [],
      order: {
        remark: '',
        statistics: {
          paid_price: 0
        },
        order_list: {
          total: ''
        },
        discount_rate: 10
      },
      functionList: [
        { setType: 'dishGiving', name: '赠菜' },
        { setType: 'returnMenu', name: '退菜' },
        { setType: 'delete', name: '删除' },
        { setType: 'specifications', name: '规格' },
        { setType: 'requirement', name: '要求' },
        { setType: 'discount', name: '打折' },
        { setType: 'equalCall', name: '等叫' },
        { setType: 'urgent', name: '加急' },
        // { setType: 'ggOrder', name: '挂单' },
        { setType: 'vegrush', name: '催菜' },
        { setType: 'remarks', name: '备注' }
      ],
      functionIndex: '',
      DiscountPrice: 0,
      toOrderSwith: false,
      isarr: [],
      remark: '',
      checkoutShow: false,
      swiperShow: true,
      Buckle: false,
      openCalss: {
        width: '360px'
      },
      openFunctionClass: {
        oopacity: 1
      },
      dynamicShow: false,
      alldiscount_rate: 10,
      isClick: true
    }
  },
  methods: {
    transformRMBKey(v) {
      return Calc.divide(v,100)
    },
    transformMondy(value1, value2) {
      value1 = Number(value1)
      if (value2) {
       value2 = Number(value2)
        return transformRMB(Calc.minus(value1, value2))
      }
      return transformRMB(value1)
    },
    setOperation(item, idx, type) {
      /**
       * @param {Object} item 当前点击数组
       * @param {Number} idx 当前点击索引
       */
      this.uselistIdx = idx
      if (type === true) {
        this.dynamicShow = true
      }
      this.Buckle = false
    },
    /**
     * @description 触发工具栏功能
     * @param {Object} item
     * @param {Number} functionIndex 标识，储存当前索引
     */
    openOperation(item, index) {
      /**
       * 分发任务
       * 不需要弹出滑块有  赠菜 ：删除 ： 等叫 ： 加急 ： 催菜
       * @param {Booler} Buckle 判断是否展开组件层
       * */

      // 拦截未有商品的情况
      if (!this.list.length) {
        this.$notify({
          title: '警告',
          message: `当前没有选择商品，无法使用${item.name}`,
          type: 'warning'
        })
        return
      }
      // 拦截退菜的情况
      if (
        this.list[this.uselistIdx].refund_price &&
        (item.setType !== 'discount' && item.setType !== 'remarks')
      ) {
        this.$notify({
          title: '警告',
          message: `当前商品为退菜商品，无法使用${item.name}`,
          type: 'warning'
        })
        return
      }
      // 拦截时价商品为未赋予单价的时候
      if (
        this.list[this.uselistIdx].is_current === 1 &&
        this.list[this.uselistIdx].is_exists_current === 0 &&
        item.setType !== 'delete'
      ) {
        this.$notify({
          title: '警告',
          message: `当前商品为时价商品同时未给予时价,无法使用${item.name}`,
          type: 'warning'
        })
        return
      }
      /** @type 赠菜 */
      if (item.setType === 'dishGiving') {
        let obj = {
          discountPrice: 0,
          discount_reason: '赠菜',
          is_discount: 1,
          discount_rate: 0
        }
        this.setDiscount(obj)
      }
      /**  @type 删除   */
      if (item.setType === 'delete') {
        this.Buckle = false
        this.deleteList()
      }
      /**  @type 等叫 || 加急 */
      if (item.setType === 'equalCall' || item.setType === 'urgent') {
        this.setProductCalss(item.setType)
        this.Buckle = false
      }
      /**  @type 催菜  */
      if (item.setType === 'vegrush') this.goVegrush()
      /** @type 打折   */
      if (item.setType === 'discount') {
        if (this.functionIndex != item.setType) this.Buckle = true
        else this.Buckle = !this.Buckle
      }
      /** @type 规格 */
      if (item.setType === 'specifications') {
        // 拦截没有规格
        if (!this.list[this.uselistIdx].group) {
          this.$notify({
            title: '警告',
            message: '当前商品没有规格，暂不支持该操作',
            type: 'warning'
          })
          return
        }
        if (this.functionIndex != item.setType) this.Buckle = true
        else this.Buckle = !this.Buckle
      }
      /** @tpye 退菜 */
      if (item.setType === 'returnMenu') {
        if (!this.list[this.uselistIdx].switch) {
          this.$notify({
            title: '警告',
            message: '当前商品尚未下单，不能进行退菜操作',
            type: 'warning'
          })
          return
        }
        if (this.functionIndex != item.setType) this.Buckle = true
        else this.Buckle = !this.Buckle
      }
      /** @type 备注 */
      if (item.setType === 'remarks') {
        if (this.functionIndex != item.setType) this.Buckle = true
        else this.Buckle = !this.Buckle
      }
      /** @type 要求 */
      if (item.setType === 'requirement') {
        let sulf = this.list[this.uselistIdx]
        if (sulf.contorno || sulf.procedure || sulf.taste) {
          if (this.functionIndex != item.setType) this.Buckle = true
          else this.Buckle = !this.Buckle
        } else {
          this.$notify({
            title: '错误',
            message: '当前商品没有要求属性，暂不支持该操作',
            type: 'warning'
          })
          return
        }
      }
      this.functionIndex = item.setType
    },
    /**
     * @description  设置杂项费
     */  
    miscellaneous() {
      /**
       * 获取杂项费
        * @param {Object} this.codePaw 存储位置
       */
      getPayButtom().then(res => {
        this.codePaw = res.data.data
      })
    },
    /**
     *  @description 购物车数据统计
     *  @param {Number} nuwsPrices 杂项费总额
     *  @param {Number} paidPrice 订单总价
     */
    computedData() {
      let nuwsPrices = 0 //服务费
      let paidPrice = 0 // 订单总价
      // 餐具费，服务费
      if (this.codePaw.is_service == 1) {
        nuwsPrices = Calc.plus(
          nuwsPrices,
          Number(this.codePaw.service_price * this.service_nums)
        )
      }
      if (this.codePaw.is_tableware == 1) {
        let codePawPrcie = Calc.times(
          Number(this.codePaw.tableware_fee),
          Number(this.tables_numInfo)
        )
        nuwsPrices = Calc.plus(nuwsPrices, codePawPrcie)
      }
      // 但如果我之前下单了，上次订单不含杂项费 || 之前餐位费不是这个价格
      if(this.order.id) {
        // 餐具费
        nuwsPrices = 0
        let tableNumPrice = Calc.times(this.order.tableware_fee,this.order.tableware_num)
        nuwsPrices = Calc.plus(tableNumPrice,this.order.service_price)
      }
      /**
       *  @param {Number} DiscountPrice 优惠总额
       *  @param {Number} hisElprice 小计总额
       *  @param {Number} total 商品份数
       */
      let DiscountPrice = 0
      let thisElprice = 0
      let total = 0
      this.list.forEach((el, idx) => {
        if (!el.refund_price && el.refund_price !== 0 ) {
          thisElprice = el.price
          paidPrice = Calc.plus(paidPrice, thisElprice)
          total = Calc.plus(total, Number(el.num))
          if (el.discount_amount) {
            DiscountPrice = Calc.plus(DiscountPrice, Number(el.discount_amount))
          }
        }
      })
      this.$set(this.listHeader[0],'total',total)
      this.$set(
        this.order.statistics,
        'total_price',
        Twopoints(Calc.plus(nuwsPrices, paidPrice))
      )
      let newPaiprice = Calc.times(
        Calc.minus(Calc.plus(nuwsPrices, paidPrice), DiscountPrice),
        Calc.divide(this.alldiscount_rate, 10)
      )
      // 如果有全局打折
      let allatePrice = 0
      if (this.alldiscount_rate != 10) {
        this.alldiscount_rate = Number(this.alldiscount_rate)
        let confiDisprice = Calc.minus(
          Calc.plus(nuwsPrices, paidPrice),
          DiscountPrice
        )
        allatePrice = Twopoints(
          Calc.minus(
            confiDisprice,
            parseInt(
              Calc.times(confiDisprice, Calc.divide(this.alldiscount_rate, 10))
            )
          )
        )
      }
      this.DiscountPriceOrder = this.transformMondy(allatePrice)
      this.DiscountPrice = this.transformMondy(
        Calc.plus(DiscountPrice, allatePrice)
      )
      this.$set(this.order.statistics, 'paid_price', newPaiprice)
      this.$set(this.order.order_list, 'total', total)
    },
    /**
     * @description 下单
     */
    async commitOrder(v, isPayNow) {
      if (this.isClick) {
        this.$notify({
          title: '错误',
          message: '还没有添加任何菜品',
          type: 'warning'
        })
        return
      }
      if (this.order.status == 1) {
        this.$notify({
          title: '错误',
          message: '当前为订单为线上支付，暂不能操作该订单',
          type: 'warning'
        })
        return
      }
      if (!this.toOrderSwith) {
        this.toOrderSwith = true
        /**
         * @param {Number} toprice 应收
         * @param {Number} paprice 实收
         * @param {Number} DiscountPrice 优惠总额
         */
        let toprice = 0
        let paprice = 0
        let DiscountPrice = 0
        this.isarr = []
        this.list.forEach((el, idx) => {
          if (!el.switch) {
            this.isarr.push(el)
            toprice = Calc.plus(el.price, toprice)
            if (el.discount_amount) {
              el.final_price = parseInt(
                Calc.times(el.price, Calc.divide(el.discount_rate, 10))
              )
              DiscountPrice = Calc.plus(
                DiscountPrice,
                Number(el.discount_amount)
              )
            } else {
              el.final_price = JSON.parse(JSON.stringify(el.price))
            }
          }
        })
        toprice = parseInt(toprice)
        paprice = parseInt(Calc.minus(toprice, DiscountPrice))
        // return
        let data = {
          // 加密串
          check_token: dyencrypt(
            `${toprice}-${paprice}-${2}-${this.adminInfo.shop.shop_id}`,
            'toOrder'
          ),
          total_price: toprice,
          paid_price: paprice,
          table_no: this.useTable_no,
          list: this.isarr,
          remark: this.remark,
          meals: v,
          discount_rate: this.alldiscount_rate,
          pay_action: 2,
          tableware_num: this.tables_numInfo,
          tableware_fee:
            this.codePaw.is_tableware == 1 ? this.codePaw.tableware_fee : 0,
          service_price:
            this.codePaw.is_service == 1 ? this.codePaw.service_price : 0,
          append: Calc.minus(v, 1),
          pin_out: 0
        }
        if (data.list.length > 0) {
          await toOrder(data).then(res => {
            this.isarr = []
            toprice = 0
            paprice = 0
            if (res.code == -10033) {
              this.$notify.error({
                title: '出错',
                message: '下单失败,请联系管理员'
              })
              this.toOrderSwith = false
            } else {
              if (res.data.code == 1) {
                const data = {
                  table_no: this.useTable_no,
                  id: 0,
                  trade_no: 0
                }
                setOrder(data).then(resj => {
                  this.order = resj.data.data
                  this.toOrderSwith = false
                  this.$store.commit('setUseOrder', resj.data.data)
                  this.$store.commit('setCartList', [])
                  this.myOrder()
                  setTimeout(()=>{
                    if (isPayNow == true) {
                        this.checkout()
                      }
                  },1000)
                  // this.$notify({
                  //   type: 'success',
                  //   title: '成功',
                  //   message: '订单已经成功下单',
                  //   duration: 1000,
                  //   onClose: () => {
                  //     if (isPayNow == true) {
                  //       this.checkout()
                  //     }
                  //   }
                  // })
                })
              } else {
                this.$notify.error({
                  title: res.data.message
                })
                this.toOrderSwith = false
              }
            }
          })
        } else {
          this.$notify.error({
            title: '请选择菜品后再下单！'
          })
          this.toOrderSwith = false
        }
      }
      this.computedData()
    },
    /**
     * @description 结账
     */
    checkout() {
      // 拦截没有下单时候就想结账
      if (!this.order.add_time || this.order.add_time == '') {
        this.$notify({
          type: 'warning',
          title: '提示',
          message: '当前没有下单，不能进行结账操作'
        })
        return
      }
      // 拦截下单商品
      if (this.order.status === 1) {
        this.$notify({
          type: 'success',
          title: '提示',
          message: '订单已经支付，谢谢光临'
        })
        return
      }
      // 拦截时价和称重没有改的情况
      let switchOff = false
      let isSwitch = false
      this.list.forEach(item => {
        if (
          (item.is_editable == 1 &&
            item.is_exists_edit != 1 &&
            item.switch == true) ||
          (item.is_current == 1 &&
            item.is_exists_current != 1 &&
            item.switch == true)
        ) {
          switchOff = true
        }
        if (item.switch == false) {
          isSwitch = true
        }
      })
      if (isSwitch) {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '还有商品未下单，请确认是否下单！'
        })
        return
      }
      if (switchOff) {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '当前存在称重商品或者时价商品尚未更改，无法结账'
        })
        return
      }
      this.checkoutShow = true
    },
    /**
     * @description 结账回调
     * @param {Booler} res.show 结账窗口显示
     * @param {Number} res.type 回调类型  0 ：什么都没有操作   1：支付成功  2 ： 支付失败
     */
    checkoutLogCallBack(res) {
      this.checkoutShow = res.show
      if (res.type == 1) {
        this.$router.push({ name: 'home' })
      }
    },
    /**
     * @description 工能栏算法
     * @param {String} type 标识 - || +
     */
    calculation(type) {
      let sulf = this.list[this.uselistIdx]
      // 拦截下单后商品
      if (sulf.switch == true) {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '商品已经下单，不能进行加减操作'
        })
        return
      }
      if (type === '+') {
        // 拦截沽清
        if (sulf.is_limit === 1 && sulf.cplimit_num < sulf.num + 1) {
          this.$notify({
            title: '抱歉',
            message: '该商品已经售磬，无法添加进购物车',
            type: 'warning'
          })
          return
        }
        // 对多ID情况进行沽清拦截
         if (sulf.is_limit === 1) {
          let isKeyLimitOff = 0 
          this.list.forEach(el => {
            if ((el.switch == false || el.switch == undefined) && el.id === sulf.id) {
              isKeyLimitOff = Calc.plus(el.num,isKeyLimitOff )
            }
          })
          console.log(isKeyLimitOff,sulf)
          if(isKeyLimitOff >= sulf.cplimit_num) {
            this.$notify({
              title: '抱歉',
              message: '该商品已经售磬，无法添加进购物车',
              type: 'warning'
            })
            return
          }
         }
        this.$set(sulf, 'num', sulf.num + 1)
      } else {
        if (sulf.num == 1) {
          this.deleteList()
        } else {
          this.$set(sulf, 'num', sulf.num - 1)
        }
      }
      // 如果存在优惠
      if (sulf.discount_amount) {
        let newDiscount = Calc.times(
          Calc.divide(sulf.discount_amount, Calc.minus(sulf.num, 1)),
          sulf.num
        )
        this.$set(sulf, 'discount_amount', newDiscount)
      }
      this.$set(
        sulf,
        'price',
        Twopoints(Calc.times(sulf.paramePrice, sulf.num))
      )
      this.setCartLsitInfo()
      this.computedData()
    },
    /**
     * @description 删除
     */
    deleteList() {
      if (this.list[this.uselistIdx].switch == true) {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '商品已经下单，不能进行删除操作'
        })
        return
      }
      let sulf = this.list[this.uselistIdx]
      this.$confirm(`是否确认删除?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning ',
        customClass: 'calction'
      })
        .then(() => {
          this.list.splice(this.uselistIdx, 1)
          if (this.list.length == 0) this.uselistIdx = 0
          else this.uselistIdx = this.list.length - 1
          let arr = []
          this.list.forEach(el => {
            if (el.switch === false) arr.push(el)
          })
          this.$store.commit('setCartList', arr)
          return
        })
        .catch(() => {
          return
        })
    },
    /**
     *  @description 设置等叫 和 加急
     *  @param {String} type 1 : 等叫   2： 加急
     */
    setProductCalss(type) {
      let key
      type === 'equalCall' ? (key = 1) : (key = 2)
      let sulf = this.list[this.uselistIdx]
      if (sulf.switch == true) {
        // 如果之前设置，设立反选
        if (sulf.type == key) key = ''
        const data = {
          id: sulf.id,
          type: key
        }
        modifyBaseInfoProduct(data).then(res => {
          this.myOrder()
        })
        return
      }
      // 如果之前设置过，就反选
      if (sulf.type === key) this.$set(sulf, 'type', '')
      else this.$set(sulf, 'type', key)
      this.setCartLsitInfo()
    },
    /**
     * @description 催菜
     */
    goVegrush() {
      this.Buckle = false
      if (this.list[this.uselistIdx].switch == false) {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '商品没有下单，不能进行催菜操作'
        })
        return
      }
      urgeOrderGoods({ id: this.list[this.uselistIdx].id }).then(res => {
        if (res.data.code === 1) {
          if (window.android)
            window.android.printOneOrder(0,JSON.stringify(res.data.data))
          this.$notify({
            type: 'success',
            title: '成功',
            message: '已经进行了催菜，请稍等'
          })
          this.$set(this.list[this.uselistIdx], 'urge', 1)
        }
      })
    },
    /**
     * @description 优惠
     * @param {Number} discount_rate
     */
    async setDiscount(res) {
      //如果是整单优惠
      if (res.typeKey === 0) {
        if (!this.order.order_no) {
          this.alldiscount_rate = res.discount_rate
          this.$set(this.order, 'discount_rate', res.discount_rate)
        } else {
          this.alldiscount_rate = res.discount_rate
          const data = {
            id: this.order.id,
            discount_rate: res.discount_rate
          }
          let rsulf = await beforeSettlemen(data)
          await this.myOrder()
        }
        this.$notify({
          type: 'success',
          title: '成功',
          message: '已写入整单优惠'
        })
        this.computedData()
        this.Buckle = false
        return
      }
      // 如果此刻已经整单打折为0，就不能单品优惠
      if( this.order.discount_rate === '0' || this.alldiscount_rate === '0' || this.alldiscount_rate === 0) {
        this.$notify({
          type: 'warning',
          title: '抱歉',
          message: '订单已经免单，暂不能进行整单打折'
        })
        return
      }

      let sulf = this.list[this.uselistIdx]
      // 计算优惠了多少钱
      res.discount_amount = Calc.minus(sulf.price, res.discountPrice)
      this.$set(this.list, this.uselistIdx, {
        ...this.list[this.uselistIdx],
        ...res,
        modify: 1
      })
      this.aginCalcList()
      sulf = this.list[this.uselistIdx]
      // 下单的商品
      if (sulf.switch) {
        await modifyOrderGoods(sulf).then(resqon => {
          if (resqon.data.code === 1) {
            this.myOrder()
            this.$notify({
              title: '成功',
              message: `已经对商品${sulf.name}进行了优惠`,
              type: 'success'
            })
          } else {
            this.$notify({
              title: '警告',
              message: '优惠更改失败，请联系管理员',
              type: 'warning'
            })
          }
        })
      }
      // 没下单的商品
      if (!sulf.switch) {
        this.$notify({
          title: '成功',
          message: `已经对商品${sulf.name}进行了优惠`,
          type: 'success'
        })
        this.$set(this.list, this.uselistIdx, {
          ...this.list[this.uselistIdx],
          ...res
        })
        this.setCartLsitInfo()
      }
      this.Buckle = false
      this.computedData()
    },
    /**
     * @description: 更改规格
     * @param {Object} res 选好的新规格对象
     * @return:
     */
    async specPrmis(res) {
      let keyres = res
      // 新规格对象赋值
      let sulf = this.list[this.uselistIdx]
      // 如果这个商品之前是有优惠的，剔除优惠
      if (sulf.discount_amount) {
        this.$set(sulf, 'discount_useinfo', '')
        this.$set(sulf, 'discount_reason', '')
        this.$set(sulf, 'discount_rate', 10)
        this.$set(sulf, 'discount_amount', 0)
      }
      // 开始区分下单与未下单
      if (!sulf.switch) {
        // 重新计算真实单价
        let unitPrice = Calc.plus(
          Calc.minus(sulf.paramePrice, sulf.group.group_price),
          res.group_price
        )
        // 重新渲染和更新小计
        this.$set(sulf, 'paramePrice', unitPrice)
        this.$set(sulf, 'price', Calc.times(sulf.num, unitPrice))
        this.$set(sulf, 'group', res)
        this.setCartLsitInfo()
      } else {
        //重新计算真实单价
        this.$set(sulf, 'group', res)
        let paramePrice =
          Number(sulf.group.group_price) +
          Number(sulf.procedure ? sulf.procedure.proces_price : 0) +
          Number(sulf.contorno ? sulf.contorno.contorno_price : 0)
        this.$set(sulf, 'price', Calc.times(Number(sulf.num), paramePrice))
        sulf.is_group = 1
        sulf.modify = 1
        sulf.final_price = sulf.price
        let resinfo = await modifyOrderGoods(sulf)
        if (resinfo.data.code === 1) {
          await this.myOrder()
          this.$notify({
            type: 'success',
            title: '成功',
            message: '修改规格成功'
          })
        } else {
          this.$notify({
            type: 'warning',
            title: '错误',
            message: '修改失败，请联系管理员'
          })
        }
      }
      this.Buckle = false
      this.computedData()
    },
    async myOrder(type) {
      // 判断台桌号是否已经空了
      if (this.useTable_no == '') {
        this.$store.commit(
          'setUseTable_no',
          sessionStorage.getItem('tables_noInfo')
        )
      }
      const data = {
        table_no: this.useTable_no,
        id: 0,
        trade_no: 0
      }
      let res = await setOrder(data)
      if (res.data.data !== null) {
        this.tables_numInfo = res.data.data.tableware_num
        if (res.data.data.order_list) this.list = res.data.data.order_list.list
        else this.list = []
        this.$store.commit('setUseOrder', res.data.data)
        this.order = res.data.data
        this.alldiscount_rate = res.data.data.discount_rate
        this.tables_numInfo = res.data.data.tableware_num
      } else {
        this.tables_numInfo = sessionStorage.getItem('table_num')
      }
    },
    /**
     * @description: 写入退菜
     * @param {Object} res 由退菜组件计算好的退菜参数
     * @return:
     */
    async toReturnMenu(res) {
      res.id = this.list[this.uselistIdx].id
      let data = await rdSavet(res)
      if (data.data.code === 1) {
        this.$notify({
          type: 'success',
          title: '成功',
          message: `菜品${this.list[this.uselistIdx].name}退菜成功`
        })
        await this.myOrder('returnMenu')
        this.toPrinter(5, data.data.data)
        this.computedData()
      } else {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '退菜失败，请联系管理员'
        })
      }
      this.Buckle = false
    },
    /**
     * @description 更改时价 和 重量
     * @param {Number} res.type 标识 1：更改了 0 ：没有改动
     */
    async toDynamic(res) {
      if (res.type == 0) {
        this.dynamicShow = false
        return
      }
      let sulf = this.list[this.uselistIdx]
      // 区分是否下单
      if (sulf.switch == true) {
        // 是时价菜赋值新的单价
        if (sulf.is_current == 1) {
          this.$set(sulf, 'unit_price', res.timePrcie)
          this.$set(sulf, 'is_exists_current', 1)
        }
        // 是称重赋予重量
        if (sulf.is_editable == 1) {
          this.$set(sulf, 'num', res.weight)
          this.$set(sulf, 'is_exists_edit', 1)
        }
        this.aginCalcList()
        sulf = this.list[this.uselistIdx]
        sulf.modify = 1
        let resQ = await modifyOrderGoods(sulf)
        if (resQ.data.code == 1) {
          await this.myOrder()
          this.$notify({
            type: 'success',
            title: '成功',
            message: `更改成功，请重新核对价格`
          })
          this.computedData()
        } else {
          this.$notify({
            type: 'warning',
            title: '错误',
            message: '更改失败，请联系管理员'
          })
        }
      } else {
        if (sulf.is_current == 1) {
          this.$set(sulf, 'paramePrice', res.timePrcie)
          this.$set(sulf, 'is_exists_current', 1)
          this.$set(sulf, 'unit_price', res.timePrcie)
        }
        if (sulf.is_editable == 1) {
          this.$set(sulf, 'num', res.weight)
          this.$set(sulf, 'is_exists_edit', 1)
        }
        this.aginCalcList()
        this.setCartLsitInfo()
      }
      this.dynamicShow = false
    },
    /**
     * @description 写入备注 || 打包
     */
    toRemarks(res) {
      let sulf = this.list[this.uselistIdx]
      // 如果它写入是整单备注
      if (res.remarksType == 1) {
        if (!this.order.order_no) {
          this.$set(this.order, 'remark', res.remarks)
          this.remark = res.remarks
          this.$notify({
            type: 'success',
            title: '成功',
            message: `已经写入了整单备注`
          })
        } else {
          const data = {
            id: this.order.id,
            remark: res.remarks
          }
          modifyBaseInfo(data).then(res => {
            this.myOrder()
          })
        }
        this.Buckle = false
        return
      }
      // 区分是否已经下单
      if (sulf.switch) {
        const data = {
          id: sulf.id,
          remark: res.remarks,
          is_pack: res.openlist_isPack
        }
        modifyBaseInfoProduct(data).then(res => {
          this.myOrder()
        })
      } else {
        // 写入备注
        this.$set(sulf, 'remark', res.remarks)
        // 写入打包
        this.$set(sulf, 'is_pack', res.is_pack == true ? 1 : 0)
      }
      this.setCartLsitInfo()
      this.Buckle = false
    },
    /**
     *  @description 同步list
     */
    setCartLsitInfo(type) {
      let carryArr = JSON.parse(JSON.stringify(this.list))
      let arr = []
      let trueArr = []
      carryArr.forEach(el => {
        if (!el.switch) arr.push(el)
        else trueArr.push(el)
      })
      if (type == true) {
        this.uselistIdx = 0
        this.$store.commit('setCartList', [])
      } else this.$store.commit('setCartList', arr)
    },
    /**
     * @description  写入要求
     */
    async toRequire(res) {
      let sulf = this.list[this.uselistIdx]
      // 区分是否已经下单
      if (sulf.switch) {
        this.$set(this.list, this.uselistIdx, res)

        this.aginCalcList()
        sulf = this.list[this.uselistIdx]
        let resinfo = await modifyOrderGoods(sulf)
        if (resinfo.data.code === 1) {
          await this.myOrder()
          this.$notify({
            type: 'success',
            title: '成功',
            message: '已经成功写入要求'
          })
          this.computedData()
        } else {
          this.$notify({
            type: 'warning',
            title: '错误',
            message: '修改失败，请联系管理员'
          })
        }
      } else {
        this.$set(this.list, this.uselistIdx, { ...res, modify: 1 })
        this.$notify({
          type: 'success',
          title: '成功',
          message: '已经成功写入要求'
        })
        this.aginCalcList()
        this.computedData()
      }
      this.Buckle = false
    },
    /**
     * @description 重新计算该商品的全部参数
     */
    aginCalcList() {
      let calcinfo = this.list[this.uselistIdx]
      // 找出真实单价
      let total = 0
      let influence = 0
      // 先判断初始单价是用规格价 还是 单价
      if (
        calcinfo.group &&
        (calcinfo.is_current != 1 || calcinfo.is_exists_current != 1)
      ) {
        total = Calc.plus(total, calcinfo.group.group_price)
      } else {
        total = Calc.plus(total, calcinfo.unit_price)
      }
      // 判断是否有配菜
      if (calcinfo.contorno) {
        total = Calc.plus(total, calcinfo.contorno.contorno_price)
        influence = Calc.plus(influence, calcinfo.contorno.contorno_price)
      }
      // 判断是否有做法
      if (calcinfo.procedure) {
        total = Calc.plus(total, calcinfo.procedure.proces_price)
        influence = Calc.plus(influence, calcinfo.procedure.proces_price)
      }
      // 计算出小计 以及 总价
      calcinfo.price = parseInt(Twopoints(Calc.times(total, calcinfo.num)))
      calcinfo.final_price = parseInt(
        Calc.times(
          calcinfo.price,
          Calc.divide(Number(calcinfo.discount_rate), 10)
        )
      )
      this.$set(this.list, this.uselistIdx, calcinfo)
      this.list[this.uselistIdx].modify = 1
    },
    /** @description 重新编排数据 */
    carryArrSort(arr, key) {
      return arr.sort((a, b) => {
        let keyA = a[key]
        let leyB = b[key]
        return keyA ? 0 : -1
      })
    },
    /** @description  重新编排人数 */
    async setEdlog(res) {
      if (this.order.order_no) {
        const data = {
          id: this.order.id,
          num: res
        }
        modifyNum(data).then(resinfo => {
          if (resinfo.data.code === 1) {
            this.$notify({
              type: 'success',
              title: '成功',
              message: `已经更改了就餐人数`
            })
            this.myOrder()
          } else {
            this.$notify({
              type: 'warning',
              title: '错误',
              message: '更改失败，请联系管理员'
            })
          }
        })
      } else {
        this.tables_numInfo = res
      }
      this.numberSelectPros.show = false
      this.computedData()
    },
    /** @description 取消编排人数 */
    clearEdlog(res) {
      this.numberSelectPros.show = res
    },
    /** @description 关闭滑块 */
    swiperFalse(res) {
      this.Buckle = false
    },
    useTableTime(start) {
      /**
       * 用餐时间
       * 返回{hours：小时，minutes：分钟}
       */

      let dateTime = new Date()
      let day = start.getDate()
      let hours = start.getHours()
      let minutes = start.getMinutes()
      let useForTime = {}
      useForTime.hours =
        (dateTime.getDate() - day) * 24 + dateTime.getHours() - hours
      useForTime.minutes = dateTime.getMinutes() - minutes
      if (useForTime.minutes < 0) {
        useForTime.hours -= 1
        useForTime.minutes += 60
      }
      return useForTime
    },
    /**
     * @description 触发打印机
     */
    toPrinter(key, list) {
      // 如果不走接口
      if (list) {
        if(window.android) {
          // list.printer.forEach((el, idx) => {
            window.android.printOneOrder(
              0,
              JSON.stringify(list)
            )
          // })
        }
        return
      }

      const data = {
        type: key,
        id: this.order.id
      }
      replacementOrder(data)
        .then(keyres => {
          if (window.android) {
            if (keyres.data.code == 1) {
              let sulf = keyres.data.data
              // sulf.printer.forEach((el, idx) => {
                // sulf.printerInfo = el
                window.android.printOneOrder(
                  0,
                  JSON.stringify(sulf)
                )
              // })
            } else {
              this.$notify.error({
                title: '出错',
                message: keyres.data.message
              })
            }
          }
        })
        .catch(error => {
          console.log(error, 'error')
        })
    },
    btnStatus() {
      /**
       * 判断下单按钮是否可点击
       * 1：有下单时间--》可点击，
       * 2：没有下单时间--》2.1：只有小吃项--newOrder.length == isSnack.length不可点击、2.2还有其他项，可以点击
       */
      if (this.$store.state.useOrder.add_time) {
        this.isClick = false
      } else {
        let newOrder = JSON.parse(JSON.stringify(this.cartList))
        let isSnack = newOrder.filter((item, index) => {
          return item.isSnack
        })
        if (newOrder.length == isSnack.length) {
          this.isClick = true
        } else {
          this.isClick = false
        }
      }
    },
    /**
     * @description 去掉台桌列表的 新 || 加 状态
     */
    async clearTablesAddOrNew(){
     if(this.order.is_new == 1 || this.order.append == 1) {
       const data = {
         id:this.order.id,
         is_new:0,
         append:0
       }
       let res = await modifyBaseInfo(data)
     }
    }
  },
  computed: {
    useOrder() {
      /**
       * 当前订单
       * @param {Object}
       */
      let sulf = this.$store.state.useOrder
      if (this.$store.state.useOrder.add_time != undefined) {
        /**
         * 计算用餐时间
         */
        let changeTime = this.$store.state.useOrder.add_time.split('-')
        let ordertime = new Date(changeTime.join('/'))
        this.useTime = this.useTableTime(ordertime)
        setInterval(() => {
          this.useTime = this.useTableTime(ordertime)
        }, 60000)
      }

      if (sulf.order_list) {
        this.$set(this.listHeader[0], 'total', sulf.order_list.total)
        let Carry = JSON.parse(JSON.stringify(this.cartList))
        this.list = JSON.parse(
          JSON.stringify([...sulf.order_list.list, ...Carry])
        )
        if (this.$refs.listbox) {
          setTimeout(() => {
            this.$refs.listbox.scrollTop = this.$refs.listbox.scrollHeight + 200
          },200)
        }
        this.order = JSON.parse(JSON.stringify(sulf))
      } else if (this.cartList.length == 0) {
        this.list = []
        this.order.remark = ''
        this.order.statistics.paid_price = 0
      } else {
        this.list = JSON.parse(JSON.stringify(this.cartList))
        setTimeout(() => {
          this.$refs.listbox.scrollTop = this.$refs.listbox.scrollHeight + 200
        },200)
      }
      if (sulf.order_refund) {
        sulf.order_refund.list.forEach(el => {
          el.switch = true
          el.unit = '份'
        })
        this.list = [...this.list, ...sulf.order_refund.list]
        this.carryArrSort(this.list, 'switch')
      }
      return this.$store.state.useOrder
    },
    adminInfo() {
      /**
       * 全局基本信息
       * @param {Object}
       */
      return this.$store.state.adminInfo
    },
    tables_num() {
      /**
       * 当前开台人数
       * @param {String}
       */
      let num = sessionStorage.getItem('table_num')
      if (num == null || num == '') num = 1
      return Number(num)
    },
    service_nums() {
      let num = sessionStorage.getItem('service_num')
      if (num == null || num == '') num = 1
      return Number(num)
    },
    service_nums() {
      let num = sessionStorage.getItem('service_num')
      if (num == null || num == '') num = 1
      else this.tables_numInfo = num
      return num
    },
    functionListH() {
      /**
       *  提取功能栏前三个
       * @param {Array} this.functionList
       */
      return this.functionList.filter((item, index) => {
        return index < 3
      })
    },
    functionListF() {
      /**
       * 把剩余功能提取出来
       * @param {Array} this.functionList
       */
      return this.functionList.filter((item, index) => {
        return index > 2
      })
    },
    useTable_no() {
      return this.$store.state.useTable_no
    },
    cartList() {
      return this.$store.state.cartList
    },
    TheWorld() {
      return this.$store.state.TheWorld
    }
  },
  watch: {
    cartList: {
      handler(n, o) {
        // 同时进行光线追踪
        // this.uselistIdx = this.cartList.length - 1
        this.computedData()
        this.btnStatus()
      },
      deep: true
    },
    useOrder: {
      handler(n, o) {
        this.computedData()
      },
      deep: true
    },
    TheWorld: {
      handler(n, o) {
        if (n === true) {
          this.uselistIdx = this.list.length - 1
          this.$store.commit('setTheWorld', false)
         if (this.$refs.listbox) {
          setTimeout(() => {
            this.$refs.listbox.scrollTop = this.$refs.listbox.scrollHeight + 200
          },200)
        }
        }
      },
      deep: true
    },
    tables_num: {
      handler(n, o) {}
    }
  },
  async mounted() {
    await this.myOrder('returnMenu')
    await this.btnStatus()
    await this.clearTablesAddOrNew()
    this.computedData()
  },
  created() {
    this.miscellaneous()
  }
}
</script>
<style lang="less" scoped>
@import url('../../assets/less/menu/shopCart.less');
@import url('../../assets/less/menu/shopCartMedia.less');
</style>
<style lang="less">
.not-click {
  div {
    cursor: not-allowed !important;
  }
  div:first-child {
    border: 1px solid #dcdfe6 !important;
    color: #dcdfe6 !important;
  }
  div:last-child {
    background: #dcdfe6 !important;
  }
}
.calction {
  position: absolute;
  left: 50% !important;
  top: 10vh !important;
  transform: translateX(-50%) !important;
  .el-message-box__header {
    span {
      color: #171922;
      font-size: 16px;
      font-weight: bold;
    }
  }
  .el-message-box__content {
    text-align: center;
    p {
      color: #464c5b;
      font-size: 16px;
    }
  }
  .el-message-box__btns {
    display: flex;
    button {
      flex: 1;
      color: #fff !important;
      height: 44px;
      font-size: 16px;
      font-weight: 600;
    }
    button:first-child {
      background: #171922 !important;
      border-color: #171922 !important;
      outline: none;
    }
    button:last-child {
      background: #fe7622;
      border-color: #fe7622 !important;
      outline: none;
    }
  }
}
</style>