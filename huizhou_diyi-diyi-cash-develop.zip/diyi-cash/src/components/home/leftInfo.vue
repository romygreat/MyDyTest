<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-30 08:46:51
 * @LastEditTime : 2019-12-30 09:39:54
 -->
<template>
  <div class="leftInfo">
    <header>
      <div class="shop-info">
        <section class="logo">
          <img @touchstart="showInitAdroin" :src="adminInfo.shop?logos:logos" alt />
          <div>
            <h3>{{adminInfo.shop?adminInfo.shop.name:''}}</h3>
            <!-- <p>商户编号：*******</p> -->
          </div>
        </section>
        <section class="time">
          <span>{{nowTime.hr?nowTime.hr:'00'}}:{{nowTime.min?nowTime.min:'00'}}:{{nowTime.seconds?nowTime.seconds:'00'}}</span>
          <span>{{nowTime.year}}年{{nowTime.mon}}月{{nowTime.day}}日 星期{{nowTime.week}}</span>
        </section>
        <section class="user">
          <p>操作员：{{adminInfo.realname}}</p>
        </section>
      </div>
    </header>
    <section>
      <figure>台桌的订单信息</figure>
      <h3 v-if="keyShow">桌号：{{tables_no}}</h3>
      <h3 v-if="keyShow">订单号：{{order.order_no}}</h3>
      <h3 v-if="keyShow">下单时间：{{order.add_time}}</h3>
      <h3 v-if="keyShow">
        订单状态：
        <span>{{order.status !== '' ? orderStatus[order.status] : '未下单'}}</span>
      </h3>
      <h3 v-if="keyShow">用餐时间：{{useTime.hours}}时{{useTime.minutes}}分</h3>
      <div v-if="keyShow" class="orderParameter">
        <dl>
          <dt>未结账订单</dt>
          <dd>{{order.statistics ? order.statistics.count : 0}}</dd>
        </dl>
        <dl>
          <dt>待支付金额(元)</dt>
          <dd>
            <span>￥</span>
            {{points(order.statistics ? order.statistics.paid_price : 0)}}
          </dd>
        </dl>
        <hr />
        <div @click="toCheckoutShow()">{{order.status == 1 ? '已结账' : '结账'}}</div>
      </div>
      <div v-if="!keyShow" class="no-order">
        <img :src="nullproduct" alt="">
        <p>{{tables_no}}台桌</p>
        <p>暂时没有订单</p>
        </div>
    </section>
    <checkoutLog
      v-on:checkoutLogCallBack="checkoutLogCallBack($event)"
      v-if="checkoutShow"
      :show="checkoutShow"
      :data="order"
    />
  </div>
</template>
<script>
import logos from '@/assets/img/man-circle@2x.png'
import { setOrder, setShopTable, getAdminInfo } from '@/api/home'
import Calc from 'number-precision'
import { getStautsText, Twopoints, setSessionStorage } from '@/libs/util'
import checkoutLog from '_c/common/checkoutLog'
import { ChangeTime } from '@/libs/changeTime'
import nullproduct from '@/assets/img/nullproduct.png'

export default {
  components: { checkoutLog },
  data() {
    return {
      logos,
      nullproduct,
      orderList: [],
      setOrderRes: {
        id: 0
      },
      setOffKey: '',
      order: {
        trade_no: '',
        statistics: {
          count: 0,
          paid_price: 0
        },
        add_time: '',
        status: ''
      },
      orderStatus: {},
      tables_noInfo: '',
      checkoutShow: false,
      keyShow: false,
      nowTime: {
        year: '',
        mon: '',
        day: '',
        hr: '',
        min: '',
        seconds: '',
        week: ''
      },
      useTime: {
        hours: 0,
        minutes: 0
      },
      loops: ''
    }
  },
  methods: {
    /**
     *  @description 长按事件
     */
    showInitAdroin() {
      clearInterval(this.Loops)
      this.loops = setTimeout(async () => {
        if (window.android) window.android.setttingActivity()
      }, 1000)
    },
    clearLoop() {
      clearInterval(this.loops)
    },
    async mySetOrder() {
      /**
       *  获取订单详情
       *  @param {String} this.setOrderRes.table_no 台桌号
       *  @param {Object} this.order 订单详情
       * **/
      // const data = {
      //   table_no: this.tables_noInfo,
      //   id: 0
      // }
      const data = {
        table_no: this.$store.state.useTable_no,
        id: 0
      }
      await setOrder(data).then(res => {
        if (res.data.data == null) {
          this.keyShow = false
          this.order = {}
          this.order.trade_no = ''
          this.order.add_time = ''
          this.order.status = ''
          this.order.statistics = {}
          this.order.statistics.count = ''
          this.order.statistics.paid_price = ''
          setSessionStorage('myOrder', {})
          this.$store.commit('setUseOrder', {})
        } else {
          this.keyShow = true
          this.order = res.data.data
          console.log(this.order, '订单')

          this.$store.commit('setUseOrder', res.data.data)
          setSessionStorage('myOrder', res.data.data)
        }
      })
    },
    async setOrderState() {
      /**
       * 处理全台桌订单参数数组化
       * @param {Object} allTableState.order(vuex) 当前全订单参数
       * @param {Aarry}  this.orderList 转化后的数组，方便DOM简洁
       * **/
      if (JSON.parse(sessionStorage.getItem('allOrderState')) === null) {
        const data = {
          page: 1,
          rows: 1,
          sign: 'table',
          title: '',
          subarea_id: ''
        }
        let res = await setShopTable(data)
        sessionStorage.setItem(
          'allOrderState',
          JSON.stringify({
            order: res.data.data.order,
            state: res.data.data.status
          })
        )
      }

      let sulf = JSON.parse(sessionStorage.getItem('allOrderState')).order
      let keyNumber = 0
      let name = ''
      for (let key in sulf) {
        if (key == 'order_total') name = '订单总数'
        if (key == 'order_unincome_money') name = '未收金额'
        if (key == 'order_unincome') name = '未结订单'
        this.orderList.push({ name: name, value: sulf[key] })
      }
    },
    async checkoutLogCallBack(res) {
      this.orderList = []
      this.checkoutShow = res.show
      await this.mySetOrder()
      this.setOrderState()
      this.$emit('newTables', true)
    },
    toCheckoutShow() {
      if (this.order.status == 1) {
        return
      }
      // 拦截时价和称重没有改的情况
      let switchOff = false
      this.order.order_list.list.forEach(item => {
        if (
          (item.is_editable == 1 &&
            item.is_exists_edit != 1 &&
            item.switch == true) ||
          (item.is_current == 1 &&
            item.is_exists_current != 1 &&
            item.switch == true)
        ) {
          switchOff = true
        }
      })
      if (switchOff) {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '当前存在称重商品或者时价商品尚未更改，无法结账'
        })
        return
      }
      this.checkoutShow = true
    },
    points(v) {
      /**
       * 精确转小数点后两位
       * @param {String || Number} v 要转化参数
       */
      v = Calc.divide(v, 100)
      return Twopoints(v)
    },
    async setAdminInfo() {
      let adminInfo = (await getAdminInfo({})).data.data
      this.$store.commit('setAdminInfo', adminInfo)
      sessionStorage.setItem('adminInfo', JSON.stringify(adminInfo))
    },
    getTime() {
      /**
       * 时钟
       */
      let dateTime = new Date()
      let week = ['天', '一', '二', '三', '四', '五', '六']
      this.nowTime.year = dateTime.getFullYear()
      this.nowTime.mon = dateTime.getMonth() + 1
      this.nowTime.day = dateTime.getDate()
      this.nowTime.week = week[dateTime.getDay()]
      this.nowTime.hr =
        dateTime.getHours() < 10
          ? '0' + dateTime.getHours()
          : dateTime.getHours()
      this.nowTime.min =
        dateTime.getMinutes() < 10
          ? '0' + dateTime.getMinutes()
          : dateTime.getMinutes()
      this.nowTime.seconds =
        dateTime.getSeconds() < 10
          ? '0' + dateTime.getSeconds()
          : dateTime.getSeconds()
       let changeTime  =  []
      if( this.order.add_time !== undefined) {
         changeTime = this.order.add_time.split('-')
      }
      let ordertime = new Date(changeTime.join('/'))
      let day,
        hours,
        minutes = ''
      day = this.nowTime.day - ordertime.getDate()
      hours = this.nowTime.hr - ordertime.getHours() + day * 24
      minutes = this.nowTime.min - ordertime.getMinutes()
      if (this.nowTime.min - ordertime.getMinutes() < 0) {
        hours -= 1
        minutes += 60
      }
      this.useTime.hours = hours
      this.useTime.minutes = minutes
    }
  },
  computed: {
    tables_no() {
      return this.$store.state.useTable_no
    },
    adminInfo() {
      return this.$store.state.adminInfo
    },
    allOrderState() {
      this.setOrderState()
      return this.$store.state.allTableState
    }
  },
  watch: {
    tables_no: {
      handler(n) {
        this.tables_noInfo = n
        sessionStorage.setItem('tables_noInfo', JSON.stringify(n))
        this.mySetOrder()
      },
      deep: true
    }
  },
  async mounted() {
    await this.mySetOrder()
    this.orderStatus = getStautsText('order.status')
    this.$store.commit(
      'setAdminInfo',
      JSON.parse(sessionStorage.getItem('adminInfo'))
    )
    if (this.$store.state.useTable_no != '')
      this.tables_noInfo = this.$store.state.useTable_no
    this.setOrderState()
  },
  created() {
    this.setAdminInfo()
    setInterval(() => {
      this.getTime()
    }, 1000)
  }
}
</script>
<style lang='less' scoped>
@import url('../../assets/less/home/lefiInfo.less');
@import url('../../assets/less/home/leftInfoMedia.less');
</style>

