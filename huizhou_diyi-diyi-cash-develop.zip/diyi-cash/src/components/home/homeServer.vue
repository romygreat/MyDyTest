<!--
 * @Author: 叶锦荣
 * @Date: 2019-12-27 10:37:31
 * @LastEditTime : 2019-12-30 12:01:18
 -->
<template>
    <div class="headerServer" > 
        <div @click="openList"  class="header" >
            <div class="frequency" >
              <i class='el-icon-message-solid frequencyImg' ></i>
              <span v-if="tips > 0" >{{tips}}</span>
            </div>
            <div v-if="tips > 0 && headerInfo.type !== 1" class="infokeyj" >
               {{headerInfo.table_name}}桌需要<span>{{serverStauts[headerInfo.type]}}</span>服务
            </div>
            <div v-else class="infokeyj"  >
                当前没有服务需求
            </div>
            <div class="buttom" > 
                 <i class='el-icon-arrow-down buttomImg' ></i>
            </div>
        </div>
        <transition name="list">
            <section class="serverList" v-show="listShow" >
                <h3>服务提醒</h3>
                <dl v-for="(item, index) in list" :key="index" >
                    <dt>
                      {{item.table_name}}桌台需要<span>{{serverStauts[item.type]}}</span>服务
                    </dt>
                    <dd>{{item.addtime}}</dd>
                    <div @click="toServerStatus(item)" :style="item.status === 1 ? 'background:#b6b6b6' : ''" >{{item.status === 0 ? '去服务' : '已服务'}}</div>
                </dl>
                <div class="footerButtom" >
                    <div>
                        <div @click="deleteShow = true" class="clear" >
                            <i class="el-icon-delete-solid"></i>
                        </div>
                        <section class="paging" >
                            <div @click="switchPage('nextOff')" :style=" nextOff ? 'background:#FE7622;border-color:#FE7622' : ''" class="paingBox" >
                                <i class="el-icon-arrow-left" ></i>
                            </div>
                            <div class="info" >
                                <span>{{resdata.page}}</span>
                                / {{ Math.ceil(total / resdata.rows)}}
                            </div>
                            <div @click="switchPage('upperOff')" :style="  upperOff ? 'background:#FE7622;border-color:#FE7622' : ''" class="paingBox">
                               <i class="el-icon-arrow-right" ></i>
                            </div>
                        </section>
                    </div>
                </div>
            </section>
        </transition>
        <el-dialog title="清空提醒" custom-class="del-dialog" center :visible.sync="deleteShow" width="20%">
            <p>
                此操作为
                <span style="color:#FE7622;font-weight: bold;">清空整个服务提醒列表！</span>
            </p>
            <p>确认是否清空?</p>
            <span slot="footer" class="dialog-footer">
                <el-button @click="deleteShow = false">取 消</el-button>
                <el-button type="primary" @click="clearInfo()">确定</el-button>
            </span>
        </el-dialog>
    </div>
</template>
<script>
import { listService , modifyService,dellogList } from "@/api/tips"
import { getStautsText } from '@/libs/util'
export default {
    data(){
        return{
            resdata:{
                rows:8,
                page:1,
                sort: {
                 status:'dec',
                 addtime: 'desc'
                }
            },
            list:[],
            total:0,
            serverStauts:{},
            listShow:false,
            headerInfo:{},
            nextOff:false,
            upperOff:false,
            deleteShow:false
        }
    },
    methods:{
        openList(){
            if(this.total === 0) {
                return
            }
            this.listShow = !this.listShow
        },
        /** 
         * @description 信息提醒列表
         */
        async tolist(){
            let res = (await listService(this.resdata)).data.data
            this.list = res.list
            this.total = res.total
            if(res.list.length) {
                this.headerInfo.table_name = res.list[0].table_name
                this.headerInfo.type =  res.list[0].type
            }
            this.pageStatus()
        },
        /**
         * @description 服务状态更改
         */
        async toServerStatus(item){
            if(item.status == 1) {
                return
            }
            const data = {
                id:item.id,
                 status: 1
            }
            let res = (await modifyService(data)).data
            this.$notify({
                title: res.code === 1 ? '成功' : '失败',
                message: res.code === 1 ? '该消息已经成功置为已阅。' : `${res.message}`,
                type:res.code === 1 ? 'success' : 'warning'
            })
            await this.tolist()
            this.$emit('localTables',true)
        },
        /**
         * @description 分页判断
         */
        pageStatus(){
            if (this.resdata.page == 1) {
                this.nextOff = false
                //而且当总数大于页码 * 条数
                if (this.total > this.resdata.rows * this.resdata.page) this.upperOff = true
                else this.upperOff = false
            }
            // 当页码非1得时候
            else {
                this.nextOff = true
                if (
                this.total > this.resdata.rows * this.resdata.page &&
                Math.ceil(this.resdata.rows * this.resdata.page) > 1
                )
                this.upperOff = true
                else this.upperOff = false
            }
        },
        /**
         * @description 页面切换
         */
        switchPage(type) {
            if(type === 'nextOff' && this.nextOff === true) {
                this.resdata.page--
                this.tolist()
            }
            if (type === 'upperOff' && this.upperOff === true) {
                 this.resdata.page++
                 this.tolist()
            } 
        },
        /**
         * @descrtiption 一键清除全部信息
         */
        async clearInfo(){
            let res = (await dellogList({})).data
             this.$notify({
                title: res.code === 1 ? '成功' : '失败',
                message: res.code === 1 ? '服务列表已经清空' : `${res.message}`,
                type:res.code === 1 ? 'success' : 'warning'
            })
            await this.tolist()
            this.listShow = false
            this.deleteShow = false
            this.$emit('localTables',true)
        }
    },
    computed:{
        tips(){
          return this.$store.state.tipsNum
        }
    },
    watch:{
        tips:{
            handler(n,o) {
              this.tolist()
              this.$emit('localTables',true)
            }
        }
    },
    mounted(){
        this.serverStauts = getStautsText('service.type')
        this.tolist()
    }
}
</script>
<style lang="less" scoped>
@import url('../../assets/less/home/homeServer.less');
@import url('../../assets/less/home/dialog.less');
</style>
<style  scoped >
.list-enter-active, .list-leave-active {
  transition: opacity .5s;
}
.list-enter, .list-leave-to /* .list-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>