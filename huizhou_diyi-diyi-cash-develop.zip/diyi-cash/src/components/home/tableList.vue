<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-30 08:46:51
 * @LastEditTime : 2019-12-30 14:28:12
 -->
<template>
  <div class="tableList">
    <header v-if="subaList.list.length">
      <dl>
        <dd
          @click="setSubareaId(item.id)"
          :class="tablsRes.subarea_id == item.id ? 'use' : ''"
          v-for="(item,idx) in subaList.list"
          :key="idx"
        >{{item.title}}</dd>
      </dl>
      <topPaging
        top="14"
        right="20"
        v-on:setTopPage="setTopPage($event)"
        :row="subaRes.rows"
        :page="subaRes.page"
        :total="subaList.total"
      />
    </header>
    <section class="parameter">
        <dl v-for="(item, index) in tablsListPar" :key="index">
          <span v-if="index != 0"></span>
          <dt>{{item.name}}</dt>
          <dd>({{item.value}})</dd>
        </dl>
        <div v-if="homeServerShow" class="serverInfo" >
          <homeServer v-on:localTables='localTables($event)' />
        </div>
    </section>
    <section class="table">
      <dl>      
        <dd
          @click="clickTime(item,idx)"
          @touchstart="showDeleteButton(item,idx)"
          @mousedown="showDeleteButton(item,idx)"
          @mouseup="emptyTime"
          @touchend="emptyTime"
          :class="{ 'tablesUse' : item.status == 1,'tablesActive' : useTable == idx,'tablesSub':item.status == 2, 'orderSucc' : item.order_status == 1 }"
          v-for="(item,idx) in tablsList"
          :key="idx"
        >
          <img v-if="item.is_new && item.is_new === 1" class="isnewOrderImg"  :src="isnewOrder" >
          <img v-if="item.append && item.append === 1" class="isnewAddImg" :src='isnewAdd' />
          <img v-if="item.type"  class="isServerImg" :src="tablesServer" alt="" srcset="">
          <img class="isUseImg"   v-if=" useTable == idx" :src="isUse" alt="" srcset="">
          <h3>{{item.title}}</h3>
          <p v-if="item.status!=0">
            <span>￥</span>
            {{points(item.money)}}
          </p>
          <h4 v-if="item.order">{{tablesOrderStatus[item.order[0].status]}}</h4>
          <h4 v-else>{{item.order_status_val?item.order_status_val:stateAarry[item.status]}}</h4>
          <span>{{item.tableware_num ? item.tableware_num : 0}} / {{item.people_num}}</span>
        </dd>
        <dd class="add_new-table" @click="OpenNewTableDialog">
          <img :src="add" alt />
        </dd>
        <div class="page" v-if="showPaing==true">
          <Paging
            v-on:setPage="setPage($event,'menu')"
            :rows="tablsRes.rows"
            :page="tablsRes.page"
            :total="tablsTotal"
          />
        </div>
        <h3 v-if="tablsList.length == 0">抱歉! 找不到有关记录</h3>
      </dl>
      <transition name="keyboard">
        <keyboard
          @sendInput="getInput"
          v-if="isKeyboardShow"
          class="table-keyboard"
          :inputItem="tablsRes.search"
        />
      </transition>

      <section class="tableButoom">
        <div id="table-input">
          <el-input
            :maxlength="40"
            placeholder="输入台桌名称搜索"
            clearable
            @change="getTablesList"
            v-model="tablsRes.search"
            @focus="getSystem()"
            :readonly="isReadonly"
          >
            <template slot="prepend">
              <img :src="search" />
            </template>
            <template slot="append">
              <img :src="key" />
            </template>
          </el-input>
        </div>
        <div>
          <el-button @click="checkTableStatus(1)" class="no-pay-button">
            已结账
            <p v-if="orderCalcS !== 0">{{orderCalcS}}</p>
          </el-button>
        </div>

        <div>
          <el-button @click="checkTableStatus(0)" class="no-pay-button">
            未结账
            <p v-if="orderCalcN !== 0">{{orderCalcN}}</p>
          </el-button>
        </div>
        <div>
          <el-button @click="openStage('清台')">清 台</el-button>
        </div>

        <div>
          <el-popover placement="top" popper-class="more-btn" width="90" trigger="click">
            <!-- <el-button>拼 台</el-button> -->
            <el-button @click="isChange()">换 台</el-button>
            <el-button @click="mergeOrder()">合 单</el-button>
            <el-button slot="reference">更 多</el-button>
          </el-popover>
        </div>
      </section>
      <!-- 换台弹窗 -->
      <el-dialog
        title="可换台桌"
        custom-class="change-dialog"
        center
        :visible.sync="modal1"
        width="20%"
      >
        <ul class="changeList">
          <div class="change-details">
            <span
              @click="avgChangeTables({id:''},'all','change');"
              :class="allchangetitleoff == false ? 'usechangetitie' : '' "
            >全部</span>
            <span
              :class="changetitleUSE == index && allchangetitleoff == true ? 'usechangetitie' : ''"
              @click="avgChangeTables(item,index,'change');"
              v-for="(item,index) in reschangedatatitle"
              :key="index"
            >{{item.title}}</span>
          </div>
          <topPaging
            top="-6"
            right="20"
            v-on:setTopPage="setChangePage($event)"
            :row="subaRes.rows"
            :page="subaRes.page"
            :total="subaList.total"
          />
          <div v-if="reschangedata.length > 0" class="changeList-li" style="border:none;">
            <li
              :class="changeTablesUSE == index ? 'usechangelist' : '' "
              @click="checkTable(item,index,'change')"
              v-for="(item,index) in reschangedata"
              :style="item.status==1?'cursor: not-allowed;color:#e6e6e7':'cursor:pointer'"
              :key="index"
            >
              <img :src="gouhao2" />
              {{item.title}}
            </li>
            <div class="page">
              <Paging
                class="changeBtn"
                v-if="changePaing==true"
                v-on:setPage="setPage($event,'change')"
                :rows="reschangeTablse.rows"
                :page="reschangeTablse.page"
                :total="changeTotal"
              />
            </div>
          </div>
          <div v-else>
            <h3 class="changeListOffTables">该区域暂时没有台桌</h3>
          </div>
        </ul>
        <span slot="footer" class="dialog-footer">
          <el-button @click="modal1 = false">取 消</el-button>
          <el-button type="primary" @click="openStage('换台')">确 认</el-button>
        </span>
      </el-dialog>
      <!-- 合单弹窗 -->
      <el-dialog
        title="选择合单台桌"
        custom-class="change-dialog"
        center
        :visible.sync="modal2"
        width="20%"
      >
        <ul class="changeList">
          <div v-if="mergeTable&&mergeTable.length > 0" class="changeList-li" style="border:none;">
            <li
              :class="mergeTableIndex == index  ? 'usechangelist' : '' "
              @click="checkTable(item,index,'merge')"
              v-for="(item,index) in mergeTable"
              :style="item.status==0?'cursor: not-allowed;color:#e6e6e7':'cursor:pointer'"
              :key="index"
            >
              <img :src="gouhao2" />
              {{item.title}}
            </li>
          </div>
          <div v-else>
            <h3 class="changeListOffTables">该区域暂时没有台桌</h3>
          </div>
        </ul>
        <span slot="footer" class="dialog-footer">
          <el-button @click="modal2 = false">取 消</el-button>
          <el-button type="primary" @click="openStage('合单')">确 认</el-button>
        </span>
      </el-dialog>
      <!-- 新台桌添加 -->
      <el-dialog
        title="添加新桌台"
        custom-class="new-table-dialog"
        center
        :visible.sync="newTable"
        width="10%"
        @close="removePramrs()"
      >
        <el-form
          class="add-table-form"
          :model="newTableParams"
          :rules="rules"
          ref="newTableParams"
          label-width="80px"
        >
          <el-form-item label="桌台名称" prop="title">
            <el-input clearable :maxlength="40" v-model="newTableParams.title"></el-input>
          </el-form-item>
          <el-form-item label="厅面楼层" prop="subarea_id">
            <el-select
              clearable
              popper-class="select-center"
              v-model="newTableParams.subarea_id"
              placeholder="请选择厅面楼层"
            >
              <el-option
                v-for="item in tableDetails"
                :key="item.id"
                :label="item.title"
                :value="item.id"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="可坐人数">
            <el-input-number :min="1" :max="99" v-model="newTableParams.people_num"></el-input-number>
          </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
          <el-button @click="newTable = false">取 消</el-button>
          <el-button type="primary" @click="addNewTableAndOpenNewTable">确 认</el-button>
        </span>
      </el-dialog>
    </section>
    <numberSelect
      v-on:clearEdlog="clearEdlog($event)"
      v-on:setEdlog="setEdlog($event)"
      v-if="numberSelectPros.show"
      :unit="numberSelectPros.unit"
      :title="numberSelectPros.title"
      :show="numberSelectPros.show"
    />
  </div>
</template>

<script>
import { replacementOrder, printerList } from '@/api/printer'
import xuanzhong from '@/assets/img/xuanzhong.png'
import gouhao2 from '@/assets/img/gou2.png'
import search from '@/assets/img/search.png'
import key from '@/assets/img/key.png'
import add from '@/assets/img/add.png'
import isnewOrder from "@/assets/img/isnewOrder.png"
import isnewAdd from "@/assets/img/isnewAdd.png"
import isUse from "@/assets/img/isUse.png"
import tablesServer from "@/assets/img/tablesServer.png"
import {
  setShopTable,
  listSubarea,
  getStatus,
  openShopTable,
  changeShopTable,
  closeShopTable,
  setOrder,
  saveShopTable,
  statisticsStatus
} from '@/api/home'
import {
  getStautsText,
  Twopoints,
  setStautsText,
  setSessionStorage,
  getSessionStorage,
  getKeyShow
} from '@/libs/util'
import Calc from 'number-precision'
import numberSelect from '_c/common/numberSelect'
import Paging from '_c/common/paging'
import Keyboard from '_c/common/keyboard'
import { get } from 'http'
import { orderMerge, busyTable, delShopTable } from '@/api/order'
import topPaging from '_c/common/topPaging'
import homeServer from "_c/home/homeServer"
export default {
  components: { numberSelect, Paging, Keyboard, topPaging,homeServer },
  props: ['newTabesInfo'],
  data() {
    return {
      tablesServer,
      isnewAdd,
      isUse,
      isnewOrder,
      orderCalcS:0,
      orderCalcN:0,
      keyShow: false,
      loading: false,
      xuanzhong,
      gouhao2,
      key,
      search,
      add,
      stateAarry: [],
      tablesOrderStatus: {},
      tablsRes: {
        page: 1,
        rows: 26,
        sign: 'table',
        search: '',
        subarea_id: '',
        sort: { sort: 'asc', id: 'asc' }
      },
      tableState: '',
      tablsList: [],
      tablsTotal: 0,
      changeTotal: 0,
      tablsState: {},
      tablsOrder: {},
      subaRes: {
        page: 1,
        rows: 6,
        sort: {
          sort: 'asc'
        }
      },
      subaResTable: {
        page: '',
        rows: ''
      },
      subaList: {
        list: [],
        total: ''
      },
      useTable: 0,
      tableId: '',
      timersClick: 0,
      timers: '',
      numberSelectPros: {
        title: '',
        show: false,
        unit: ''
      },
      modal1: false,
      reschangedatatitle: [],
      reschangeTablse: {
        page: 1,
        rows: 23,
        sign: 'table'
      },

      reschangedata: [],
      tableNo: '',
      changeNo: '0',
      allchangetitleoff: false,
      changetitleUSE: '0',
      changeTablesUSE: '0',
      mergeTableIndex: [],
      modal2: false,
      mergeTablse: {
        page: 1,
        rows: 23
      },
      mergeDetalisoff: false,
      mergeDetalis: '0',
      mergeTable: [],
      mergeTableNo: [],
      setOrderRes: {
        id: 0,
        trade_no: 0
      },
      orderStatus: {},
      showPaing: true,
      changePaing: true,
      targetbtn: 2,
      isReadonly: false,
      tablsListPar: [],
      newTable: false,
      newTableParams: {
        title: '',
        subarea_id: '',
        machine_id: '',
        status: 0,
        people_num: 1,
        sort: ''
      },
      switchSta: '',
      tableDetails: [],
      timeout: null,
      rules: {
        title: [{ required: true, message: '输入新的台桌名', trigger: 'blur' }],
        subarea_id: [
          { required: true, message: '请选择厅面楼层', trigger: 'change' }
        ]
      },
      Loop: null,
      homeServerShow:false
    }
  },
  methods: {
    setSubareaId(v) {
      /**
       *  @param {String} v 传递过来的台桌分类
       *  **/

      if (v || v != '') {
        this.tablsRes.subarea_id = v
        this.tablsRes.page = 1
      } else {
        this.tablsRes = {
          page: 1,
          rows: 26,
          sign: 'table',
          search: '',
          subarea_id: '',
          machine: 'shop',
          sort: { sort: 'asc', id: 'asc' }
        }
      }
      this.getTablesList()
    },
    async getTablesList(type) {
      let data = {}
      // 换台
      if (type == 'change') {
        data = this.reschangeTablse
      } else {
        data = this.tablsRes
      }
      await setShopTable(data).then(res => {
        /** *
         *  获取台桌列表
         *  @param {Aarry} tablsList 台桌列表
         *  @param {object} tablsState 所有台桌状态
         *  @param {boject} tablsOrder 所有台桌订单信息
         *  @param {Number} tablsTotal 所有台桌的总数（分页用）
         */
        if (type == 'change') {
          if (res.data.data.list) {
            this.reschangedata = res.data.data.list
            this.changeTotal = res.data.data.total

            /**
             * 每一页的数量*页数>总数
             */
            if (
              this.reschangeTablse.rows * this.reschangeTablse.page <
              this.changeTotal
            ) {
              this.changePaing = true
            } else {
              if (this.reschangeTablse.page > 1) {
                this.changePaing = true
              } else {
                this.changePaing = false
              }
            }
          } else {
            this.reschangedata = []
          }
        } else {
          this.tablsTotal = res.data.data.total
          if (this.tablsRes.rows * this.tablsRes.page > this.tablsTotal) {
            if (this.tablsRes.page > 1) {
              this.showPaing = true
            } else {
              this.showPaing = false
            }
          } else {
            this.showPaing = true
          }
          if (res.data.data.list) {
            this.tablsList = res.data.data.list
            for (let i = 0; i < this.tablsList.length; i++) {
              if (this.tablsList[i].order_status != undefined) {
                if (this.tablsList[i].order_status == 0) {
                  this.tablsList[i].order_status_val = '待结账'
                } else {
                  this.tablsList[i].order_status_val = '已结账'
                }
              }
            }
          } else {
            this.tablsList = []
          }
          if (res.data.data.status) {
            this.tablsState = res.data.data.status
          }

          let sulf = {
            order: res.data.data.order,
            state: res.data.data.status
          }

          this.$store.commit('setAllTableState', sulf)

          // 获取当前索引，绑定所选订单数值
          if (type === 'mounted') {
            this.$store.commit('setUseTable_no', this.tablsList[0].title)
            this.useTable = 0
            this.tableId = this.tablsList[0].id
          }
          this.toListSubarea()
        }
      })
    },
    setPage(res, type) {
      /**
       * 由分页组件 paging 传递过来的参数，指挥上下翻页
       *  @param {String} res 标识  next ： 上一页  upper ： 下一页
       */
      if (type == 'menu') {
        if (res === 'next') this.tablsRes.page--
        else this.tablsRes.page++
        this.getTablesList()
      } else if (type == 'change') {
        if (res === 'next') this.reschangeTablse.page--
        else this.reschangeTablse.page++
        this.getTablesList('change')
      }
    },
    setTopPage(res) {
      if (res === 'next') {
        this.subaRes.page--
      } else {
        if (
          this.subaRes.page == 1 &&
          this.subaRes.page * this.subaRes.rows > this.subaList.total
        ) {
          return
        } else {
          this.subaRes.page++
        }
      }
      this.getListSubarea('menu')
      this.tablsRes.subarea_id = ''
      this.getTablesList()
    },
    setChangePage(res) {
      if (res === 'next') this.subaRes.page--
      else this.subaRes.page++
      this.getListSubarea('change')
      this.reschangeTablse.subarea_id = ''
      this.getTablesList('change')
    },
    async getListSubarea(type) {
      let data = {}
      if (type == 'menu') {
        data = this.subaRes
      } else if (type == 'change') {
        data = this.subaRes
      }
      await listSubarea(data).then(res => {
        /**
         * 获取台桌分类
         * @param {Aarry} subaList.list 台桌分类
         * @param {Number} subaList.total 分类总数
         */
        if (type == 'menu') {
          let allObj = { id: '', title: '全部' }
          this.subaList.list = [allObj, ...res.data.data.list]

          this.subaList.total = res.data.data.total
        } else if (type == 'change') {
          this.reschangedatatitle = res.data.data.list
          this.subaList.total = res.data.data.total
        }
      })
    },
    clickTime(item, index) {
      /**
       * 分发单双击事件
       * @param {Number} this.timersClick  1 : 单机  2 ：双击
       * @param {String} this.timers  开关
       * @param {Number} this.useTable 当前台桌
       * **/

      this.useTable = index
      this.tableId = item.id
      this.timersClick++
      this.$store.commit('setUseTable_no', item.title)
      this.tableState = item.status
      if (this.timers) {
        clearTimeout(this.timers)
      }
      this.timers = null
      this.timers = setTimeout(() => {
        if (this.timersClick == 1) {
          this.timersClick = 0
        }
      }, 300)
      if (this.timersClick === 2) {
        this.timersClick = 0
        //如果当前台桌未处于开台的情况下
        if (item.status == 0) {
          this.numberSelectPros.title = '选择人数'
          this.numberSelectPros.show = true
          this.numberSelectPros.unit = '人'
          return
        }
        this.$router.push({ name: 'menu' })
      }
    },
    points(v) {
      /**
       * 精确转小数点后两位
       * @param {String || Number} v 要转化参数
       */
      v = Calc.divide(v, 100)
      return Twopoints(v)
    },
    setEdlog(res) {
      /**
       * 来自数字选择组件 numberSelect 同时进行开台操作
       * @param {Number} res(session) 获取的参数，开台人数
       * :备注 2019.10.10 叶：这里后期我打算改成先写入接口，
       *  利用setOrder接口储存人数，防止刷新
       * **/

      setSessionStorage('table_num', res)
      setSessionStorage('service_num', 1)
      const data = {
        title: this.tablsList[this.useTable].title
      }
      // 开台
      openShopTable(data).then(res => {
        if (res.data.code == 1) {
          this.getTablesList()
          this.$router.push({ name: 'menu' })
          this.numberSelectPros.show = res
        }
      })
    },
    clearEdlog(res) {
      /**
       *  来自数字选择组件 numberSelect 的关闭请求
       *  @param {Boolean} res false
       *  **/

      this.numberSelectPros.show = res
    },

    getBusyTables() {
      /**
       * 当前桌台之外的所有就餐台桌
       * 在合单上使用
       */
      this.mergeTablse.id = this.tableId
      busyTable(this.mergeTablse).then(res => {
        if (res.data.data == []) {
          this.mergeTable = []
        } else {
          this.mergeTable = res.data.data.list
        }
      })
    },
    avgChangeTables(item, index, type) {
      /**
       * 切换分类
       * @param{object} item切换分类
       * @param{string} index分类索引
       *  @param{string} 操作的动作：换台、合单
       *
       */
      if (type == 'change') {
        if (index == 'all') {
          this.allchangetitleoff = false
        } else {
          this.changetitleUSE = index
          this.allchangetitleoff = true
        }
        this.reschangeTablse.subarea_id = item.id
        this.reschangeTablse.page = 1
        this.getTablesList('change')
      } else if (type == 'merge') {
        if (index == 'all') {
          this.mergeDetalisoff = false
        } else {
          this.mergeDetalis = index
          this.mergeDetalisoff = true
        }
        this.mergeTablse.subarea_id = item.id
        this.getBusyTables()
      }
    },
    isChange() {
      /**
       * 开启换台
       * @param {object}  tablesinfoList 换台时获取的选中台桌
       * @param {Boolean} modal1  打开台桌选择弹框
       */
      let tablesinfoList = getSessionStorage('myOrder')
      if (tablesinfoList.order_no == undefined) {
        this.$notify.error({
          title: '错误',
          message: '该台桌未下单，暂不能进行换台操作'
        })
      } else {
        this.getListSubarea('change')
        this.getTablesList('change')
        this.modal1 = true
      }
    },
    mergeOrder() {
      /**
       * 合单
       */
      if (getSessionStorage('myOrder').table_no) {
        this.getBusyTables()
        this.modal2 = true
      } else {
        this.$notify.error({
          title: '错误',
          message: '该台桌未下单，暂不能进行合单操作'
        })
      }
    },
    checkTable(item, index, type) {
      if (type == 'change') {
        if (item.status == 0) {
          this.changeTablesUSE = index
          this.tableNo = item.title
        }
      } else if (type == 'merge') {
        this.mergeTableIndex = index
        this.setOrderRes.table_no = item.title
        setOrder(this.setOrderRes).then(res => {
          this.mergeTableNo = res.data.data
        })
      }
    },
    openStage(type) {
      /**
       * 执行换台
       * @param {String} type 清台、换台等动作标识
       * @param {String} change 换后的台桌
       * @param {String} title2 当前的台桌
       * @param {boolean} title 弹窗开关
       */
      if (type == '换台') {
        const data = {
          title: this.tableNo,
          change: getSessionStorage('myOrder').table_no,
          order_id: this.tablsList[this.useTable].order_id
        }
        changeShopTable(data).then(res => {
          this.$notify.success({
            title: '成功',
            message: res.data.message
          })
          this.useTable = this.changeTablesUSE
          this.$store.commit('setUseTable_no', this.tableNo)
          setSessionStorage('myOrder', {})
          this.modal1 = false
          this.getTablesList()
          if (window.android) {
            let sulf = res.data.data
            // sulf.printer.forEach((el, idx) => {
            window.android.printOneOrder(0, JSON.stringify(sulf))
            // })
          }
        })
      } else if (type == '清台') {
        let data = {}
        if (getSessionStorage('myOrder').table_no == undefined) {
          if (this.tableState != 0) {
            data = {
              title: this.$store.state.useTable_no,
              pwd: '123456'
            }
          } else {
            this.$notify.error({
              title: '错误',
              message: '该台桌未下单，暂不能进行清台操作'
            })
            return
          }
        } else {
          data = {
            title: getSessionStorage('myOrder').table_no,
            pwd: '123456'
          }
        }
        closeShopTable(data).then(res => {
          if (res.data.code == 1) {
            this.$notify.success({
              title: '成功',
              message: res.data.message
            })
            this.getTablesList()
          } else {
            this.$notify.error({
              title: '错误',
              message: res.data.message
            })
          }
        })
      } else if (type == '合单') {
        if (this.mergeTableNo == null) {
          this.$notify.error({
            title: '错误',
            message: '合单的台桌未下单，请下单后再合单'
          })
          return
        } else {
          const data = {
            order_id: getSessionStorage('myOrder').id,
            z_order_id: this.mergeTableNo.id
          }

          orderMerge(data).then(res => {
            if (res.data.code == 1) {
              let newNum =
                Number(getSessionStorage('myOrder').tableware_num) +
                Number(this.mergeTableNo.tableware_num)
              setSessionStorage('table_num', newNum)
              setSessionStorage(
                'service_num',
                getSessionStorage('service_num') + 1
              )
              this.useTable = 0
              this.$store.commit('setUseTable_no', this.tablsList[0].title)
              this.$notify.success({
                title: '成功',
                message: '合单成功'
              })
              this.modal2 = false
              this.getTablesList()
            }
          })
        }
      }
    },
    getInput(item) {
      this.tablsRes.search = item.value
    },
    checkTableStatus(val) {
      this.tablsRes.status = val
      this.tablsRes.sign = 'order'
      this.tablsRes.page = 1
      this.getTablesList()
    },
    getSystem() {
      let version = navigator.userAgent.toLocaleLowerCase()
      let isWin = version.indexOf('windows') > -1 ? true : false
      if (isWin) {
        this.isReadonly = false
      } else {
        this.isReadonly = true
      }
    },
    tableParams() {
      /**
       * 处理全台桌状态参数数组化
       * @param {Object} allTableState.state(vuex) 当前全台桌的参数
       * @param {Aarry} this.tablsListPar 转化后的数组，方便DOM简洁
       * **/
      this.tablsListPar = []
      let oxy = JSON.parse(sessionStorage.getItem('allTablesState'))
      let keyOff = 0
      let keyname = ''
      for (let i in oxy) {
        if (i == 'all') keyname = '全部'
        if (i == 'leisure') keyname = '空闲'
        if (i == 'unpaid') keyname = '待结账'
        if(i === 'paid') keyname = '已结账'
        if (i == 'subscribe') keyname = '预约'
        this.tablsListPar.push({ name: keyname, value: oxy[i] })
      }
    },
    getTableDetails(v) {
      if (v) {
        this.subaResTable.page += 1
      }
      listSubarea(this.subaResTable).then(res => {
        this.tableDetails = res.data.data.list
      })
    },
    addNewTableAndOpenNewTable() {
      /**
       * 新添加台桌并开台
       */
      if (this.newTableParams.title == '') {
        this.$notify.error({
          title: '出错',
          message: '新添加的台桌名称不能为空'
        })
        return
      }
      if (this.newTableParams.subarea_id == '') {
        this.$notify.error({
          title: '出错',
          message: '请选择厅面楼层'
        })
        return
      }
      this.newTableParams.shop_id = this.$store.state.adminInfo.shop.id
      saveShopTable(this.newTableParams).then(res => {
        if (res.data.code == 1) {
          /**
           * 添加成功
           * 跳转到添加的桌台分类的列表
           */
          this.getTablesList()
          this.newTable = false
        }
      })
    },
    removePramrs() {
      this.newTableParams = {
        title: '',
        subarea_id: '',
        machine_id: '',
        status: 0,
        people_num: 1,
        sort: ''
      }
    },
    OpenNewTableDialog() {
      this.newTable = true
      this.getTableDetails()
      this.newTableParams.subarea_id = this.tablsRes.subarea_id
    },
    // 传给阿明数组
    async toPrinter() {
      if (window.android) {
        if (this.$store.state.isPrinter.length) {
        } else {
          let res = (await printerList({})).data
          this.$store.commit('setIsPrinter', res.data.list)
          window.android.getIpList(JSON.stringify(res.data.list))
        }
      }
    },
    // 长按弹出删除桌台的操作
    showDeleteButton(item) {
      clearTimeout(this.Loop)
      const data = {
        id: item.id,
        shop_id: this.shopId
      }
      this.Loop = setTimeout(
        async function() {
          this.$confirm('是否删除该桌台？', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning ',
            customClass: 'calction'
          })
            .then(() => {
              console.log(this.shopId)

              if (item.status != 0) {
                this.$notify.error({
                  title: '出错',
                  message: '该桌台正在使用中，不能进行删除操作'
                })
                return
              } else {
                delShopTable(data).then(res => {
                  console.log(res)
                  if (res.data.code == 1) {
                    this.$notify.success({
                      title: '成功',
                      message: '该桌台已被删除'
                    })
                    this.getTablesList()
                  }
                })
              }
            })
            .catch(() => {
              console.log('取消删除')
            })
        }.bind(this),
        1000
      )
    },
    // 取消长按的计时器
    emptyTime() {
      clearTimeout(this.Loop)
    },
    /** 
     * @description 获取当前台桌状态
     */
    async toListSubarea(){
      let sulf = (await statisticsStatus({})).data.data
      this.orderCalcS = sulf.paid
      this.orderCalcN = sulf.unpaid
      sessionStorage.setItem('allTablesState', JSON.stringify(sulf))
      this.tableParams()
    },
    localTables(res) {
      this.getTablesList()
    },
    /**
     * @description 去掉台桌列表的 新 || 加 状态
     */
    async clearTablesAddOrNew(){
     if(this.order.is_new == 1) {
       const data = {
         id:this.order.id,
         is_new:0,
         append:0
       }
       let res = await modifyBaseInfo(data)
     }
    } 
  },
  mounted() {
    this.toPrinter()
  },
  async created() {
    let res = await getStatus({})
    setStautsText(res.data.data)
    this.$store.commit('setAllStatus', res.data.data)
    this.homeServerShow = true
    this.tablsListPar = []
    this.stateAarry = getStautsText('shop_table.status')
    this.tablesOrderStatus = getStautsText('order.status')
    await this.getTablesList('mounted')
    this.getListSubarea('menu')
    this.orderStatus = getStautsText('order.status')
    this.toListSubarea()
  },
  computed: {
    isKeyboardShow() {
      return this.$store.state.keyshow
    },
    tables_no() {
      return this.$store.state.useTable_no
    },
    monitorList() {
      return this.$store.state.monitorList.order
    },
    clearTablesInfoKey() {
      return this.$store.state.monitorList.table
    },
    shopId() {
      return this.$store.state.adminInfo.shop.id
    }
  },
  watch: {
    newTabesInfo: {
      handler(n, o) {
        if (n == true) {
          this.$emit('regression', false)
          this.getTablesList()
        }
      },
      deep: true
    },
    'tablsRes.search': {
      handler(n, o) {
        if (n != o) {
          this.tablsRes.page = 1
          this.getTablesList()
        }
      }
    },
    monitorList: {
      handler(n, o) {
        if (n == 1) this.getTablesList()
      }
    },
    clearTablesInfoKey: {
      handler(n, o) {
        if (n == 1) this.getTablesList()
      }
    }
  }
}
</script>

<style lang="less" scoped>
@import url('../../assets/less/home/tableList.less');
@import url('../../assets/less/home/tableListMedia.less');
</style>
<style>
@import url('../../assets/less/home/dialog.less');
/** 针对UI控件无法使用内嵌样式
*/
.more-btn {
  width: 120px !important;
  height: 100px !important;
  min-width: 90px !important;
  display: flex;
  flex-flow: column;
}
.more-btn button {
  width: 100%;
  height: 50px;
  margin-bottom: 5px !important;
  color: #333;
  margin-left: 0 !important;
  font-size: 16px !important;
  border: none;
}
.more-btn button:hover,
.more-btn button:active,
.more-btn button:focus {
  color: #fe7622 !important;
  border: none;
  background-color: #fff !important;
}

.more-btn button:not(:first-child) {
  margin-top: 6px;
}
.tableButoom .el-input {
  width: 372px !important;
  display: flex !important;
  height: 52px !important;
  float: left;
}
@media screen and (max-width: 1280px) {
  .tableButoom .el-input {
    width: 370px !important;
  }
}
.tableButoom .el-input__suffix span i {
  font-size: 24px !important;
  line-height: 40px;
}
.tableButoom .el-input input {
  height: 100% !important;
  border-color: #fff !important;
}
.tableButoom .el-input .el-input-group__append {
  padding: 0 !important;
  padding-right: 16px !important;
}
.tableButoom .el-input .el-input-group__prepend {
  padding: 0 !important;
  padding-left: 16px !important;
}
.tableButoom .el-input .el-input-group__prepend,
.tableButoom .el-input .el-input-group__append {
  width: 32px !important;
  box-sizing: border-box;
  border-color: #fff !important;
  height: 52px;
  display: flex;
  align-items: center;
  background-color: #fff !important;
  outline: none !important;
}
.tableButoom .el-input .el-input-group__prepend img {
  width: 20px;
  height: 20px;
  margin: auto 0;
  padding: 0;
}
.tableButoom .el-input .el-input-group__append img {
  width: 24px;
  height: 22px;
  margin: auto 0;
  padding: 0;
}
.tableButoom .el-button,
.tableButoom .el-button:hover,
.tableButoom .el-button:active,
.tableButoom .el-button:focus {
  display: block !important;
  height: 52px !important;
  width: 120px !important;
  color: #fe7622;
  background-color: #fff !important;
  font-size: 16px;
  color: #464c5b;
  font-weight: bold;
}
.tableButoom .el-button:active {
  border-color: #fe7622 !important;
  color: #fe7622 !important;
}
.tableButoom .no-pay-button {
  position: relative;
}
.tableButoom .no-pay-button p {
  position: absolute;
  right: -12px;
  top: -12px;
  color: #fff;
  display: block;
  background: #fe7622;
  width: 24px;
  height: 24px;
  font-size: 12px;
  text-align: center;
  line-height: 24px;
  border-radius: 50%;
}
.add-table-form .el-form-item {
  margin-bottom: 22px !important;
}
.select-center {
  text-align: center !important;
}
</style>
<style lang="less">
  .calction {
  position: absolute;
  left: 50% !important;
  top: 10vh !important;
  transform: translateX(-50%) !important;
  .el-message-box__header {
    span {
      color: #171922;
      font-size: 16px;
      font-weight: bold;
    }
  }
  .el-message-box__content {
    text-align: center;
    p {
      color: #464c5b;
      font-size: 16px;
    }
  }
  .el-message-box__btns {
    display: flex;
    button {
      flex: 1;
      color: #fff !important;
      height: 44px;
      font-size: 16px;
      font-weight: 600;
    }
    button:first-child {
      background: #171922 !important;
      border-color: #171922 !important;
      outline: none;
    }
    button:last-child {
      background: #fe7622;
      border-color: #fe7622 !important;
      outline: none;
    }
  }
}
</style>