/*
 * @Author: 叶锦荣
 * @Date: 2019-11-20 19:04:47
 * @LastEditTime : 2019-12-30 11:22:02
 */
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

// ui组件
import 'element-ui/lib/theme-chalk/index.css'
import {
  Button,
  Message,
  Input,
  Dialog,
  Notification,
  DatePicker,
  Select,
  Option,
  Pagination,
  Table,
  TableColumn,
  Form,
  FormItem,
  Switch,
  InputNumber,
  MessageBox,
  Autocomplete,
  Popover,
  Tooltip,
  Radio,
  Tree
} from 'element-ui'
Vue.use(Button)
  .use(Input)
  .use(Dialog)
  .use(DatePicker)
  .use(Select)
  .use(Option)
  .use(Option)
  .use(Pagination)
  .use(Table)
  .use(TableColumn)
  .use(Form)
  .use(FormItem)
  .use(Switch)
  .use(InputNumber)
  .use(Autocomplete)
  .use(Popover)
  .use(Tooltip)
  .use(Radio)
  .use(Tree)

Vue.prototype.$message = Message
Vue.prototype.$notify = Notification;
Vue.prototype.$confirm = MessageBox.confirm;
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')