import axios from '@/libs/axios'
// 添加或修改店铺台桌信息
// 添加或修改店铺台桌信息
export const saveShopTable = (data) => {
    return axios.request({
      url: '/shop/ShopTable/saveShopTable',
      data
    })
  }
  
  // 批量添加店铺台桌
  export const saveBatchTable = (data) => {
    return axios.request({
      url: '/shop/ShopTable/saveBatchTable',
      data
    })
  }
  
  // 删除店铺台桌信息
  export const delShopTable = (data) => {
    return axios.request({
      url: '/shop/ShopTable/delShopTable',
      data
    })
  }
  
  // 店铺台桌列表（前端下拉列表用）
  export const optionShopTable = () => {
    return axios.request({
      url: '/shop/ShopTable/optionShopTable'
    })
  }
  
  // 2.5台桌列表
  export const setShopTable = (data) => {
    return axios.request({
      url: '/shop/ShopTable/setShopTable',
      data
    })
  }