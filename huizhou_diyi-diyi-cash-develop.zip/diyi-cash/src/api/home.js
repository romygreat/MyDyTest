/*
 * @Author: 叶锦荣
 * @Date: 2019-11-12 08:49:23
 * @LastEditTime : 2019-12-27 17:23:15
 */
import axios from '@/libs/axios'

// 菜单列表
export const cateProduct = data => {
  return axios.request({
    url: '/Product/Product/cateProduct',
    data
  })
}
// 菜品分类
export const shopCate = data => {
  return axios.request({
    url: '/Product/ProductCate/shopCate',
    data
  })
}
// 台桌详情
export const setOrder = (data) => {
  return axios.request({
    url: '/order/order/setOrder',
    data
  })
}
// 台桌列表
export const setShopTable = (data) => {
  return axios.request({
    url: '/shop/ShopTable/setShopTable',
    data
  })
}
// 店铺区域列表
export const listSubarea = (data) => {
  return axios.request({
    url: '/shop/ShopSubarea/listSubarea',
    data
  })
}
// 全局储存状态
export const getStatus = data => {
  return axios.request({
    url: '/status/text/getStatusText',
    data
  })
}
//开台
export const openShopTable = (data) => {
  return axios.request({
    url: '/shop/shopTable/openShopTable',
    data
  })
}

// 2.5 换台
export const changeShopTable = (data) => {
  return axios.request({
    url: '/shop/shopTable/changeShopTable',
    data
  })
}
// 2.5 清台
export const closeShopTable = (data) => {
  return axios.request({
    url: '/shop/shopTable/closeShopTable',
    data
  })
}
// 监听轮询
export const monitor = (data) => {
  return axios.request({
    url: '/sundry/Cash/monitor',
    data
  })
}
// 服务获取
export const getService = (data) => {
  return axios.request({
    url: '/shop/shopService/getService',
    data
  })
}
// 获取商家信息  
export const getAdminInfo = (data) => {
  return axios.request({
    url: ' /account/Account/getAdminInfo',
    data
  })
}

// 添加或修改店铺台桌信息
export const saveShopTable = (data) => {
  return axios.request({
    url: '/shop/ShopTable/saveShopTable',
    data
  })
}
// 获取门店设置
export const getShop = () => {
  return axios.request({
    url: '/shop/shopSet/getShop'
  })
}
// 临时刷新门店设置
export const getShopById = () => {
  return axios.request({
    url: ' /shop/shop/getShopById'
  })
}
// 统计当前台桌状态
export const statisticsStatus = data => {
  return axios.request({
    url: '/shop/ShopTable/statisticsStatus',
    data
  })
}