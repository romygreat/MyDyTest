import axios from '@/libs/axios'

// 登录
export const login = data => {
  return axios.request({
    url: '/account/Login/userLogin',
    data
  })
}

// 登出
export const logout = () => {
  return axios.request({
    url: '/account/Login/userLogout'
  })
}
