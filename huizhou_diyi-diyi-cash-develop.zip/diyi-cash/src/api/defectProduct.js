/*
 * @Author: 叶锦荣
 * @Date: 2019-11-30 11:04:15
 * @LastEditTime: 2019-12-02 17:30:05
 */
import axios from '@/libs/axios'

// 沽清列表
export const sellOutProduct = (data) => {
    return axios.request({
        url: '/product/product/sellOutProduct',
        data
    })
}
// 沽清 修改 删除
export const operationProduct = (data) => {
    return axios.request({
        url: '/product/product/operationProduct',
        data
    })
}
// 一键删除全部沽清
export const emptyLimit = (data) => {
    return axios.request({
        url: '/product/product/emptyLimit',
        data
    })
}