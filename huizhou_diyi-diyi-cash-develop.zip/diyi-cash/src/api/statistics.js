import axios from '@/libs/axios'

// 商品排行
export const rankList = (data) => {
    return axios.request({
        url: '/statistics/Statistics/saleOrder',
        data
    })
}
// 营业报表
export const businessReport = (data) => {
    return axios.request({
        url:'/statistics/Statistics/businessReport',
        data
    })
}
//免单、退菜等异常监控
export const abnormal = (data)=>{
    return axios.request({
        url:'/statistics/Statistics/listenException',
        data
    })
}