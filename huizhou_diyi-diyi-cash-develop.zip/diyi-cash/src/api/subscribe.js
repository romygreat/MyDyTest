import axios from '@/libs/axios'

// 预约列表 - 列表
export const shopReserveList = (data) => {
    return axios.request({
        url: '/shop/ShopReserve/shopReserveList',
        data
    })
}
// 预约列表 - 修改添加
export const shopReserveSave = (data) => {
    return axios.request({
      url: '/shop/ShopReserve/shopReserveSave',
      data
    })
  }
  //删除预约
  export const shopReserveDel = (data) => {
    return axios.request({
      url: '/shop/ShopReserve/shopReserveDel',
      data
    })
  }
