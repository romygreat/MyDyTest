/*
 * @Author: 叶锦荣
 * @Date: 2019-11-20 09:00:29
 * @LastEditTime: 2019-11-27 10:19:36
 */
import axios from '@/libs/axios'

// 触发打印信息 
export const replacementOrder = data => {
  return axios.request({
    url: '/order/order/ReplacementOrder',
    data
  })
}
// 打印机列表 
export const printerList = data => {
  return axios.request({
    url: '/device/Printer/list',
    data
  })
}
//打印机添加 & 修改
export const printerSave = data => {
  return axios.request({
    url: '/device/Printer/save',
    data
  })
}
//打印机删除
export const printerDelete = data => {
  return axios.request({
    url: '/device/Printer/delete',
    data
  })
}
//打印机厂商列表
export const printerManuList = data => {
  return axios.request({
    url: '/device/PrinterManu/list',
    data
  })
}
// 轮询触发打印
export const timePrinter = data => {
  return axios.request({
    url: '/order/order/getOrderPrint',
    data
  })
}
// 获取打印单信息
export const getOrderPrint = data => {
  return axios.request({
    url: '/order/order/getOrderPrint',
    data
  })
}