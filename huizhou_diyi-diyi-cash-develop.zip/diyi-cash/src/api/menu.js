/*
 * @Author: 叶锦荣
 * @Date: 2019-10-21 13:50:24
 * @LastEditTime: 2019-12-04 16:38:48
 */
import axios from '@/libs/axios'
 
// 门店菜单列表
export const cateProduct = data => {
  return axios.request({
    url: '/Product/Product/cateProduct',
    data
  })
}
// 门店菜单分类
export const shopCate = data => {
  return axios.request({
    url: '/Product/ProductCate/shopCate',
    data
  })
}
// 下单
export const toOrder = data => {
  return axios.request({
    url: '/order/Order/toOrder',
    data
  })
}
// 获取商户支付信息
export const getPayButtom = () => {
  return axios.request({
    url: '/shop/shopSet/getShop'
  })
}
// 台桌详情
export const setOrder = data => {
  return axios.request({
    url: '/order/order/setOrder',
    data
  })
}
// 结账
export const closeOrder = data => {
  return axios.request({
    url: '/order/order/settlement',
    data
  })
}
// 修改下单后的商品状态
export const modify = data => {
  return axios.request({
    url: '/order/orderList/modify',
    data
  })
}
// 催菜
export const urgeOrderGoods = (data) => {
  return axios.request({
    url: '/order/OrderList/urgeOrderGoods',
    data
  })
}
// 原因选择
export const reasonList = (data) => {
  return axios.request({
    url: '/shop/Reason/list',
    data
  })
}
// 下单后修改参数
export const modifyOrderGoods = (data) => {
  return axios.request({
    url: '/order/orderList/modifyOrderGoods',
    data
  })
}
// 退菜
export const rdSavet = (data) => {
  return axios.request({
    url: '/order/OrderList/refund',
    data
  })
}
// 撤单
export const revokeOrder = (data) => {
  return axios.request({
    url: 'order/Order/revoke',
    data
  })
}
// 获取单位库列表
export const productUnitList = (data) => {
  return axios.request({
    url: '/product/ProductUnit/list',
    data
  })
}
// 下单后修改备注
export const modifyBaseInfo = (data) => {
  return axios.request({
    url: '/order/Order/modifyBaseInfo',
    data
  })
}
// 下单后修改单品备注
export const modifyBaseInfoProduct = (data) => {
  return axios.request({
    url: ' /order/orderList/modifyBaseInfo',
    data
  })
}

// 挂账公司列表
export const oAList = (data) => {
  return axios.request({
    url: '/order/OrdeerHangingAccounts/oAList',
    data
  })
}

// 挂账列存储 && 修改
export const oASave = (data) => {
  return axios.request({
    url: '/order/OrderArrearage/oASave',
    data
  })
}
// 下单后修改人数
export const modifyNum = (data) => {
  return axios.request({
    url: '/order/Order/modifyNum',
    data
  })
}
// 整单优惠
export const beforeSettlemen = (data) => {
  return axios.request({
    url: '/order/Order/beforeSettlement',
    data
  })
}
// 生成二维码 
export const createPayUrl = (data) => {
  return axios.request({
    url: '/Pay/Pay/createPayUrl',
    data
  })
}
// 客户被扫支付
export const scannedPay = (data) => {
  return axios.request({
    url: '/Pay/Pay/scannedPay',
    data
  })
}
// 客户被扫模式,支付结果查询
export const scannedPayResultQuery = (data) => {
  return axios.request({
    url: '/Pay/Pay/scannedPayResultQuery',
    data
  })
}
// 关闭被扫模式订单
export const closeScannedOrder = (data) => {
  return axios.request({
    url: '/Pay/Pay/closeScannedOrder',
    data
  })
}
// 监听订单是否已经支付
export const getOrderStatus = (data) => {
  return axios.request({
    url: 'order/order/getOrderStatus',
    data
  })
} 