import axios from '@/libs/axios'

// 信息列表
export const listService = (data) => {
    return axios.request({
        url: '/shop/ShopService/listService',
        data
    })
}
// 修改信息列表状态
export const modifyService = (data) => {
    return axios.request({
        url: '/shop/ShopService/modifyService',
        data
    })
}
// 信息  /order/orderlog/list
export const orderlogList = (data) => {
    return axios.request({
        url: 'order/OrderLog/list',
        data
    })
}

//  清空服务信息
export const dellogList = () => {
    return axios.request({
        url: 'shop/ShopService/delService',
    })
}
// 清空订单信息
export const delmsgList = () => {
    return axios.request({
        url: 'order/orderLog/del',
    })
}