import axios from '@/libs/axios'
// 订单列表
export const indexOrder = (data) => {
    return axios.request({
        url: '/order/order/indexOrder',
        data
    })
}
// 获取订单列表
export const orderDataButtom = (data) => {
    return axios.request({
        url: '/order/order/listOrder',
        data
    })
}
// 订单通知
export const newOrderButtom = (data) => {
    return axios.request({
        url: '/order/order/newOrder',
        data
    })
}

//  新订单提醒
export const orderTips = () => {
    return axios.request({
        url: '/order/order/newOrder'
    })
}

// 当前桌台外的其它就餐桌台
export const busyTable = (data) => {
    return axios.request({
        url: '/shop/shopTable/repasting',
        data
    })
}

// 合单
export const orderMerge = (data) => {
    return axios.request({
        url: '/order/Order/single',
        data
    })
}

// 补单打印
export const printingOrder = (data) => {
    return axios.request({
        url: '/order/order/ReplacementOrder',
        data
    })
}

// 根据台桌获取订单
export const getOrderByTable = (data) => {
    url: '/order/order/getOrderByTitile',
    data
}

// 获取订单详情
export const orderDetails = (data) => {
    url: '/order/order/detailsOrder',
    data
}

// 删除店铺台桌信息
export const delShopTable = (data) => {
    return axios.request({
      url: '/shop/ShopTable/delShopTable',
      data
    })
  }