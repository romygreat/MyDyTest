/*
 * @Author: 叶锦荣
 * @Date: 2019-11-26 09:41:07
 * @LastEditTime: 2019-11-26 09:41:29
 */
import defectProduct from './defectProduct.vue'
export default defectProduct