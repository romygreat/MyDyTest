<!--
 * @Author: 叶锦荣
 * @Date: 2019-11-26 09:40:57
 * @LastEditTime : 2019-12-20 16:35:33
 -->
<template>
  <div class="defectProduct">
    <div class="list">
      <h3>商品沽清</h3>
      <ul>
        <li v-for="(item, index) in listHeader" :key="index">{{item.name}}</li>
      </ul>
      <section>
        <dl v-for="(item, index) in list" :key="index">
          <dt>{{item.name}}</dt>
          <dd v-if="item.limit_num !== 0" >{{item.limit_num}} {{item.unit ? item.unit : '份'}}</dd>
          <dd v-else >已沽清</dd>
          <div>
            <p @click="setDefect(item)" >修改</p>
            <p @click="delInfo(item,'del')" >删除</p>
          </div>
        </dl>
      </section>
      <aside>
        <div>
          沽清菜品：
          <span>{{total}}</span>
        </div>
        <div @click="toEmptyLimit()" >
          <img :src="clearListButtom" alt srcset /> 全部删除
        </div>
      </aside> 
    </div>
    <menuList  v-on:setDefect='setDefect($event)'  :defectProduct="refresh" />
    <numberSelect
      v-on:clearEdlog="clearEdlog($event)"
      v-on:setEdlog="setEdlog($event)"
      v-if="numberIskey"
      :unit="numberSelectPros.unit"
      :title="numberSelectPros.title"
      :show="numberIskey"
      :buttomText='logText'
    />
  </div>
</template>
<script>
import clearListButtom from '@/assets/img/clearListButtom.png'
import menuList from '_c/menu/menuList'
import { sellOutProduct, operationProduct,emptyLimit } from '@/api/defectProduct'
import numberSelect from '_c/common/numberSelect'
export default {
  data() {
    return {
      clearListButtom,
      listHeader: [
        { name: '品名', type: 'name' },
        { name: '库存', type: 'number' },
        { name: '编辑', type: 'open' }
      ],
      list: [{ name: '菜品', num: 5 }],
      total: 0,
      numberIskey:false,
      numberSelectPros:{
        unit:'份',
        title:'选择沽清数量'
      },
      logText:'确认沽清',
      opendata:{},
      refresh:false
    }
  },
  components: {
    menuList,numberSelect
  },
  methods: {
    /** 
     * @description 获取沽清列表
     */
    async setSellOutProduct() {
      let res = await sellOutProduct({page:1,rows:100,is_limit:1})
      this.list = res.data.data.list
      this.total = res.data.data.total
    },
    /**
     * @description 开启弹窗
     */
    setDefect(res) {
      console.log(res,'11')
      this.numberIskey = true
      this.opendata = res
    },
    /**
     *  @description 增  删   改
     */
    async setEdlog(res,type) {
      console.log(res)
      if(type) {
        this.opendata = res
      } else {
        console.log(this.opendata.is_editable == 1,this.opendata, res !== 0)
        if(this.opendata.is_editable == 1 && res !== 0) {
          this.$notify.error({
              title: '抱歉',
              message: `商品${this.opendata.name}为称重商品，沽清值只能设为0`
          })
          return
        }
      }
       const data = {
         id:this.opendata.id,
         is_limit: type ? 0 : 1,
         limit_num:type ? 0 : res,
         operation: type ? 'del' : 'edit'
       }
       let sulf = (await operationProduct(data)).data 
       if(sulf.code === 1) {
          this.$notify({
            type: 'success',
            title: '成功',
            message: type ? `删除成功` : `已经成功对商品进行了操作`
          })
       } else {
          this.$notify({
            type: 'warning',
            title: '错误',
            message: type ? `删除失败` : '沽清失败，请联系管理员'
          })
       }
      this.setSellOutProduct()
      this.refresh = true
      setTimeout(() => {
        this.refresh = false
      },1000)
      this.numberIskey = false
    },
    /**
     * @description 关闭弹窗
     */
    clearEdlog(res) {
      this.numberIskey = false
    },
    /**
     * @description 一键删除全部沽清
     */
     toEmptyLimit(){
      this.$confirm(`是否确认删除?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning ',
        customClass: 'calction'
      })
      .then(async () => {
        let sulf = await emptyLimit({})
        console.log(sulf.data,'回调')
        if(sulf.data.code === 1) {
          this.setSellOutProduct()
          this.$notify({
            type: 'success',
            title: '成功',
            message: `已经一键全部删除了所有的沽清商品`
          })
        }  else {
          this.$notify({
            type: 'warning',
            title: '错误',
            message: '删除失败，请联系管理员'
          })
        }
      })
      .catch(() => {

      })
    },
    delInfo(item,type){
      this.$confirm(`是否确认删除?`, '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning ',
        customClass: 'calction'
      })
      .then(() => {
        this.setEdlog(item,'del')
      })
      .catch(() => {
        
      })
    }
  },
  mounted() {
    this.setSellOutProduct()
    this.numberIskey = false
  }
}
</script>
<style lang="less" scoped >

@import url('../../assets/less/defectProduct/defectProduct.less');
@import url('../../assets/less/defectProduct/defectProductMedia.less');

</style>
<style lang="less">
  .calction {
  position: absolute;
  left: 50% !important;
  top: 10vh !important;
  transform: translateX(-50%) !important;
  .el-message-box__header {
    span {
      color: #171922;
      font-size: 16px;
      font-weight: bold;
    }
  }
  .el-message-box__content {
    text-align: center;
    p {
      color: #464c5b;
      font-size: 16px;
    }
  }
  .el-message-box__btns {
    display: flex;
    button {
      flex: 1;
      color: #fff !important;
      height: 44px;
      font-size: 16px;
      font-weight: 600;
    }
    button:first-child {
      background: #171922 !important;
      border-color: #171922 !important;
      outline: none;
    }
    button:last-child {
      background: #fe7622;
      border-color: #fe7622 !important;
      outline: none;
    }
  }
}
</style>