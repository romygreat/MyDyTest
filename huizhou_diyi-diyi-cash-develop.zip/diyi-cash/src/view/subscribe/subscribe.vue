<template>
  <div class="orderBigbox">
    <div class="orderBigbox-list">
      <div class="content">
        <div class="orderBigbox-list-h">
          <h3>预约列表</h3>
          <div class="search">
            <el-input
              :maxlength="40"
              v-model="resdata.repast_name"
              placeholder="请输入预约人名称"
              style="width:160px;margin-right: 10px;display:block;float:left;"
            ></el-input>
            <el-date-picker
              style="width:200px;margin-right: 10px;display:block;float:left;"
              type="date"
              id="searchdatetime"
              v-model="start_time"
              placeholder="请选择预约时间"
              popper-class="time"
              @focus="getItem(2)"
            ></el-date-picker>
            <el-input
              :maxlength="40"
              placeholder="输入预约电话号码"
              v-model="resdata.repast_phone"
              style="width:160px;margin-right: 10px;display:block;float:left;"
            ></el-input>
            <el-button
              :autofocus="false"
              class="search-btn"
              @click="getshopReserveList(1)"
              style="width:60px;height:40px;margin-right:10px;display:block;float:left;"
            >搜索</el-button>
            <el-button
              :autofocus="false"
              class="search-btn"
              @click="start_time='';getshopReserveList()"
              style="width:60px;height:40px;margin-left:0;display:block;float:left;"
            >重置</el-button>
          </div>
        </div>
        <el-table
          :data="Tabledata"
          highlight-current-row
          class="msg-table"
          header-row-class-name="table"
          row-class-name="table-row"
          cell-class-name="body-cell"
          header-cell-class-name="table-cell"
          style="width: 100%;"
          empty-text="暂时没有客户预约！"
        >
          <el-table-column align="center" prop="start_time" label="预约日期" width="160"></el-table-column>
          <el-table-column align="center" prop="repast_name" label="预约人" width="120"></el-table-column>
          <el-table-column align="center" prop="repast_num" label="预约人数" width="80"></el-table-column>
          <el-table-column align="center" prop="repast_phone" label="联系电话" width="120"></el-table-column>
          <el-table-column align="center" prop="table_title" label="预约桌号" width="120"></el-table-column>
          <el-table-column
            :show-overflow-tooltip="true"
            label="备注"
            width="140"
            style="border-bottom: 5px solid #000;"
             align="center"
          >
            <template slot-scope="scope">
              <span>{{scope.row.remark==''?'无':scope.row.remark}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="操作" width="100">
            <template slot-scope="scope">
              <el-button class="edit-button" @click="editClick(scope)" type="text" size="small">修改</el-button>
              <el-button class="del-button" @click="delClick(scope)" type="text" size="small">删除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <el-pagination
          v-if="total>10"
          class="table-page"
          popper-class="table-page-popper"
          background
          @prev-click="humit"
          @next-click="humit"
          @current-change="humit"
          :page-size="6"
          layout="prev, pager, next"
          :total="total"
        ></el-pagination>
      </div>
    </div>
    <div class="orderBigbox-info">
      <section class="subscribeRight">
        <div class="header">
          <h3>预约</h3>
        </div>
        <div class="details">
          <el-form
            :model="subscribeForm"
            :rules="rules"
            ref="subscribeForm"
            class="form"
            label-position="right"
            label-width="80px"
          >
            <el-form-item style="margin-bottom:24px;" label="预约日期" prop="start_time">
              <el-date-picker
                clearable
                id="check-time"
                type="datetime"
                placeholder="选择日期时间"
                v-model="subscribeForm.start_time"
                style="width:200px;"
                popper-class="checktime"
                @focus="getItem(1)"
              ></el-date-picker>
            </el-form-item>
            <el-form-item style="margin-bottom:24px;" label="用餐人数" prop="repast_num">
              <el-input
                :maxlength="40"
                clearable
                placeholder="请输入用餐人数"
                v-model.number="subscribeForm.repast_num"
                style="width:200px;"
              ></el-input>
            </el-form-item>
            <el-form-item style="margin-bottom:24px;" label="预约人" prop="repast_name">
              <el-input
                :maxlength="40"
                clearable
                placeholder="请输入预约人姓名"
                v-model="subscribeForm.repast_name"
                style="width:200px;"
              ></el-input>
            </el-form-item>
            <el-form-item style="margin-bottom:24px;" label="联系电话" prop="repast_phone">
              <el-input
                :maxlength="40"
                clearable
                placeholder="请输入联系电话"
                v-model.number="subscribeForm.repast_phone"
                style="width:200px;"
              ></el-input>
            </el-form-item>
            <el-form-item style="margin-bottom:24px;" label="预定桌号" prop="table_id">
              <el-select
                clearable
                placeholder="请输入预定桌号"
                v-model="subscribeForm.table_id"
                style="width:200px;"
                popper-class="check-table"
              >
                <el-option v-for="item in list" :key="item.id" :label="item.title" :value="item.id"></el-option>
              </el-select>
            </el-form-item>

            <el-form-item style="margin-bottom:10px;" label="自动锁台">
              <el-switch v-model="editSwitch" active-color="#FE7622" inactive-color="#DCDFE6"></el-switch>
            </el-form-item>

            <el-form-item style="margin-bottom:24px;color:#464C5B;" label="备注">
              <el-input
                :maxlength="40"
                v-model="subscribeForm.remark"
                type="textarea"
                rows="4"
                style="width:200px;max-height:120px;"
                resize="none"
              ></el-input>
            </el-form-item>
          </el-form>
          <span class="form-btn" @click="setshopReserveList('subscribeForm')">确定预约</span>
        </div>
      </section>
    </div>
    <el-dialog
      title="删除预约"
      custom-class="del-dialog"
      center
      :visible.sync="delListShow"
      width="20%"
    >
      <p>当前正在进行删除预约操作，删除后不可恢复！</p>
      <p>确认是否删除?</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="delListShow = false">取 消</el-button>
        <el-button type="primary" @click="isdel">删 除</el-button>
      </span>
    </el-dialog>

    <el-dialog custom-class="edit-dialog" title="修改预约信息" center :visible.sync="editListShow">
      <el-form
        :model="delList"
        :rules="rules"
        ref="delList"
        class="edit-form"
        label-position="right"
        label-width="80px"
      >
        <el-form-item style="margin-bottom:24px;" label="预约日期" prop="start_time">
          <el-date-picker
            clearable
            type="datetime"
            placeholder="选择日期时间"
            v-model="delList.start_time"
            style="width:200px;"
            id="time"
            @focus="getItem(3)"
            popper-class="time"
          ></el-date-picker>
        </el-form-item>
        <el-form-item style="margin-bottom:24px;" label="用餐人数" prop="repast_num">
          <el-input
            clearable
            placeholder="请选择用餐人数"
            v-model.number="delList.repast_num"
            style="width:200px;"
          ></el-input>
        </el-form-item>
        <el-form-item style="margin-bottom:24px;" label="预约人" prop="repast_name">
          <el-input
            :maxlength="40"
            clearable
            placeholder="请输入预约人姓名"
            v-model="delList.repast_name"
            style="width:200px;"
          ></el-input>
        </el-form-item>
        <el-form-item style="margin-bottom:24px;" label="联系电话" prop="repast_phone">
          <el-input
            :maxlength="40"
            clearable
            placeholder="请输入联系电话"
            v-model.number="delList.repast_phone"
            style="width:200px;"
          ></el-input>
        </el-form-item>
        <el-form-item style="margin-bottom:24px;" label="预定桌号" prop="table_id">
          <el-select
            clearable
            popper-class="check-table"
            placeholder="请选择预定桌号"
            v-model="delList.table_id"
            style="width:200px;"
          >
            <el-option v-for="item in list" :key="item.id" :label="item.title" :value="item.id"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item style="margin-bottom:24px;" label="自动锁台">
          <el-switch v-model="DeleditSwitch" active-color="#FE7622" inactive-color="#DCDFE6"></el-switch>
        </el-form-item>

        <el-form-item style="margin-bottom:24px;color:#464C5B;" label="备注">
          <el-input
            :maxlength="80"
            type="textarea"
            rows="4"
            style="width:200px;"
            resize="none"
            v-model="delList.remark"
          ></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="editListShow = false">取 消</el-button>
        <el-button type="primary" @click="editDelList('delList')">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import {
  shopReserveList,
  shopReserveSave,
  shopReserveDel
} from '@/api/subscribe.js'
import { setShopTable } from '@/api/table.js'
import dayjs from 'dayjs'
import { setInterval } from 'timers'
export default {
  data() {
    return {
      tableList: [],
      table_title: '',
      isGetScreenTable: true,
      start_time: '',
      resdata: {
        page: 1,
        rows: 10,
        repast_name: '',
        repast_phone: '',
        start_time: '',
        sort: {
          start_time: 'desc'
        }
      },
      Tabledata: [],
      subscribeForm: { start_time: '', repast_num: '', is_open: 1, remark: '' },
      ruleSub: [{}],
      delListShow: false,
      delList: { repast_num: 1 },
      editListShow: false,
      editTime: '',
      editSwitch: true,
      resdatatime: '',
      DeleditSwitch: false,
      list: [],
      total: 0,
      rules: {
        repast_name: [
          { required: true, message: '预约人姓名不得为空', trigger: 'blur' }
        ],
        start_time: [
          { required: true, message: '预约时间不得为空', trigger: 'blur' },
          {
            validator: (rule, value, callback) => {
              let now = new Date().getTime()
              let itime = dayjs(value).valueOf()
              if (itime - now < 0) {
                callback(new Error('所选时间已经过去，请选择正确时间'))
              } else {
                callback()
              }
            },
            trigger: 'blur'
          }
        ],
        repast_phone: [
          { required: true, message: '预约电话不能为空', trigger: 'change' },
          {
            pattern: /^1(3|4|5|6|7|8|9)\d{9}$/,
            message: '手机号码格式有误',
            trigger: 'blur'
          }
        ],
        repast_num: [
          { required: true, message: '预约人数不得为空' },
          { type: 'number', message: '预约人数必须是数字' },
          {
            validator: (rule, value, callback) => {
              if (value>99) {
                callback(new Error('预约人数不能超过99人'))
              } else {
                callback()
              }
            },
            trigger: 'blur'
          }
        ]
      }
    }
  },
  methods: {
    /**
     * 获取预约列表
     */
    getshopReserveList(type) {
      if (type) {
        this.resdata.page = 1
        let time = new Date(this.start_time)
        if (this.start_time == '' || this.start_time == null) {
          this.resdata.start_time = ''
        } else {
          this.resdata.start_time =
            time.getFullYear() +
            '-' +
            (time.getMonth() + 1) +
            '-' +
            time.getDate()
        }
      }
      shopReserveList(this.resdata).then(res => {
        this.total = res.data.data.total
        this.Tabledata = res.data.data.list
        this.resdata = {
          page: 1,
          rows: 10,
          repast_name: '',
          repast_phone: '',
          start_time: '',
          sort: {
            start_time: 'desc'
          }
        }
      })
    },
    /**
     * 分页
     */
    humit(v) {
      this.resdata.page = v
      this.getshopReserveList()
    },
    /**
     * 台桌选项
     */
    getRemarksList() {
      const data = {
        sign: 2,
        title: '',
        status: 0
      }
      setShopTable(data).then(res => {
        this.list = JSON.parse(JSON.stringify(res.data.data.list))
      })
    },
    /**
     * 确定预约
     */
    setshopReserveList(name) {
      this.$refs[name].validate(valid => {
        if (valid) {
          this.editSwitch
            ? (this.subscribeForm.is_open = 1)
            : (this.subscribeForm.is_open = 0)
          shopReserveSave(this.subscribeForm).then(res => {
            if (res.data.code == 1) {
              this.subscribeForm.repast_num = 1
              this.subscribeForm.start_time = ''
              this.clearDetime()
              this.editSwitch = true
              this.getshopReserveList()
              this.subscribeForm = {
                start_time: '',
                repast_num: '',
                is_open: 1,
                remark: ''
              }
              
              this.$refs.subscribeForm.resetFields(); 

              this.$notify.success({
                title: '成功',
                message: '已经成功预约'
              })
            } else {
              this.$notify.error({
                title: '成功',
                message: res.data.data
              })
            }
          })
        } else {
          this.$notify.error({
            title: '错误',
            message: '预约出错！'
          })
          return false
        }
      })
    },
    clearDetime() {
      this.resdatatime = ''
      this.subscribeForm.start_time = ''
    },
    /**
     * 修改预约
     */
    editClick(item) {
      this.delList = JSON.parse(JSON.stringify(item.row))
      this.delList.repast_num = Number(this.delList.repast_num)
      this.delList.is_open == 0
        ? (this.DeleditSwitch = false)
        : (this.DeleditSwitch = true)
      this.editListShow = true
      if (this.editListShow == true) {
        setTimeout(() => {
          document.getElementById('time').setAttribute('readOnly', true)
        }, 300)
      }
    },
    editDelList(name) {
      /**
       * 修改预约
       */
      let isCheck = true
      this.$refs[name].validate(valid => {
        if (valid) {
          this.DeleditSwitch == true
            ? (this.delList.is_open = 1)
            : (this.delList.is_open = 0)
          if (isCheck) {
            isCheck = false
            shopReserveSave(this.delList).then(res => {
              isCheck = true
              this.$notify.success({
                title: '成功',
                message: '已经成功更改了预约信息'
              })
              this.delList = {}
              this.editListShow = false
              this.getshopReserveList()
            })
          }
        } else {
          this.$notify.error({
            title: '错误',
            message: '填写格式有误，请核对后再确认预约'
          })
        }
      })
    },
    /**
     * 删除预约
     */
    delClick(item) {
      this.delList = {
        id: JSON.parse(JSON.stringify(item.row.id))
      }
      this.delListShow = true
    },
    isdel() {
      shopReserveDel(this.delList).then(res => {
        this.$message({
          customClass: 'msg-dialog',
          message: '已经成功删除选中的预约信息',
          type: 'success'
        })
        this.getshopReserveList()
        this.delListShow = false
      })
    },
    getItem(val) {
      /**
       * 去掉键盘事件
       * 1、添加预约的时间框、2、搜索的时间框、3、编辑的时间框
       */
      if (val == 1) {
        setTimeout(() => {
          let checkTime = document.getElementById('check-time')
          let inputs = document.getElementsByClassName('checktime')[0]
          inputs.querySelectorAll('input')[0].setAttribute('readOnly', true)
          inputs.querySelectorAll('input')[1].setAttribute('readOnly', true)
        }, 600)
      }
      if (val == 2) {
        setTimeout(() => {
          let checkTime = document.getElementById('searchdatetime')
          let inputs = document.getElementsByClassName('time')[0]
          inputs.querySelectorAll('input')[0].setAttribute('readOnly', true)
          inputs.querySelectorAll('input')[1].setAttribute('readOnly', true)
        }, 600)
      }
      if (val == 3) {
        setTimeout(() => {
          let checkTime = document.getElementById('time')
          let inputs = document.getElementsByClassName('time')[0]
          inputs.querySelectorAll('input')[0].setAttribute('readOnly', true)
          inputs.querySelectorAll('input')[1].setAttribute('readOnly', true)
        }, 600)
      }
    }
  },
  mounted() {
    this.getshopReserveList()
    this.getRemarksList()
    let checkTime = document.getElementById('check-time')
    checkTime.setAttribute('readOnly', true)
    document.getElementById('searchdatetime').setAttribute('readOnly', true)
  }
}
</script>

<style lang='less' scoped>
@import url('../../assets/less/subscribe/subscribe.less');
@import url('../../assets/less/subscribe/subscribeMedia.less');
</style>
<style lang='less'>
@import url('../../assets/less/table.less');
@import url('../../assets/less/subscribe/dialog.less');
@import url('../../assets/less/subscribe/dialogMedia.less');
</style>