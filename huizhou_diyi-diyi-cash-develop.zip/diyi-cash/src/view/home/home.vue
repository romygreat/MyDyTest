<!--
 * @Author: 叶锦荣
 * @Date: 2019-10-30 08:46:51
 * @LastEditTime: 2019-11-07 17:22:08
 -->
<template>
  <div>
    <section class="home clear">
      <LeftInfo v-on:newTables="newTables($event)" />
      <TableList v-on:regression='regression($event)' :newTabesInfo="newTabesInfo" />
    </section>
  </div>
</template>

<script>
import LeftInfo from '_c/home/leftInfo'
import TableList from '_c/home/tableList'
import { getStatus } from '@/api/home'
import { setStautsText } from '@/libs/util'
export default {
  data() {
    return {
      newTabesInfo: false
    }
  },
  async created() {
    await getStatus({}).then(res => {      
      setStautsText(res.data.data)
    })
  },
  methods: {
    newTables() {
      this.newTabesInfo = true
    },
    regression(){
      this.newTabesInfo = false
    }
  },
  components: {
    LeftInfo,
    TableList
  }
}
</script>

<style lang="less" scoped>
@import url('../../assets/less/home/home.less');
@import url('../../assets/less/home/homeMedia.less');
</style>