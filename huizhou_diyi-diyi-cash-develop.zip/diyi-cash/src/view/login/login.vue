<template>
  <div class="login">
    <div class="login-banner">
      <div class="title">
        <div class="login-title">
          <h3>客官餐饮管理系统</h3>
          <h5>收银管家</h5>
        </div>
        <span>让餐饮和运营变得简单</span>
        <img src="../../../src/assets/img/login_bg.png" alt />
        <!-- | 服务热线：400-888-8888 -->
        <p>广东迪溢商务服务有限公司 技术支持 </p>
      </div>
    </div>
    <div class="login-input">
      <h5>商家登录</h5>
      <div class="name-password">
        <el-autocomplete
          class="user"
          @focus="input=1;getSystem()"
          :readonly="isReadonly"
          v-model="loginInfo.account"
          :fetch-suggestions="querySearch"
          :style="input==1?'border-color:#FD8117':'border-color:rgba(228,231,237,1)'"
          placeholder="请输入账号"
          id="account"
          :popper-class="showPopper==false?'isShowAccount':'account-check'"
        >
          <template slot="prepend">
            <img :src="userImg" alt />
          </template>
          <span
            v-if="loginInfo.account != ''"
            class="el-input__icon"
            slot="suffix"
            @click="loginInfo.account = ''"
          >
            <img src="../../../src/assets/img/close.png" alt />
          </span>
        </el-autocomplete>

        <el-input
          class="user"
          :maxlength='40'
          :readonly="isReadonly"
          :style="input==2?'border-color:#FD8117':'border-color:rgba(228,231,237,1)'"
          v-model="loginInfo.pwd"
          type="password"
          placeholder="请输入密码"
          @focus="input=2;getSystem()"
          id="pwd"
        >
          <template slot="prepend">
            <img :src="passwordImg" alt />
          </template>
          <span
            v-if="loginInfo.pwd != ''"
            class="el-input__icon"
            slot="suffix"
            @click="loginInfo.pwd = ''"
          >
            <img src="../../../src/assets/img/close.png" alt />
          </span>
        </el-input>
      </div>
      <div class="keyboard">
        <ul>
          <li @click="getInput(item)" v-for="item in keyboardvalue" :key="item.index">{{item}}</li>
          <li @click="getInput('back')">
            <img src="../../../src/assets/img/back.png" alt />
          </li>
          <li @click="getInput(0)">0</li>
          <li @click="getLogin" style="background:#FD8117">
            <img src="../../../src/assets/img/go@2x.png" alt />
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
import { login } from '@/api/login'
import { setToken } from '@/libs/util'
import userfocus from '@/assets/img/userfocus.png'
import user from '@/assets/img/user.png'
import passwordfocus from '@/assets/img/passwordfocus.png'
import password from '@/assets/img/password.png'
import { setTimeout } from 'timers'
import { NowData } from '@/libs/changeTime'
export default {
  data() {
    return {
      loginAccount: [],
      passwordImg: password,
      userImg: userfocus,
      input: 1,
      loginInfo: {
        account: '',
        pwd: '',
        terminal_domain: 'shop.gddiyi.com'
      },
      keyboardvalue: [1, 2, 3, 4, 5, 6, 7, 8, 9],
      buttonSwitch: false,
      isReadonly: false,
      showPopper: false
    }
  },
  methods: {
    async getLogin() {
      /**
       * 登陆
       * @param {Object} loginInfo 登陆参数
       * @param {Boolean} buttonSwitch  限制器
       */
      if (
        this.loginInfo.account == '' ||
        this.loginInfo.pwd == '' ||
        this.loginInfo.pwd.length < 6
      ) {
        this.$message({
          offset: 300,
          customClass: 'login-dialog',
          message: '登录密码或账号错误，请检查！',
          type: 'error'
        })
        return
      }
      if (!this.buttonSwitch) {
        this.buttonSwitch = true
        await login(this.loginInfo).then(res => {
          this.buttonSwitch = false
          if (res.data.code === 10011) {
            let sult = res.data.data
            let now = new Date().getTime()
            sult.login_time = NowData(now)
            this.$store.commit('setAdminInfo', sult)
            sessionStorage.setItem('adminInfo', JSON.stringify(sult))
            let expiresVal = Number(sult.token_validity) / 60 / 60 / 24
            setToken(sult.token, expiresVal)
            this.$router.push({ name: 'home' })
        
            let accountArry = []
            if (localStorage.getItem('account') != null) {
              accountArry = localStorage.getItem('account').split(',')
            }
         

            if (
              this.showPopper &&
              accountArry.length < 5 &&
              accountArry.indexOf(this.loginInfo.account) == -1
            ) {
              let account =
                localStorage.getItem('account') + ',' + this.loginInfo.account
              localStorage.setItem('account', account)
            }
            if (accountArry.length == 0) {
              localStorage.setItem('account', this.loginInfo.account)
            }

          }
          else {
            this.$notify.error({
              title: '错误',
              message: res.data.message
            })
          } 
          if (res.data.code === -10016) {
            this.$notify.error({
              title: '错误',
              message: '登录密码或账号错误，请检查！'
            })
          }
        })
      }
    },
    /**
     * 用户输入
     * @param {String} val (1、账号，2、密码)
     * @param {String} account  账号
     * @param {String} pwd  密码
     */
    getInput(val) {
      let accountInput = document.getElementById('account') //根据id选择器选中对象
      let pwdInput = document.getElementById('pwd') //根据id选择器选中对象
      let accountPos = accountInput.selectionStart
      let pwdPos = pwdInput.selectionStart
      let inputCursor = 0
      if (this.input == 1) {
        accountInput.focus()
        if (accountPos != this.loginInfo.account.length) {
          if (val == 'back') {
            this.loginInfo.account =
              this.loginInfo.account.substring(0, accountPos - 1) +
              this.loginInfo.account.substring(accountPos)
            inputCursor = accountPos - 1
          } else {
            this.loginInfo.account =
              this.loginInfo.account.substring(0, accountPos) +
              val +
              this.loginInfo.account.substring(accountPos)
            inputCursor = accountPos + 1
          }
          setTimeout(() => {
            accountInput.setSelectionRange(inputCursor, inputCursor)
          }, 1)
        } else {
          if (val == 'back') {
            this.loginInfo.account = this.loginInfo.account.substring(
              0,
              this.loginInfo.account.length - 1
            )
          } else {
            this.loginInfo.account += val
          }
        }
      }
      if (this.input == 2) {
        pwdInput.focus()
        if (pwdPos != this.loginInfo.pwd.length) {
          if (val == 'back') {
            this.loginInfo.pwd =
              this.loginInfo.pwd.substring(0, pwdPos - 1) +
              this.loginInfo.pwd.substring(pwdPos)
            inputCursor = pwdPos - 1
          } else {
            this.loginInfo.pwd =
              this.loginInfo.pwd.substring(0, pwdPos) +
              val +
              this.loginInfo.pwd.substring(pwdPos)
            inputCursor = pwdPos + 1
          }
          setTimeout(() => {
            pwdInput.setSelectionRange(inputCursor, inputCursor)
          }, 1)
        } else {
          if (val == 'back') {
            this.loginInfo.pwd = this.loginInfo.pwd.substring(
              0,
              this.loginInfo.pwd.length - 1
            )
          } else {
            this.loginInfo.pwd += val
          }
        }
      }
    },
    querySearch(queryString, cb) {
      /**
       * 建议输入框
       */
      var restaurants = []
      if (this.showPopper) {
        for (
          let i = 0;
          i < localStorage.getItem('account').split(',').length;
          i++
        ) {
          let obj = { value: localStorage.getItem('account').split(',')[i] }
          restaurants.push(obj)
        }
      }

      var results = queryString
        ? restaurants.filter(this.createFilter(queryString))
        : restaurants
      // 调用 callback 返回建议列表的数据
      cb(results)
    },
    createFilter(queryString) {
      return restaurant => {
        return (
          restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) ===
          0
        )
      }
    },
    /**
     * 清楚密码按钮
     */
    clearPwd() {
      this.loginInfo.pwd = ''
    },
    getSystem() {
      let version = navigator.userAgent.toLocaleLowerCase()
      let isWin = version.indexOf('windows') > -1 ? true : false
      if (isWin) {
        this.isReadonly = false
      } else {
        this.isReadonly = true
      }
    }
  },
  created() {
    this.loginAccount = this.$store.state.account
    if (
      localStorage.getItem('account') == '' ||
      localStorage.getItem('account') == null
    ) {
      this.showPopper = false
    } else {
      this.showPopper = true
    }
  },
  watch: {
    /**
     * 根据焦点切换图片
     */
    input(val) {
      if (val == 1) {
        this.userImg = userfocus
        this.passwordImg = password
      } else {
        this.userImg = user
        this.passwordImg = passwordfocus
      }
    }
  }
}
</script>
<style lang='less' scoped>
@import url('../../assets/less/logo/logo.less');
</style>
<style lang="less">
@import url('../../assets/less/subscribe/dialog.less');
.name-password {
  .el-input-group__prepend {
    background: transparent !important;
    width: 28px;
    border: none;
  }
  .el-input__inner {
    border: none;
    color: #c0c4cc !important;
    font-size: 20px !important;
  }
  .el-input__inner:hover {
    border: none;
  }
  input {
    background: transparent !important;
  }
}
.isShowAccount {
  display: none;
}
.account-check {
  max-width: 180px !important;
  .el-scrollbar {
    .el-autocomplete-suggestion__wrap {
      ul > li {
        font-size: 16px !important;
        padding: 8px 0 !important;
        text-align: center;
      }
      ul > li:hover{
        color: #fd8117;
      }
    }
  }
}
</style>
