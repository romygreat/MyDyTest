<template>
  <div class="orderBigbox">
    <div class="orderBigbox-list">
      <div class="content">
        <div class="orderBigbox-list-h">
          <h3>信息提醒</h3>
          <span class="clear-btn" @click="delAllService">
            <img src="./../../assets/img/del.png" alt />
            清空
          </span>
        </div>
        <el-table
          :data="list"
          highlight-current-row
          class="msg-table"
          header-row-class-name="table"
          row-class-name="table-row"
          cell-class-name="body-cell"
          header-cell-class-name="table-cell"
          empty-text="暂时没有要处理的消息！"
          style="width: 100%; min-height: 600px;height: 625px;margin-bottom:20px;"
        >
          <el-table-column align="center" label="序号" width="100">
            <template slot-scope="scope">
              <span style="margin-left:12px;">{{Number(scope.row.ind) + (resdata.page-1)*9}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="桌号" width="100">
            <template slot-scope="scope">
              <span style="color:#FE7622;">{{scope.row.table_name}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="服务内容" width="280">
            <template slot-scope="scope">
              <span>需要</span>
              <span style="color:#FE7622;">{{serverStauts[scope.row.type]}}</span>
              <span>服务</span>
            </template>
          </el-table-column>
          <el-table-column align="center" prop="addtime" label="时间" width="220"></el-table-column>
          <el-table-column prop="status" label="状态" width="140">
            <template slot-scope="scope">
              <span
                @click="editStatus(scope.row)"
                class="service-button"
                :class="scope.row.status == 0?'service-button':'service-button disable-click'"
                :style="scope.row.status == 0?'background:#FE7622;color:#fff;':'background:#EBEBED;color:#999999;'"
              >{{scope.row.status == 0 ? '去服务' : '已服务' }}</span>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          class="table-page"
          popper-class="table-page-popper"
          background
          @prev-click="humit"
          @next-click="humit"
          @current-change="humit"
          layout="prev, pager, next"
          :total="serviceTotal"
          v-if="serviceTotal>10"
        ></el-pagination>
      </div>
    </div>
    <div class="orderBigbox-info">
      <div class="header">
        <h3>订单提醒</h3>
      </div>
      <div class="details">
        <ul class="orderBigbox-info-list">
          <hgroup>
            <h3>桌台</h3>
            <h3>内容</h3>
          </hgroup>
          <aside>
            <li :v-if="!item.group_spec" v-for="(item,index) in newOrder" :key="index">
              <div>
                <span>{{item.table_no}}</span>
                <span>{{msgValue[item.status]}}</span>
                <p>
                  <i class="el-icon-time" style="margin-right:4px;"></i>
                  {{item.add_time}}
                </p>
              </div>
            </li>
          </aside>
        </ul>
        <footer>
          <span @click="delAllMsg">
            <img src="./../../assets/img/del.png" alt />
            清空
          </span>
        </footer>
      </div>
    </div>
    <el-dialog
      title="清空信息提醒"
      custom-class="del-dialog"
      center
      :visible.sync="delServiceShow"
      width="20%"
    >
      <p>此操作将清空所有的消息，清空后不可恢复！</p>
      <p>确认是否清空?</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="delServiceShow = false">取 消</el-button>
        <el-button type="primary" @click="isdelService">清 空</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="清空订单提醒"
      custom-class="del-dialog"
      center
      :visible.sync="delMsgShow"
      width="20%"
    >
      <p>此操作将清空所有的订单提醒，清空后不可恢复！</p>
      <p>确认是否清空?</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="delMsgShow = false">取 消</el-button>
        <el-button type="primary" @click="isdelMsg">清 空</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import del from '@/assets/img/del.png'
import { getStautsText } from '@/libs/util'
import {
  listService,
  modifyService,
  orderlogList,
  dellogList,
  delmsgList
} from '@/api/tips.js'
export default {
  data() {
    return {
      list: [],
      serviceTotal: 0,
      newOrder: [],
      serverStauts: [],
      resdata: {
        rows: 10,
        page: 1,
        sort: {
          addtime: 'desc'
        }
      },
      delServiceShow: false,
      delMsgShow: false,
      msgValue: {}
    }
  },
  methods: {
    getListService(v) {
      /**
       * 获取信息服务列表
       */
      if (v) {
        this.resdata.page = v
      }
      listService(this.resdata).then(res => {
        this.list = res.data.data.list

        this.serviceTotal = res.data.data.total
        console.log(this.serviceTotal, '消息列表', this.list)
        let tipStatus = this.list.filter(item => {
          return item.status == 0
        })
        let num = 0
        for (let index = 0; index < this.list.length; index++) {
          this.list[index].ind = index + 1
          if (this.list[index].status == 0) {
            num += 1
          }
        }
      })
    },
    editStatus(val) {
      /**
       * 查看消息
       * 置为已读
       */
      if (val.status == 1) {
        this.$notify.error({
          title: '错误',
          message: '该消息已经已阅，无法更改状态'
        })
        return
      }
      const data = {
        id: val.id,
        status: 1
      }
      modifyService(data).then(res => {
        this.getListService()
        this.$notify.success({
          title: '成功',
          message: '该消息已经成功置为已阅。'
        })
      })
    },
    getorderlogList() {
      /**
       * 获取订单提醒列表
       */
      orderlogList({
        sort: {
          add_time: 'desc'
        }
      }).then(res => {
        this.newOrder = res.data.data.list
      })
    },
    /**
     * 分页
     */
    humit(v) {
      this.resdata.page = v
      this.getListService()
    },
    /**
     * 清空消息提醒
     */
    delAllService() {

      this.delServiceShow = true
    },
    isdelService() {
      /**
       * 删除消息列表
       */
      this.delServiceShow = false
      dellogList().then(res => {
        this.getListService()
        this.$notify.success({
          title: '成功',
          message: '已清空所有信息提醒。'
        })
      })
    },
    delAllMsg() {
      this.delMsgShow = true
    },
    isdelMsg() {
      /**
       * 删除订单提醒
       */
      delmsgList().then(res => {
        this.delMsgShow = false
        this.getorderlogList()
        if (res.data.code == 1) {
          this.$notify.success({
            title: '成功',
            message: '已清空所有订单提醒。'
          })
        }
      })
    }
  },
  mounted() {
    this.getListService()
    this.getorderlogList()
  },
  created() {
    this.serverStauts = getStautsText('service.type')
    this.msgValue = getStautsText("order_log.msg")
    
  },
  computed: {
    tips() {
      return this.$store.state.tipsNum
    },
    newOrderTip() {
      return this.$store.state.newOrderTips
    }
  },
  watch: {
    tips: {
      handler(n, o) {
        if (n != o) {
          this.getListService()
        }
      }
    },
    newOrderTip: {
      handler(n, o) {
        if (n) {
          this.getorderlogList()
        }
      }
    }
  }
}
</script>

<style lang='less' scoped>
@import url('../../assets/less/tips/tips.less');
@import url('../../assets/less/tips/tipsMedia.less');
</style>
<style lang='less'>
@import url('../../assets/less/table.less');
@import url('../../assets/less/subscribe/dialog.less');
.tips-table::before {
  height: 0;
}
</style>