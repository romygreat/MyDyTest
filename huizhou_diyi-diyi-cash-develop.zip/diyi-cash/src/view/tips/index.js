import Tips from './tips.vue'
export default Tips