import Order from './order.vue'
export default Order