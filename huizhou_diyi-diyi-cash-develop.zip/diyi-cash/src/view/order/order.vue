<!--
 * @Author: 叶锦荣
 * @Date: 2019-11-01 18:04:06
 * @LastEditTime: 2019-12-17 16:36:30
 -->
<template>
  <div class="orderBigbox">
    <div class="orderBigbox-list">
      <div class="content">
        <div class="orderBigbox-list-h">
          <h3>销货单</h3>
          <div class="search">
            <el-input
              clearable
              style="width:160px;margin-right: 10px;display:block;float:left;"
              placeholder="请输入订单编号"
              v-model="resdata.order_no"
              prefix-icon="el-icon-search"
            ></el-input>
            <el-select
              clearable
              style="width:120px;margin-right: 10px;display:block;float:left;"
              v-model="resdata.pay_action"
              placeholder="支付方式"
              popper-class="select-center"
            >
              <el-option
                v-for="item in pay_actionList"
                :key="item.pay_action"
                :label="item.label"
                :value="item.pay_action"
              ></el-option>
            </el-select>
            <el-select
              clearable
              popper-class="select-center"
              style="width:120px;margin-right: 10px;display:block;float:left;"
              v-model="resdata.table_no"
              placeholder="请选择桌台"
            >
              <el-option
                v-for="item in list"
                :key="item.id"
                :label="item.title"
                :value="item.title"
              ></el-option>
            </el-select>

            <el-select
              clearable
              popper-class="select-center"
              style="width:120px;margin-right: 10px;display:block;float:left;"
              v-model="resdata.status"
              placeholder="订单状态"
            >
              <el-option
                v-for="(item,index) in pay_status"
                :key="item.value"
                :label="item.value"
                :value="item.label"
              ></el-option>
            </el-select>
            <el-button
              medium
              :autofocus="false"
              @click="indexOrderList(true)"
              style="width:60px;height:39px;color:#fff;display:flex;justify-content:center;background:#fe7622;border:none;"
            >搜索</el-button>
          </div>
        </div>
        <el-table
          @row-click="goList"
          empty-text="暂时没有订单信息！"
          :data="orderlist"
          class="msg-table"
          header-row-class-name="table"
          :row-class-name="tableRow"
          cell-class-name="body-cell"
          header-cell-class-name="table-cell"
          style="width: 100%; min-height: 600px;height: 625px;margin-bottom:20px;"
          :highlight-current-row="true"
        >
          <el-table-column align="center" label="订单编号" width="180" prop="order_no"></el-table-column>
          <el-table-column align="center" label="下单时间" width="150" prop="add_time"></el-table-column>
          <el-table-column align="center" label="桌号" width="66" prop="table_no"></el-table-column>
          <el-table-column align="center" label="人数" width="60" prop="tableware_num"></el-table-column>
          <el-table-column align="center" prop="addtime" label="状态" width="70">
            <template slot-scope="scope">
              <span
                :style="scope.row.status==0?'color:#FE7622 !important;':''"
              >{{statusList[scope.row.status]}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" prop="status" label="支付方式" width="80">
            <template slot-scope="scope">
              <span>{{payaction[scope.row.pay_action]}}</span>
            </template>
          </el-table-column>
          <el-table-column label="支付类型"  align="center" width="80">
            <template slot-scope="scope">
              <span>{{scope.row.pay_way==0?'/':payWay[scope.row.pay_way]}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="金额" width="80" class-name="price-cell">
            <template slot-scope="scope">
              <span>{{'￥'+ transformMondy(scope.row.paid_price)}}</span>
            </template>
          </el-table-column>
          <el-table-column align="center" label="操作" width="74">
            <template slot-scope="scope">
              <span
                class="service-button"
                :class="scope.row.status == 0?'service-button':'service-button disable-click'"
                :style="scope.row.status == 0?'background:#FE7622;color:#fff;':'background:#EBEBED;color:#999999;'"
                @click="scope.row.status == 0?revoke(scope.row.id):''"
              >{{buttonValue(scope.row.status)}}</span>
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          v-if="listshow"
          class="table-page"
          popper-class="table-page-popper"
          background
          layout="prev, pager, next"
          :total="Number(resdata.total)"
          @prev-click="humit"
          @next-click="humit"
          @current-change="humit"
        ></el-pagination>
      </div>
    </div>
    <div class="orderBigbox-info">
      <div class="header">
        <h3>商品信息</h3>
        <span v-if="listshow">人数：{{orderinfoList.tableware_num}}</span>
      </div>
      <div class="details">
        <ul class="orderBigbox-info-list">
          <hgroup>
            <h3 v-for="(item,index) in orderinfoListComlun" :key="index">{{item}}</h3>
          </hgroup>
          <aside v-if="listshow">
            <li
              :v-if="!item.group_spec"
              v-for="(item,index) in orderinfoList.order_list.list"
              :key="index"
            >
              <div>
                <span>{{item.name}}</span>
                <span>{{item.num}}{{item.unit != '' ? item.unit : '份'}}</span>
                <span>￥{{Number(item.discount_rate)!=10?transformMondy(item.price*Number(item.discount_rate)/10):transformMondy(item.price)}}</span>
              </div>
              <p v-if="item.group">-[规格]：{{item.group.group_title}}</p>
              <p v-if="item.procedure_name">-[做法]：{{item.procedure_name}}</p>
              <p v-if="item.contorno">-[配菜]：{{item.contorno.contorno_name}}</p>
              <p v-if="item.taste">-[口味]：{{item.taste.name}}</p>
              <p v-if="Number(item.discount_rate)!=10">
                -[{{Number(item.discount_rate)==0?'赠':Number(item.discount_rate)+'折'}}]{{item.discount_reason?': '+item.discount_reason:''}}
                <span
                  style="float:right;"
                >-￥{{transformMondy(item.price-item.price*item.discount_rate/10)}}</span>
              </p>
              <p v-if="item.remark!=''">-[备注]：{{item.remark}}</p>
            </li>
            <li v-for="item in orderinfoList.order_refund.list" :key="item.id">
              <div class="del">
                <span>{{item.name}}</span>
                <span>{{item.num}}{{item.unit ? item.unit : '份'}}</span>
                <span>￥{{transformMondy(item.refund_price)}}</span>
              </div>
              <p v-if="item.group">-[规格]：{{item.group.group_title}}</p>
              <p v-if="item.procedure_name">-[做法]：{{item.procedure_name}}</p>
              <p v-if="item.contorno">-[配菜]：{{item.contorno.contorno_name}}</p>
              <p>-[退]：{{item.refund_reason}}</p>
            </li>

            <!-- 杂项费 -->
            <li v-show="orderinfoList.tableware_fee != 0">
              <div>
                <span>餐具费</span>
                <span>{{orderinfoList.tableware_num}}位</span>
                <span>￥{{transformMondy(orderinfoList.tableware_fee * orderinfoList.tableware_num)}}</span>
              </div>
            </li>

            <li v-show="orderinfoList.service_price != 0">
              <div>
                <span>服务费</span>
                <span>{{1}}项</span>
                <span>￥{{transformMondy(orderinfoList.service_price)}}</span>
              </div>
            </li>

            <li v-if="orderinfoList.discount_rate!=10" class="order-discount">
              <div>
                <span>整单打折: {{orderinfoList.discount_rate+'折'}}</span>
                <span>{{'-￥' +transformMondy(orderinfoList.discount_amount)}}</span>
              </div>
            </li>
            <li v-if="orderinfoList.remark||orderinfoList.remark!=''" class="order-discount">
              <div>
                <span>整单备注</span>
                <span>{{orderinfoList.remark}}</span>
              </div>
            </li>
          </aside>
        </ul>
        <h1
          style="text-align: center;opacity: .8;font-size:24px;margin-top:100px;"
          v-if="!listshow"
        >暂无商品详情</h1>
        <footer>
          <div class="list-detail">
            <span>商品总数:{{Math.floor(totalNum)}}</span>
            <span>操作员:{{adminInfo.realname}}</span>
          </div>
          <h3>结算明细</h3>
          <div class="pay-details">
            <p>应收</p>
            <p>￥{{listshow?transformMondy(orderinfoList.total_price):0}}</p>
          </div>
          <div class="pay-details">
            <p>优惠</p>
            <p>
              -￥{{orderinfoList.total_price?transformMondy(discountAmount(orderinfoList.all_discount_amount,orderinfoList.discount_amount)):0}}
            </p>
          </div>
          <div class="pay-details">
            <p>抹零</p>
            <p>-￥{{orderinfoList.pin_out>0?transformMondy(orderinfoList.pin_out):0}}</p>
          </div>
          <div class="pay-details">
            <p>实收</p>
            <p class="pay">￥{{listshow?transformMondy(orderinfoList.paid_price):0}}</p>
          </div>
          <div class="pay-btn">
            <span @click="print">补打</span>
            <span @click="SettleOrder">结账</span>
          </div>
        </footer>
      </div>
    </div>
    <checkoutLog
      :show="settleShow"
      v-if="settleShow"
      :data="orderinfoList"
      v-on:checkoutLogCallBack="checkoutLogCallBack($event)"
    ></checkoutLog>
    <el-dialog title="撤单提醒" custom-class="del-dialog" center :visible.sync="revokeShow" width="20%">
      <p>是否撤销该订单?</p>
      <span slot="footer" class="dialog-footer">
        <el-button @click="revokeShow = false">取 消</el-button>
        <el-button type="primary" @click="toRevoke()">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { replacementOrder } from '@/api/printer'
import { getStautsText, transformRMB } from '@/libs/util'
import { setShopTable } from '@/api/table.js'
import { indexOrder, printingOrder } from '@/api/order.js'
import checkoutLog from '@/components/common/checkoutLog/checkoutLog'
import { revokeOrder } from '@/api/menu'
import Calc from 'number-precision'
export default {
  components: {
    checkoutLog
  },
  data() {
    return {
      revokeShow: false,
      resdata: {
        revokeId: '',
        status: '',
        page: 1,
        rows: 10,
        order_no: '',
        table_no: '',
        terminal: 'cash',
        sort: {
          add_time: 'desc'
        },
        pay_action: ''
      },
      orderlist: [],
      orderinfoList: [],
      orderinfoListComlun: ['品名', '数量', '小计'],
      useindex: 0,
      listshow: false,
      totalNum: '',
      statusList: [],
      payaction: [],
      pay_actionList: [
        { pay_action: 1, label: '线上支付' },
        { pay_action: 2, label: '餐后支付' }
      ],
      pay_status: [],
      list: [],
      settleShow: false,
      printData: {
        apportion: 1
      },
      payWay: {}
    }
  },
  methods: {
    /**
     * 台桌选项
     */
    getRemarksList() {
      const data = {
        sign: 2,
        title: '',
        status: 0
      }
      setShopTable(data).then(res => {
        this.list = JSON.parse(JSON.stringify(res.data.data.list))
      })
    },
    /**
     * 订单列表
     */
    indexOrderList(type) {
      if (type) {
        this.resdata.page = 1
        this.useindex = 0
      }
      indexOrder(this.resdata).then(res => {
        if (res.data.data.list && res.data.data.list.length > 0) {
          this.totalNum = ''
          this.listshow = true
          this.orderlist = res.data.data.list

          this.orderinfoList = this.orderlist[this.useindex]
          this.orderinfoList.all_discount_amount = 0

          this.orderinfoList.order_list.list.forEach(item=>{
            this.orderinfoList.all_discount_amount = this.discountAmount(item.discount_amount,this.orderinfoList.all_discount_amount)
          })          
          if (this.orderinfoList.order_list === undefined) {
            this.orderinfoList.order_list = {}
            this.orderinfoList.order_list.list = []
          }
          if (this.orderinfoList.order_refund == undefined) {
            this.orderinfoList.order_refund = {}
            this.orderinfoList.order_refund.list = []
          }
          this.resdata.total = res.data.data.total
          this.orderinfoList.order_list.list.forEach(element => {
            this.totalNum = Number(element.num) + Number(this.totalNum)
          })
          this.dealProductParam()
        } else {
          this.totalNum = ''
          this.orderlist = []
          this.orderinfoList = []
          this.listshow = false
        }
      })
    },
    dealProductParam() {
      /**
       * 处理菜品参数
       */

      for (let i = 0; i < this.orderinfoList.order_list.list.length; i++) {
        if (this.orderinfoList.order_list.list[i].procedureArr) {
          let procedureName = this.orderinfoList.order_list.list[
            i
          ].procedureArr.filter(item => {
            return item.id == this.orderinfoList.order_list.list[i].procedure_id
          })
          this.orderinfoList.order_list.list[i].procedure_name =
            procedureName[0].name
        }

        if (
          this.orderinfoList.order_list.list[i].contornoArr &&
          this.orderinfoList.order_list.list[i].contornoArr.length > 0
        ) {
          let contornoNames = this.orderinfoList.order_list.list[
            i
          ].contornoArr.filter(item => {
            let ids = String(this.orderinfoList.order_list.list[i].contorno_ids)
            return ids.split(',').indexOf(item.id) > -1
          })
        }
      }

      if (this.orderinfoList.order_refund) {
        for (let i = 0; i < this.orderinfoList.order_refund.list.length; i++) {
          if (this.orderinfoList.order_refund.list[i].procedureArr) {
            let procedureName = this.orderinfoList.order_refund.list[
              i
            ].procedureArr.filter(item => {
              return (
                item.id == this.orderinfoList.order_refund.list[i].procedure_id
              )
            })
            this.orderinfoList.order_refund.list[i].procedure_name =
              procedureName[0].name
          }
          if (this.orderinfoList.order_refund.list[i].contornoArr.length > 0) {
            let contornoNames = this.orderinfoList.order_refund.list[
              i
            ].contornoArr.filter(item => {
              if (this.orderinfoList.order_refund.list[i].contorno_ids) {
                return (
                  this.orderinfoList.order_refund.list[i].contorno_ids
                    .split(',')
                    .indexOf(item.id) > -1
                )
              } else {
                return []
              }
            })
            let contornoName = ''
            for (let i = 0; i < contornoNames.length; i++) {
              if (contornoName == '') {
                contornoName = contornoNames[i].name
              } else {
                contornoName += ',' + contornoNames[i].name
              }
            }
            this.orderinfoList.order_refund.list[i].contorno_name = contornoName
          }
        }
      }
    },
    /**
     * 分页点击
     */
    humit(v) {
      this.resdata.page = v
      this.indexOrderList()
    },
    /**
     * 获取到订单详情
     */
    goList(row) {
      for (let i = 0; i < this.orderlist.length; i++) {
        if (row.id == this.orderlist[i].id) {
          this.useindex = i
        }
      }
      this.indexOrderList()
    },
    transformMondy(value) {
      return transformRMB(value)
    },
    SettleOrder() {
      let switchOff = false
      this.orderinfoList.order_list.list.forEach(item => {
        if (
          (item.is_editable == 1 &&
            item.is_exists_edit != 1 &&
            item.switch == true) ||
          (item.is_current == 1 &&
            item.is_exists_current != 1 &&
            item.switch == true)
        ) {
          switchOff = true
        }
      })
      if (switchOff == true) {
        this.$notify({
          type: 'warning',
          title: '错误',
          message: '当前存在称重商品或者时价商品尚未更改，无法结账'
        })
        return
      }
      if (this.orderinfoList.status == 0) {
        this.settleShow = true
      } else {
        this.$notify.error({
          title: '错误',
          message: '该订单已结账，请勿重复结账'
        })
        return
      }
    },
    checkoutLogCallBack(res) {
      /**
       * 结账回调
       * @param {Booler} res.show 结账窗口显示
       * @param {Number} res.type 回调类型  0 ：什么都没有操作   1：支付成功  2 ： 支付失败
       */
      this.settleShow = res.show
      this.getRemarksList()
      this.indexOrderList()
    },
    async print() {
      this.printData.id = this.orderinfoList.id
      const data = {
        id: this.printData.id,
        type: this.orderinfoList.status === 0 ? 1 : 2
      }
      let sulf = await replacementOrder(data)
      if (window.android) {
        if (sulf.data.code == 1) {
          let numberPrcie = 0
          sulf.data.data.order_list.forEach(jl => {
            numberPrcie = Calc.plus(jl.discount_amount, numberPrcie)
          })
          sulf.data.data.discount_amountInfo = Calc.plus(
            numberPrcie,
            sulf.data.data.discount_amount
          )
            window.android.printOneOrder(
              0,
              JSON.stringify(sulf.data.data)
            )
          // })
          this.$notify({
            type: 'success',
            title: '成功',
            message: `已经成功打印，请稍等`
          })
        } else {
          this.$notify.error({
            title: '出错',
            message: sulf.data.message
          })
        }
      }
    },
    tableRow({ row, rowIndex }) {
      if (rowIndex == this.useindex) {
        return 'table-row current-row'
      } else {
        return 'table-row '
      }
    },
    buttonValue(type) {
      if (type == 0) {
        return '撤单'
      } else {
        return '禁用'
      }
    },
    revoke(id) {
      this.revokeShow = true
      this.revokeId = id
    },
    toRevoke() {
      revokeOrder({ id: this.revokeId }).then(res => {
        this.revokeShow = false
        if (res.data.code === 1) {
          this.$notify({
            type: 'success',
            title: '成功',
            message: `此订单已撤单`
          })
          this.indexOrderList()
        }
      })
    },
    discountAmount(totalPrice, paidPrice) {
      return Calc.plus(totalPrice, paidPrice)
    }
  },
  mounted() {
    this.getRemarksList()
    this.indexOrderList()
  },
  created() {
    this.statusList = getStautsText('order.status')
    this.payaction = getStautsText('order.pay_action')
    this.payWay = getStautsText('order.pay_way')
    for (let i = 0; i < Object.keys(this.statusList).length; i++) {
      this.pay_status.push({
        label: Object.keys(this.statusList)[i],
        value: Object.values(this.statusList)[i]
      })
    }
  },
  computed: {
    adminInfo() {
      return this.$store.state.adminInfo
    }
  }
}
</script>

<style lang='less' scoped>
@import url('../../assets/less/order/order.less');
@import url('../../assets/less/order/orderMedia.less');
</style>
 <style lang="less">
@import url('../../assets/less/table.less');
.select-center {
  text-align: center;
}
</style>