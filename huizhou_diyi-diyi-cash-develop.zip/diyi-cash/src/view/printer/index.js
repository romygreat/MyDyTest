import printer from './printer.vue'
export default printer