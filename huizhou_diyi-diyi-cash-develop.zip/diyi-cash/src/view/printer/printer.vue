<!--
 * @Author: 叶锦荣
 * @Date: 2019-11-20 09:00:29
 * @LastEditTime: 2019-11-21 16:00:56
 -->
<template>
  <div class="printer">
    <div class="printer-box">
      <printerList v-on:noShowtitle='noShowtitle($event)' />
    </div>
  </div>
</template>
<script>
import printerList from '_c/common/printerList'
export default {
  components: {
    printerList
  }
}
</script>
<style lang='less' scoped>
@import url('../../assets/less/priner/priner.less');
</style>
