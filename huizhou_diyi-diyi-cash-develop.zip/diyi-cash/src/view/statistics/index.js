import Statistics from './statistics.vue'
export default Statistics