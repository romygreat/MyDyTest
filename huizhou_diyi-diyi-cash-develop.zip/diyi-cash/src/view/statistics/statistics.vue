<template>
    <section class="statistics">
      <ColumnTabs @sendIndex="getIndex"></ColumnTabs>
      <statisticsDetails :statisticsIndex="statisticsIndex"></statisticsDetails>
    </section>
</template>
<script>
import ColumnTabs from '../../components/common/statistics/columnTabs'
import statisticsDetails from '../../components/common/statistics/statisticsDetails'

export default {
  components: {
    ColumnTabs,
    statisticsDetails
  },
  data() {
    return {
      statisticsIndex: ''
    }
  },
  methods: {
    getIndex(val) {
      this.statisticsIndex = val
    }
  }
}
</script>
<style lang="less" scoped>
@import url('../../assets/less/statistics/statistics.less');
@import url('../../assets/less/statistics/statisticsMedia.less');
</style>