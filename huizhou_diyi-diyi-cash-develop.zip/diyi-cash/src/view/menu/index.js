import menu from './menu.vue'
export default menu