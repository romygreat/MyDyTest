<template>
    <div class="menu" >
        <shopCart/>
        <menuList/>
    </div>
</template>
<script>
import shopCart from  '_c/menu/shopCart'
import menuList from '_c/menu/menuList'
export default {
    data(){
        return{
              
        }
    },
     components:{
        shopCart,
        menuList
     }
}
</script>
<style lang="less" scoped >
@import url('../../assets/less/menu/menu.less');
</style>