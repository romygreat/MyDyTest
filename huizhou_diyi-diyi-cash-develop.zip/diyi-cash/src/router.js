import Vue from 'vue'
import Router from 'vue-router'
import { getToken, setToken } from '@/libs/util'
import Home from './view/home'
import cantaiImg from './assets/img/cantai.png'
import dingdan from './assets/img/dingdan.png'
import xinxi from './assets/img/xinxi.png'
import tuichu from './assets/img/tuichu.png'
import baobiao from './assets/img/baobiao.png'
import subscribe from './assets/img/subscribeimg.png'
import printer from './assets/img/printerImg.png'
import guqing from './assets/img/guqingImg.png'
Vue.use(Router)
let router = new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home,
      meta: {
        title: '餐台',
        icon: cantaiImg
      }
    },
    {
      path: '/order',
      name: 'order',
      meta: {
        title: '订单',
        icon: dingdan
      },
      component: () => import('./view/order')
    },
    {
      path:'/defectProduct',
      name:'defectProduct',
      meta:{
        title:'沽清',
        icon:guqing
      },
      component: () => import('./view/defectProduct')
    },
    {
      path: '/subscribe',
      name: 'subscribe',
      meta: {
        title: '预约',
        icon: subscribe
      },
      component: () => import('./view/subscribe/subscribe')
    },
    // {
    //   path: '/tips',
    //   name: 'tips',
    //   meta: {
    //     title: '信息',
    //     icon: xinxi
    //   },
    //   component: () => import('./view/tips')
    // },
    {
      path: '/statistics',
      name: 'statistics',
      meta: {
        title: '统计',
        icon: baobiao
      },
      component: () => import('./view/statistics')
    },
    {
      path: '/printer',
      name: 'printer',
      meta: {
        title: '打印机',
        icon: printer
      },
      component: () => import('./view/printer')
    },
    {
      path: '/login',
      name: 'login',
      meta: {
        title: '登录'
      },
      component: () => import('./view/login')
    },
    {
      path: '/signOut',
      name: 'signOut',
      meta: {
        title: '退出',
        icon: tuichu
      },
      component: () => import('./view/login')
    },
    {
      path: '/menu',
      name: 'menu',
      meta: {
        title: '菜单'
      },
      component: () => import('./view/menu')
    }
  ]
})

router.beforeEach(async (to, from, next) => {
  const shopToken = getToken()
  if (!shopToken && to.name != 'login') {
    // location.href = '/login'
    next({ path: '/login' })
  } else {
    setToken(shopToken)
    next()
  }
})


export default router