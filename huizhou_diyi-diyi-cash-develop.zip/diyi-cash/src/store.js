import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    cateProduct: [],
    adminInfo: {},
    useOrder: {},
    useTable_no: '',
    allTableState: {},
    cartList: [],
    account: [],
    keyshow: Boolean,
    newsOrder: '0',
    newsServer: 0,
    TheWorld: false,
    monitorList: {},
    allStatus:{},
    tipsNum:0,
    isPrinter:[],
    newOrderTips:Boolean
  },
  mutations: {
    setAllStatus(state,allStatus){
      state.allStatus = allStatus
    },
    setCateProduct(state, cateProduct) {
      state.cateProduct = cateProduct
    },
    setAdminInfo(state, adminInfo) {
      state.adminInfo = adminInfo
    },
    setDetalis(state, detalis) {
      state.detalis = detalis
    },
    setUseTable_no(state, useTable_no) {
      state.useTable_no = useTable_no
    },
    setUseOrder(state, useOrder) {
      state.useOrder = useOrder
    },
    setAllTableState(state, allTableState) {
      state.allTableState = allTableState
    },
    setCartList(state, cartList) {
      state.cartList = cartList
    },
    setUserAccount(state, account) {
      state.account = account
      localStorage.setItem('account', account)
    },
    setKeyShow(state, keyshow) {
      state.keyshow = keyshow
      localStorage.setItem('keyshow', keyshow)
    },
    setTheWorld(state, TheWorld) {
      state.TheWorld = TheWorld
    },
    setMonitorList(state, monitorList) {
      state.monitorList = monitorList
    },
    setTipsNum(state,tipsNum){
      state.tipsNum = tipsNum
    },
    setIsPrinter(state,isPrinter) {
      state.isPrinter = isPrinter
    },
    setNewOrderTips(state,newOrderTips){
      state.newOrderTips = newOrderTips
    }
  },
  actions: {
    setIsPrinter({
      commit
    },isPrinter) {
      commit('setIsPrinter',isPrinter)
    },
    setCateProduct({
      commit
    }, cateProduct) {
      /**  
       *  @param {Aarry} cateProduct 菜单列表
       * */
      commit('setCateProduct', cateProduct)
    },
    setAdminInfo({
      commit
    }, adminInfo) {
      /**  
       *  @param {Object} adminInfo 全局商家信息状态
       * */
      commit('setAdminInfo', adminInfo)
    },

    setUseOrder({
      commit
    }, useOrder) {
      /**  
       *  @param {Object} useOrder 当前所选台桌订单
       * */
      commit('setUseOrder', useOrder)
    },
    setUseTable_no({
      commit
    }, useTable_no) {
      /** 
       * @param {String} useTable_no 当前所选台桌号
       * **/
      commit('setUseTable_no', useTable_no)
    },
    setAllTableState({
      commit
    }, allTableState) {
      /** 
       * @param {Object} allTableState.order 当前商家全部订单信息
       * @param {Object} allTableState.state 当前全部台桌统计的状态
       * **/
      commit('setAllTableState', allTableState)
    },
    setCartList({
      commit
    }, cartList) {
      /** 
       * @param {Aarry} cartList 购物车列表
       */
      commit('setCartList', cartList)
    },
    setUserAccount({
      commit
    }, account) {
      commit('setUserAccount', account)
    },
    setKeyShow({
      commit
    }, keyshow) {
      commit('setKeyShow', keyshow)
    },
    setTheWorld({ commit }, TheWorld) {
      commit('setTheWorld', TheWorld)
    },
    setMonitorList({ commit }, monitorList) {
      commit('setMonitorList', monitorList)
    },
    /**
     *  @param {Object} allStatus  //全局对象参数
     */
    setAllStatus({commit}, allStatus) {
      commit('setAllStatus'.allStatus)
    },
    setTipsNum({commit},tipsNum){
      commit('setTipsNum',tipsNum)
    },
    setNewOrderTips({commit},newOrderTips){
      commit('setNewOrderTips',newOrderTips)
    }
  }

})