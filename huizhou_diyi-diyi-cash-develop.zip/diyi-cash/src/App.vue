<template>
  <!-- @click="clickDom($event)" -->
  <section
    @click="clickDom($event)"
    :class="bgshow ? 'loginBg' : ''"
    class="bigbox"
    :style="contentStyleObj"
  >
    <LeftNav @signOut="signOut" />
    <el-dialog title="退出" custom-class="signout-dialog" :visible.sync="signout" width="30%">
      <span>退出后将无法进行更多操作！</span>
      <span>是否确认退出？</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="signout = false">取 消</el-button>
        <el-button type="primary" @click="logOut">确 定</el-button>
      </span>
    </el-dialog>
    <div id="app" :style="appStyleObj">
      <router-view />
    </div>
    <audio id="vio" style="height: 40px; display:block !important; width:40px; " :src="voiceinfo"></audio>
    <audio
      id="vioServer"
      style="height: 40px; display:block !important; width:40px; "
      :src="vioServerInfo"
    ></audio>
  </section>
</template>

<script>
import voiceinfo from './assets/audio/a.mp3'
import vioServerInfo from './assets/audio/orderserver.mp3'
import cashBg from '@/assets/img/bg.png'
import LeftNav from '_c/common/leftNav/leftNav'
import { logout } from '@/api/login.js'
import {
  getToken,
  setToken,
  getStautsText,
  setStautsText
} from '@/libs/util.js'
import OrderTips from './store'
import { mapMutations } from 'vuex'
import { orderTips } from './api/order'
import { timePrinter, printerList } from '@/api/printer'
import {
  monitor,
  getService,
  getStatus,
  setShopTable,
  getShop,
  getShopById
} from '@/api/home'
import { orderlogList } from '@/api/tips.js'
import { getOrderPrint } from '@/api/printer'
import Calc from 'number-precision'
import { async } from 'q'
export default {
  name: 'app',
  data() {
    return {
      voiceinfo,
      vioServerInfo,
      contentStyleObj: {
        height: '',
        width: ''
      },
      appStyleObj: {
        height: '',
        width: ''
      },
      cashBg,
      bgshow: false,
      signout: false,
      monitorKey: '',
      serverList: {},
      currentRotuer: ''
    }
  },
  methods: {
    ...mapMutations(['increase', 'clearNews', 'serverSetValue']),
    /**
     * 获得当前客户的浏览器大小 以及当前路由
     * @param {Number} window.innerHeight
     *  **/
    screenHeight() {
      this.contentStyleObj.height = window.innerHeight + 'px'
      this.contentStyleObj.width = window.innerWidth + 'px'
      this.appStyleObj.height = window.innerHeight + 'px'
      this.appStyleObj.width = window.innerWidth - 80 + 'px'
    },
    playinfo() {
      if (this.adminInfo.shop.is_voice == 1)
        document.getElementById('vio').play()
    },
    /**
     * 页面的点击事件
     */
    clickDom(e) {
      let isShow = this.$store.state.keyshow
      let menuInput = document.getElementById('menu-input')
      let keyboard = document.getElementById('keyboard')
      let tableInput = document.getElementById('table-input')
      if (tableInput) {
        if (tableInput.contains(e.target)) {
          if (isShow == true) {
            this.$store.commit('setKeyShow', false)
          } else {
            this.$store.commit('setKeyShow', true)
          }
        } else {
          if (keyboard) {
            if (keyboard.contains(e.target) == false) {
              this.$store.commit('setKeyShow', false)
            }
          }
        }
      } else if (menuInput) {
        if (menuInput.contains(e.target)) {
          if (isShow == true) {
            this.$store.commit('setKeyShow', false)
          } else {
            this.$store.commit('setKeyShow', true)
          }
        } else {
          if (keyboard) {
            if (keyboard.contains(e.target) == false) {
              this.$store.commit('setKeyShow', false)
            }
          }
        }
      }
    },
    signOut(val) {
      this.signout = val
    },
    logOut() {
      logout().then(res => {
        if (res.data.code == 1) {
          this.signout = false
          clearInterval(this.tiemr)
          clearInterval(this.monitorKey)
          // sessionStorage.clear()
          setToken('')
          this.$router.push({ name: 'login' })
        } else {
          this.$notify({
            type: 'warning',
            title: '错误',
            message: res.data.message
          })
        }
      })
    },
    /**
     * @description 全局监听变量
     */
    async setMonitor() {
      clearInterval(this.monitorKey)
      if (this.$router.history.current.name !== 'login') {
        this.monitorKey = setInterval(async () => {
          let res = await monitor({})
          // 有服务
          this.$store.commit('setTipsNum', res.data.data.call)
          if (res.data.data.service == 1) {
            getService({}).then(resInfo => {
              this.playVioServer(`台桌${resInfo.data.data.table_name}需要${
                  this.serverList[resInfo.data.data.type]
                }`)
              this.$notify({
                type: 'success',
                title: '成功',
                message: `台桌${resInfo.data.data.table_name}需要${
                  this.serverList[resInfo.data.data.type]
                }`,
                duration: 3000
              })
            })
          }

          // 需要打印
          if (res.data.data.printer == 1) {
            let sulf = await getOrderPrint({})
           

            if (sulf.data.code == 1) {
              if (window.android) {
                this.$notify({
                  type: 'success',
                  title: '成功',
                  message: `正在打印中，请稍等`
                })
                // 如果是制作单
                if (sulf.data.data.sign == 2) {
                  window.android.printOneOrder(
                    7,
                    JSON.stringify(sulf.data.data)
                  )
                } else {
                  let numberPrcie = 0
                  sulf.data.data.order_list.forEach(jl => {
                    numberPrcie = Calc.plus(jl.discount_amount, numberPrcie)
                  })
                  sulf.data.data.discount_amountInfo = Calc.plus(
                    numberPrcie,
                    sulf.data.data.discount_amount
                  )
                  window.android.printOneOrder(
                    0,
                    JSON.stringify(sulf.data.data)
                  )
                }
              }
            } else {
              this.$notify.error({
                title: '出错',
                message: res.data.message
              })
            }
          }
          // 有新订单
          if (res.data.data.order == 1) {
            /**
             * 有订单提示的时候 vuex存变量 true（目的：要在信息页面的时候实时刷新出列表）
             */
            this.$store.commit('setNewOrderTips', true)
            this.playinfo()
            let codeRes = (await setShopTable({ sign: 'table' })).data
            if (codeRes.code == 1) {
              let codeRess = (await orderlogList({sort: {add_time: 'desc'}})).data
              if (codeRess.code==1) {
                  this.$notify({
                  type: 'success',
                  title: '成功',
                  message: `台桌${codeRess.data.list[0].table_no},有新订单，请及时处理！`,
                  duration: 3000
                })
              }
              
            }
          } else {
            /**
             * 轮询到不是产生新订单的时候 vuex存变量false
             * 目的：防止轮询一次就刷新一次列表
             */
            this.$store.commit('setNewOrderTips', false)
          }
          // 有新设置
          if (res.data.data.shop_set_update == 1) {
            if (getToken() === '' || getToken() === undefined || !getToken()) {
            } else {
              let shopMoeld = await getShopById({})
              if (shopMoeld.data.code === 1) {
                let obj = JSON.parse(sessionStorage.getItem('adminInfo'))
                obj.shop = shopMoeld.data.data
                this.$store.commit('setAdminInfo', obj)
                sessionStorage.setItem('adminInfo', JSON.stringify(obj))
                if (this.currentRotuer !== 'home') {
                  this.$router.push({ name: 'home' })
                }
              }
            }
          }
          this.$store.commit('setMonitorList', res.data.data)
        }, 5000)
      }
      if (this.$router.history.current.name === null) clearInterval(this.tiemr)
    },
    playVioServer(info) {
      if (this.adminInfo.shop.is_voice == 1)
        // document.getElementById('vioServer').play()
        if(window.android) {
          window.android.startServiceVoice(JSON.stringify(info))
        }
    }
  },
  watch: {
    $route(to, from) {
      this.currentRotuer = to.name
      if (to.name === 'login') {
        this.bgshow = true
      } else {
        this.bgshow = false
        this.setMonitor()
      }
    },
    allStatus: {
      handler(n, o) {
        this.serverList = n.service.type
      },
      deep: true
    }
  },
  computed: {
    adminInfo() {
      return this.$store.state.adminInfo
    },
    allStatus() {
      return this.$store.state.allStatus
    }
  },
  async created() {
    window.addEventListener('resize', this.screenHeight)
    this.screenHeight()
    if (this.$router.history.current.name === 'login') this.bgshow = true
    else this.bgshow = false
    this.$store.commit('setKeyShow', false)
  },
  destroyed() {
    window.removeEventListener('resize', this.screenHeight)
  },
  async mounted() {
    if (!this.allStatus.service) {
      this.setMonitor()
    } else {
      this.serverList = this.allStatus.service.type
      // this.setMonitor()
    }
    if (this.$router.history.current.name === null)
      clearInterval(this.monitorKey)
  },
  components: { LeftNav }
}
</script>
<style lang="less">
@import url('./assets/less/common.less');
</style>